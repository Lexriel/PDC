#include <stdio.h>
#include <stdlib.h>

/*permet d'indenter une ligne avec "nombre" blancs*/
void indenter(int nombre)
{
    int tmp=1;
    while (tmp <= nombre)
    {
        putchar(' ');
        tmp++;
    }
}

/*permet de modifier le fichier selon le modele défini en tp*/
void modifFile(){
    int c;
    int tmp;
    int indent = 0;
    enum {ETAT_NORMAL,COMMENTAIRE,DEBUT_LIGNE} etat = DEBUT_LIGNE;
    while ((c=getchar()) != EOF)
    {
        switch (etat)
        {
            /*nous sommes en d�but de ligne*/
            case DEBUT_LIGNE:
                switch(c)
                {
                    /*on vient de trouver le premier caractere du commentaire*/
                    case '/':
                        tmp = c;
                        c = getchar();
                        if (c == '*'){
                        /*on vient de trouver un d�but de commentaire, il est donc bien placer en debut de ligne*/
                            indenter(indent);
                            putchar(tmp);
                            putchar(c);
                            etat = COMMENTAIRE;
                        }
                        else
                        {
                        /*sa ne corespond pas a un commentaire, nous sommes donc dans le contexte normal*/
                            indenter(indent);
                            putchar('\n');
                            putchar(tmp);
                            putchar(c);
                            etat = ETAT_NORMAL;
                        }
                    break;
                    /*on trouve une accolade ouvrante en d�but de ligne*/
                    case '{':
                        putchar('\n');
                        indenter(indent);
                        putchar(c);
                        /*on ajoute une indentation*/
                        putchar('\n');
                        indenter(indent);
			indent = indent+4;
                        etat = DEBUT_LIGNE;
                    break;
                    /*on trouve une accolade fermante en d�but de ligne*/
                    case '}':
                        putchar('\n');
			indent = indent-4;
                        indenter(indent);
                        putchar(c);
                        /*on supprime une indentation*/
                        putchar('\n');
                        indenter(indent);
                        etat = DEBUT_LIGNE;
                    break;
                    /*pas d'intentation pour les include etc...*/
                    case '#':
                        putchar(c);
                        etat = ETAT_NORMAL;
                    break;
		    case '\n':
		      break;
                    default:
                        indenter(indent);
                        putchar(c);
                        etat = ETAT_NORMAL;
                    break;
                }
            break;
            /*nous sommes dans un commentaire*/
            case COMMENTAIRE:
                switch(c)
                {
                    /*on trouve une fin de ligne dans le commentaire*/
                    case '\n':
                        /*on ferme le commentaire*/
                        putchar('*');
                        putchar('/');
                        /*passage � la ligne*/
                        putchar('\n');
                        /*on ouvre un autre commentaire en indentant*/
                        indenter(indent);
                        putchar('/');
                        putchar('*');
			putchar(' ');
                    break;
                    /*on trouve une possible fin de commentaire*/
                    case '*':
                        putchar(c);
                        c = getchar();
                        /*c'est effectivement une fin de commentaire*/
                        if (c=='/')
                        {
                            /*on �crit la fin et on passe � la ligne*/
                            putchar(c);
                            putchar('\n');
                            etat = DEBUT_LIGNE;
                        }
                        else
                        {
                            putchar(c);
                        }
                    break;
                    default:
                        /*on ignore tous les types de caract�res*/
                        putchar(c);
                    break;
                }
            break;
            case ETAT_NORMAL:
                switch(c)
                {
                    /*on trouve une accolade ouvrante*/
                    case '{':
                        putchar('\n');
                        indenter(indent);
                        putchar(c);
                        /*on ajoute une indentation*/
                        /*indent = indent + 4;*/
                        putchar('\n');
			indent = indent + 4;
                        etat = DEBUT_LIGNE;
                    break;
                    /*on trouve une accolade fermante*/
                    case '}':
                        putchar('\n');
			indent = indent-4;
                        indenter(indent);
                        putchar(c);
                        /*on supprime une indentation*/
                        putchar('\n');
                        etat = DEBUT_LIGNE;
                    break;
                    case '/':
                        tmp = c;
                        c = getchar();
                        if (c == '*'){
                        /*on vient de trouver un d�but de commentaire*/
                            putchar('\n');
                            indenter(indent);
                            putchar(tmp);
                            putchar(c);
                            etat = COMMENTAIRE;
                        }
                        else
                        {
                        /*sa ne corespond pas a un commentaire, nous sommes donc dans le contexte normal*/
                            putchar(tmp);
                        }
                    break;
		    case '\n':
		      putchar(c);
		      etat = DEBUT_LIGNE;
		    break;
		    default:
		      putchar(c);
		    break;
                }
            break;
        }
        /*on est si le nombre d'accolades ouvrantes et fermantes est identique*/
        /*if (c == EOF){
            if (indent>0){
                fprintf(stderr,"il y a trop d'accolade ouvrante dans le fichier\n");
            }
            else
            {
                if (indent<0){
                    fprintf(stderr,"il y a trop d'accolade fermante dans le fichier\n");
                }
            }
        }*/
    }
}

int main(){
    modifFile();
    exit(EXIT_SUCCESS);
}
