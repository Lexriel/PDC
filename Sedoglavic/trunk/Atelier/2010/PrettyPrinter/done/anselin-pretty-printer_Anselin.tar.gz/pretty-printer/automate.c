#include <stdio.h>
#include <stdlib.h>

/*permet de supprimer les blancs et les tabulations d'un fichier*/
void suppressionBlcTab(){
    int c;
    enum {ETAT_DBT_LIGNE, ETAT_NORMAL} etat = ETAT_DBT_LIGNE;

    while ((c=getchar()) != EOF) {
        switch (etat) {
            case ETAT_DBT_LIGNE:
                switch (c) {
                    case ' ':
                    case '\t':
                        break;
		    case '\n':
			putchar('\n');
			etat = ETAT_DBT_LIGNE;
		      break;
                    default:
                        putchar(c);
                        etat = ETAT_NORMAL;
                        break;
                }
                break;
            case ETAT_NORMAL:
                switch (c) {
                    case '\n':
                        putchar('\n');
                        etat=ETAT_DBT_LIGNE;
                        break;
                    default :
                        putchar(c);
                        break;
                }
        }
    }

    exit(EXIT_SUCCESS);
}

int main(){
  suppressionBlcTab();
  exit(EXIT_SUCCESS);
}
