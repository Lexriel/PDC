#include <stdio.h>
#include <stdlib.h>

enum {ETAT_DBT_LIGNE, ETAT_NORMAL, COMMENTAIRE } etat = ETAT_DBT_LIGNE;
/*enum {COMMENTAIRE, PAS_COMMENTAIRE} etat_commentaire = PAS_COMMENTAIRE;*/

void ajouter_blanc (int indent)
{
  int cpt;
  for (cpt = 0; cpt < (indent*4); cpt++)
    {
      putchar(' ');
    }
}

int main(void)
{

  int niveau_indent = 0;
  char c;
  char carac_tmp;

  while ((c = getchar()) != EOF)
    {  
      switch (etat) {
      case COMMENTAIRE:
	switch(c) {
	case '\n':
	  putchar('*');
	  putchar('/');
	  putchar('\n');
	  ajouter_blanc(niveau_indent);
	  putchar('/');
	  putchar('*');
	  break;
	case '*':
	  carac_tmp = getchar();
	  if (carac_tmp == '/')
	    {
	      putchar('\n');
	      etat = ETAT_DBT_LIGNE;
	    }
	  break;
	default:
	  putchar(c);
	  break;
	}
      case ETAT_DBT_LIGNE:
	switch (c) {
	case ' ':
	  break;
	case '\t':
	  break;
	case '}':
	  niveau_indent--;
	  putchar('\n');
	  ajouter_blanc(niveau_indent);
	  putchar('}');
	  break;
	case '{':
	  putchar('\n');
	  ajouter_blanc(niveau_indent);
	  putchar('{');
	  putchar('\n');
	  niveau_indent++;
	  break;
	case '/':
	  carac_tmp = getchar();
	  if (carac_tmp == '*')
	    {
	      etat = COMMENTAIRE;
	      putchar('\n');
	      ajouter_blanc(niveau_indent);
	      putchar('/');
	      putchar('*');
	    }
	  break;
	default:
	  ajouter_blanc(niveau_indent);
	  putchar(c);
	  etat = ETAT_NORMAL;
	  break;
	}
	break;
      case ETAT_NORMAL:
	switch (c) {
	case '\n': 
	  putchar('\n');
	  etat=ETAT_DBT_LIGNE;
	  break;
	case '{':
	  putchar('\n');
	  ajouter_blanc(niveau_indent);
	  putchar('{');
	  putchar('\n');
	  niveau_indent++;
	  etat=ETAT_DBT_LIGNE;
	  break;
	case '}':
	  niveau_indent--;
	  putchar('\n');
	  ajouter_blanc(niveau_indent);
	  putchar('}');
	  etat=ETAT_DBT_LIGNE;
	  break;
	case ';':
	  putchar(';');
	  carac_tmp = getchar();
	  if (carac_tmp !='\n') 
	    {
	      putchar('\n');
	    } else {
	    putchar(carac_tmp);
	  }
	  etat = ETAT_DBT_LIGNE;
	  break;
	default :
	  putchar(c);
	  break;
	}
      } 
    }

  return EXIT_SUCCESS;
}
