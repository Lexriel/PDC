#include <stdio.h>
#include <stdlib.h>


void tabulation (int n) {

int i=0;
if (n!=0){
while (i<(4*n)){
putchar(' ');
i++;

}
}

}


int main()
{	
	int indent=0;
	int c;	

	/**
	DBT_L-etat debut ligne
	MACRO-etat macro
	DCOM-debut commentaire
	COM-commentaire
	FCOM-fin commentaire
	SCOM- n-autres commentaire apres que dans le 1er commentaire on ait tombe sur '\n'
	NORMAL-etat normal
	PARO-parenthese ouvrante
	PARF-parenthese fermante
	GMET-guillimets
	**/
    	
	enum {MACRO,DBT_L,DCOM,COM,FCOM,SCOM,NORMAL,PARO,PARF,GMET} etat = DBT_L;
    	while ((c=getchar()) != EOF) {
        	switch (etat) {
            		
			case DBT_L :
                		switch (c) {
                    			
                    		case '\t':
                        			break;

				case '{':	
						
						
						
						
						etat=PARO;
						break;

				case '}':
						
						indent--;
											
						etat=PARF;
						break;

				case '#' : putchar(c);
					   etat=MACRO;
						break;

				case '"':
					putchar(c);
					etat=GMET;
					break;

				case ' ':
					break;

				case '/':
					
					etat=DCOM;
					break;
				case '\n':
						putchar('\n');
						
					
						
						etat=DBT_L;

						break;

                    		default:
					tabulation(indent);
                        		putchar(c);
                        		etat = NORMAL;
                        		break;
                		
				}
				break;
                	

		case PARO:
			switch (c) {
				case ' ': break;
				case '\n':tabulation(indent);
					indent++;					
					putchar('{');	
					 putchar('\n');
					
					etat=DBT_L;
					; break;
				



					
				default:
					tabulation(indent);
					putchar('{');
					putchar('\n');
					indent++;
					tabulation(indent);
					putchar(c);
					etat=NORMAL;
					
					break;
				}

			
				break;


		case PARF:
			switch (c){
				case ' ': break;
				case '\n':

						
						indent=indent-1;
						tabulation(indent);
						
						putchar('}');
						putchar('\n');

					
						etat=DBT_L;
				break;
				
				default:indent=indent-1;
					tabulation(indent);
					putchar('}');					
					putchar('\n');
					tabulation(indent);
					putchar(c);
					etat=NORMAL;
					
					break;



				}
				break;

			
			case NORMAL:
				
				switch (c) {
					case '{':
						putchar('\n');
						
						
						
						etat=PARO;
						break;

									
					case '}':
						putchar('\n');
						etat=PARF;
						break;
					

					
					case '\n':
						putchar('\n');
						
						etat=DBT_L;

						
						break;



					case '"' :

						putchar(c);
						etat=GMET;
						break;


					case '/':
						putchar('\n');
						tabulation(indent);
						etat=DCOM;
						break;
					case '*':
						etat=FCOM;	
					
					default:
						putchar(c);
						etat=NORMAL;
						break;

					}
					 
						
			break;

			case DCOM:
				switch (c) {
					case '*':				
						putchar('/');
						putchar(c);
						etat=COM;
						break;
					
					default:putchar(c);
						etat=NORMAL;
						break;

					}
				break;

			
			case SCOM:
				switch (c){
					case ' ': break;

					default:putchar(' ');
						putchar(c);
						etat=COM;
						break;







				} break;

			case COM:
				switch (c) {
					case '*':
						
						etat=FCOM;
						break;
					case '\n':
						
						putchar(' ');
						putchar('*');
						putchar ('/');
						putchar(c);
						tabulation(indent);
						putchar ('/');
						putchar('*');
						etat=SCOM;
						break;
					default:
						putchar(c);
						break;	


					}
			break;



			case FCOM:
				switch (c){
					case '/':putchar('*');
						putchar(c);
						
						etat=NORMAL;
						break;

					default:putchar('*');
						putchar(c);
						etat=COM;
						break;

				}	
				break;


			case MACRO :
				switch (c) {
					case '\n':putchar(c);
						  etat=DBT_L;
						  break;

					default:putchar(c);
						break;
					
					}
			break;

			case GMET:
				switch (c) {
					case '"':putchar(c);
						 etat=NORMAL;
						break;

					default:
						putchar(c);
						break;
					}
			
			break;




		}
	}
    exit(EXIT_SUCCESS);
}

