#include <stdio.h>
#include <stdlib.h>

#define PP 4



int 
main()
{
    int c;
    int i,ident,cpt_acc;

    /* cpt_acc compte les accolades */

    ident=0;
    cpt_acc=0;
    enum {ETAT_DBT_LIGNE, ETAT_NORMAL,ETAT_COMMPOS,ETAT_COMM,ETAT_FIN_COMM } 
    etat = ETAT_DBT_LIGNE;
  
    while ((c=getchar()) != EOF) {
        switch (etat) {
            case ETAT_DBT_LIGNE:
                switch (c) {
		case ' ':
	 	case '\t':
		  break;
		default:
		  for(i=0;i<ident*PP;i++)
		    putchar(' ');
		  putchar(c);
		  etat = ETAT_NORMAL;
		  break;
                }
                break;
            case ETAT_NORMAL:
	      switch (c) {
	      case '\n': 
		etat=ETAT_DBT_LIGNE;
		break;
	      case '{':
		putchar('\n');
		putchar('{');
		putchar('\n');
		ident++;
		etat=ETAT_NORMAL;
		cpt_acc++;
		break;
	      case ';':
		putchar(';');
		putchar('\n');
		etat=ETAT_NORMAL;
		break;
	      case '}':
		putchar('\n');
		putchar('}');
		ident--;
		cpt_acc--;
		etat=ETAT_NORMAL;
		break;
	      case '/':
		putchar('\n');
		putchar('/');
		etat=ETAT_COMMPOS;
		break;
	      default :  
		putchar(c);
		break;
	      }
	      break;
	      
	case ETAT_COMMPOS :
	  switch (c) {
	  case '*':
	    putchar('*');
	    etat = ETAT_COMM;
	    break;
	  default:
	    putchar(c);
	    etat = ETAT_NORMAL;
	    break;
	  }
	  break;
	case ETAT_COMM:
	  switch (c){
	  case '*':
	    putchar('*');
	    etat=ETAT_FIN_COMM;
	    break;
	  case '\n':
	    putchar('*');
	    putchar('/');
	    putchar('\n');
	    putchar('/');
	    putchar('*');
	    break;
	  case ',':
	    putchar(',');
	    break;
	  default:
	    putchar(c);
	    break;
	  }
	  break;
	case ETAT_FIN_COMM:
	  switch (c){
	  case '/':
	    putchar('/');
	    putchar('\n');
	    etat=ETAT_NORMAL;
	    break;
	  default:
	    etat=ETAT_COMM;
	    break;
	  }
	  break;
	}
    }
    if (!cpt_acc){
      exit(EXIT_FAILURE);
    }else	
      exit(EXIT_SUCCESS);
}
