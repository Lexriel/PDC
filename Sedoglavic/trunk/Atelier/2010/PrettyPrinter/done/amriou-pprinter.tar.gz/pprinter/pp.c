#include <stdio.h>
#include <stdlib.h>
#include "config.h"

/* Affiche l'indentation d'une ligne */
void print_indent(unsigned int n)
{
  for (;n>0;n--)
    printf("  ");
}

int main()
{
  /* Différents états de l'automate */
  typedef 
    enum {BEGIN_LINE, 		/* Début de ligne */
	  INST,		/* Début d'instructions et instructions */
	  BEGIN_COM,		/* Début de commentaire */
	  COM,			/* Corps de commentaire */
	  END_COM,		/* Fin de commentaire */
	  END_INST,		/* Fin d'instruction */
	  STRING,			/* Chaine de caractère */
	  DIVIDE,			/* Signe division */
	  OPEN_BRACE,		/* Accolade ouvrante */
	  CLOSE_BRACE,		/* Accolade fermante */
	  OPEN_BRACKET,		/* Parenthèse ouvrante */
	  CLOSE_BRACKET,		/* Parenthèse fermante */
	  SHARP_INST}states;	/* Aucun changement à faire */

  /* Etat de l'automate à un instant */
  states current_state = BEGIN_LINE;
  
  int c;                /* Caractère récupéré sur l'entrée standart */
  int brace_indent = 0;	/* Indentation pour les accolades */
  
  while ((c=getchar()) != EOF)
    {
      switch (current_state){
      
	/* Si l'état courant est sur début de ligne */
      case BEGIN_LINE:
	switch (c){
	case SPACE:             /* On saute les espaces et les tabs */
	case TAB:		/* (On ne les affiches pas) */
	  break;
	  
	case NL:
	  putchar(NL);
	  break;
	case SHARP: 		/* Si #, aucun changements, on affiche tout */
	  putchar(SHARP);
	  current_state=SHARP_INST;
	  break;
	case DIV:		/* Si / en début de ligne */
	  print_indent(brace_indent);
	  putchar(DIV);
	  current_state=DIVIDE;
	  break;
	case ENDINST: 		      /* Si fin d'instruction */
	  print_indent(brace_indent); /* On affiche l'indentation */
	  putchar(ENDINST);	      /* On affiche le signe de fin d'inst */
	  putchar(NL);		      /* On saute une ligne */
	  break;
	case LBRACE:		      /* Si { en début de ligne */
	  print_indent(brace_indent); 
	  putchar(LBRACE);
	  brace_indent++;	      /* On augmente l'indentation */
	  current_state=OPEN_BRACE;   /* On change d'état */
	  break;
	case RBRACE:		/* Si } en début de ligne */
	  brace_indent--;
	  print_indent(brace_indent);
	  putchar(RBRACE);
	  current_state=CLOSE_BRACE;  /* On change d'état */
	  break;
	  
	case LBRACKET:
	  print_indent(brace_indent);
	  putchar(LBRACKET);
	  current_state=OPEN_BRACKET;
	  break;

	default :  		/* Sinon on est dans une instruction */
	  print_indent(brace_indent);
      	  putchar(c);
	  current_state=INST;        /* On change d'état */
	  break;
	}
	break;

	/* Si l'état courant est sur DIVIDE */
      case DIVIDE:
	if (c == STAR)
	  current_state=BEGIN_COM;
	else
	  current_state=INST;
	putchar(c);
	break;

	/* Si l'état courant est sur début de commentaire */
      case BEGIN_COM:
	switch (c){
	case SPACE:		/* On saute les espaces et les tabs */
	case TAB:
	  break;
	default:
	  putchar(SPACE);	/* On ne laisse qu'un espace après le  */
	  putchar(c);
	  current_state=COM;
	  break;
	}
	break;

	/* Si l'état courant est sur commentaire */
      case COM:
	switch (c){
	case NL:
	  putchar(STAR);
	  putchar(DIV);
	  putchar(NL);
	  print_indent(brace_indent);
	  putchar(DIV);
	  putchar(STAR);
	  current_state=BEGIN_COM;
	  break;
	  
	case STAR:
	  putchar(STAR);
	  current_state=END_COM;
	  break;

	default:
	  putchar(c);
	  break;
	}
	break;

	/* Si l'état courant est sur fin de commentaire */
      case END_COM:
	switch (c){
	case DIV:
	  putchar(DIV);
	  putchar(NL);
	  current_state=BEGIN_LINE;
	  break;
	  
	default:
	  putchar(c);
	  current_state=COM;
	  break;
	}
	break;

	/* Si l'état courant est sur début d'instruction */
      case INST:
	switch(c){
	case ENDINST:		/* TODO */
	  putchar(ENDINST);
	  current_state=END_INST;
	  break;
	case DIV:		/* Si il y a un commentaire après l'instruction */
	  putchar(NL);
	  print_indent(brace_indent);
	  putchar(DIV);
	  current_state=DIVIDE;
	  break;
	case NL:
	  putchar(NL);
	  current_state=BEGIN_LINE;
	  break;
	case LBRACE:		/* S'il y a une { après l'instruction */
	  putchar(NL);
	  print_indent(brace_indent);
	  putchar(LBRACE);
	  brace_indent++;
	  current_state=OPEN_BRACE;
	  break;
	case RBRACE:		/* TODO */
	  putchar(NL);
	  brace_indent--;
	  print_indent(brace_indent);
	  putchar(RBRACE);
	  current_state=CLOSE_BRACE;
	  break;
	case LBRACKET:
	  putchar(LBRACKET);
	  current_state=OPEN_BRACKET;
	  break;
	case DQUOTE:		/* Si " alors on est dans une chaine */
	  putchar(DQUOTE);
	  current_state=STRING;
	  break;
	default :		/* Sinon, on affiche */
	  putchar(c);
	  break;
	}
	break;
	
	/* Si l'état courant est sur fin d'instruction */
      case END_INST:
	switch (c){
	case SPACE:
	case NL:
	  putchar(NL);
	  current_state=BEGIN_LINE;	  
	  break;
	case LBRACE:
	  putchar(NL);
	  brace_indent++;
	  print_indent(brace_indent);
	  putchar(LBRACE);
	  current_state=OPEN_BRACE;
	  break;
	case RBRACE:
	  brace_indent--;
	  putchar(NL);
	  print_indent(brace_indent);
	  putchar(RBRACE);
	  current_state=CLOSE_BRACE;
	  break;
	default:
	  putchar(NL);
	  print_indent(brace_indent);
	  putchar(c);
	  current_state=INST;
	}
	break;

	/* Si l'état courant est sur { */
      case OPEN_BRACE:
	switch (c){
	case LBRACE:
	  putchar(NL);
	  print_indent(brace_indent);
	  putchar(LBRACE);
	  brace_indent++;
	  break;
	case NL:
	  putchar(NL);
	  current_state=BEGIN_LINE;
	  break;
	default:
	  putchar(NL);
	  print_indent(brace_indent);
	  putchar(c);
	  current_state=INST;
	  break;
	}

	break;
	
	/* Si état courant est sur accolade fermante */
      case CLOSE_BRACE:
	switch (c){
	case RBRACE:
	  putchar(NL);
	  brace_indent--;
	  print_indent(brace_indent);
	  putchar(RBRACE);
	  break;
	case SPACE:
	case NL:
	  putchar(NL);
	  current_state=BEGIN_LINE;
	  break;

	default:
	  putchar(NL);
	  print_indent(brace_indent);
	  putchar(c);
	  current_state=INST;
	  break;
	}
	break;
	
	/* Si l'état courant est dans une chaine */
      case STRING:
	if (c == DQUOTE){
	  putchar(DQUOTE);
	  current_state=INST;
	}
	else putchar(c);
	break;
	  

	/* Si l'état est dans l'état aucun changement */
      case SHARP_INST:
	switch (c){
	case NL:
	  putchar(NL);
	  current_state=BEGIN_LINE;
	  break;
	
	case SHARP:
	  putchar(NL);
	  putchar(SHARP);
	  break;
          
	default:
	  putchar(c);
	  break;
	}
	break;

      case OPEN_BRACKET:
	if (c == RBRACKET)
	  {
	    putchar(RBRACKET);
	    current_state=INST;
	  }
	else
	  putchar(c);
	break;
      }	/* Fin du switch current_state */
    } /* Fin du while getchar */
  
  exit(EXIT_SUCCESS);
}
