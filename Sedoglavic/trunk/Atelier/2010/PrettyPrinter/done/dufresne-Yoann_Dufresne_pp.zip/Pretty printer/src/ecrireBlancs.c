#include <stdio.h>

void ecrireBlancs (int i) {
  int cpt;
  cpt = 0;

  for (cpt = 0 ; cpt<i ; cpt++)
    putchar('\t');
}
