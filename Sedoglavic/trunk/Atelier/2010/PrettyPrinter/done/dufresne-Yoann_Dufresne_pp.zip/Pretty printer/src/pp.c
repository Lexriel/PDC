#include <stdio.h>
#include <stdlib.h>
#include "ecrireBlancs.c"

int 
main()
{
  /* Les declarations */
  int c;
  int indent;
  int crochets;
  enum mesEtats {ETAT_DBT_LIGNE, ETAT_NORMAL, COMMENTAIRE, OBLIQUE_LU, ETOILE_LUE};
  enum mesEtats etat;

  /* Les initialisations */
  etat = ETAT_DBT_LIGNE;
  indent = 0;
  crochets = 0;
  
  /* Tant que l'on est pas a la fin du fichier, on le partours pour l'indenter corectement */
  while ((c=getchar()) != EOF) {



    switch (etat) {
      /* Etat dans lequel on se trouve lorsque l'on est en debut de ligne */
    case ETAT_DBT_LIGNE:
      switch (c) {
      case ' ':
      case '\t':
	break;

      case '/' :
	ecrireBlancs(indent);
	etat = OBLIQUE_LU;
	break;

      case '\n':
	putchar(c);
	break;

      case '#':
	while ((c != '\n') && (c != EOF)) {
	  putchar(c);
	  c = getchar();
	}
	break;

      case '{' :
	ecrireBlancs(indent);
	indent++;
	putchar(c);
	putchar('\n');
	crochets++;
	break;
	
      case '}':
	indent--;
	ecrireBlancs(indent);
	putchar(c);
	if (crochets > 0) {
	  crochets--;
	} else {
	  fprintf(stderr, "Trop de crochets fermants !\n");
	}
	break;

      case ';' :
	ecrireBlancs(indent);
	putchar(c);
	putchar('\n');
	etat = ETAT_DBT_LIGNE;
	break;

      default:
	ecrireBlancs(indent);
	putchar(c);
	etat = ETAT_NORMAL;
	break;
      }
      break;



      case OBLIQUE_LU:
	/* Etat pour preparer a l'entree dans un commentaire. Si une etoile est lue ensuite, on passera dans un commentaire */
      switch(c) {
      case '*':
	etat = COMMENTAIRE;
	putchar('\n');
	ecrireBlancs(indent);
	putchar('/');
	putchar('*');
	break;

      case '/':
	putchar(c);

      default :
	break;
      }
      break;



    case COMMENTAIRE:
      /* Etat dans lequel on se trouve lorsque l'on est en train de lire un commentaire. Uniquement lorsqu'on a lu un oblique suivis d'une etoile */
      switch (c) {
      case '\n':
	putchar(' ');
	putchar('*');
	putchar('/');
	putchar(c);
	ecrireBlancs(indent);
	putchar('/');
	putchar('*');
	while (((c = getchar()) == ' ') || (c == '\t')) {}
	putchar(' ');
	if (c == '*') {
	  etat = ETOILE_LUE;
	}
	putchar(c);
	break;

      case '*':
	etat = ETOILE_LUE;

      default:
	putchar(c);
	break;
      }
      break;



    case ETOILE_LUE:
      /* Etat de preparation a la sortie de commentaire. Si on lis un oblique, alors on sort de l'etat de commentaire pour retourner dans l'etat normal. */
      switch (c) {
      case '/':
	etat = ETAT_NORMAL;
	putchar(c);
	break;

      case '*':
	putchar(c);
	break;

      default:
	putchar(c);
	etat = COMMENTAIRE;
      }
      break;



    case ETAT_NORMAL:
    /* Etat dans lequel on se trouve lorsqu'on ne se trouve pas en debut de ligne et qu'aucun cas particulier n'a ete releve */
      switch (c) {
      case '/' :
	etat = OBLIQUE_LU;
	break;

      case '\n': 
	putchar('\n');
	etat = ETAT_DBT_LIGNE;
	break;

      case '{' :
	indent++;
	crochets++;
	putchar(c);
	putchar('\n');
	etat = ETAT_DBT_LIGNE;
	break;

      case '}':
	indent--;
	if (crochets > 0) {
	  crochets--;
	} else {
	  fprintf(stderr, "Trop de crochets fermants !\n");
	}
	putchar('\n');
	ecrireBlancs(indent);
	putchar(c);
	etat = ETAT_DBT_LIGNE;
	break;

      case ';' :
	etat = ETAT_DBT_LIGNE;
	putchar(c);
	putchar('\n');
	break;

      default :  
	putchar(c);
	break;
      }
    }
  }
  

  if (crochets != 0) {
    fprintf(stderr, "Programme mal crochete !\n");
  }

  if (etat == COMMENTAIRE) {
    fprintf(stderr, "Commentaire non termine\n");
  }

  exit(EXIT_SUCCESS);
}

