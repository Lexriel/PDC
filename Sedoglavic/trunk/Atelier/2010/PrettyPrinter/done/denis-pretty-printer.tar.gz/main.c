#include <stdio.h>
#include <stdlib.h>


void espaces(int indentation){
    int i = 0;
    if(indentation > 0){
        for(i=0 ; i<indentation ; i++){
            putchar(' ');
            putchar(' ');
            putchar(' ');
            putchar(' ');
        }
    }
}

int main(){
    int c;
    int indentation = 0;
    enum {DBT_LIGNE, NORMAL,STRING ,CPP, DBT_COM, COM , FIN_COM} etat = DBT_LIGNE;

    while ((c=getchar()) != EOF) {
        switch (etat) {
            case DBT_LIGNE:
                switch (c) {
                    case ' ':
                    case '\t':
                    case '\n':
                        break;
                        case '#':
                        etat = CPP;
                        putchar(c);
                        break;

                    case '/':
                        etat = DBT_COM;
                        break;
                    default:
                        espaces(indentation);
                        putchar(c);
                        etat = NORMAL;
                        break;
                }
                break;
            case NORMAL:
                switch (c) {
                    case '{':
                        putchar('\n');
                        espaces(indentation);
                        putchar(c);
                        putchar('\n');
                        indentation++;
                        etat = DBT_LIGNE;
                        break;

                    case '}':
                        putchar('\n');
                        indentation--;
                        espaces(indentation);
                        putchar(c);
                        putchar('\n');
                        etat = DBT_LIGNE;
                        break;
                    case '\n':
                        putchar('\n');
                        etat=DBT_LIGNE;
                        break;

                    case '"':
                        etat = STRING;
                    default :
                        putchar(c);
                        break;
                }
            break;


            case STRING:
                switch (c) {
                    case '"' :
                        etat = NORMAL;
                    default:
                        putchar(c);
                        break;
                }
            break;

             case CPP:
                switch (c) {
                    case '\n' :
                        etat = DBT_LIGNE;
                    default:
                        putchar(c);
                        break;
                }
            break;

            case DBT_COM:
                switch (c) {
                    case '*' :
                        espaces(indentation);
                        putchar(c);
                        etat = COM;
                        break;
                    default:
                        etat = NORMAL;
                        putchar(c);
                        break;
                }
            break;

            case COM:
                switch (c) {
                    case '\n' :
                        putchar('*');
                        putchar('/');
                        putchar('\n');
                        putchar('/');
                        putchar('*');
                        break;
                    case '*':
                        etat = FIN_COM;
                    default:
                        putchar(c);
                        break;
                }
            break;

            case FIN_COM:
                switch (c) {
                    case '/':
                        etat = NORMAL;
                        putchar(c);

                    default:
                        putchar(c);
                        etat = COM;
                        break;
                }
            break;


        }
    }

if(indentation != 0){
    fprintf(stderr,"Erreur d'accolades");
    return EXIT_FAILURE;
}
if(etat == COM || etat == FIN_COM){
    fprintf(stderr,"Erreur de commentaire");
    return EXIT_FAILURE;
}

    return EXIT_SUCCESS;
}
