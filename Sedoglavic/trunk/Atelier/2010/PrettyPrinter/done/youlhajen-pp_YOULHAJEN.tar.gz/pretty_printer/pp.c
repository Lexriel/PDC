// YOULHAJEN Jamal dine
// L3 informatique Groupe 2
//  2010/2011


#include <stdio.h>
#include <stdlib.h>

void ident(int nbEspace);

int main() {
  int nbEspace=0;

  int c;
 // declaration de type enumere des states
  enum {B_L_STATE, NORMAL_STATE, B_T_STATE,E_T_STATE, COMMENT_STATE , INDENT_STATE } state = B_L_STATE;
  
  while ((c=getchar()) != EOF) {
    switch (state) {

    case B_L_STATE:

      switch (c) {
      case ' ':

      case '\t':
	ident(nbEspace);
	state = INDENT_STATE;
	break;

      case '{':
	ident(nbEspace);
	putchar(c);
	putchar('\n');
	nbEspace++;
	break;

     case '}':
       nbEspace--;
       ident(nbEspace);
	putchar(c);
	putchar('\n');
	break;

      case '\n':
	putchar(c);
	
	break;

      case '/' : 
	state = B_T_STATE;
	break;

      default:  
	ident(nbEspace);
	putchar(c);
	state = NORMAL_STATE;
	break;
      }
      break;

    case INDENT_STATE:
      switch (c) {
      case ' ':
	
      case '\t':
	break;

      case '{' :
	putchar(c);
	putchar('\n');
	state= B_L_STATE;
	nbEspace++;
	break;

      case '}' :
	nbEspace--;
	putchar(c);
	putchar('\n');
	state= B_L_STATE;
	break;


      case '/':
	state = B_T_STATE;
	break;

      case '\n' :
	putchar(c);
	state = B_L_STATE;
	break;

      default :
	putchar(c) ;
	state = NORMAL_STATE;
      }
      break;

    case NORMAL_STATE:

      switch (c) {

      case '{':
	putchar('\n');
	ident(nbEspace);
	putchar(c);
	putchar('\n');
	state=B_L_STATE;
	nbEspace++;
	break;

     case '}':
       nbEspace--;
	putchar('\n');
	ident(nbEspace);
	putchar(c);
	putchar('\n');
	state=B_L_STATE;
	break;

      case '/' : 
	state = B_T_STATE;
	break;
	    
      case '*' :
	state = E_T_STATE;
	break;

      case '\n':
	state=B_L_STATE;
	break;
      case ';':
	putchar(c);
	putchar('\n');
	state=B_L_STATE;
	break;

      default :
	putchar(c);
	break;

      }
      break;

    case B_T_STATE:

      switch (c) {
      case '*' :
	putchar('\n');
	ident(nbEspace);
	putchar('/');
	putchar('*');
	state= COMMENT_STATE;
	break;

      default : 
	putchar(c);
	state= NORMAL_STATE;
      }
      break;
	
    case E_T_STATE:

      switch (c) {
      case '/' :
	putchar(c);
	state= B_L_STATE;
	break;

      default :
	putchar(c);
	state = COMMENT_STATE;
      }
      break;

    case COMMENT_STATE:
      switch (c) {

      case '\n' :
	putchar('*');
	putchar('/');
	putchar('\n');
	ident(nbEspace);
	putchar('/');
	putchar('*');
	putchar(' ');
	while ((c=getchar()) == ' ') {}
	putchar(c);
	break;

      case '*' :
	state = E_T_STATE;

      default :
	putchar(c);
      }
      break;
  }
  }
  exit(EXIT_SUCCESS);
  
}

void ident(int nbEspace) {
  int i;
  
  for (i=0; i<nbEspace*4;i++) {
    putchar(' ');
  }
}