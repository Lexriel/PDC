#include <stdio.h>
#include <stdlib.h>

/* fonction qui ajoute un nombre 'indent' de tabulation*/
void indent(int indent){
  int cpt;
  for(cpt=0;cpt<indent;++cpt){
    putchar('\t');
  }
}

/*fonction quand on rencontre une accolade Ouvrante */
void accoladeO(int* ind){
  putchar('\n');
  indent(*ind);
  (*ind)++;
  putchar('{');
  putchar('\n');
}

/*fonction quand on rencontre une accolade Fermante */
void accoladeF(int* ind){
  putchar('\n');
  (*ind)--;
  indent(*ind);	
  putchar('}');
  putchar('\n');
}

int main(){
  int c,ind;
  enum {ETAT_DBT_LIGNE, ETAT_NORMAL, ETAT_PE_COMM, ETAT_COMM, ETAT_PEF_COMM } etat = ETAT_DBT_LIGNE;
  
  ind = 0;
  
  while ((c=getchar()) != EOF) {   
    switch (etat) {
    case ETAT_DBT_LIGNE:
      switch (c) {
      case ' ':
      case '\t':
      case '\n' :
	break;
      case '{' :
	accoladeO(&ind);
	break;
      case '}' :
	accoladeF(&ind);
	break;
      case '/':
	etat = ETAT_PE_COMM;
	break;
      default:
	indent(ind);
	putchar(c);
	etat = ETAT_NORMAL;
	break;
      }
      break;

    case ETAT_NORMAL:

      switch (c) {
      case '\n': 
	putchar(c);
	etat=ETAT_DBT_LIGNE;
	break;
      case '{' :
	accoladeO(&ind);
	etat=ETAT_DBT_LIGNE;
	break;
      case '}' :
	accoladeF(&ind);
	etat=ETAT_DBT_LIGNE;
	break;
      case '/':
	etat = ETAT_PE_COMM;
	break;
      default :  
	putchar(c);
	break;
      }
      break;

    case ETAT_COMM:
      switch(c){
      case '\n':
	putchar('*');
	putchar('/');
	putchar('\n');
	indent(ind);
	putchar('/');
	putchar('*');
	break;
      case '*':
	etat = ETAT_PEF_COMM;
	break;
      default :  
	putchar(c);
	break;
      }
      break;
      
    case ETAT_PE_COMM:
      
      switch(c) {
      case'*':
	putchar('\n');
	indent(ind);
	putchar('/');
	putchar(c);
	etat = ETAT_COMM;
	break;
      default:
	putchar('/');
	putchar(c);
	etat = ETAT_NORMAL;
	break;
      }
      break;

    case ETAT_PEF_COMM:

      switch(c) {
      case'/':
	putchar('*');
	putchar(c);
	putchar('\n');
	etat = ETAT_DBT_LIGNE;
	break;
      default:
	putchar('*');
	putchar(c);
	etat = ETAT_COMM;
	break;
      }
      break;
    }
  }
  
  exit(EXIT_SUCCESS);
}
