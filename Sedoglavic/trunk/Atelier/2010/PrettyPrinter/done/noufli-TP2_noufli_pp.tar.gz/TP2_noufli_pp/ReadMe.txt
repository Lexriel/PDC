Auteur: Noufli Larbi
Le 5 octobre 2010


	La Commande pretty printer qui consiste a bien indenté un programme  a été modéliser du point de vue 

	d'un automate d'où l'énumeration des différents états où l'on peut se trouver lorsque qu'on parcours 
	
	un fichier. Vous trouverez ainsi dans pp.c les commentaires des différentes état que l'on parcours.


	Pour tester la commande il suffit de taper:


		pp < file.c > resulat.c
