/*
  Auteur: Noufli Larbi
  Date: Le 05 octobre 2010

*/



    #include <stdio.h>
    #include <stdlib.h>
    
    #define une_tabulation 4
    
    /*
    La fonction gerer_la_tabulation(int indentation) permet l'indentation de la ligne en fonction 
    de l'indentation courante
    */
    void gerer_la_tabulation(int indentation) {
      int i;
      i=0;
      while (i<indentation*une_tabulation){
	putchar(' ');
	i++;
      }
      
      
    }
    int main() {
      int indentation=0;

      int c;
      /*
      On declare une enumeration d'état dans lequel  peut se trouver la ligne que l'on souhaite 
      indenté
      */
      enum {ETAT_DEBUT_LIGNE, ETAT_NORMAL, ETAT_TEMP_SLACH,ETAT_TEMP_FIN_SLACH, ETAT_COMMENTAIRE , ETAT_INDENTATION } etat = ETAT_DEBUT_LIGNE;
      
      /*
      on parcours l'entrés standard tant qu'on est pas à la fin du fichier
      */
      while ((c=getchar()) != EOF) {
	switch (etat) {

	case ETAT_DEBUT_LIGNE:
      /*
      On switch sur le carractaire courant 
      si on tombe sur un espace on ne fait rien
      si on tombe sur une tabulation on les retirent avec ici gerer_la_tabulation(0)
      
      */
	  switch (c) {
	  case ' ':

	  case '\t':
	    gerer_la_tabulation(indentation);
	    etat = ETAT_INDENTATION;
	    break;
    
	/*
	Si on tombe sur une accolade ouvrante on indente suivant l'indentation courante
	On affiche l'accolade ouvrante 
	on passe à la ligne 
	enfin on incrémente l'indentation courante
	
	*/
	  case '{':
	    gerer_la_tabulation(indentation);
	    putchar(c);
	    putchar('\n');
	    indentation++;
	    break;

	/*
	Si on tombe sur une accolade fermante on decremente l'indentation courante
	on affiche les tabulation
	on affiche l'accolade fermante
	enfin on passe à la ligne
	
	*/
	case '}':
	  indentation--;
	  gerer_la_tabulation(indentation);
	    putchar(c);
	    putchar('\n');
	    break;
	/*
	On affiche les sauts de ligne
	*/
	  case '\n':
	    putchar(c);
	    break;
	  /*
	  Si on tombe sur un / on bascule dans un etat Temporaire appelé ETAT_TEMP_SLACH
	  */
	  case '/' : 
	    etat = ETAT_TEMP_SLACH;
	    break;
	   /*
	   Lors de la premiére analyse si on ne tombe sur aucun cas précedent on gére la tabulation
	   on affiche les carrataires 
	   enfin on passe à un état appelé ETAT_NORMAL
	   */
	  default:  
	    gerer_la_tabulation(indentation);
	    putchar(c);
	    etat = ETAT_NORMAL;
	    break;
	  }
	  break;
	  
	  /*
	  Une fois dans l'etat appelé ETAT_NORMAL on applique les même régle vue précedement
	  */
	  case ETAT_NORMAL:

	  switch (c) {

	  case '{':
	    putchar('\n');
	    gerer_la_tabulation(indentation);
	    putchar(c);
	    putchar('\n');
	    etat=ETAT_DEBUT_LIGNE;
	    indentation++;
	    break;

	case '}':
	  indentation--;
	    putchar('\n');
	    gerer_la_tabulation(indentation);
	    putchar(c);
	    putchar('\n');
	    etat=ETAT_DEBUT_LIGNE;
	    break;

	  case '/' : 
	    etat = ETAT_TEMP_SLACH;
	    break;
		
	  case '*' :
	    etat = ETAT_TEMP_FIN_SLACH;
	    break;

	  case '\n':
	    etat=ETAT_DEBUT_LIGNE;
	    break;
	    /*
	    Lorsque l'on tombe sur un point virgule on l'affiche puis on passe à la ligne
	    */
	  case ';' :
	   
	    putchar(c);
	    etat=ETAT_DEBUT_LIGNE;
	    putchar('\n');
	    break;
	  /*
	  Si on est dans l'état appelé ETAT_NORMAL est que l'on est tombé dans aucun cas de figure ci dessus
	  on affiche le carractaire 
	  */
	  default :
	    putchar(c);
	    break;

	  }
	  break;
	/*
	on définit un etat appelé ETAT_INDENTATION ou l'on applique les même régle que pour l'état ETAT_NORMAL
	*/
	case ETAT_INDENTATION:
	  switch (c) {
	  case ' ':
	    
	  case '\t':
	    break;

	  case '{' :
	    putchar(c);
	    putchar('\n');
	    etat= ETAT_DEBUT_LIGNE;
	    indentation++;
	    break;

	  case '}' :
	    indentation--;
	    putchar(c);
	    putchar('\n');
	    etat= ETAT_DEBUT_LIGNE;
	    break;


	  case '/':
	    etat = ETAT_TEMP_SLACH;
	    break;

	  case '\n' :
	    putchar(c);
	    etat = ETAT_DEBUT_LIGNE;
	    break;

	  default :
	    putchar(c) ;
	    etat = ETAT_NORMAL;
	  }
	  break;
	  
	  /*
	  Lorsqu'on est dans un état appelé ETAT_COMMENTAIRE 
	  */
	  
	  case ETAT_COMMENTAIRE:
	  switch (c) {
	  /*
	  Si on tombe sur un saut de ligne on affiche une étoile
	  on affiche /
	  on passe la lgne 
	  on gére la tabulation
	  on affiche /
	  on affiche une étoile
	  on affiche un espace
	  
	  
	  */
	  case '\n' :
	    putchar('*');
	    putchar('/');
	    putchar('\n');
	    gerer_la_tabulation(indentation);
	    putchar('/');
	    putchar('*');
	    putchar(' ');
	    while ((c=getchar()) == ' ') {/*on ne fait rien*/}
	    putchar(c);
	    break;
	  /*
	  Si on tombe sur une étoile on bascule dans un état appelé ETAT_TEMP_FIN_SLACH
	  
	  */
	  case '*' :
	    etat = ETAT_TEMP_FIN_SLACH;

	  default :
	    putchar(c);
	  }
	  break;
      

	

	case ETAT_TEMP_SLACH:

	  switch (c) {
	  case '*' :
	    putchar('\n');
	    gerer_la_tabulation(indentation);
	    putchar('/');
	    putchar('*');
	    etat= ETAT_COMMENTAIRE;
	    break;
	/*
	Si on ne tombe pas sur une étoile alors on bascule dans l'etat appelé ETAT_NORMAL
	*/
	  default : 
	    putchar(c);
	    etat= ETAT_NORMAL;
	  }
	  break;
	    
	case ETAT_TEMP_FIN_SLACH:
	 /*
	 Si on tombe sur / alors on affiche le carractaire puis on rebascule dans un état ETAT_DEBUT_LIGNE
	 */
	  switch (c) {
	  case '/' :
	    putchar(c);
	    etat= ETAT_DEBUT_LIGNE;
	    break;

	  default :
	    putchar(c);
	    etat = ETAT_COMMENTAIRE;
	  }
	  break;

	
      }
      }
      exit(EXIT_SUCCESS);
      
    }
