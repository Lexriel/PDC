/* Bogdan Gaza - Grupe 2 - S5 Informatique */

#include <stdlib.h>
#include <stdio.h>

#include "pp.h"

int
main(void)
{
  pretty_print();
  return 0;
}
