/* Bogdan Gaza - Grupe 2 - S5 Informatique */

#include <stdio.h>

#include "pp.h"
#include "pp_flags.h"

/* outputs the indent for each line */
void show_indent(int x){
  int i;
  for(i=0;i<x*INDENT_SIZE;i++){
    putchar(' ');
  }  
}

/* treats the START_LINE state */
void start_line(){
  /* when forced = 2 then on the last line it could not find end of comment */
  /* and it outputs the start of comment on this line */
  if(forced == 2){
    show_indent(indent_level);
    putchar('/');
    putchar('*');
    c = ' ';
    /* sets the right flags so that it knows it's inside a comentary */
    state = MIDDLE_LINE;
    buffer_length = 0;
    comment_start = 2;
  }

  switch(c){
    case '\n':
      putchar(c);
    break;
    
    case '#':
      state = DIRECTIVE_LINE;
      putchar(c);
    break;

    /* ignores tabs and spaces - they are counted in the detect_whitespace */
    case '\t':
    case ' ':
    break;
    
    /* start of comment simbol */
    case '/':
      state = MIDDLE_LINE;
      comment_start = 1;
      reserved = 1;
      forced = 1;
    break;
    
    /* start of bracket */
    case '{':
      /* ignore braces if inside of comment */
      if(comment_start != 0) {
        putchar(c);
        break;
      }
      show_indent(indent_level);
      putchar(c);
      indent_level++;
      indented = 1;
      
      nb_brances++;

    break;
    
    /* stop of bracket */
    case '}':
      /* ignore braces if inside of comment */
      if(comment_start != 0) {
        putchar(c);
        break;
      }
      indent_level--;
      show_indent(indent_level);
      putchar(c);
      
      nb_brances++;

    break;
    
    /* none of the above goes to MIDDLE_LINE */
    default:
      show_indent(indent_level);
      state = MIDDLE_LINE;
      putchar(c);
    break;
  }
}

/* treats the lines that begin with # */
void directive_line(){
  switch(c){
    case '\n':
      state = START_LINE;
      putchar(c);
      last_char = '\n';
    break;
    
    default:
      putchar(c);
    break;
  }
}

/* treats the middle of the line case */
void middle_line(){
  switch(c){
    /* if new line encoutered, set state to start line */
    case '\n':
      state = START_LINE;
      putchar(c);
      last_char = '\n';
    break;
    
    /* comment start */
    case '{':
      /* ignore braces if inside of comment */
      if(comment_start != 0 || base_char == '\'') {
        putchar(c);
        break;
      }
      nb_brances++;

      if(old_char != '\n') putchar('\n');
      show_indent(indent_level);
      putchar(c);
      indent_level++;
      indented = 1;
      state = START_LINE;
    break;
    
    /* comment end */
    case '}':
      /* ignore braces if inside of comment */
      if(comment_start != 0 || base_char == '\'') {
        putchar(c);
        break;
      }
      nb_brances++;
      if(old_char != '\n') putchar('\n');
      indent_level--;
      show_indent(indent_level);
      
      putchar(c);
    break;

    /* none of the above */
    default:
      putchar(c);
    break;
  }  
}

/* Detects group of characters that are to be ignored */
/* e.g. a series of tabs and spaces followed by a end of line character *//* of a comment. In this cases we can ignore this characters. */
/* Also it aranges comments and adds begin / end of comentary on a line. */
int detect_whitespace(){
  int i;
  int old_reserved = reserved;
  
  /* if line already indented do not output end of line again */
  if(indented==1){
    indented = 0;
    if(c != '\n') putchar('\n');
  }
  
  /* start line treats whitespaces separately */
  if(state==START_LINE) return 0;
  
  switch(c){
    /* ignore tabs and whitespaces but count them and store them */
    /* into the buffer */
    case ' ':
    case '\t':
      buffer[buffer_length++] = c;
      return 1;
    break;
    
    /* in case of end of line change state, check if end of comment encountered */
    case '\n':
      buffer_length = 0;
      state = START_LINE;
      
      /* if end of comment is not present then close comment */
      if(comment_start == 2){
        
        putchar(' ');
        putchar('*');
        putchar('/');
        
        /* force comment on next line */
        forced = 2;
      }

      putchar('\n');
      last_char = '\n';
      
      if(indented == 1){
        indented = 0;
      }
      
      return 1;
    break;
    
    /* comment start */
    case '/':
      /* checks which state is in */
      if(comment_start == 0){
        /* buffer comment */
        comment_start = 1;
        reserved = 1;
        
        return 1;
      }else if(comment_start == 3){ /* means comment is stopped */
        /* output buffered comment is comment end is present */
        comment_start = 0;
        reserved = 0;
        
        putchar(' ');
        putchar('*');
        putchar('/');
        
        buffer_length = 0;
        forced = 0;

        nb_comments++;
      }
      
      return 1;
    break;
    
    /* second simbol of comment start or end */
    case '*':
      if(comment_start == 1){ /* comment start */
        comment_start = 2;
        reserved = 0;
        
        if(forced != 1) {
          putchar('\n');
          last_char = '\n';
        }
        show_indent(indent_level);
        /* output buffered comment */
        putchar('/');
        putchar('*');

        nb_comments++;
        
        buffer_length = 0;
        forced = 0;
        
        return 1;
      }else if(comment_start==2){ /* comment stop */
        comment_start = 3;
        reserved = 1;
        
        return 1;
      }
      

    break;
    
    default:
      /* check if after comment start the next character is the token */
      if(old_reserved==1 && reserved==1) {
        comment_start = 0;
        reserved = 0;
        putchar('/');
      }
      
      /* check if the comment end is not present force empty buffer */
      if(forced == 2){
        buffer_length = 0;
        putchar(' ');
        forced = 0;
      }

      /* none of the above means that buffer (if exists) must be outputed */
      for(i=0;i<buffer_length;i++) putchar(buffer[i]);
      buffer_length = 0;
    break;
  }
  
  return 0;
}

void
pretty_print(void)
{
  state = START_LINE;
  
  while((c=getchar())!=EOF){

    /* ignores whitespaces everywhere */
    if(detect_whitespace()){
      continue;
    }
    
    /* switch on state of the automata */
    switch(state){
      case START_LINE:
      start_line();
      break;
      
      case DIRECTIVE_LINE:
      directive_line();
      break;
      
      case MIDDLE_LINE:
      middle_line();
      break;
    }
    
    old_char = last_char;
    last_char = '\0';
    /* last char read */
    base_char = c;
  }

  if(nb_brances%2 != 0) fprintf(stderr,"Error number of brances");
  if(nb_comments%2 != 0) fprintf(stderr,"Error number of comments");
}
