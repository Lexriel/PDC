/* Bogdan Gaza - Grupe 2 - S5 Informatique */

/* main header file */
#ifndef PP_H
#define PP_H

void pretty_print(void);

#endif
