/* Bogdan Gaza - Grupe 2 - S5 Informatique */
/* header file for global flag names */

#ifndef PP_FLAGS_H
#define PP_FLAGS_H

#define BUFFER_SIZE 1024
#define INDENT_SIZE 4

/* all states of the automata */
enum state_m {START_LINE, MIDDLE_LINE, DIRECTIVE_LINE};

/* char read each time from stdin */
char c;

/* which state is the automata in */
enum state_m state;
/* indent level for each line */
int indent_level = 0;
/* comment present flag */
int comment_start = 0;

/* first token of comment, check for the next one */
int reserved;

/* white space stack */
char buffer[BUFFER_SIZE];
int buffer_length = 0;

/* force new comment on the next line */
int forced;

/* last end of line char read */
char last_char;
char old_char;

char base_char;

/* if last line is indented or not */
int indented = 0;

/* count the number of accents */
int acc_number;

/* number of braces */
int nb_brances;

/* number of comments */
int nb_comments;

#endif
