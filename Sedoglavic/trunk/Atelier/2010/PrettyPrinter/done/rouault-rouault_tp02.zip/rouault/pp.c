/* Auteur: Xavier Rouault*/
/* Version: 06/10/2010 */


#include <stdio.h>
#include <stdlib.h>
#define indent_default 4

void indenter(int ident)
{
  int i;
  for(i=0; i <= ident; i++)
  {
    putchar(' ');
  }
}



int 
main()
{
  int indent;
  indent = 0;
    int c;
    int tmp;
    enum etat_m{ETAT_DBT_LIGNE, ETAT_NORMAL, ETAT_COM, ETAT_ERR };
    enum etat_m etat;
    etat = ETAT_DBT_LIGNE;
  
    while ((c=getchar()) != EOF)
      {
        switch (etat)
	  {
	  case ETAT_DBT_LIGNE:
	    switch (c) 
	      {
	      case ' ':
	      case '\t':
		break;
	      case '\n':
		putchar(c);
		break;

	      case '/':
		if ((tmp =getchar())== '*')
		  {
		    indenter(indent);
		    putchar(c);
		    putchar(tmp);
		    etat= ETAT_COM;
		  }
		else
		  {
		    putchar(c);
		  }
		break;

	      case '}':
		if((tmp=getchar())== '\'')
		  {
		    putchar(c);
		  }
		else
		  {
		    /* On teste si le caractere suivant est autre chose qu'un \n */
		    /* Si c'est le cas, on inscrit le caractere c puis on passe a la ligne */
		    /* Puis on passe à la ligne et on change l'etat en ETAT_NORMAL */
		    if((tmp = getchar()) != '\n')
		      {
			putchar(c);
			putchar('\n');
			putchar(tmp);
			etat= ETAT_NORMAL;
		      }
		    else
		      {
			putchar(c);
			putchar(tmp);
			indent=indent - 2;
		      }
		  }
		break;

	      
	      case '{':
		if((tmp=getchar())== '\'')
		  {
		    putchar(c);
		  }
		else
		  {
		    /* On teste si le caractere suivant est autre chose qu'un \n */
		    /* Si c'est le cas, on indente et on inscrit le caractere c */
		    /* Puis on passe à la ligne et on change l'etat en ETAT_NORMAL */
		    if((tmp = getchar()) != '\n')
		      {
			indenter(indent);
			putchar(c);
			putchar('\n');
			indent +=2;
			indenter(indent);
			putchar(tmp);
			etat= ETAT_NORMAL;
		      }
		    else
		      {
			indenter(indent);
			putchar(c);
			putchar(tmp);
		      }
		  }
		break;
		
	      default: 
		indenter(indent);
		putchar(c);
		etat = ETAT_NORMAL;
		break;
	      }
	    break;


	  case ETAT_NORMAL:
	    switch (c)
	      {
	      case '\n': 
		putchar(c);
		etat=ETAT_DBT_LIGNE;
		break;
		
	      case '/':
		if ((tmp = getchar())== '*')
		  {
		    putchar('\n');
		    indenter(indent);
		    putchar(c);
		    putchar(tmp);
		    etat= ETAT_COM;
		  }
		else
		  {
		    putchar(c);
		    putchar(tmp);
		  }
		break;

	      case ':':
		putchar(c);
		indent = indent+2;
		etat= ETAT_DBT_LIGNE;
		break;

	      case '*':
		if ((tmp = getchar())== '/')
		  {
		    putchar(c);
		    putchar(tmp);
		    etat= ETAT_DBT_LIGNE;
		  }
		else
		  {
		    putchar(c);
		    putchar(tmp);
		  }
		break; 
		
	      case '#':
		break;
	      
	      case '{':
		if((tmp= getchar())== '\'')
		  {
		    putchar(c);
		    putchar(tmp);
		  }
		else
		  {
		    putchar('\n');
		    indenter(indent);
		    putchar(c);
		    indent= indent + 2;
		    putchar('\n');
		    etat= ETAT_DBT_LIGNE;
		  }
		break;
	
	      case '}':
		if((tmp= getchar())== '\'')
		  {
		    putchar(c);
		    putchar(tmp);
		  }
		else
		  {
		    putchar('\n');
		    indent= indent -2;
		    indenter(indent);
		    putchar(c);
		    putchar('\n');
		    etat= ETAT_DBT_LIGNE;
		  }
		break;
		
	      default :  
		putchar(c);
		break;
	      }
	    break;
	    
	    
	    
	  case ETAT_COM:
	    switch(c)
	      {
	      case '\n': 
		putchar('*');
		putchar('/');
		putchar('\n');
		indenter(indent);
		putchar('/');
		putchar('*');
		break;
	      case '*':
		if ((tmp = getchar())== '/')
		  {
		    putchar(c);
		    putchar(tmp);
		    etat= ETAT_NORMAL;
		  }
		else
		  {
		    putchar(c);
		    putchar(tmp);
		  }
		break;
	      
	      default:
		putchar(c);
		break;
	      }
	    break;
	    
	  case ETAT_ERR:
	    switch(c){
	    default:
	      exit(EXIT_FAILURE);
	      break;
	    }
	    break;
	  }
	
      }
    exit(EXIT_SUCCESS);
    return 0;
}
