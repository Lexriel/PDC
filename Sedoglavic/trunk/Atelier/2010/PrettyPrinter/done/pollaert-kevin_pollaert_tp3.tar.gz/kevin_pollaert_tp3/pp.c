#include <stdio.h>
#include <stdlib.h>

void traitement_indent(int i){
  while (i!=0){
     putchar('\t');
      i--;
    }
}

void traitement_ouvrante(int i){
  putchar('\n');
  traitement_indent(i);
  putchar('{');
  putchar('\n');
}

void traitement_fermante(int i){
  putchar('\n');
  traitement_indent(i);
  putchar('}');
  putchar('\n');
}

int
main()
{
  int c;
  int indentation;

  enum {ETAT_DBT_LIGNE, ETAT_NORMAL} 
  etat = ETAT_DBT_LIGNE;
  indentation = 0;
  while ((c=getchar()) != EOF) 
    {
      switch (etat) 
	{
	case ETAT_DBT_LIGNE:
	  switch (c) 
	    {
	    case ' ':
	    case '\n':
	      break;
	    case '\t':
	      break;
	    case '{':
	      traitement_indent(indentation);
	      indentation++;
	      putchar(c);
	      putchar('\n');
	      break;
	    case '}':
	      indentation--;
	      traitement_indent(indentation);
	      putchar(c);
	      putchar('\n');
	      break;
	    default:
	      traitement_indent(indentation);
	      putchar(c);
	      etat = ETAT_NORMAL;
	      break;
	    }
	  break;
	case ETAT_NORMAL:
	  switch (c) 
	    {
	    case '\t':
	      break;
	    case '{':
	      traitement_ouvrante(indentation);
	      indentation++;
		etat = ETAT_DBT_LIGNE;
	      break;
	    case';':
	      putchar(c);
	      putchar('\n');
	      etat = ETAT_DBT_LIGNE;
	      break;
	    case '}':
	      indentation--;
	      traitement_fermante(indentation);
		etat = ETAT_DBT_LIGNE;
	      break;
	    case '\n':
	      putchar(c);
	      etat = ETAT_DBT_LIGNE;
	      break;
	    default :
	      putchar(c);
	      break;
	    }
	}
      
    }
  exit(EXIT_SUCCESS);
}

