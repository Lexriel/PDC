#include <stdlib.h>
#include <stdio.h>
#include "utils.h"

int main(int argc, char *argv[]) {
	prettyprinter();

	return EXIT_SUCCESS;
}
