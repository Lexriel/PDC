#include <stdio.h>
#include <stdlib.h>

void indentation(int indent) {
	int i;
	int indentation = indent;
	for(i=0;i<indentation;i++)
		printf("\t");
}

void prettyprinter() {
	int c;
	int indentor;
	int retourLigne;
	int debutLigne;
	int debutCom;
	int finCom;
	int com;

	indentor = 0; /* permet de gerer le niveau de l'indentation */
	retourLigne = 0; /* permet de gerer les retours a la ligne */
	debutLigne = 0; /* permet de gerer les '\t' et ' ' en debut de ligne */
	debutCom = 0; /* permer de gerer l'ouverture de commentaire */
	finCom = 0; /* permer de gerer la fermeture de commentaire */
	com = 0; /* permer de savoir si on est dans un commentaire ou non */


	while((c=getchar()) != EOF) {

		if (com) {
			if (finCom) {
				printf("*");
				debutLigne = 0;
				if (c== '/') {
					printf("/\n");
					indentation(indentor);
					com = 0;
					debutLigne = 1;
				}
			}

			switch (c) {
				case '*':
					finCom = 1;
					break;
				case '\n':
					printf(" */\n");
					indentation(indentor);
					printf("/* ");
					debutLigne = 1;
					finCom = 0;
					break;
				case '/':
					if (!finCom) {
						printf("%c",c);
						debutLigne = 0;
					}
					finCom = 0;
					break;
				case '\t':
					if (!debutLigne)
						printf("%c",c);
					break;
				case ' ':
					if (!debutLigne)
						printf("%c",c);
					break;
				default:
					printf("%c",c);
					debutLigne = 0;
					finCom = 0;
					break;
			}
		}

		else {
			if (debutCom) {
				if (c == '*') {
					printf("\n");
					indentation(indentor);
					com = 1;
				}
				printf("/");
				debutLigne = 0;
				debutCom = 0;
			}

			if (retourLigne) {
				if (c != '\n') {
					printf("\n");
				}
				retourLigne--;
				indentation(indentor);
				debutLigne = 1;
			}

			switch (c) {
				case '{':
					printf("\n");
					indentation(indentor);
					indentor++;
					retourLigne++;
					printf("%c",c);
					break;
				case '}':
					printf("\n");
					indentor--;
					indentation(indentor);
					retourLigne++;
					printf("%c",c);
					break;
				case '\n':
					printf("%c",c);
					debutLigne = 1;
					indentation(indentor);
					break;
				case '\t':
					if (!debutLigne)
						printf("%c",c);
					break;
				case ' ':
					if (!debutLigne)
						printf("%c",c);
					break;
				case '/':
					debutCom = 1;
					break;
				default:
					printf("%c",c);
					debutLigne = 0;
					break;
			}
		}









	}
	if (indentor < 0)
		fprintf(stderr, "\nERREUR : Parenthese ouvrante manquante !\n");
	if (indentor > 0)
		fprintf(stderr, "\nERREUR : Parenthese fermante manquante !\n");
	if (com > 0)
		fprintf(stderr, "\nERREUR : commentaire non fermant !\n");
}
