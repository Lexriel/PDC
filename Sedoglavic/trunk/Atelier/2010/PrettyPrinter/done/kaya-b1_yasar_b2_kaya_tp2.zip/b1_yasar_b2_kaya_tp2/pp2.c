
/********************/
/**  Nom 	  : Yasar*/
/**  Prenom : Abdurahman*/
/**      binome1*/
/***/
/**  Nom    : Kaya*/
/**  Prenom : Ulas*/
/**      binome2*/
/***/
/** ERASMUS - 2010*/
/************************/
#include <stdio.h>#include <stdlib.h>

/*fonction qui supprime les blancs*/
int espace(int c)
{
    int res;
    
    if(c==''||c=='\t')
    {
        res=0;
        res=res+espace(c=getchar());
        
        

    }    
    else		res=c;
    return res;

}


/*fonction pour ecrire 4 blancs au debut*/
void tab(int length)
{
    int i;
    
    for(i=0;
    i<length;
    i++)		printf("    ");
    
    

}

int main()
{
    int c;
    
    /*fin = 0 --> etat normal program va continuer a ecrire les caracteres*/
    int fin=0,ouv=0,g_t=0;
    
    /*fin = 1 --> etat fin de la ligne*/
    
    /*fin = 2 --> etat commentaire*/
    while( (c=getchar())!=EOF )
    {
        
        /*fin = 3 --> etat test pour '\n'*/
        if(c==34)			g_t=!g_t;
        if(fin==3 && ouv!=0)
        /*pour le caractere '\n'*/
        c=espace(c);
        
        	if(fin==2&&c=='*')
        {
            
            /*dans une commentaire s'il y a une * ce code va verifier la caractere */
            c=getchar();
            
            /*suivant et si c'est / il va fermer le commentaire*/
            if(c=='/')
            {
                printf("*/");				fin=1;				c=getchar();				g_t=0;			}			else				putchar('*');		}
                if(fin==2&&c=='\n'){
                /*ce code cherche la caractere '\n' dans une commentaire*/
                printf("*/\n");
                tab(ouv);
                printf("
                /*");*/
                /*c=getchar();*/
                /*c=espace(c);*/
                /*}*/
                /*                if(c=='\n'){
                /*s'il y a une caractere '\n' dans lentree ce code va changer ce caractere avec le suivant car encore il y a au moins '\n' */
                c=getchar();
                }                
                
                if(c=='

            }            
            ' && !g_t)
            {
                
                /*controller les accolades fermants*/
                putchar('\n');
                
                ouv--;
                fin=1;
                
                

            }            
            
            if(fin==1)
            {
                
                /*ce code pour les debuts des lignes il supprimme les blancs.. */
                if(c!='
                {
                    ' || c!='\n' )       				putchar('\n');
                    c=espace(c);
                    tab(ouv);
                    fin=0;
                    }                    
                    
                    if(c=='
                    {
                        ' && !g_t)
                        {
                            
                            /*controller les accolades ouvrants*/
                            putchar('\n');
                            tab(ouv);
                            ouv++;
                            fin=1;
                            }                            
                            
                            if(c=='/')
                            {
                                
                                /*ce code verifie la caractere suivant si c'est * il ouvrit une commentaire dans le ligne suivant*/
                                c=getchar();
                                if(c=='*')
                                {
                                    printf("\n");
                                    tab(ouv);
                                    printf("
                                    /*");*/
                                    /*c=getchar();*/
                                    /*c=espace(c);*/
                                    /*fin=2;*/
                                    /*g_t=1;*/
                                    /*}*/
                                    /*else{*/
                                    /*putchar('/');*/
                                    /*}*/
                                    /*}*/
                                    /*		if(c==';' && !g_t)
                                    /*code pour les fins de lignes*/
                                    fin=1;
                                    
                                    putchar(c);
                                    
                                    /*affiche les caracteres qui ne sont pas dans les debuts de lignes*/
                                    
                                    if(c=='\n')
                                    {
                                        tab(ouv);
                                        fin=3;
                                        }                                        
                                        
                                        if(c=='

                                    }                                    
                                    ' && !g_t)
                                    {
                                        tab(ouv);
                                        fin=1;
                                        }                                        
                                        }                                        
                                        
                                        if(ouv&&ouv<0)printf("EXIT_FAILURE:Plusaccoladefermant\n");
                                        if(ouv && ouv>0) printf("EXIT_FAILURE : Moins accolade fermant\n");
                                        if(g_t) printf("EXIT FAILURE : Erreur de commantaires\n");
                                        
                                        return0;

                                    }                                    
                                    �EXIT_FAILURE : Moins accolade fermant
