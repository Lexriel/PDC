int comparInt(const void *a ,const void *b)
{

  if (* (int *) a == * (int *) b)
  {
    return 0;
  }
  else
  {
    if (* (int *)a > * (int *) b)
    {
      return 1;
    }
    else
      return -1;
  }
}

int comparChar(const void *a ,const void *b)
{

  if (* (char *) a == * (char *) b)
  {
    return 0;
  }
  else
  {
    if (* (char *)a >= * (char *) b)
    {
      return 1;
    }
    else
      return -1;
  }
}

int comparLongInt(const void *a ,const void *b)
{

  if (* (long *) a == * (long *) b)
  {
    return 0;
  }
  else
  {
    if (* (long *)a > * (long *) b)
    {
      return 1;
    }
    else
      return -1;
  }
}

int comparShortInt(const void *a ,const void *b)
{

  if (* (short *) a == * (short *) b)
  {
    return 0;
  }
  else
  {
    if (* (float *)a > * (float *) b)
    {
      return 1;
    }
    else
      return -1;
  }
}




