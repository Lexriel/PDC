#include <stdio.h>
#include <stdlib.h>
#include "readl.h"
#include "qs.h"
#include "compar.h"
#include <string.h>
#include "tools.h"

#define MAXLINE 100
#define NMAXCHAR 81

int main(int argc, char *argv[])
{

  /* commande corect
     ./msort   
   */
  if((argc == 1) && (strcmp(argv[0],"./msort") == 0)) 
  {
    static char line[NMAXCHAR];
    int nbLine = 0;
    int nbChar;
    int index;

    while(((nbChar = readl(line)) != EOF))
    {
      if (nbLine > MAXLINE)
	fatal(0,"le nbr de ligne est superieur a MAXLINE\n",EXIT_FAILURE);

      quicksort(line,nbChar,sizeof(char),comparChar);

      for (index = 0; index <  nbChar; index++)
	printf("%c",line[index]);
      printf("%s\n"," ");

      nbLine++;
    }
   
    exit(EXIT_SUCCESS);
  }

  fprintf(stderr,"%s","veuilliez taper une commande correcte :\n");
  fprintf(stderr,"%s","./msort \n");
  exit(EXIT_FAILURE);
}


	  
        
	

 
