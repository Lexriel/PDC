extern void quicksort(void *tab, int nmemb, int size,int (*compar)(const void *,const void *));

