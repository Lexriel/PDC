#include <stdio.h>
#include <stdlib.h>
#include "qsint.h"
#include "qs.h"
#include "compar.h"

#define TABSIZE 1000

int main (void)
{
  int index;
  static int tab[TABSIZE];
  static char tab2[10] = {'s','b','d','x','w','m','z','y','a','i'};
  static int tab3[TABSIZE];
  
  for (index = 0; index < TABSIZE; index++)
    *(tab +index) = rand();

  for (index = 0; index < TABSIZE; index++)
    *(tab3 +index) = rand();

  
  quicksort_int(tab,20);
  
  printf("%s\n", "tri quicksort_int");
  for (index = 0; index <  10; index++)
    printf("%d\n",tab[index]);
  printf("%s\n"," ");
  

  quicksort(tab3,10,sizeof(int),comparInt);
  quicksort(tab2,10,sizeof(char),comparChar); 

  printf("%s\n", "tri quicksort generique sur des entiers");
  for (index = 0; index <  10; index++)
  printf("%d\n",tab3[index]);
  printf("%s\n"," ");

  
  printf("%s\n", "tri quicksort generique sur des caracteres");
  for (index = 0; index <  10; index++)
    printf("%c\n",tab2[index]);
  printf("%s\n"," ");


  exit(EXIT_SUCCESS);
}
