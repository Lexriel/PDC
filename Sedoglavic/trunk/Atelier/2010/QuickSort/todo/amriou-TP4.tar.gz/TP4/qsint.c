#include <stdio.h>
#include <stdlib.h>


void quicksort_int(int tab[], unsigned int size)
{
  int pivot = tab[0];
  int *montant = tab;
  int *descendant = tab + size-1;
  int cpt = 0;

  if(size > 1)
  {
    while (montant !=  descendant)
    {
      while (*montant < pivot)
      {
	montant++;
	cpt++;
      }
      while ((descendant != montant) && (*descendant > pivot))
	descendant--;
      
      if (descendant > montant)	
      {
	int stock = *montant;
	*montant = *descendant;
	*descendant = stock;
      }
    }
     
  quicksort_int(tab,cpt);
  quicksort_int(tab+cpt+1,size-cpt-1);
  } 
}




      
	
