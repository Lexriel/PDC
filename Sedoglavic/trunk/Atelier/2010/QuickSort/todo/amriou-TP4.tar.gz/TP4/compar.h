extern int comparInt(const void *a ,const void *b);


extern int comparChar(const void *a ,const void *b);


extern int comparLongInt(const void *a ,const void *b);

extern int comparShortInt(const void *a ,const void *b);


