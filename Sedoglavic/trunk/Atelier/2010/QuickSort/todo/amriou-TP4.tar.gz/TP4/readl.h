/*
  Lit une ligne sur l'entree standart.
  Cette ligne doit comporter moins de MAXLINE carateres.
  
  Le resultat est retourner dans line.
  Un \0 est ecrit en fin de chaine.

  Le tableau line doit etre de taille au moins MAXLINE+1.

  Retourne le nombre de caractere lu, nos compris le \0 final.
  Retourne EOF si la fin  de fichier et atteinte.
  
  Termine le programme sur une erreur si rencontre d'une ligne de plus
  de MAXLINE  
 */
extern int readl(char line[]);
