#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void quicksort(void *tab, int nmemb, int size,
	       int (*compar)(const void *,const void *))
{
 
  void *montant =  tab;
  char *montantC = montant; 
  char *descendant = montantC + ((nmemb-1) * size);
  char *pivot = malloc(size);
  char *stock = malloc(size);
  
  
  int cpt = 0;

  if(nmemb > 1)
  {
    memcpy(pivot,montant,size);

    while (montantC !=  descendant)
    {
      while ((compar(montantC,pivot) < 0))
      {
	montantC = montantC + size;
	cpt++;
      }
      
      while ((descendant != montantC) && (compar(descendant,pivot) > 0))
	descendant = descendant - size;
      
      if (montantC < descendant)
      {
        memcpy(stock,montantC,size);
        memcpy(montantC,descendant, size);
	memcpy(descendant,stock,size);	
      }
    }  
    free(pivot);
    free(stock);
    quicksort((char *) tab,cpt,size,compar);
    quicksort((char *) tab + ((cpt+1) *size) ,nmemb-cpt-1,size,compar);
  }
}	
