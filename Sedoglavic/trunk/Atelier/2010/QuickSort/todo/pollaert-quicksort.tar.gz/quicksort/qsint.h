#include <stdio.h>
#include <stdlib.h>

#define TABSIZE 1000


void quicksort_int(int tab[], unsigned int size);
