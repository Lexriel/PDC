#include <stdio.h>
#include <stdlib.h>

/* f est la fonction de comparaison d'entiers */
int f(const void *a, const void *b){
  int i = *(int *)a;
  int j = *(int *)b;
  if (i==j) return 0;
  if (i>j) return 1;
  return -1;
}


void affichertab(int tab[], unsigned int taille){
  int i;
  for(i=0;i<taille;++i){
    printf("|%d",tab[i]);
  }
  printf("\n");
}

void quicksort(void * base, int nmemb, int size, int(*compar)(const void*, const void*))
{
  if (nmemb>1){
  char * pivot;
  char * tmp;
  char * min;
  char * max;
  int cpt;

  char buffer[4];
  tmp = &buffer[0];

  pivot = (char*)base;
  min = (pivot + (1*size));
  max = (pivot + ((nmemb -1)*size));

  while (min < max){
    while( f(min,pivot)<0 && min<(pivot+((nmemb-1)*size)) ){ 
      min = (min + (1*size));
    }

    while ( (f(pivot, max)<=0) && (max>pivot) ){
      max = (max - (1*size));
    }

/*echange du min et du max */ 
    if (min>=max){break;}
    
    for (cpt=0; cpt<size; ++cpt  ){
      *(tmp+cpt) = *(min+cpt);
      *(min+cpt) = *(max+cpt);
      *(max+cpt) = *(tmp+cpt);
    }
  }
  
/* echange du pivot et de max */ 

  if (f(pivot,max)>0){
    for (cpt=0; cpt<size; ++cpt  ){
      *(tmp+cpt) = *(pivot+cpt);
      *(pivot+cpt) = *(max+cpt);
      *(max+cpt) = *(tmp+cpt);
    }
  }   
  
  quicksort(pivot, (min - pivot)/size,size,f);
  quicksort(min, nmemb - (((min - (pivot-(1*size)) )/size)-1),size,f);
   
  }
}

int main()
{
  int t[5];
  t[0] = 01;
  t[1] = 36;
  t[2] = 50;
  t[3] = 02;
  t[4] = 14;

   
  affichertab(t,5);
  
  quicksort(t, 5, sizeof(t[0]), f);

  printf("devient:\n");
  affichertab(t,5);
  return 0;
}
