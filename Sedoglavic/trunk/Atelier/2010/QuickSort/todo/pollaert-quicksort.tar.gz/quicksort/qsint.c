#include "qsint.h"


void echanger(int tableau[], int a, int b)
{
    int temp = tableau[a];
    tableau[a] = tableau[b];
    tableau[b] = temp;
}

void affichertab(int tab[], unsigned int taille){
  int i;
  for(i=0;i<taille;++i){
    printf("|%d",tab[i]);
  }
  printf("\n");
}

void quicksort_int(int tab[], unsigned int taille)
{
  if (taille>1){
  int pivot;
  int tmp;
  int * min;
  int * max;

  pivot = tab[0];
  min = (tab + 1);
  max = (tab + (taille -1));

  while (min < max){

    while( (*min < pivot)&& (min<(tab+taille))){
      min = (min + 1);
    }
    while((*max >= pivot)&&( max>tab)){
      max = (max - 1);
    }

    if (min>max){break;}
    
    tmp = *min;
    *min = *max;
    *max = tmp;     

  }

  if (tab[0]>*max){
  tab[0] = *(max);
  *(max) = pivot;  
  }  

  quicksort_int(tab, min - (tab));
  quicksort_int(min, taille - (min - tab));

  }
}

int main()
{
  int t[5];
  t[0] = 52;
  t[1] = 36;
  t[2] = 50;
  t[3] = 01;
  t[4] = 14;
  affichertab(t,5);
  quicksort_int(t, 5);

  printf("\nfin\n");
  affichertab(t,5);
return 0;
}
