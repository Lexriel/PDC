#include "qsint.h"
#include "tools.h"
#define NOMBRE_MAX 100

#define swap(p1,p2,sz){				\
    size_t j;					\
    for (j=0; j<sz; j++){			\
	char ptmp = *(p1+j);			\
	*(p1+j) = *(p2+j);			\
	*(p2+j) = ptmp;				\
      }						\
  }


void printtab(int tab[],int size){
  int i =0;
  for(i = 0;i< size;i++){
    printf("%d-",tab[i]);
  }
      printf("\n");

}

void quicksort_int(int tab[], unsigned int size)
{
    if(size > 1){
        int pivot;
        int montant;
        int descendant;
        int tmp=0;

        pivot = 0;
        montant = 0;
        descendant = size-1;

        while(montant < descendant){

            while(compare(tab[montant],tab[pivot])< 0){
               if(montant == descendant){
                    break;
                }
                montant++;
            }

            while(compare(tab[pivot],tab[descendant]) <= 0){
                if(montant == descendant){
                    break;
                }
                descendant--;
            }

            if(montant == descendant){
                break;
            }

            tmp = tab[montant];
            tab[montant]= tab[descendant];
            tab[descendant] = tmp;
        }
        tmp = tab[pivot];
        tab[pivot] = tab[descendant] ;
        tab[descendant] = tmp;

    quicksort_int(tab,montant);
    quicksort_int(tab+descendant+1,size-descendant-1);

    }
}

/*void quicksort(void *base, int nmemb, int size,int(*compare)(const void *, const void *))
{
    if(nmemb > 1){
        int pivot;
        int montant;
        int descendant;

        pivot = 0;
        montant = 0;
        descendant = nmemb-1;

        while(montant < descendant){

            while(compare(base[montant],base[pivot])< 0){
               if(montant == descendant){
                    break;
                }
                montant++;
            }

            while(compare(base[pivot],base[descendant]) <= 0){
                if(montant == descendant){
                    break;
                }
                descendant--;
            }

            if(montant == descendant){
                break;
            }

            swap(base+(montant*nmemb),base+(descdescendant*nmemb),nmemb);
        }
       swap(base+(pivot*nmemb),base+(descdescendant*nmemb),nmemb);

    quicksort_int(base,montant);
    quicksort_int(base+descendant+1,nmemb-descendant-1);

    }
}
*/
void alea(int tableau[], int size){
  int i,nombre;
  for(i=0;i<size;i++){
    nombre=rand()%NOMBRE_MAX;
    tableau[i]=nombre;
  }
}

int main(int argc, char * argv[])
{

    int tab[100];
    alea(tab,100);
    printtab(tab,100);
    quicksort_int(tab,100);
    printtab(tab,100);

  return EXIT_SUCCESS;
}
