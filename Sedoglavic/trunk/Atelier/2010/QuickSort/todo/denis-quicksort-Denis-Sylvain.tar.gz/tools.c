#include "tools.h"


int compare(int elem1, int elem2)
{
  if (elem1 == elem2)
  {
    return 0;
  }
  if (elem1 > elem2)
  {
    return 1;
  }

  return -1;
}
