#include <stdio.h>
#include <stdlib.h>

void quicksort_int(int tab[], unsigned int size);
void alea(int tableau[], int size);
void quicksort(void *base, int nmemb, int size,int(*compare)(const void *, const void *));

