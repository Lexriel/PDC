Sylvain Denis Grp2

Impl�mentation du quicksort g�n�rique n'a pas pu etre test�, mais est d�fini dans le fichier qsin.c .
Quicksort_int fonctionnel.