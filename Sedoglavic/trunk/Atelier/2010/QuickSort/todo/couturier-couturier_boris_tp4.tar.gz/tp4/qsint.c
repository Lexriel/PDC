#include "qsint.h"

void affiche_tab(int tab[], int size)
{
  int cpt;
  printf("{ ");
  for (cpt = 0; cpt < size; cpt++)
    {
      printf("%d ",tab[cpt]);
    }
  printf("} (indice precedent: %d)", tab[-1]);
}

void quicksort_int(int tab[], unsigned int size)
{
  
  if (size==2)
    {
      
      return ;
    }

  if (size > 1)
    {
      int min = 1;
      int max = size-1;
      int tmp;
      int *pivot = &tab[0];
      int gnaa = 0;

      printf("le pivot est: %d", *pivot);

      while (min < max)
	{
	  printf("----- boucle %d -----\n", gnaa++);
	  while (compare(tab[min], *pivot) < 0)
	    {
	      min++;
	    } 
	  while  (compare(*pivot, tab[max]) <= 0)
	    {
	      max--;
	    }

	  if ((min > max))
	    {
	      printf("switch pivot\n");
	      tmp = tab[max];
	      tab[max] = *pivot;
	      *pivot = tmp;
	    }
	  else
	    {
	      printf("switch  %d et %d\n",tab[min], tab[max]);
	      tmp = tab[min];
	      tab[min] = tab[max];
	      tab[max] = tmp;
	    }
	  affiche_tab(tab, size);
	  printf("\n\n");
	}
      printf("min: %d ; max: %d\n", min, max);  
      printf("\n\n\n\n");   
      /*quicksort_int(tab, max+1);*/
      quicksort_int(tab+max+1, size-min);
    }
}

int main(int argc, char * argv[])
{
  int tab[10];
  /*int i;*/
  
  tab[0] = 3;
  tab[1] = 2;
  tab[2] = 5;
  tab[3] = 4;
  tab[4] = 7;
  tab[5] = 9;
  tab[6] = 1;
  tab[7] = 8;
  tab[8] = 8;
  tab[9] = 2;

  quicksort_int(tab, 10);
  /*for (i = 0; i < 10; i++)
    {
      printf("%d\n", tab[i]);
      }*/
  return EXIT_SUCCESS;
}
