int compare(int elem1, int elem2);
