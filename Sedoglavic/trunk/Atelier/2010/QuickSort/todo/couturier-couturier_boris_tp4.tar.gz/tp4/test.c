#include <stdlib.h>
#include <stdio.h>
#include <time.h>

int main(void)
{
  int i,j ;
  char *c ;
  c = (char *) &i ;
  for(j=0;j<4 ; j++) 
    c[j] =getchar() ;

  srand(time(NULL));
  printf("%d\n",rand());
  return 0;
}
