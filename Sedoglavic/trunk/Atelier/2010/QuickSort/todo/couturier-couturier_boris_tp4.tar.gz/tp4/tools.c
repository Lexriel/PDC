#include "tools.h"


int compare(int elem1, int elem2)
{
  return elem1-elem2;
}
