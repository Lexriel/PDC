#include<stdio.h>
#include<stdlib.h>
#include "qsint.h"

int main()
{
   

   int i = 0;
    srand(time(NULL));
   /* generate random numbers and fill them to the list*/
   for(i = 0; i < MAX_ELEMENTS; i++ ){
       list[i] = rand()%RAND_MAX;
   }
   printf("The list before sorting is:\n");
   printlist(list,MAX_ELEMENTS);
    
   /* sort the list using quicksort*/
   quicksort(list,0,MAX_ELEMENTS-1);
 
   /* print the result*/
   printf("The list after sorting using quicksort algorithm:\n");
   printlist(list,MAX_ELEMENTS); 
return 0;

}

