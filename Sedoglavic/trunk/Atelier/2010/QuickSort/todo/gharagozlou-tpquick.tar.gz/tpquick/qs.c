#include<stdio.h>
#include<stdlib.h>
#include <string.h>



typedef int 
compare_obj_gener
( const void *x , const void *y);


typedef compare_obj_gener *compareur_t;





void
swap( void * x, void * y,int size,int numbre)
{
 void *tmp = calloc(1,numbre);
memcpy((char *)tmp,(char *)x,size*numbre);
memcpy((char *)x,(char *)y,size*numbre);
memcpy((char *)y,(char *)tmp,size*numbre);
 }


void
* choose_pivot(int i,int j,int size,void *base )
{
   return  ((char*)base+((i+j) /2)*size);
}



void 
* donne_dernier_elt_gener
(void *base , int nombre_elt, int size)
{
 /*return &base[nombre_elt-1];*/
  return ((char *)base+nombre_elt*size);
}

/*
int *a;
a[2];
a+sizeof(int)*2

void *a;
a[2]

*/


int
 fct( void * x, void * y)
{
    
   return (x-y);
}


void 
quicksort
( void *base , int number , int size,
               int (*f)(void *,void *))
{
 int cptr, nombre, nouvo_nombre,indice_gauche,indice_droite; 


 void *key, *nouvo_dernier, *nouvo_debut, *nouvo_pivot,* dernier,*debut;


 indice_gauche=0;
 indice_droite=size;
 dernier=donne_dernier_elt_gener(base,number,size);
 debut=base;
   if( indice_gauche<indice_droite)
   {
      nouvo_pivot = choose_pivot(indice_gauche ,indice_droite,size,debut);  /*  calculer un pivot  en tenant compte des de l allocation dynamique */

     /* memcpy((char *)dest,(char *)source,size*nr_elt);*/

      swap(debut,nouvo_pivot,size,number);
      key = debut;
      nouvo_debut = ((char*)debut+indice_gauche*size)+1;
      nouvo_dernier = dernier;


      while(f(nouvo_debut,nouvo_dernier) <=0 )
      {
         while((f(nouvo_debut,dernier) <= 0) && ((*(char *)base+indice_gauche*size)<=( *(key)) )    /* fgfgfggf */
                indice_gauche+=1;
         while((f(nouvo_dernier,debut) >= 0) && (*(char *)base+indice_droite*size)>(*key))
                indice_droite-=1;
         if( f(nouvo_debut,nouvo_dernier) < 0)
                      { 
                         nouvo_nombre=indice_droite-indice_gauche;
                         swap(nouvo_debut,nouvo_dernier,size,nouvo_nombre);
                      }
       }

     /*swap two elements*/
      swap(debut,nouvo_dernier,size,number);
      cptr=0;
      while((f((debut+cptr),nouvo_dernier)!=0){cptr++;}
      nombre=cptr;
      /* recursively sort the lesser list*/
      quicksort(debut,nombre,size,f);
      nouvo_nombre=number-nombre;
      quicksort(nouvo_dernier+1,nouvo_nombre,size,f);
}

