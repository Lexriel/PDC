/* Bogdan Gaza - L3S5 - grupe 2 - Erasmus */
#include <stdlib.h>
#include <stdio.h>
#include "qsint.h"

int main(int argc, char *argv[]){
  int maxsize;
  int *tab;
  int i;

  /* check argument */
  if(argc<2){
    printf("Usage: ./qsint_test MAXSIZE \nWhere size of the integer array. SIZE < 10**6 \nBy default MAXSIZE = 1000\n");
    /* set default size */
    maxsize = 1000;
  }else{
    /* set maxsize to argument */
    maxsize = atoi(argv[1]);
  }

  /* alocate array */
  tab = (int *)calloc(maxsize,sizeof(int));

  /* populate array with random data */
  populate(tab,maxsize);

  /* sort array */
  quicksort_int(tab,maxsize-1);

  /* show array */
  for(i=0;i<maxsize;i++){
    printf("%d ",tab[i]);
  }

  printf("\n");

  return 0;
}
