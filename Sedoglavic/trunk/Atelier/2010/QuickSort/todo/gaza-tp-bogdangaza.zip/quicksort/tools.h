#ifndef READL_H
#define READL_H

#define MAXLINE 1024

extern int readl(char []);

#endif
