#include <stdlib.h>
#include <time.h>

#define TABSIZE 1000

void populate(int *,int);
void quicksort_int(int *,int);

