/* Bogdan Gaza - groupe 2 - L3S5 - Erasmus */
#include <string.h>
#include <stdio.h>
#include "qs.h"

/* sort function */
void quicksort(void *base, int nmemb, int size, int(*compar)(const void *, const void *)){
  int old_size = size;

  int left = 0;
  int right = size;

  /* alocate temporary buffer */
  void *tmp = calloc(1,nmemb);

  /* alocate pivot */
  void *pivot =calloc(1,nmemb);

  /* copy pivot */
  memcpy((char *)pivot,(char *)((char *)base + nmemb*(size/2)),1024);

  while(left <= right){
    /* move left pointer */
    while(compar((char *)base + left * nmemb,pivot) < 0) {
      left++;
    }
    /* move right pointer */
    while(compar(pivot,(char *)base + right * nmemb) < 0){
      right--;
    }

    /* swap */
    if(left <= right){
      memcpy((char *)tmp,(char *)((char *)base + left * nmemb),nmemb);
      memcpy((char *)((char *)base + left*nmemb),(char *)((char *)base + right*nmemb),nmemb);
      memcpy((char *)((char *)base + right * nmemb),(char *)tmp,nmemb);

      left++;
      right--;
    }
  }
  /* recursion */
  if(0 < right) quicksort(base,nmemb,right,compar);
  if(left < old_size) quicksort((char *)base + left*nmemb,nmemb,old_size-left,compar);
}
