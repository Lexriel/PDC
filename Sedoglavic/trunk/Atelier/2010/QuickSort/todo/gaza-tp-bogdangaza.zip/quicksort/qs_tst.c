/* Bogdan Gaza - L3S5 - grupe 2 - Erasmus */
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "qs.h"

/* compare function */
int compare(const void *a, const void *b){
  if(*(int *)a < *(int *)b) return -1;
  else if(*(int *)a > *(int *)b) return 1;

  return 0;
}


int main(int argc, char *argv[]){
  int maxsize;
  int *tab;
  int i;
  int seed;

  /* check argument */
  if(argc<2){
    printf("Usage: ./qsint_test MAXSIZE \nWhere size of the integer array. SIZE < 10**6 \nBy default MAXSIZE = 1000\n");
    /* set default size */
    maxsize = 1000;
  }else{
    /* set maxsize to argument */
    maxsize = atoi(argv[1]);
  }

  /* alocate array */
  tab = (int *)calloc(maxsize,sizeof(int));

  /* populate array with random data */
  seed = time(NULL);
  srand(seed);
  for(i=0;i<maxsize;i++){
    tab[i] = rand() % (10 * maxsize);
  }

  for(i=0;i<maxsize;i++){
    printf("%d ",tab[i]);
  }

  printf("\n");


  /* sort array */
  quicksort(tab,sizeof(int),maxsize-1,compare);

  /* show array */
  for(i=0;i<maxsize;i++){
    printf("%d ",tab[i]);
  }

  printf("\n");

  return 0;
}
