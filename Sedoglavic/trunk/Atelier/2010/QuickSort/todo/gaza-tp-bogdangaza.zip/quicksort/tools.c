/* Bogdan Gaza - groupe 2 - L3S5 - Erasmus */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tools.h"

int readl(char line[]){
  int len;
  if(fgets(line,1024,stdin)==NULL) return EOF;
  else{
    if((len=strlen(line) > MAXLINE)){
      return -1;
    }else {
      len = strlen(line);
      if(line[len-1]=='\n') line[len-1]='\0';
      return strlen(line);
    }
  }
}
