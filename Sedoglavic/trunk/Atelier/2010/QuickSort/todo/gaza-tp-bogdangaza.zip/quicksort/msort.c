/* Bogdan Gaza - groupe 2 - L3S5 - Erasmus */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "tools.h"
#include "qs.h"

#define NMAXLINE 1024
#define NMAXCHAR 1024

/* compare function */
int compare(const void *a, const void *b){
  int t = strcmp((char *)a,(char *)b);
  return t;
}

int main(int argc,char *argv[]){

  char line[NMAXLINE+1][NMAXCHAR];
  int index=0;
  int i=0;

  /* read lines in buffer */
  while(readl(line[index++]) != EOF){

    if(index>NMAXLINE+1){
      printf("Too many lines to sort. Existing\n");
    } 
  }

  /* sort them */
  quicksort(line,NMAXCHAR,index-1,compare);

  /* show array */
  for(i=0;i<index;i++){
    printf("%s \n",line[i]);
  }

  return 0;
}
