/* Bogdan Gaza - groupe 2 - L3S5 - Erasmus */
#include "qsint.h"
#include <string.h>
#include <stdio.h>

/* random populate function */
void populate(int *tab,int size){
  int i;

  int seed = time(NULL);
  srand(seed);

  for(i=0;i<size;i++){
    tab[i] = rand() % (10 * size);
  }
}

/* sort array */
void quicksort_int(int *tab, int size){
  int old_size = size; /* keep old size */

  int left = 0;
  int right = size;

  int tmp;
  int pivot = tab[size/2];

  while(left <= right){
    while(tab[left] < pivot){
      left++;
    }
    while(pivot < tab[right]){
      right--;
    }

    if(left<=right){
      tmp = tab[left];
      tab[left]=tab[right];
      tab[right]=tmp;
      left++;
      right--;
    }

  }

  if(0 < right) quicksort_int(tab,right);
  if(left < old_size) quicksort_int(tab+left,old_size-left);
}
