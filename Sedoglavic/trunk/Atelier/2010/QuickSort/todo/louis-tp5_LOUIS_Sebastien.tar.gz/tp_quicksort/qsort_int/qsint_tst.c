#include "qsint.h"
 
int
main
(void)
{ 
  int tab[TABSIZE],i;
  gen_tab_alea(tab);
  quicksort_int(tab,TABSIZE);
  printf("apres tri : ");
  for(i=0;i<TABSIZE;i++)
    printf("%d ",tab[i]);
  printf("\n");
  return 0;
}
