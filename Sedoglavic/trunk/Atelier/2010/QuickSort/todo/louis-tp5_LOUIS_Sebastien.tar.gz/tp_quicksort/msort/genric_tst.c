#include "qs.h"
#include <string.h>
#include <stdio.h>

int
main
(void)
{
  int i;
  char *tab[4]={"abzn", "abjhlnvkwln", "zzz", "azerty"};
  quicksort(tab, 4,sizeof(tab), comparer);
  for (i=0; i<4;i++)
    printf("%s", tab[i]);
  return 0;
}

int 
comparer
(const void *s1, const void*s2)
{
  return strcmp((char*)s1,(char*)s2);
}


