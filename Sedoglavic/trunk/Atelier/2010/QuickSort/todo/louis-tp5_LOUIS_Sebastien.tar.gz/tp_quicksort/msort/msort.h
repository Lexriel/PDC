#include "qs.h"
#define NMAXLINE 50
#define NMAXCHAR 81


int remplissage (char **);

void affichage(char **, int );

int readl (char *,int );

int comparer (const void * ,const  void * );
