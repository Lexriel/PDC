#include "msort.h"
#include <string.h>

int
main
(void)
{
  int nmembres,size;
  char *tab[NMAXLINE];
  nmembres = remplissage(tab);
  size = sizeof(tab[0]);
  quicksort(tab, nmembres, size, comparer);
  affichage(tab,nmembres);
  return 0;
}




