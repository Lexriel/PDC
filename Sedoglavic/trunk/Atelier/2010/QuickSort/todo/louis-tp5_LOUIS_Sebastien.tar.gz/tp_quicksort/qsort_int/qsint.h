#include <stdio.h>
#include <stdlib.h>
#define TABSIZE 20
 
void gen_tab_alea(int tab[]);
int f(int a, int b);
void echanger(int *a,int *b);
void quicksort_int(int tab[], unsigned int size);
