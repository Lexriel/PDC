#include "qsint.h"
 
void 
gen_tab_alea
(int tab[])
{
  int i;
  for (i=0;i<TABSIZE;i++)
    tab[i]=rand();
}



int 
f
(int a, int b)
{
  return a-b; 
}


void
echanger
(int *a,int *b)
{
  int temp;
  temp=*b;
  *b=*a;
  *a=temp;
}

