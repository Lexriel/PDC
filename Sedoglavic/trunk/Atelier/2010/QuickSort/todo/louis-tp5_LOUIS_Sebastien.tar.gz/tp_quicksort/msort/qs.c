#include "qs.h"

void 
quicksort
(void *base, int nmemb, int size,int (*compar) (const void *, const void *))
{
  unsigned int pivot, montant, descendant, boucle;
  
  if (nmemb==2){
    if (compar(base,(base+size))>0)
      echanger(base,(base+size),size);
  }
  else if (nmemb>2)
    {
      boucle=1;
      pivot = 0;
      montant= size;
      descendant=(nmemb-1)*size;
      while(boucle){
	for(; ((*compar)(base+montant,base+pivot)<0) && (montant<descendant); montant+=size)
	  ;
	for(;( (*compar)(base+pivot,base+descendant)<=0)&&(pivot<descendant);descendant-=size)
	  ;
	
	if (montant<descendant)
	  echanger(base+montant,base+descendant,size);
	else 
	  boucle=0;
      } 
      echanger(base+pivot,base+descendant,size);
      quicksort(base,descendant,size, compar);
      quicksort(base+descendant+size,nmemb-descendant-1,size,compar);
    }
}
/*
 *Le compilateur emmet un warning (traité en erreur grace a -Werror car le passage des poiteurs, qui sont de type void*,
 * lui pose probleme, le castage etant fait lors du traitement de compar
 * je n'ai pas réussi à trouver la sollution à ce probleme.
 */
