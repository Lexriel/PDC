#include <stdio.h>
#include <stdlib.h>
#include "msort.h"

/*
 *echange les ojets de taille size, poités ar a et par b
 */
void
echanger
(void * a, void * b, int size)
{
  void * temp;
  temp=malloc(size);
  *temp=*a;
  *a=*b;
}

/*
 *remplit le tableau avec les lignes de stdin
 */
int
remplissage
(char **tab)
{
  int i;
  i=0;
  while((readl(tab[i++],NMAXLINE)!=EOF)&&(i<=NMAXLINE))
    ;
  return i-1;
}


/*
 *affiche le contenu du tableau de chanes de caracteres
 */
void
affichage
(char *tab[], int nb)
{
  int i,j;
  for (i=0; i<nb;i++)
	printf("%s\n",tab[i]);
}


/*
 *le compar pour les chaines de caracteres
 */
int
comparer 
(void * m1, void * m2)
{
  char *s1, *s2;
  s1=(char *) m1;
  s2=(char*) m2;
  return strcmp(s1,s2);
}

/*
 *lit une ligne (code du tp mcolrm modifié pour ne pas utiliser de maccro
 */
int
readl
(char line[],int max)
{
  int i,c;
  i=0;
  while ((i<max)&&((c=getchar())!=EOF)&&(c!='\n')){
    line[i++]malloc(sizeof(char));
    line[i]=c;
  }
  line[i]=c;
  if ((line[i]!='\n')&&(line[i]!=EOF))
    fprintf(stderr,"trop de caracteres\n");
  else
    line[i]='\0';
  if (line[i-1]==EOF)
    return EOF;
  else
    return i-1;
}

