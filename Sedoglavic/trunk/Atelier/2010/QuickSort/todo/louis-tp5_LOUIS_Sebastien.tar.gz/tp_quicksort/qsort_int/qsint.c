#include "qsint.h"


void 
quicksort_int
(int tab[], unsigned int size)
{
  unsigned int pivot, montant, descendant, boucle;


  if (size==2){
    if (f(tab[0],tab[1])>0)
      echanger(&tab[0],&tab[1]);
  }
  else if (size>2)
    {
      boucle=1;
      pivot = 0;
      montant= 1;
      descendant=size-1;
      while(boucle){
	for(; (f(tab[montant],tab[pivot])<0) && (montant<descendant); montant++)
	  ;
	for(;( f(tab[pivot],tab[descendant])<=0)&&(pivot<descendant);descendant--)
	  ;

	if (montant<descendant)
	  echanger(&tab[montant],&tab[descendant]);
	else 
	  boucle=0;
       } 
      echanger(&tab[pivot],&tab[descendant]);
      quicksort_int(tab,descendant);
      quicksort_int(&tab[descendant+1],size-descendant-1);
    }
}
