
void echanger (void * a, void * b, int size);
void quicksort(void *base, int nmemb, int size, int(*compar)(const void *, const void *));
int comparer (const void *, const void *);
