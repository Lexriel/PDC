/*Dufour Et Laraki*/
#include <stdio.h>
#include <stdlib.h>

#define TABSIZE 10

void initialiserTab(int tab[]) {
  int i;
  int z;
  z=TABSIZE;
  for (i=0;i<z;i++) {
    tab[i]=rand();
  }
}

void initialiserTabu(int tab[]) {
  int i;
  int z;
  tab[0]=0;
  tab[1]=5;
    tab[2]=7;
      tab[3]=3;
        tab[4]=9;
	  tab[5]=4;
	    tab[6]=500;
	      tab[7]=25;
	        tab[8]=45;
		  tab[9]=5;

  }






int 
f(int x,int y)
{       int z=0;
	z=x-y;
	return z;
}


void echanger(int tab[],int x,int y){
int temp=tab[x];
tab[x]=tab[y];
tab[y]=temp;
}

int partitioner(int tab[],int premier,int dernier,int pivot) {
      echanger(tab,pivot,dernier);
      int j=premier;
      int i;
      for (i=premier;i<dernier-1;i++) {
	 if (tab[i]<=tab[dernier]) {
	   echanger(tab,i,j);
	   j++;
	 }
      }
      echanger (tab,dernier,j);
      return j;
}

void afficherTab(int tab[]){
  int i;
  for (i=0;i<TABSIZE;i++) {
  printf("%i | ",tab[i]);
  }
}

void traiterTab(int tab[],int premier,int dernier) {
  if (premier<dernier) {
    int pivot=premier;
    pivot =partitioner(tab,premier,dernier,pivot);
    printf("Apres partition ");
    afficherTab(tab);
    printf("\n");
    traiterTab(tab,premier,pivot-1);
    printf("Apres traitement1 ");
    afficherTab(tab);
    printf("\n");
    traiterTab(tab,pivot+1,dernier);
     printf("Apres traitement2 ");
    afficherTab(tab);
    printf("\n");
  }
}




int 
main()
{
int line[TABSIZE];
initialiserTabu(line);
int z=TABSIZE;
int i=0;
printf("\n");
for (i=0;i<z;i++) {
  printf("%i | ",line[i]);
}
printf("\n");
printf("Apres Tri on obtient\n");
traiterTab(line,0,TABSIZE);
for (i=0;i<z;i++) {
  printf("%i | ",line[i]);
}
printf("\n");
return 0;
}

