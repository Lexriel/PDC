#include <stdlib.h>
#include <stdio.h>
#include "qsint.h"


int main (){
  int tab[TABSIZE];
   initialiser(tab,TABSIZE);
   print_tab(tab,TABSIZE);
   printf("\n" );
   quicksort_int(tab,TABSIZE);
   print_tab(tab,TABSIZE);
   printf("\n");
   exit(EXIT_SUCCESS);
 }
