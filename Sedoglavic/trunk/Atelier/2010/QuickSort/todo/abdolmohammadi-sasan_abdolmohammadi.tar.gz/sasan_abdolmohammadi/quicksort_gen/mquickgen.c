#include <stdio.h>
#include <stdlib.h>
#define TABSIZE 6

/* Remplit un tableau tab d'une taille size avec des chiffres aleatoires */
void aleatoire(int tab[], int size){
	int i;

	for (i = 0; i<size; i++){
		tab[i] = rand();
	}
return;
}


/* Affiche la tableau tab d'une taille size */
void affiche(int tab[], int size){
	int i;

	for (i = 0; i<size; i++) {
		printf("%d : %d \n",i,tab[i]);
	}
}


/* Affiche la tableau tab de char, d'une taille size */
void afficheChar(char tab[], int size){
	int i;

	for (i = 0; i<size; i++) {
		printf("%d : %c \n",i,tab[i]);
	}
}


/* Permet d'echanger deux valeurs d'un tableau de type void*, en precisant le taille du type des elements du tableau */
void swap(const void* a, const void* b, int sizeoftype) {
	char tmp;
	int i =0;
	for(i=0;i<sizeoftype;i++){
		tmp = *((char *)a) ;
		*((char *) a) = *((char *)b) ;
		*((char *) b) = tmp ;
		a=(void *)(1+(char *) a) ;
		b=(void *)(1+(char *) b) ;
	}
}


/* Partitionnenement d'un tableau de type void, nmemb le nombre de case, sizeoftype la taille
du type, et compar un pointeur de fonction qui indique la fonction de tri */
void partitionner (void* tab, int nmemb, int *half,int sizeoftype, int(*compar)(const void *, const void *)){
	*half = 0;
	void * pivot = tab;
	int pivot1 = *(int*)tab;
	int montant = 0;
	int descendant = nmemb-1;
	int i = 0;
	int diff;
	char tmp;
	char tmp2;

	while (1) {
		while (((diff = compar(tab+(montant*sizeoftype),&pivot1))>0) && (montant < nmemb))
			montant++;
		while (((diff = compar(tab+(descendant*sizeoftype),&pivot1))<0) && (descendant >= 0))
			descendant--;
		if (montant == descendant) 
			break;
		else {	
			swap(tab+(montant*sizeoftype),tab+(descendant*sizeoftype),sizeoftype);
			}
		}
	*half = descendant;
	return ;
}


/* Le quicksort generique */
void quicksort (void *tab, int nmemb, int sizeoftype, int(*compar)(const void *, const void *)) {
	int montant ;
	int descendant ;
	montant = 1 ;
	descendant = nmemb-1 ;

	if (nmemb <= 1)
	return ;

	while (1){
		while ((compar(tab+(montant*sizeoftype),tab)>0) && (montant < nmemb))
			montant++;

		while ((compar(tab+(descendant*sizeoftype),tab)<0) && (descendant >= 0))
		descendant--;

		if (montant >= descendant) 
		break;

		swap(tab+(montant*sizeoftype),tab+(descendant*sizeoftype),sizeoftype);
}
  
swap(tab,tab+(descendant*sizeoftype),sizeoftype);
  
quicksort(tab,descendant,sizeoftype,compar);

quicksort((tab+(descendant*sizeoftype)+sizeoftype),
	    nmemb-descendant-1,sizeoftype,compar);
}


/* Fonction de comparaison du type char (ordre alphabetique */
int compareChar(const void *a, const void *b) {
	return ((int)(*(char*)b)) - ((int)(*(char*)a));
}

/* Fonction de comparaison du type int (croissant) */
int compareInt(const void *a, const void *b) {
	return (*(int*)b) - (*(int*)a);
}



void parcours(void * tab, int sizeoftype, int nb) {
int i = 0;

for (i = 0; i< nb; i++) {
	printf("%p\n", tab+(i*sizeoftype));
}
}


/* Pour tester */
int main (void) {
	char tab[TABSIZE] = {'M','m','z','D','p','a'};
	/*int tab[TABSIZE] = {3,4,1,8,6,2};*/

	int (*compare)(const void *, const void *) = &compareChar;
	/*int (*compare)(const void *, const void *) = &compareInt;*/

	/* Sur tableau de char */
	printf("Avant :\n");
	afficheChar(tab,TABSIZE);
	quicksort(tab, TABSIZE, sizeof(char), compare);

	printf("Apres :\n");
	afficheChar(tab,TABSIZE);

	/* Sur tableau d'entier 
	aleatoire(tab,TABSIZE);*/
	
	/*printf("Avant :\n");
	affiche(tab, TABSIZE);
	quicksort(tab, TABSIZE, sizeof(int), compare);
	printf("Apres :\n");
	affiche(tab, TABSIZE);*/

return 0;
}
