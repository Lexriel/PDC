#include <stdio.h>
#include <stdlib.h>
#define TABSIZE 1000

/* Remplit un tableau tab d'une taille size avec des chiffres aleatoires */
void aleatoire(int tab[], int size){
	int i;

	for (i = 0; i<size; i++){
		tab[i] = rand();
	}
return;
}


/* Affiche la tableau tab d'une taille size */
void affiche(int tab[], int size){
	int i;

	for (i = 0; i<size; i++) {
		printf("%d : %d \n",i,tab[i]);
	}
}


/* Permet de partitionner le tableau tab d'une taille size, et modifie le pointeur half qui est la moitié du tableau */
void partitionner (int tab[], int size, int *half){
	*half = 0;
	int pivot = tab[0];
	int montant = 0;
	int descendant = size-1;
	int tmp;
	
	while (1) {
		while ((tab[montant] < pivot) && (montant < size))
			montant++;
		while ((tab[descendant] > pivot) && (descendant >= 0))
			descendant--;
		if (montant == descendant) 
			break;
		else {	
			tmp = tab[montant];
			tab[montant] = tab[descendant];
			tab[descendant] = tmp;
		}
	}
	*half = descendant;
	return ;
}


/* Permet de trier un tableau selon le principe du qicksort */
void quicksort_int(int tab[], unsigned int size) {
	int half; 
	int *half_p = &half;

	if (size <= 1) {
		return ;
	} else {
		partitionner(tab,size,half_p);
		quicksort_int(tab,half);
		quicksort_int(&tab[half+1],size-half-1);
	}

}


/* Pour tester */
int main (void) {
	int tab[TABSIZE];

	/*Remplissage aleatoire du tableau*/
	aleatoire(tab,TABSIZE);
	affiche(tab,TABSIZE);
	
	/*Quicksort du tableau*/
	quicksort_int(tab,TABSIZE);
	affiche(tab,TABSIZE);
return 0;
}
