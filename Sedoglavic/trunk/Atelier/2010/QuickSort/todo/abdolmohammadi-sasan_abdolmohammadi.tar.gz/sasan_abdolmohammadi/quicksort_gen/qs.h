#define TABSIZE 20
/*extern void initialiser(int *tab, unsigned int taille);*/
extern void quicksort_gen(int *tab, unsigned int size);
/*extern int f(int x, int y);*/
extern int compar(const void *, const void *);
extern void quicksort(void *base, int nmemb, int size,int(*compar)(const void *, const void *));
extern void echanger(int *tab, unsigned int indice1, unsigned int indice2);
extern void print_tab(int *tab,int size);
