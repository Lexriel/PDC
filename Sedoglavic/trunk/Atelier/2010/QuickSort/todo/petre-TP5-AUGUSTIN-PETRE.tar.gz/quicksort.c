#include <stdlib.h>
#include <stdio.h>


int f(int a,int b){
	if (a==b) return 0;
	if (a<b) return (-1);
	if (a>b) return 1;
	
			

return 0;	
}



void echanger(int t[],int a,int b){

	int stock;
	stock=t[a];
	t[a]=t[b];
	t[b]=stock;




}

int droit(int t[],int size,int indicedepart,int indiceechangegauche ,int indicepivot);

int gauche(int t[],int size,int indicedepart,int indicedebutdroit ,int indicepivot){
	int debut,nindicepivot;
	
		debut=indicedepart;		
		while(f(t[debut],t[indicepivot])==(-1) ){
		debut++;
		}
		
		
	if(indicedebutdroit!=(debut)){
		
		

		return 	droit(t,size,indicedebutdroit,debut,indicepivot);/*au tout debut indiceechange =size*;on metra aussi l'indice du pivot*/		

		
	}
	return indicedebutdroit;



return 0;
}

int droit(int t[],int size,int indicedepart,int indiceechangegauche ,int indicepivot){
	int  debut,nindicepivot;
	
		debut=indicedepart;
		                                                   nindicepivot=indicepivot;
		
		
		/*recherche d'un nobre <pivot*/
		while(f(t[debut],t[indicepivot])==1){
		debut--;
		}
		

	if(indicedepart!=indiceechangegauche){
		
		echanger(t,debut,indiceechangegauche);/*utilisation de indice echange gauche pour l'echange*/
		if (f(debut,indicepivot)==0) nindicepivot=indiceechangegauche;
		if (f(indiceechangegauche,indicepivot)==0) nindicepivot=debut;
		
		return gauche(t,size,indiceechangegauche,debut,nindicepivot);		


	}
	return indicedepart;
		

	
	
return 0;
}


void quicksort_int(int tab[],unsigned int size){

	int pivot,pi,i;
	int *tab2;

	pivot=(int ) (rand()%(size));
	
	
	
	pivot=gauche(tab,size,0,(size-1),pivot);
	
	for (i=0;i<size;i++){
		printf("%d \n",tab[i]);
	}
	tab2=&tab[pivot+1];
	
	
	if ((size>1) &&(pivot!=0)) quicksort_int(tab,pivot);
	
	
	if ((size>1) && (pivot!=(size-1))) quicksort_int(tab2,(size-pivot-1));
	
	
	


}





















int 
 
main(void ){
	
	int i,r,o,j,pivot;
	int l[13]={84,21,98,45,50,96,7,15,4,8,100,99,97};
	/*int l[10]={15,2,8,4,21,45,65,50,84,96} ;*/

	
	srand(8);
	quicksort_int(l,13);
	
	
	
	for (i=0;i<13;i++){
		printf("%d \n",l[i]);
	
	}
	return 0;

}
