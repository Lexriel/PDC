#include <stdlib.h>
#include <stdio.h>


void affichertab(int tab[], unsigned int taille){
  int i;
  for(i=0;i<taille;++i){
    printf("|%d",tab[i]);
  }
  printf("\n");
}

void quicksort_int(int tab[],unsigned int taille){
  if(taille > 1){
    int pivot;
    int tmp;
    int * min;
    int * max;
    
    pivot = tab[0];
    min = (tab + 1);
    max = (tab + (taille - 1));
   
    /* 
    printf("tab[0] : %d\n",tab[0]);
    printf("*(max) : %d\n",*(max));
    printf("pivot : %d\n",pivot);
    printf("*(min) : %d\n",*(min));
    */
    
    /*
    printf("\ninitial\n");
    affichertab(tab,taille);
    */


    while (min <  max){
      
      while( *min < pivot && min<(tab+taille)){
	min = (min + 1);
      }
      while( *max >= pivot && max>tab){
	max = (max - 1);
      }
      if(min < max){
	tmp = *min;
	*min = *max;
	*max = tmp;
      }
      
      /*      
      affichertab(tab,taille);
      */

    }

    /*    
    printf("\ntab[0] : %d\n",tab[0]);
    printf("*(max) : %d\n",*(max));
    printf("pivot : %d\n",pivot);
    printf("*(min) : %d\n",*(min));
    */

    if(tab[0]>*max){
    tab[0] = *(max);
    *(max) = pivot;
    }

    /*
    affichertab(tab,taille);
    */
    
    /*
    printf("\ntab : %d\n",*tab);
    printf("taille1 : %d\n",(min-tab-1)); 
    */

    quicksort_int(tab, (min - tab-1));
    
    /*    
    printf("\nmin : %d\n",*min);
    printf("taille2 : %d\n", taille - (min-tab));
    */

    quicksort_int(min, (taille - (min - tab)));
    
    /*    
    printf("\nfin\n");
    affichertab(tab,taille);
    */

  }
  
}

/*
int main(int argc, char** argv){
  int tableau[19];
  unsigned int taille;
  
  tableau[0] =9;
  tableau[1] =5;
  tableau[2] =98;
  tableau[3] =15;
  tableau[4] =7;
  tableau[5] =2;
  tableau[6] =3;
  tableau[7] =46;
  tableau[8] =21;
  tableau[9] =8;
  tableau[10] =9;
  tableau[11] =56;
  tableau[12] =41;
  tableau[13] =23;
  tableau[14] =54;
  tableau[15] =86;
  tableau[16] =51;
  tableau[17] =8;
tableau[18] =12;
  taille = 19;
  
  affichertab(tableau,taille);
  quicksort_int(tableau,taille);
  affichertab(tableau,taille);
  
  return 0;
}
*/
