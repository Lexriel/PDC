void quicksort_int(int tab[],unsigned int taille);

/*
  int compare(int a,int b){
  if (a < b)
  return -1;
  if (a > b)
  return 1;
  return 0;
  }
*/
