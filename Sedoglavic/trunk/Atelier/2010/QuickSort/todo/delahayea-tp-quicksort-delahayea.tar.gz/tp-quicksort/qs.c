#include <stdlib.h>
#include <stdio.h>

int compar(const void * a, const void * b){
  int a2, b2;
  a2 = * (int *) a;
  b2 = * (int *) b;
  if (a2 < b2)
  return -1;
  if (a2 > b2)
  return 1;
  return 0;
}

void affichertab(int tab[], unsigned int taille){
  int i;
  for(i=0;i<taille;++i){
    printf("|%d",tab[i]);
  }
  printf("\n");
}

void quicksort(void * base, int nmemb, int size,
               int(*compar)(const void *, const void *)){
  int cpt;
affichertab((int*)base,nmemb);
  if(nmemb > 1){
    char* pivot;
    char* tmp;
    char* min;
    char* max;
   
    tmp = (char*) malloc(size);

    pivot = (char*) base;
    min = (pivot + (1*size));
    max = (pivot + ((nmemb - 1)*size));
affichertab((int*)pivot,nmemb);
    while (min <  max){
      while( compar(min,pivot)<0 && min<(pivot+((nmemb-1)*size))){
	min = (min + (1*size));
      }
      printf("min : %d\n",*min);
      while( compar(max,pivot)>=0 && max>(pivot+(1*size))){
	max = (max - (1*size));
      }
      printf("max : %d\n",*max);
      if(min < max){
	for(cpt=0;cpt<size;++cpt){
	  *(tmp + cpt) = *(min + cpt);
	  *(min + cpt) = *(max + cpt);
	  *(max + cpt) = *(tmp + cpt);
	}
      }
    }

    
    if(compar(pivot,max)>0){
      for(cpt=0;cpt<size;++cpt){
	*(tmp + cpt) = *(pivot+ cpt);
	*(pivot + cpt) = *(max + cpt);
	*(max + cpt) = *(tmp + cpt);
      }
    }
    affichertab((int*)pivot,nmemb);
    free(tmp);
    quicksort(pivot, (min - pivot)/size, size, compar);
    quicksort(min, nmemb - ((min - pivot-(1*size))/size) - 1, size, compar);

  }
}
  
  
int main(int argc, char** argv){
  int tableau[19];
  unsigned int taille;
  
  tableau[0] =9;
  tableau[1] =5;
  tableau[2] =98;
  tableau[3] =15;
  tableau[4] =7;
  tableau[5] =2;
  tableau[6] =3;
  tableau[7] =46;
  tableau[8] =21;
  tableau[9] =8;
  tableau[10] =9;
  tableau[11] =56;
  tableau[12] =41;
  tableau[13] =23;
  tableau[14] =54;
  tableau[15] =86;
  tableau[16] =51;
  tableau[17] =8;
  tableau[18] =12;
  taille = 19;
  
  /*
    tableau[0] =52;	
    tableau[1] =36;
    tableau[2] =50;
    tableau[3] =1;
    tableau[4] =14;
    taille = 5;
  */
  /*
    tableau[0] =5;
    tableau[1] =4;
    tableau[2] =3;
    tableau[3] =2;
    tableau[4] =1;
    taille = 5;
  */
  quicksort(tableau,taille,sizeof(tableau[0]),compar);
  
  affichertab(tableau,taille);
  
  return 0;
}
