int compar(const void * a, const void * b);

void affichertab(int tab[], unsigned int taille);

void quicksort(void * base, int nmemb, int size,
               int(*compar)(const void *, const void *));
