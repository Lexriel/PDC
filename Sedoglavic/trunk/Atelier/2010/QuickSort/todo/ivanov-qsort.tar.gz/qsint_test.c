#include <stdio.h>
#include <stdlib.h>

#include "qsint.h"
#define TABSIZE 5


int 
main
(void)
{
  int i,j;
  
  printf("initialize the tab \n");
  int tab[TABSIZE];
  init_tab(tab);
  for(i=0;i<TABSIZE;i++){
    printf("%d \n",tab[i]);
  }
  
  quicksort_int(tab,TABSIZE);
  
  printf("Sorted tab \n");
  for(j=0;j<TABSIZE;j++){ 
    printf("%d \n",tab[j]);
  }
    
  
  return 0;
}
  
  
