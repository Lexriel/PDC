#include <stdio.h>
#include <stdlib.h>
#include "readl.h"
#include "qs.h"
#include <string.h>

#define NBMAXLINE 20
#define NMAXCHAR 20
/*Max number of lines to read */


int 
cstring_cmp
(const void *a, const void *b) 
  { 
    const char **ia = (const char **)a;
    const char **ib = (const char **)b;
    return strcmp(*ia, *ib);
    /* strcmp functions works exactly as expected from
       comparison function */ 
  } 

void 
print_cstring_array(char **array, size_t len) 
{ 
    size_t i;
    
    for(i=0; i<len; i++) 
      printf("%s", array[i]);
    
    putchar('\n');
} 

char *lines[NBMAXLINE];


int
comparaison
(const void *a, const void *b)
{
  int c=*(int*)a, d=*(int*)b;
  return c-d;
}


int
main
(void)
{


    
  int i=0;
  size_t strings_len;
  char *temp;
  
  while(i<NBMAXLINE)
  {
    temp=(char *) malloc(sizeof(char)*NMAXCHAR);
    fgets(temp,NMAXCHAR+1,stdin);
    lines[i]=temp;
    i++;
  }
  
  strings_len = sizeof(lines) / sizeof(char *);
  print_cstring_array(lines,strings_len);
  quicksort(lines,strings_len,sizeof(char *),cstring_cmp);
  print_cstring_array(lines,strings_len);
  
  return 0;
  
}

  
