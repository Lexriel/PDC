extern void quicksort (void *base, size_t nmemb, size_t size, int (*compar)(const void*, const void *));

extern void swap(void *value1, void *value2, size_t size);
