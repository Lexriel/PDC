#include <stdlib.h>


void
swap
(void *value1, void *value2, size_t size)
{
  void *value3;
  
  value3 = malloc(size);
  
  memcpy(value3, value1, size);
  memcpy(value1, value2, size);
  memcpy(value2, value3, size);
  
  free(value3);
}



void 
quicksort 
(void *base, size_t nmemb, size_t size, int (*compar)(const void*, const void *))
{
  /* base la reference de 1-ere element de tab 
     nmemb le nombre d'elements a trier
     size taille en bytes d'un element du tab
     compar pointer d'une fonction
  */
  
  char *debut, *fin, *montant, *descendant, *pivot;
  
  debut = base;
  fin = debut+(size*nmemb)-size;
  
  while (debut < fin)
    {
      montant = debut;
      descendant = fin;
      
      /* on choisit un pivot au milieu du tableau,
	 (et on le place au début pour le partitionnement) */
      swap (debut, debut+(((fin-debut)/(size*2))*size), size);
      pivot = debut;
      
      /* Partitionnement */
      do
        {
	  while (montant < descendant && compar(descendant, pivot) > 0)
	    descendant -= size;
	  swap (montant, descendant, size);
	  pivot = descendant;
	  
	  while (montant < descendant && compar(montant, pivot) <= 0)
	    montant += size;
	  swap (descendant, montant, size);
	  pivot = montant;
        }
      while (montant < descendant);
      
      /* Pour minimiser les appels récursifs */
      if (montant-debut < fin-montant)
        {
	  quicksort(debut, (montant-debut)/size, size, compar);
	  debut = montant+size;
        }
      else
        {
	  quicksort(montant+size, (fin-montant)/size, size, compar);
	  fin = montant-size;
        }
    }
}
