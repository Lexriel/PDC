Author: Iliya Ivanov

Notes:j'ai limite NBMAXLINE et NBMAXCHAR a 20 pour plus de visibilite et compréhension 
