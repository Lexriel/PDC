#include <stdio.h>
#include <stdlib.h>

#define TABSIZE 10

void 
init_tab
(int tab[])
{
  int i;
  /* Initiliaze the table with random int */
  
  for(i=0;i<TABSIZE;i++){
    tab[i]=rand()%1000;
  }
}

void 
echanger
(int *pe,int *pi )
{
  int tmp;

  tmp=*pe;
  *pe=*pi;
  *pi=tmp;
  
}



void 
quicksort
(int tab[],int leftBound,int rightBound)
{
  int i,j,pivot;
  if(leftBound<rightBound){
    pivot=tab[leftBound];
    echanger(&tab[leftBound],&tab[leftBound]);
    i=leftBound+1;
    j=rightBound;
    while(i<=j)
      {
	while((i<=rightBound) && (tab[i]<=pivot))
	  i++;
	while((j>=leftBound) && (tab[j]>pivot))
	  j--;
	if(i<j)
	  echanger(&tab[i],&tab[j]);
      }
    echanger(&tab[leftBound],&tab[j]);
    quicksort(tab,leftBound,j-1);
    quicksort(tab,j+1,rightBound);
  }
}

void 
quicksort_int
(int tab[],unsigned int size)
{
  
  /* On choisit toujours le primier element comme le pivot */
  quicksort(tab,0,size-1);
  
}



  
   
  
