#include "tools.h"

void echanger(int tab[],int i,int j)
{
	int k=tab[i];

	tab[i]=tab[j];
	tab[j]=k;
}

void echanger2(void ** tab,int i,int j)
{
	void * k=tab[i];

	tab[i]=tab[j];
	tab[j]=k;
}

void rempli_alea(int tab[],int size)
{
	int i;
	srand(time(NULL));
	for(i=0;i<size;i++)	tab[i]= (int)rand()%(VAL_MAX);
}

int est_trie(int tab[],int size)
{
	int i=1;
	while(i<size && tab[i-1]<=tab[i])	i++;
	return i==size;
}

void affich(int tab[],int size)
{
	int i;
	printf("\n");
	for(i=0;i<size;i++)	printf("%d ",tab[i]);
	printf("\n");
}

void affich_tabp(char *tab[],int max)
{
	int i,j;
	for(i=0;i<max;i++)
	{
		j=0;
		while(tab[i][j]!='\0')
		{
			putchar(tab[i][j]);
			j++;
		}
	}
}	

int readl(char line[]) 
{	
	char c;
	int i,cptr=0;
	
	for(i=0;i<MAX_CHAR+1;i++)	line[i]='\0';
	
	fgets(line,MAX_CHAR+2,stdin); 

	c=line[cptr];
	
	while (c!='\0') 
		c=line[++cptr];

	fatal(cptr<MAX_CHAR+1,"ligne de plus de MAX_LINE caractéres interdites",-2);
	
	return cptr; 

}

void* read_tab(int* j)
{
	void *p=malloc(MAX_CHAR*sizeof(char));
	(*j)=readl(p);
	return p;
}
	
void fatal(int assert,const char *message,int status)
{
	if(!assert)
	{
		fprintf(stderr,"**ERROR**:%s\n",message);
		exit(status);
	}
}


