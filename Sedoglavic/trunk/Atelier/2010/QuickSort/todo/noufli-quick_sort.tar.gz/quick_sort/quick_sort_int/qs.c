/*
Tp Quick sort

version Octobre 2010
*/


#include<stdio.h>
#include <stdlib.h>
#define TABSIZE 100

/*
Prototypes  
*/

int rand (void);
void quicksort_int(int tab[], unsigned int size);

/*
Declarations
*/

int tab[TABSIZE];
int i ;


/*
Fonctions
*/

void creAffTab(){
   for(i=0;i<TABSIZE;i++){

    tab[i]=rand();
  }
  for (i=0;i<TABSIZE;i++){
    printf("%d \n" ,tab[i]);
  }

}

int compare (int a , int  b){return a-b;}

int  echange(int * a , int * b) {
  int  tmp;
  tmp=*a;
  *a=*b;
  *b=tmp;
  return tmp;
}

void quicksort_int(int tab[],unsigned size) {
  int pivot;
  int * montant;
  int * descendant;
  int taille;


  /*On associe les pointeurs*/
  montant = tab;
  descendant = tab;

  /* Initialise la taille du tableau de gauche */
  taille=0;

  /* on avance sur la derniere case*/
  descendant+=size-1;

  /* le pivot est le permier element*/
  pivot=*montant;

  /* On teste s il n y a qu une case */
  if(montant==descendant) {return;}

  /* On boucle tant que le montant est avant le descendant*/
  /* On incremente le pointeur montant quand la valeur courante*/
  /* est inferieure au pivot*/
  /* On decremente le pointeur descendant quand la valeur courante*/
  /* est superieur au pivot*/
  /* Si les valeurs sont egales on incremente le montant et on recommence*/
  while(1){
    while(compare(*montant,pivot)<0){montant++;taille++;}
    while(compare(pivot,*descendant)<0){descendant--;}
  
    if(montant < descendant){
      if(*montant==*descendant){
	montant++;
	taille++;
      }else{
      echange(montant,descendant);
      }
    }else{
      break;
    }
    
  }
 
  /* Si le montant n a pas bouge alors on appelle en recursif */
  /* la fonction quicksort avec d abord la premier case du tableau*/
  /* et le reste sinon on l appelle en fonction de taille */
  if (taille==0){
    quicksort_int(tab,1);
    montant++;
    quicksort_int(montant,size-1);
  }else{
    quicksort_int(tab,taille);
    quicksort_int(montant,size-taille);
  }

}

void affichage(int tab[]){
  int i;
  for (i=0;i<TABSIZE;i++){
    printf("%d \n" ,tab[i]);
  }
  printf("\n");
}


int
main(){

  /*initialisation d'un tableau de taille 1000 */

 
  creAffTab();
  
  printf("\n");
  
  quicksort_int(tab,TABSIZE);
  
printf("Tableau apres tri\n");
  
  affichage(tab);

  return 0;

}
