#include "qsint.h"

int main()
{
	int i;
	for(i=0;i<NBR_TEST;i++)		test();
	return 0;
}

