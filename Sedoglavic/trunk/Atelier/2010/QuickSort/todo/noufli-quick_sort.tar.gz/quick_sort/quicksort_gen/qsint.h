#include "tools.h"

int pivot_int(int tableau[], int deb, int fin);
void tri_quicksort_int(int tableau[],int debut,int fin);
void quicksort_int(int tableau[],int longueur);
void test();
