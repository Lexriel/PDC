#include "qs.h"

int pivot(void** tableau, int deb, int fin,int(*sup)(const void *,const void *))
{
	int compt=deb;
	int i;
	void* p=tableau[deb];

	for(i=deb+1;i<=fin;i++)
	{
		if(sup(tableau[i],p)<0)
		{
			compt++;
			echanger2(tableau,compt,i);
		}
	}
	echanger2(tableau,compt,deb);
	return(compt);
}



void tri_quicksort(void** tableau,int debut,int fin,int(*sup)(const void *,const void *))
{

	if(debut<fin)
		{
		int p=pivot(tableau,debut,fin,sup);
		tri_quicksort(tableau,debut,p-1,sup);
		tri_quicksort(tableau,p+1,fin,sup);
		}
}

void quicksort(void *base, int nmemb, int size,int(*sup)(const void *,const void *))
{
	
	tri_quicksort((void**)base,0,nmemb-1,sup);
}


