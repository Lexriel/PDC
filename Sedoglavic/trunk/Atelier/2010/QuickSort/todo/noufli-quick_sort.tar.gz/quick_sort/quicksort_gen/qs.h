#include "tools.h"

int pivot(void** tableau, int deb, int fin,int(*sup)(const void *,const void *));
void tri_quicksort(void** tableau,int debut,int fin,int(*sup)(const void *,const void *));
void quicksort(void *base, int nmemb, int size,int(*sup)(const void *,const void *));

