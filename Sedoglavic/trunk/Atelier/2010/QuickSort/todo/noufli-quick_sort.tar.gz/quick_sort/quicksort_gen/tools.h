#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define MAX_CHAR 80
#define MAX_LINE 100
#define SIZE 50
#define VAL_MAX 1000
#define NBR_TEST 10

void echanger(int tab[],int i,int j);
void echanger2(void** tab,int i,int j);
int alea(int val);
void rempli_alea(int tab[],int size);
int est_trie(int tab[],int size);
void affich(int tab[],int size);
void affich_tabp(char *tab[],int max);
int readl(char line[]);
void* read_tab(int* p);
void fatal(int assert,const char *message,int status);
