#include "qs.h"

int compare(const void *i, const void *j) 
{
        return strcmp(*(char **)i, *(char**)j);
}


 int main()
{
	char *tab[MAX_LINE];
	int i=0,j;
	tab[i++]=read_tab(&j);
	while(i<MAX_LINE && j!=0) tab[i++]=read_tab(&j);

	fatal(i!=MAX_LINE,"trop de ligne sur le fichier d'entree",-1);

        qsort(tab,i,sizeof(char *),compare);
	affich_tabp(tab,i);
	return 0;
}
