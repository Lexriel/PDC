/*Dufour Et Laraki*/
#include <stdio.h>
#include <stdlib.h> 
#define TABSIZE 10s


void initialiserTabu(int tab[]) {
  int i;
  int z;
  tab[0]=0;
  tab[1]=5;
    tab[2]=7;
      tab[3]=3;
        tab[4]=9;
	  tab[5]=4;
	    tab[6]=500;
	      tab[7]=25;
	        tab[8]=45;
		  tab[9]=5;

  }

  void echanger(void *base,int taille,size_t i,size_t j){
    char* base_octets = base;
    int z;
    for (z=0; z<taille; z++)
    {
      char temp = base_octets[i*taille + z];
          base_octets[i*taille + z] = base_octets[j*taille + z];
          base_octets[j*taille + z] = temp;
      }
  }
  
int partition(void *base,size_t numeroEle,size_t tailleEle,
		int (*comparer)(const void *, const void *), int pivot) {
      int i=0;
      int j=numeroEle - 1;
      int jfixe=numeroEle -1;
      echanger(base,tailleEle,jfixe,pivot);
      
      while (i <=j) {
	char* base_octets = base;
	while (comparer(&base_octets[i*tailleEle], &base_octets[jfixe*tailleEle]) < 0) {
	  i++;
	}
	while (comparer(&base_octets[j*tailleEle], &base_octets[jfixe*tailleEle]) >= 0) {
	  j--;
	}
	if (i<j) {echanger(base,tailleEle,i,j);}
      }
      echanger(base,tailleEle,i,jfixe);
      return i;
}   
	
	

  
 void quicksort(void * base, size_t numeroEle, size_t tailleEle,
                int (*comparer)(const void *, const void *))
 {
     int pivotIndex;
 
     if (numeroEle>0) {
       
     pivotIndex = rand() % numeroEle;
 
     pivotIndex = partition(base, numeroEle, tailleEle, comparer, pivotIndex);
 
     quicksort(base, pivotIndex, tailleEle, comparer);
     quicksort(((char*)base) + tailleEle*(pivotIndex+1),
               numeroEle - (pivotIndex + 1), tailleEle, comparer);}
 
 }
 
 
 int compare_int(const void* left, const void* right) {
     return *((int*)left) - *((int*)right);
 }
 
 
 
int 
main()
{
int line[TABSIZE];
initialiserTabu(line);
int z=TABSIZE;
int i=0;
printf("\n");
for (i=0;i<z;i++) {
  printf("%i | ",line[i]);
}
printf("\n");
printf("Apres Tri on obtient\n");
quicksort(line,TABSIZE,sizeof(int),compare_int);	
for (i=0;i<z;i++) {
  printf("%i | ",line[i]);
}
printf("\n");
return 0;
}
