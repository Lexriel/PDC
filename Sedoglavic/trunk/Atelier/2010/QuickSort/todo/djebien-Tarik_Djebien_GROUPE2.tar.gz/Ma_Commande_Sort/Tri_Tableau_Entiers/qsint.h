#include <stdio.h>
#include <stdlib.h>


/* sort an array of integer with quicksort algorithm */
void
quicksort
(int tab[], int g, int d);


/* print an array of integers */
void
printArray
(int tab[], int lengthTab);
