#include "qsint.h"
#include <time.h>

void afficher(int tab[],char *message, int taille_tab){
  int i;
  printf("%s \n",message);
  for(i=0;i<taille_tab;i++){
    printf("%i => ",i);
    printf("%i \n",tab[i]);
  }
  printf("\n");

}

void echanger(int tab[],int a,int b)
{
    int tmp;
    tmp=tab[a];
    tab[a]=tab[b];
    tab[b]=tmp;

}

void remplir(int tab[], int nombre_max, int size){
  int i;
  srand (time (NULL));
  for(i=0;i<=size;i++){
    tab[i]= rand()%nombre_max;
  }
}



