#include <stdlib.h>
#include <stdio.h>

#define TABSIZE 11

void quicksort_int(int tab[],int indice_deb, int indice_fin);

void afficher(int tab[],char * message, int taille_tab);

void echanger(int tab[],int a,int b);

void remplir(int tab[], int nombre_max, int size);
