#include "qs.h"

void changer(char *p1, char *p2,int size){
    int j;
    char ptmp;
    for (j=0; j<size; j++){
        ptmp = *(p1+j);
        *(p1+j) = *(p2+j);
        *(p2+j) = ptmp;
    }
  }


void quicksort(void *base, int nmemb, int size, int(*compar)(const void *, const void *)){
    char *debut, *fin, *montant, *descendant, *pivot;

    debut = base;
    fin = debut+(size*nmemb)-size;

    while( debut < fin)
     {
         montant = debut;
         descendant = fin;


         /* Ici on choisi un pivot en plein millieu du tableau qu'on met au d�but avant de partionner celui-ci */
        changer(debut, debut+(((fin-debut)/(size*2))*size), size);
        pivot = debut;

        /* On peut maintenant partitionner le tableau */
        do{
        while (montant < descendant && compar(descendant, pivot) > 0) descendant -= size;

        changer(montant, descendant, size);
        pivot = descendant;

        while (montant < descendant && compar(montant, pivot) <= 0) montant += size;

        changer(descendant, montant, size);
        pivot = montant;
    }
    while (montant < descendant);

    /* Pour minimiser les appels r�cursifs */
    if (montant-debut < fin-montant){
      quicksort(debut, (montant-debut)/size, size, compar);
      debut = montant+size;
    }
    else{
      quicksort(montant+size, (fin-montant)/size, size, compar);
      fin = montant-size;
    }
  }

}

