#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void quicksort(void *base, int nmemb, int size, int(*compar)(const void *, const void *));
