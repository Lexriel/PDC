#include "qsint.h"

void quicksort_int(int tab[],int indice_deb, int indice_fin){

  int pivot;
  int montant;
  int descendant;

  pivot=tab[indice_deb];
  montant=indice_deb-1;
  descendant=indice_fin+1;

    if(indice_deb >= indice_fin)
    {
        return;
    }

  while(1){

    do montant++; while(tab[montant] < pivot);
    do descendant--; while(tab[descendant] > pivot);

    if(montant<descendant)
    {
        echanger(tab,montant,descendant);
    }else break;
  }
  quicksort_int(tab, indice_deb, descendant);
  quicksort_int(tab,descendant+1,indice_fin);

}
