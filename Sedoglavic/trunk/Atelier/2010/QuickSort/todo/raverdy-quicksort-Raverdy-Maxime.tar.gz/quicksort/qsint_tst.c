#include "qsint.h"
#include "qs.h"

int comparer(const void * chaine, const void * chaine2){
  int const * const nb1 = chaine;
  int const * const nb2 = chaine2;
  return *nb1-*nb2;
}

int main(void){
  int tab[TABSIZE];

  remplir(tab,42,TABSIZE-1);
  afficher(tab,"tableau non-trier",TABSIZE);

  /* quicksort_int(tab,0,TABSIZE-1); */
  quicksort(tab,TABSIZE,sizeof(int),comparer);
  afficher(tab,"tableau trier",TABSIZE);

  return 0;

}
