/* Flamant Sébastien groupe 2*/
#include <stdio.h>
#include <stdlib.h> 
#include <time.h>
#include <string.h>
#include "qs.h"
#define TABSIZE 100
#define NMAXLINE 10
#define NMAXCHAR 81
#define MAX 100


int comparaison( const void * chaine, const void * chaine2 ){
  int const * const nb1 = chaine;
  int const * const nb2 = chaine2;
  return *nb1-*nb2; 
}

 int comparaisonSTRING(void const * chaine, void const * chaine2){
  char const *const *pa = chaine;
  char const *const *pb = chaine2;
  return strcmp(*pa,*pb);
}


/* ----------------------------------------------MAIN-----------------------------------------*/
int main ( int argc,char *argv[]) {  
	int i;
	int tab[TABSIZE];
	int tab2[TABSIZE];
	int tab3[TABSIZE];
	int tab_original[TABSIZE];
	char *tab4[4] = {"t","a","b","z"};
	srand(time(NULL));


	printf("remplissage aléatoire d un tableau: \n");	
	for ( i=0 ; i < TABSIZE ; i ++) { 
		tab[i]= rand()%MAX; 	
		tab_original[i]= tab[i];
		tab2[i]= tab[i];	
		tab3[i]= tab[i]; } 
	affichage (tab_original,MAX);

	/* tri à bulles INT */ 
	tri_bulles(tab,TABSIZE); 
	printf("tri à bulles: \n");
	affichage (tab,MAX);		
	 
	/* tri quicksort INT */
	quicksort_int( tab2, TABSIZE);	 
	printf("tri avec QUICKSORT: \n");
	affichage (tab2,MAX); 

	/* tri tableau int avec generique */
	quicksort_generique (tab3,TABSIZE,sizeof(int),comparaison);
	printf("tri ENTIER avec quicksort générique: \n ");
	affichage (tab3,MAX);
  

	/* tri tableau char */
	printf("tableau de char *: \n ");
	affichage_gen (tab4,4);

	quicksort_generique (tab4,4,sizeof (*tab4),comparaisonSTRING);
	printf("tri CHAR * avec quicksort générique: \n ");
	affichage_gen (tab4,4);


return 0;
} 









