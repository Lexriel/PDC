#include <stdio.h>
#include <stdlib.h> 
#include <string.h> 
#include "qs.h"


/*------ QUICKSORT INT -------------*/
void affichage ( int tab[] , int x ) {
		int i ;
		for(i = 0; i < x ; ++i)
			printf("%d ", tab[i]);	
		printf("\n \n");
} 

void quicksort_int(int tab[], unsigned int size){
quicksort ( tab , 0 , size-1  );
}


void quicksort( int tableau[], int montant, int descendant){
   int pivot;
   if( montant < descendant ) { 
       pivot = partition_tableau( tableau,montant, descendant);
       quicksort( tableau,montant, pivot-1);
       quicksort( tableau, pivot+1, descendant);
   }
}
 
int partition_tableau( int tableau[] , int montant, int descendant) {
   int pivot ;
   pivot = tableau[montant]; 
	
	while (42==42){	
	   while( tableau[descendant] > pivot ) 
		descendant--;
	   while( (tableau[montant] < pivot)  ||  ((tableau[montant] == pivot)  &&  (tableau[descendant] == pivot)) 
		) montant++;
	   if ( montant<descendant ) {
		int tmp = tableau[montant];
		tableau[montant] = tableau[descendant];
		tableau[descendant] = tmp;}
	   else return descendant;
	}
}





/*------ QUICKSORT GENERIQUE -------------*/
void affichage_gen(char * tab[],int nb){
  	int i=0;
  	for(i=0;i<nb;i++){
    		printf("%s ",tab[i]);
  	}
	printf("\n");
}

void echange( char *a1, char* a2, unsigned long int size){				 
    unsigned long int j;					 
    for (j=0; j<size; j++){			
	char ptmp = *(a1+j);			
	*(a1+j) = *(a2+j);			
	*(a2+j) = ptmp;				
      }						
  }
 
void quicksort_generique(void *base,  int nb,  int size,  int(*compar)(const void *, const void *)){
  char *debut, *fin, *gauche, *droite, *pivot;
  debut = base;	/* debut est char * tandis qu'on a prit un tableau void * ) */
  fin = debut+(size*nb)-size;

  while (debut < fin){
    gauche = debut;
    droite = fin; 
    echange (debut, debut+(((fin-debut) / (size*2))*size), size);
    pivot = debut;

    /* fonction de partitionnement */
    do{
      while (gauche < droite && compar(droite, pivot) > 0)
	droite -= size;
      echange (gauche, droite, size);
      pivot = droite;

      while (gauche < droite && compar(gauche, pivot) <=0)
	gauche += size;
      echange (droite, gauche, size);
      pivot = gauche;
    }
   while (gauche < droite);

    /* Pour minimiser les appels récursifs */
    if (gauche-debut < fin-gauche){
     quicksort_generique(debut, (gauche-debut)/size, size, compar);
      debut = gauche+size;
    }
    else{
      quicksort_generique(gauche+size, (fin-gauche)/size, size, compar);
      fin = gauche-size;
    }
  }
}

 



/*-------- TRI BULLES ----------*/ 
void tri_test ( int *tab , unsigned int taille){
	int i=0; 
	int tmp=0;  	
	int tab_trie = 0;

    	while(!tab_trie){
        	tab_trie = 1;
        	for( i=0 ; i < taille-1 ; i++){
         	   if(tab[i] > tab[i+1]){
			tmp= tab[i];
			tab[i]=tab[i+1];
			tab[i+1]=tmp;
        	        tab_trie = 0;
        	    }
      	  }
        taille--;
    }

}	
	  	 
void tri_bulles(int tab[] , unsigned int size){
	int i=0;
	 
	while ( i<size ){
		tri_test(tab , size );
		i++;
	}
}
 
