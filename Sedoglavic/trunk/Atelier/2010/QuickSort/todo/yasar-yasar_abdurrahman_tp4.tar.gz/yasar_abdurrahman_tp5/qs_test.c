#include "qsint.h"
#define SIZETAB 9
int main()
{
	int i;	
	int tab[SIZETAB];

	init(tab,SIZETAB);
        for (i=0;i<SIZETAB;i++)
                printf("%d ",tab[i]);
        printf("\n");
	
	quicksort_int(tab,SIZETAB);

        for (i=0;i<SIZETAB;i++)
        	printf("%d ",tab[i]);
	        printf("\n");

	return 0;
}
