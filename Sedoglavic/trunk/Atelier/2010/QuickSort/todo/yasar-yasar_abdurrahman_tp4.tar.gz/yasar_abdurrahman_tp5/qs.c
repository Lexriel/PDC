#include "qs.h"

int compare_int(const void* left, const void* right) {
	return *((int*)left) - *((int*)right);
}

void change(void *base, int size, int elm1, int elm2)
{
	char * baseByte = base;
	char temp;

	temp = *(baseByte + elm1*size);
	*(baseByte +elm1*size)=*(baseByte + elm2*size);
	*(baseByte +elm2*size)=temp;
}

int partition(void *base, int size,int l, int r, int(*compar)(const void *, const void *))
{
	int i,j;
	char *baseByte=base;
	i=l;
		
	for(j=i+1;j<=r;j++){
		if(compar((baseByte + l*size),(baseByte + j*size)) > 0){
			i++;
			change(base,size,i,j);
		}
	}
	change(base,size,l,i);

	return i;
}
void q_sort(void *base, int size, int l, int r, int(*compar)(const void *, const void *))
{
	int k;
	if(l<r){
		k=partition(base,size,l,r,compar);
		q_sort(base,size,l,k,compar);
		q_sort(base,size,k+1,r,compar);
	}
}

void quicksort(void *base, int nmemb, int size, int(*compar)(const void *, const void *))
{
	q_sort(base,size,0,nmemb-1,compar);
}

