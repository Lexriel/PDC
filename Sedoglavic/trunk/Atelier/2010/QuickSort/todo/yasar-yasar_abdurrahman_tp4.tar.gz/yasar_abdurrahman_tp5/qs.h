#ifndef QS_H
#define QS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int compare_int(const void* left, const void* right);
void change(void *base, int size, int elm1, int elm2);
int partition(void *base, int size,int l, int r, int(*compar)(const void *, const void *));
void q_sort(void *base, int size, int l, int r, int(*compar)(const void *, const void *));

#endif
