/** NOM = YASAR
    PRENOM = Abdurrahman
    GROUPE 2
    ETUDIANT ERASMUS
*/

#ifndef TOOLS_H
#define TOOLS_H

#include <stdlib.h>
#include <stdio.h>

#define MAXLINE 81;

int options( int n, char *arg[], char *option );
void usage(int errno);
char *readline(char *s);
void mstrcpy(char *s1,char *s2, int n);

#endif

