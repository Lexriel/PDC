#ifndef QSINT_H
#define QSINT_H

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#define TABSIZE 1000

void init(int *tab, int size);
void q_sort(int *tab,int l, int r);
int partition(int *tab, int p,int q);
void q_sort(int *tab,int l, int r);
void quicksort_int(int tab[], unsigned int size);


#endif

