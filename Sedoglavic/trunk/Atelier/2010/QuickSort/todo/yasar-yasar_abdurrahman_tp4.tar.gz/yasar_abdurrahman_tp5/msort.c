#include "qs.h"
#include "tools.h"
#include <strings.h>

#define NMAXLINE 5
#define NMAXCHAR 83

int main()
{
/* pas finis */
	char st[420];
	int i;
	char *st2[5];

	for(i=0; i<NMAXLINE;i++)
	{
		readline(st+(i*NMAXCHAR));
	}
	
	/*array for the strings -> readline ???? il y a un problem ici le tableau pour strings ne marchent pas*/
	for(i=0; i<NMAXLINE;i++)
	{
		*(st2+i)=(st+i*NMAXCHAR);
	}

	quicksort(*st2, NMAXLINE, sizeof(int), strcmp);
	
	for (i=0;i<5;i++)	
		printf("%s",st2[i]);

	return 0;
}
