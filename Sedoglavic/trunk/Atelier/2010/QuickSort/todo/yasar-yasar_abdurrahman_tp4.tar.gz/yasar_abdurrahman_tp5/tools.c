/** NOM = YASAR
    PRENOM = Abdurrahman
    GROUPE 2
    ETUDIANT ERASMUS
*/

#include "tools.h"

int options( int n , char *arg[], char *option)
{
	int i;
	/*with argument*/
	if((arg[n])!=NULL){
		for(i=0;*(arg[n]+i)!='\0';i++)
		{
			*(option+i)=*(arg[n]+i);	
		}
/*		*(option+i)='\0';*/
		return 1;
	}
	/*without argument*/
	else
		return 0;
}

void usage(int errno)
{
	if(errno == -3){
		printf("Too many arguments \n");
		printf("usage:   mcolrm [col [end_col] ]\n");
	}
        
	if(errno == -2){
                printf("wrong arguments: you must type integers \n");
                printf("usage:   mcolrm [col [end_col] \n");
        }

}

char *readline(char *s)
{
	return fgets(s,82,stdin);
}

void mstrcpy(char *s1,char *s2, int n)
{	
	int i;
	for(i=0;i<n;i++)
		*(s2+i)=*(s1+i);
	*(s2+i)='\0';
}
