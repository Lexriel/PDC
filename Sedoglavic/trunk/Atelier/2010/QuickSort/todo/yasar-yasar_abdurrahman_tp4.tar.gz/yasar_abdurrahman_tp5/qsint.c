#include "qsint.h"

void init(int *tab, int size)
{
	int i;
	srand(time(NULL));
	for (i=0;i<size;i++)
		*(tab+i)=rand()%TABSIZE;
}

int partition(int *tab, int p,int q)
{
	int i,j,temp;
	i=p;
	for(j=p+1; j<=q;j++){
		if(tab[j]<=tab[p]){
			i++;
			temp=tab[i];
			tab[i]=tab[j];
			tab[j]=temp;
		}		
	}
	
	temp=tab[p];
	tab[p]=tab[i];
	tab[i]=temp;
	
	return i;
}

void q_sort(int *tab,int l, int r)
{
	int k;
	if(l<r){
		k=partition(tab,l,r);
		q_sort(tab,l,k);
		q_sort(tab,k+1,r);
	}
}

void quicksort_int(int tab[], unsigned int size)
{	
	q_sort(tab,0,size-1);
}
