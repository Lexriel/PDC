#include "compare.h"
#include <stdlib.h>
#include <stdio.h>
#define TABSIZE 10

void quicksort_int(int tab[], unsigned int size);
int main(int argc, char* argv[]);
