#include "qsint.h"

void quicksort_int(int tab[], unsigned int size){
  int pivot, min, max, tmp, i;

  pivot = tab[0];
  min = 1;
  max = size-1;
  
  while(min < max){
    while(compare(tab[min], pivot) < 0){
      min++;
    }
    while(compare(pivot, tab[max]) <= 0){
      max--;
    }
    if(min < max){
      tmp = tab[min];
      tab[min] = tab[max];
      tab[max] = tmp;
      printf("tableau temporaire \n");
      for(i = 0; i < size; i++){
	printf("%d ", tab[i]);
      }
      printf("\n");
    }
  }
  if(compare(pivot, tab[max]) > 0){
    tmp = pivot;
    tab[0] = tab[max];
    tab[max] = tmp;
  }
  printf("tableau temporaire \n");
  for(i = 0; i < size; i++){
    printf("%d ", tab[i]);
  }
  printf("\n");
  quicksort_int(tab, max+1);
  quicksort_int(tab+max, size-max);
  
}

int main(int argc, char* argv[]){
  int tab[TABSIZE];
  int i;

  tab[0] = 3 ;
  tab[1] = 5 ;
  tab[2] = 2 ;
  tab[3] = 7 ;
  tab[4] = 9 ;
  tab[5] = 1 ;
  tab[6] = 5 ;
  tab[7] = 6 ;
  tab[8] = 4 ;
  tab[9] = 2 ;

  printf("tableau d'origine \n");
  for(i = 0; i < TABSIZE; i++){
    printf("%d ", tab[i]);
  }
  printf("\n");
  quicksort_int(tab, TABSIZE);

  printf("tableau trié \n");
  for(i = 0; i < TABSIZE; i++){
    printf("%d ", tab[i]);
  }
  printf("\n");
  return 0;

}
