#include "compare.h"


int compare(int x, int y){
  return x-y;
}
