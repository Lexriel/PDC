#include "qsint.h"

int pivot_int(int tableau[], int deb, int fin)
{
	int compt=deb;
	int pivot=tableau[deb];
	int i;
	for(i=deb+1;
	i<=fin;
	i++)
	{
		if(tableau[i]<pivot)
		{
			compt++;
			echanger(tableau,compt,i);
		}
	}
	echanger(tableau,compt,deb);
	return(compt);
}

void tri_quicksort_int(int tableau[],int debut,int fin)
{
	if(debut<fin)
	{
		int pivot=pivot_int(tableau,debut,fin);
		tri_quicksort_int(tableau,debut,pivot-1);
		tri_quicksort_int(tableau,pivot+1,fin);
	}
}

void quicksort_int(int tableau[],int longueur)
{
	tri_quicksort_int(tableau,0,longueur-1);
}

void test()
{
	int tab[SIZE];
	rempli_alea(tab,SIZE);
	affich(tab,SIZE);
	quicksort_int(tab,SIZE);
	affich(tab,SIZE);
}




