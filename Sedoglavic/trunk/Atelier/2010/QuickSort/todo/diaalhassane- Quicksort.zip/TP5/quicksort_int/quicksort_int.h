#define TABSIZE 100
extern void initialiser(int *tab, unsigned int taille);
extern void quicksort_int(int *tab, unsigned int size);
extern int f(int x, int y);
extern void echanger(int *tab, unsigned int indice1, unsigned int indice2);
extern void print_tab(int *tab,int size);
