#include <stdlib.h>
#include <stdio.h>
#include "quicksort_int.h"
void initialiser(int *tab, unsigned int taille){
  int i;
  for (i =0; i < taille; i++){
    tab[i] = rand()%100;
  }
}

int f(int x, int y){
  return (x-y);
}

void print_tab( int *tab, int size) {
  int j;
  for (j=0;j<size;j++) 
    printf("%d ", tab[j]);
  printf("\n");
}

void echanger(int *tab, unsigned int indice1, unsigned int indice2){
  int z = tab[indice1];
  tab[indice1] = tab[indice2];
  tab[indice2] = z;
}

int partitionner(int *tab, unsigned int size, unsigned int debut, unsigned int fin){
  unsigned int 
    montant = debut,
    descendant = fin;
  int pivot = tab[(debut+fin)/2];
  while(montant < descendant){
    while(f(tab[montant], pivot) < 0) montant++;
    while(f(tab[descendant] ,pivot) > 0) descendant--;
    if (montant < descendant){
      if(tab[montant] != tab[descendant]){
	echanger(tab,montant,descendant);
      }
      else{
	montant++;
      }
    }
  }
  return descendant;   
}

void qs(int *tab, unsigned int size, unsigned int debut, unsigned int fin){
  int separateur;
  if(debut < fin){
    separateur = partitionner(tab,size,debut,fin);
    qs(tab,size,debut,separateur-1);
    qs(tab,size,separateur+1,fin);
  }
}

void quicksort_int( int *tab, unsigned int size){
  qs(tab,size,0,size-1);
}
