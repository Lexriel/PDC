#include <stdlib.h>
#include <stdio.h>
#include "malloc.h"

#define NALLOUE 50

/* En-tete, contient un pointeur sur l'En-tete du bloc libre suivant
 et la taille des donnes du bloc(sans l'En-tete)
struct en_tete_m {
  struct en_tete_m *next;
  unsigned taille;
};
typedef struct en_tete_m En_tete;
*/

static Bloc debut;	/* premier bloc de la liste vide */
static Bloc *bLibre = NULL;	/* debut liste libre */

void *appelSBRK(unsigned size, Bloc* last) {
  char* retsbrk;
  Bloc* retour;
  printf("(appelSBRK)\n");
  /* On alloue au minimum NALLOUE */
  if( size < NALLOUE ) {
    size = NALLOUE;
  }
  
  retsbrk = (char *) sbrk( size + sizeof(Bloc));
  
  if ( retsbrk == (char *) -1 ){
    return NULL;
  }

  retour = (Bloc *)retsbrk;
  retour->taille = size;
  retour->debutDonnees = retour + sizeof(Bloc);

  /*recollage et rebouclage des blocs libres*/
  last->next = retour;
  retour->next = bLibre ;

  return bLibre;
}


void * bam_malloc(unsigned int size, char* filename, unsigned int line){
  /*printf("malloc : %s \n %d \n", filename, line);*/
  Bloc *enCours, *prev;
  int i;

  unsigned int tailleAvecEntete;
  tailleAvecEntete = (size + sizeof(Bloc));

  prev = bLibre;

  /* Si 1er appel a malloc (la liste des blocs est vide)
   initialisation tout pointe sur le 1er bloc*/
  if ( bLibre == NULL ) {
    debut.next = bLibre = prev = &debut;
    debut.taille = 0;
  }

  /* on parcours tous les blocs libres */
  for ( enCours = prev->next ; ; prev = enCours, enCours = enCours->next )
    {
      /*si le bloc libre enCours est assez grand*/
      if(enCours->taille >= tailleAvecEntete)
	{
	  /* si le bloc libre enCours est tout juste de la bonne taille */
	  if (enCours->taille == tailleAvecEntete){
	    prev->next = enCours->next;
	  } 
	  else 
	    { /* division du bloc en deux blocs plus petits */
	      enCours->taille -= tailleAvecEntete;
	      /*deplace le pointeur du debut de bloc libre */
	      enCours = (Bloc *) ((char *) enCours + enCours->taille); 
	      /* on defini la taille du bloc qui va etre alouer */
	      enCours->taille = tailleAvecEntete;
	      enCours->debutDonnees = enCours + 1 ;
	    }
	
	  bLibre = prev;
	  enCours->next = NULL;
	  
	  /* remplissage a zero de la zone allouee par malloc */
	  for (i = 0; i < size ; i++)
	    *((char *)((enCours->debutDonnees)+i)) = '0';
	  
	
	
	  return (void *) enCours->debutDonnees;
	
	}

      /* si on arrive au dernier bloc libre et que toujours pas assez grand */
      if ( enCours == bLibre )
	  if ((enCours = (Bloc *) appelSBRK(tailleAvecEntete, enCours)) == NULL)
	    {
	      fprintf(stderr,"Disk full\n");
	      return NULL;
	    }
    }

  return NULL ;
}



void bam_free(void * ptr){
  Bloc *liber, *enCours;
  /*printf("MonFree\n");*/
  int i ;

  /* printf("pointeur: %s\n", (char*)ptr);*/

  liber = (Bloc *)ptr-1; /* pointe sur l'entete du bloc*/
  if(liber->next == NULL){
  /*parcours des bloc libres
    on s'arrete quand notre bloc liber est "encadre" par deux bloc libre*/
  for (enCours = bLibre; !(liber > enCours && liber < enCours->next) ; enCours = enCours->next){
    /*cas ou on est en bout de liste libre (donc liber est apres le dernier bloc libre)*/
    if(enCours >= enCours->next){
      /* cas ou le bloc liber est a la fin ou au debut*/
      if(liber > enCours || liber < enCours->next){
      break;
      }
    }
  }

 printf("taille segment rendu:%d \n", liber->taille);
  /* remplissage arbitraire du segment rendu */
  for (i=0; i < liber->taille ; i++){
	*((char *)((liber->debutDonnees)+i)) = '6';
  }

  /*modification des next, et recollage*/
  /* si le bloc liber est juste avant le bloc libre suivant*/
  if (liber + liber->taille == enCours->next){
    liber->taille += enCours->next->taille;
    liber->next = enCours->next->next;
    liber->next = enCours->next;
    /*sinon s'il est juste apres le bloc libre encours*/
  } else if(enCours + enCours->taille == liber){
    enCours->taille += liber->taille;
    enCours->next = liber->next;
    enCours->next = liber;
    /*sinon il est encadre par deux bloc non-libre*/
  } else {
    liber->next = enCours->next;
    enCours->next = liber;
  }
  bLibre = enCours;
  
 
  
  /*printf("libere\n");*/
  }
  
  else{
    fprintf(stderr,"Liberation impossible d'un espace non alloue\n");
  }
  
}
