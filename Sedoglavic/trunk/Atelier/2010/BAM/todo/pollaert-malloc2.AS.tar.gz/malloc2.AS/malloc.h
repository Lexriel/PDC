/* Un bloc = En_tete + un pointeur sur le debut des donnees */
struct bloc_m {
  struct bloc_m *next;
  unsigned taille;
  void * debutDonnees;
};
typedef struct bloc_m Bloc;

void *appelSBRK(unsigned size, Bloc* last);
void * bam_malloc(unsigned size, char* filename, unsigned line);
void bam_free(void * ptr);

