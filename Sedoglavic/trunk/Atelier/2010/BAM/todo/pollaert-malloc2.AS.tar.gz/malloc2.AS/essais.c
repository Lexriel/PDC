#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "malloc.h"

#define malloc(sz) bam_malloc(sz,__FILE__,__LINE__)
#define free(ptr) bam_free(ptr)

int main(int argc, char** argv){	
	char * ptr,*ptr2;
	printf("Debut\n");

	printf("allocation ptr\n");
	if((ptr = (char *) malloc(10)) != NULL){
	printf("avant ptr = %s\n",ptr);
	*(ptr) = 'S';
	*(ptr+1) = 'a';
    	*(ptr+2) = 'l';
    	*(ptr+3) = 'u';
    	*(ptr+4) = 't';
    	*(ptr+5) = '\0';
       	printf("apres ptr = %s\n",ptr);

	free(ptr);
	printf("liberation ptr\n");

    	printf("allocation ptr2\n");  
    	if((ptr2 = (char *) malloc(100)) != NULL){   
		strcpy(ptr2,ptr);
    		printf("ptr2 = %s\n",ptr2);
   		free(ptr2);
		printf("liberation ptr2\n");   
	}
	
	free(ptr);
  }

  printf("Fin\n");
  return 0;

}
