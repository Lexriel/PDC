#include <stddef.h>
#include <stdlib.h>		
#include <stdio.h>
#include <unistd.h>
#include "malloc.h"

allocation* DebutListe = NULL;


/* Redefinition of malloc () */
void *
malloc (size_t size)
{
  verification_chainage();
  return isMemDispo(size);
}

/* Redefinition of free () */
void
free (void *ptr) 
{
  int trouve =0;
  int i;
  if(DebutListe != NULL){
    allocation * tmpAlloc = DebutListe;
    while(tmpAlloc != NULL){
      if(tmpAlloc->debut == ptr){
	
	/* réécriture une fois le segment rendu pour eviter une utilisation postérieure*/
	for(i=0;i<tmpAlloc->taille;i++)
	  tmpAlloc->debut[i] = -1;
	
	trouve = 1;
	tmpAlloc->libre = 1;
	if(tmpAlloc->suivant != NULL && tmpAlloc->suivant->libre == 1){
	  allocation * useToDelete = tmpAlloc->suivant;
	  if(useToDelete->suivant != NULL)
	    useToDelete->suivant->precedant = tmpAlloc;
	  tmpAlloc->suivant = useToDelete->suivant;
	  tmpAlloc->taille += useToDelete->taille + sizeof(allocation);
	  tmpAlloc->libre = 1;
	}
	if(tmpAlloc->precedant != NULL && tmpAlloc->precedant->libre ==1 ){
	  allocation * useToDelete = tmpAlloc->precedant;
	  useToDelete->suivant = tmpAlloc->suivant;
	  useToDelete->taille += tmpAlloc->taille + sizeof(allocation); 
	}
      }
      if(tmpAlloc->suivant == NULL){
	break;
      }
      tmpAlloc = tmpAlloc->suivant;
    }	  
  }

  /*Si on tente de liberer un espace memoire qui ne nous est pas attribué, affichage d'un message d'erreur et fin du programme avec un code d'erreur a 1*/
  if(!trouve){
    printf("Le segment que vous tentez de liberer ne vous est pas alloué\n");
    exit(1);
  }
}

void* calloc(size_t nmemb,size_t size){
  int i;
  char * tmp = malloc(size*nmemb);
  if(nmemb == 0 || size == 0){
    return NULL;
  }

  for(i=0;i<size*nmemb;i++)
    tmp[i] = 0;
  return tmp;
}

void* isMemDispo(int size){
  allocation* tmpAlloc = DebutListe;
  allocation* a;
  int i;
  while(tmpAlloc != NULL){
    if(tmpAlloc->taille >= size+sizeof(allocation) && tmpAlloc->libre == 1){
      segmenter(tmpAlloc->debut,size);
      
      /*initialisation des segments a -1 pour contrer le fait que malloc retourne des segments =0 */
      for(i=0;i<tmpAlloc->taille;i++)
	tmpAlloc->debut[i] = -1;

      
      return tmpAlloc->debut;
    }
    if(tmpAlloc->suivant == NULL){
      break;
    }
    tmpAlloc = tmpAlloc->suivant;
  }
  
  a = sbrk(32768);
  a->precedant = tmpAlloc;
  a->suivant = NULL;
  a->debut =(char *) a+sizeof(allocation);
  a->taille = 32768-sizeof(allocation);
  a->libre = 1;
  if(DebutListe == NULL){
    DebutListe = a;
    free(a->debut);
  }
  else{
    tmpAlloc->suivant = a;
    free(tmpAlloc->suivant->debut);
  }
  
  return isMemDispo(size);
}

void segmenter(void * ptr,int size){
  allocation* tmpAlloc = DebutListe;
  allocation* useToCreate;
  while(tmpAlloc != NULL){
    if((char *)tmpAlloc->debut == (char*)ptr){
      allocation *a = (allocation*)(tmpAlloc->debut + size);

      useToCreate = tmpAlloc->suivant;
      a->suivant = useToCreate;
      a->precedant = tmpAlloc;
      if(useToCreate != NULL){
	useToCreate->precedant = a;
      }
      else{
	a->suivant = NULL;
      }
      tmpAlloc->suivant = a;
      a->taille = tmpAlloc->taille-size-sizeof(allocation);
      a->libre = 1;
      a->debut = ((char*)tmpAlloc->debut) + size+sizeof(allocation);

      tmpAlloc->taille = size;
      tmpAlloc->libre = 0;  
      break;
    }
    tmpAlloc = tmpAlloc->suivant;
  }
}


/*Fonction qui affiche l'intégralité des blocs alloués et libérés*/
void printfStruct(){
  allocation* tmpAllocc = DebutListe;
  printf("****************************************\n");
  printf("*** Malloc -- Etat actuel de memoire ***\n");
  printf("****************************************\n");
  while(tmpAllocc != NULL){
    printf("Segment Adresse>%d\n",(unsigned int)tmpAllocc);
    printf("         segment precedant>%d\n",(unsigned int)tmpAllocc->precedant);
    printf("         segment   suivant>%d\n",(unsigned int)tmpAllocc->suivant);
    printf("         debut>%d\n",(unsigned int)tmpAllocc->debut);
    printf("        --->taille : %d\n",tmpAllocc->taille);
    printf("        --->dispo : %d\n",tmpAllocc->libre);
    
    tmpAllocc = tmpAllocc->suivant;
  }
}


void verification_chainage(){
  allocation* tmpAlloc = DebutListe;
  int ok = 1;
  while(tmpAlloc != NULL){
    if(tmpAlloc->suivant != NULL){
      if((unsigned int)tmpAlloc->suivant != (unsigned int)tmpAlloc + (unsigned int)tmpAlloc->taille+(unsigned int)sizeof(allocation)){
	ok=0;
      }
    }


    tmpAlloc = tmpAlloc->suivant;
  }
  if(!ok){
    printf("chainage du malloc modifiée par l'utilisateur. Arret.\n");
    exit(1);
  }
}
