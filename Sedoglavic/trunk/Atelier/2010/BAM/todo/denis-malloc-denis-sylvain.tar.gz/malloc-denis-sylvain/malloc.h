/*debut => pointeur sur l'octet de debut
 *taille => taille en octets du segment 
 *libre =>disponible ou non  0/non dispo || 1/dispo
 */

/* Forget definition of malloc wrappers */
#ifdef malloc
#undef malloc
#undef free
#undef calloc
#endif



typedef struct Allocation allocation;

struct Allocation{
  allocation * suivant;
  allocation * precedant;
  char* debut;
  int taille;
  int libre;
};



void* isMemDispo(int size);
void segmenter(void * ptr,int size);
void *malloc (size_t size);
void free(void* ptr);
void printfStruct();
void verification_chainage();
void* calloc(size_t nmemb,size_t size);
