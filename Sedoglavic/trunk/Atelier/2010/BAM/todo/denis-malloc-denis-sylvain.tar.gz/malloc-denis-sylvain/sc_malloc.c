#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "malloc.h"

#define SUPER	"Supercalifragilisticexpialidocious"

int
main(void)
{
  char *str,*str1,*strcp;
    printf("%d\n",sizeof(allocation));


    str1 = malloc(30);
    printfStruct();
    str = malloc(strlen(SUPER)+10);
    printfStruct();
    strcpy(str, SUPER) ; 
    
    printf("%s\n",str);
    
    strcp = strdup(str); 
    printfStruct();
    
    printf("%s\n%s\n", str, strcp); 
    printfStruct();
    free(str);
    printfStruct();
    free(str1);
    printfStruct();
    free(strcp);
    printfStruct();

    exit(EXIT_SUCCESS);
}
