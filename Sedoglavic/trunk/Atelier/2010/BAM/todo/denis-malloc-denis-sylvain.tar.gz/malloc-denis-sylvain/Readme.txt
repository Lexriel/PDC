Denis Sylvain
Grp 2

Voici ce qui a été réalisé sur le tp malloc:

Réalisation des fonctions:

malloc,calloc,free;

Ces fonctions utilisent une liste doublement chainée de structure pour stocker les données en référence à la mémoire gérée.

Les améliorations suivantes ont été implémentées:

1. Passage à free() d’une adresse ne correspondant pas à une adresse précédemment retournée par malloc().
2. Supposition de remplissage des segments mémoire retournés par malloc() à zéro.
4. Utilisation d’un segment après l’avoir rendu par free().
6. Vérification du chaînage des blocs gérés par la bibliothèque.
7. Production d’une carte mémoire du tas 2.
