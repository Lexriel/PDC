#include<stdio.h>
#define BUFSIZE 100000
#define TRUE 1
#define FALSE 0
#include "outil.h"

static char  buf[BUFSIZE];

 

  liste_t *h;

   void allinit(void)
  {
      liste_t *ptr = (liste_t *)buf;
      ptr->fr = TRUE;
      ptr->size = BUFSIZE;
      ptr->next = NULL;
      ptr->previous = NULL;
      h = ptr;
      return;
  }

  void *alloc(unsigned int taille)
  {
      liste_t *ptr = h, *bloc;
      while((ptr->size < taille + sizeof(liste_t)) || ptr->fr == FALSE )
      {
	    if(!ptr->next)
		  return NULL;
	    ptr =  ptr->next;
      }
      ptr->fr = FALSE;

      if (!ptr->size < 2 * sizeof(liste_t) + taille)
      {
	    bloc = (liste_t *) ((char *) ptr + sizeof(liste_t) + taille);
	    bloc->fr = TRUE;
	    bloc->size = ptr->size - taille - sizeof(liste_t);
	    bloc->next = ptr->next;
	    if(ptr->next)
		    ptr->next->previous = bloc;
	    bloc->previous = ptr;
	    ptr->next = bloc;
	    ptr->size -= bloc->size;
      }
	    return (void *) ((char *) ptr + sizeof(liste_t));
  }




  void free(void * ptr)
  {
	liste_t *t = (liste_t *) ((char *) ptr - sizeof(liste_t));
	t->fr = TRUE;
	if(t->next && (t->next)->fr == TRUE)
	{
	      t->size += t->next->size;
	      t->next = t->next->next;
	}

	if(t->previous && (t->previous)->fr == TRUE)
	{
	      t->previous->size += t->size;
	      t->previous->next = t->next;
	}
	return;
  }
