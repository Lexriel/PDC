 #include<stdio.h>
#include<stdlib.h>
#include"bam.h"

int main(void)

{
    maillon_t m, m1; 

    m = malloc(100);
	m->taille = 100;
	m->b = OCCUPE;
	m->suivant = NULL;
	m->precedant = NULL;


    m1 = malloc(50);
	m1->taille = 50;
	m1->b = OCCUPE;
	m1->suivant = NULL;
	m1->precedant = m;
	m->suivant = m1;

    free(m);
    free(m1);




exit(EXIT_SUCCESS);

}

