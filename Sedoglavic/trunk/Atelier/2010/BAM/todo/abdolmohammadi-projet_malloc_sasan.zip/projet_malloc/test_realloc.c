 #include<stdio.h>
#include<stdlib.h>
#include"bam.h"

int main(void)

{
    maillon_t m, m1; 

    m = malloc(100);
	m->taille = 100;
	m->b = OCCUPE;
	m->suivant = NULL;
	m->precedant = NULL;

    m1 = realloc(m,10);
	m->taille = m->taille + 10 ;
	m->b = OCCUPE;
	m->suivant = NULL;
	m->precedant = NULL;


  

    free(m);
    free(m1);




exit(EXIT_SUCCESS);

}
