  struct liste_m
  {
		  unsigned fr;
		  unsigned int size;
		  struct liste_m *next;
		  struct liste_m *previous;
  };


  typedef struct liste_m liste_t;

  void allinit(void);
  void *alloc(unsigned int taille);
  void free(void * ptr);
