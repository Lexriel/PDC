#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include "bam.h"
#define MSIZE 1000000

 int i = 0;
 void *ptr;
 void *memory = NULL;

void *bam_malloc(int size, char * filename, unsigned line)
{
  

  if(i == 0)
  {
	if (! memory) 
	memory =   sbrk(MSIZE);     
	ptr = memory; /* memory allocation */
	memory += size + sizeof(struct maillon_s);
	printf("filename %s  ligne %d,  %d octets demande\n", filename, line, size);
	i++;
	
	return ptr;
   }
    else {
	ptr = memory; 
	memory += size + sizeof(struct maillon_s);
	
	printf("filename %s  ligne %d,  %d octets demande\n", filename, line, size);
	return ptr;
	  }
}


void *bam_calloc(int nb,int size, char * filename, unsigned line)
{
  

  if(i == 0)
  {
	if (! memory) 
	memory = (char *)sbrk(100000);    
	ptr = memory; 
	memory += size * nb;
	printf("filename %s  ligne %d,  %d elements, %d octets demande\n", filename, line, nb, size*nb);
	i++;
	
	return ptr;
   }
    else {
	ptr = memory; 
	memory += size * nb;
	
	printf("filename %s  ligne %d,  %d elements, %d octets demande\n", filename, line,nb, size*nb);
	return ptr;
	  }
}


void *bam_realloc(void *p,int size, char * filename, unsigned line)
{
   
	ptr = p; 	
	
	printf("filename %s  ligne %d,  %d octets demande plus\n", filename, line, size );
	return ptr;
	  
}



void
bam_free (void *ptr,		
	  char *filename,	
	  unsigned line) 
{
    
    printf("filename %s  ligne %d,  appel de free()\n", filename, line);
    
  
    
}