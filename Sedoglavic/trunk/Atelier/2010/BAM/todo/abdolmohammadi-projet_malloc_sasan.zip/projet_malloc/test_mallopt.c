 #include<stdio.h>
#include "outil.h"


  int main(void)
  {	
	char *A;
	char *B;
	allinit();
	A =  (char *) alloc(1000);
	B = (char *) alloc(1000);
	A = "cette phrase pour eissai version bibliothèque mallopt";
	printf("%s\n", A); 
	
	free(B);
	return 0;
  }
