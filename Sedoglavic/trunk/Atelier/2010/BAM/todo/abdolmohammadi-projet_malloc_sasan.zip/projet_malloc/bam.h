
#define malloc(sz)  bam_malloc(sz, __FILE__, __LINE__)
#define calloc(nb,sz)  bam_calloc(nb,sz, __FILE__, __LINE__)
#define realloc(ptr,sz)  bam_realloc(ptr,sz, __FILE__, __LINE__)
#define free(ptr)       bam_free(ptr, __FILE__, __LINE__)



void *bam_malloc (int size,	
		  char *filename,	
		  unsigned line); 	


void *bam_calloc(int nb,int size, 
		char * filename,
		unsigned line);


void bam_free (void *ptr,		
	      char *filename,	
	      unsigned line);


void *bam_realloc(void *p,
		  int size, 
		  char * filename,
		  unsigned line);



  enum boolean{LIBRE = 1, OCCUPE = 0};

  typedef struct maillon_s  *maillon_t;

  struct maillon_s 
  {
	int taille;
	maillon_t suivant;
	maillon_t precedant;
	int b;

  };
