

#ifndef MYREALLOC
    #define MYREALLOC 1

    /* Macros de remplacements */
    #define realloc(x,y)  myrealloc(x,y)


    /* Réalloue un espace attribué par un précédent alloc, à une nouvelle taille size */
    extern void *myrealloc (void *pointeur, unsigned int size);

#endif
