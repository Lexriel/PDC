/* memoryblock.c
 * Implémentation .des fonctions de la bibliotheque d allocation de memoire 
 */


#include <stdio.h>
#include <unistd.h>
#include <stdarg.h>
#include <stdlib.h>
#include "memoryblock.h"

#define LISTE_VIDE {0,0}


/* variable globale */

block_list_t free_memory = LISTE_VIDE;
block_list_t busy_memory = LISTE_VIDE;

/*---------------------------------------------------------------------------------------------------------------*/
                  /* Fonctions primitives et auxiliares pour gerer un block*/
/*---------------------------------------------------------------------------------------------------------------*/

/* Crée un nouveau bloc, avec le contenu passé en paramètre. */
block_t *newblock(void *content, unsigned int size) {
  block_t *res = (block_t *) sbrk(sizeof(block_t));
  res->content = content;
  res->size = size;
  res->next = NULL;
  res->prev = NULL;
  return res;
}

/* Détermine si une liste de blocksest vide ou non */
int block_list_is_free(block_list_t *block_list){
  return (!(block_list->first) && !(block_list->last)); 
}

/* Ajoute un bloc en tête de liste de blocks*/
void block_list_fist_add(block_list_t *block_list, block_t *block) {
  block_t * ancienPremier = block_list -> first;
  
  /*  "block" devient le nouveau premier */
    block_list -> first = block;
    
    /* S'il existait un élément dans la liste de blocks on met à jour le chaînage entre l'ancien premier élement et le nouveau. */
    if (ancienPremier) {
      ancienPremier -> prev = block; 
      block -> next = ancienPremier;
    } 
    
    /* Si la liste de blocksétait vide, block devient aussi le dernier élément de la liste de blocks*/
    else {
      block_list -> last = block;
    }
    
}

/* Ajoute un bloc en fin de liste de blocks*/
void block_list_last_add(block_list_t *block_list, block_t *block) {
  
  block_t * ancienDernier = block_list -> last;
  
  /* "block" devient le nouveau dernier */
    block_list -> last = block;
    
    /* si un block appartient a la liste de blocks on met à jour le chaînage entre l'ancien dernier élement et le nouveau. */
    if (ancienDernier) {
      ancienDernier -> next = block; 
      block -> prev = ancienDernier;
    } 
    
    /* Si la liste de blocks était vide, block devient aussi le premier élément de la liste de blocks*/
    else {
      block_list -> first = block;
    }
    
}


/* Détermine si "block" est dans "block_list" */
int block_list_is_exist(block_list_t *block_list, block_t *block) {
  block_t *a_block = block_list -> first; 
  while (a_block) {
    if (a_block == block) {
      return 1;
    } else {
      a_block = a_block -> next;
    }
  }
  
  return 0;
}

/* Insère "block" après "blocbase" dans "block_list". 
* Retourne ECHEC si "blocbase" n'est pas présent dans "block_list".
*/
int block_list_block_insert_after(block_list_t *block_list, block_t *block, block_t *blocbase) {
  if (!block_list_is_exist(block_list,blocbase)) {
    return ECHEC;
  } else {
    block_t *prev_block = blocbase;
    block_t *next_block = blocbase -> next;
    
    /* Chaînage précédent block */
        prev_block->next = block;
	block->prev = prev_block;
	
	/* Chaînage suivant block : plus délicat car il n'y a peut être pas de bloc après block */
        block->next = next_block;
	if (!next_block) {
	  block_list -> last = block;
	} else {
	  next_block -> prev = block;
	}
	
	return SUCCES;
  }
}

/* Insère "block" avant "blocbase" dans "block_list"
* Retourne ECHEC si "blocbase" n'est pas présent dans "block_list".
*/
int block_list_block_insert_before (block_list_t *block_list, block_t *block, block_t *blocbase)  {
  if (!block_list_is_exist(block_list,blocbase)) {
    return ECHEC;
  } 
  
  else {
    block_t *prev_block = blocbase -> prev;
    block_t *next_block = blocbase;
    
    /* Chaînage suivant block */
        next_block->prev = block;
	block->next = next_block;
	
	/* Chaînage précédent block : plus délicat car il n'y a peut être pas de bloc avant block */
        block->prev = prev_block;
	if (!prev_block) {
	  block_list->first = block;
	} else {
	  prev_block->next = block;
	}
	
	return SUCCES;
  }
}

/* Supprime "block" de "block_list".
Retourne ECHEC si "block" n'appartient pas à "block_list".
*/
int block_list_block_del(block_list_t *block_list, block_t *block) {
  if (!block_list_is_exist(block_list,block)) {
    return ECHEC;
  }
  
  else {
    block_t *prev_block = block -> prev;
    block_t *next_block = block -> next;
    
    if (!prev_block) {
      block_list -> first = next_block;
    } else {
      prev_block -> next = next_block;
    }
    
    if (!next_block) {
      block_list -> last = prev_block;
    } else {
      next_block -> prev = prev_block;
    }
    
    return SUCCES;
  }
}

/* 
Affiche l'état de la liste de blocks
*/
void block_list_print(block_list_t *block_list) {
  
  block_t *a_block = block_list -> first;
  
  while (a_block) {
    printf("[ %p , %u ]",a_block->content,a_block->size);
    a_block = a_block -> next;
  }
}

/*
Renvoie le pointeur associé à ce bloc
*/
void *block_get_pointer(block_t *block) {
  return block->content;
}

/*
Renvoie la taille associée à ce bloc
*/
unsigned int get_size(block_t *block) {
  return block->size;
}


/*---------------------------------------------------------------------------------------------------------------*/
                                       /*gestions des blocks libres*/
/*---------------------------------------------------------------------------------------------------------------*/

    /* Ajoute un nouveau bloc de mémoire libre, pointant vers pointeur et de taille size. */
    block_t *freem_add(void *pointeur, unsigned int size) {
      block_t *block = newblock(pointeur,size);
      freem_block_add(block);
      return block;
    }
    

    
    /* Ajoute le bloc à la liste de blocksde blocs de mémoire libre. */
    void freem_block_add(block_t *block) {
      block_t *a_block;
      a_block = free_memory.first;
      
      if (!a_block) { /* Si la liste de blocksest vide */
            block_list_fist_add(&free_memory,block);
      } else { /* Je cherche la première cellule dont le pointeur est plus grand que celui de la cellule à ajouter */
            while(a_block && block_get_pointer(a_block) < block_get_pointer(block)) {
	      a_block = a_block -> next;
	    }
	    
	    /* Il y en a une, j'insère ma cellule avant elle */
            if (a_block) {
	      block_list_block_insert_before(&free_memory,block,a_block);
	    } else {
	      block_list_last_add(&free_memory,block);
	    }
      }
      
    }
    

    
    
    /* Supprime le bloc passé en paramètre. Retourne ECHEC si block n'existe pas */
    int freem_block_del(block_t *block) {
      return block_list_block_del(&free_memory,block);
    }
    

    /* Trouve et renvoie la première cellule dont le bloc a une taille suffisante pour contenir size */
    block_t *freem_first_fit(unsigned int size) {
      block_t *a_block = free_memory.first;
      
      while (a_block) {
	if (get_size(a_block) >= size) {
	  return a_block;
	}
	a_block = a_block -> next;
      }
      
      /* A ce stade, je n'ai rien trouvé */
        return NULL;
       }
    
    /* Amoindris l'espace disponible de ce bloc de *size* octets. Cette opération peut donc supprimer le bloc.
    Peut retourner ECHEC en cas d'erreur. (size trop grand, par ex)*/
    int freem_reduce(block_t *block, unsigned int size) {
      unsigned int taille_block;
      taille_block = get_size(block);
      
      /* Une fois récupéré la taille du bloc passé en paramètre, trois cas se présentent. */
        /* Cas 1 : On veut retirer au bloc plus qu'il ne contient => ERREUR ! */
        if (size > taille_block) {
	  return ECHEC;
	}
	
	/* Cas 2 : On veut retirer au bloc exactement ce qu'il contient. => Suppression du bloc. */
        else if (size == taille_block) {
	  block_list_block_del(&free_memory,block);
	}
	
	/* Cas 3 : On veut retirer au bloc moins qu'il ne contient => On l'amoindrit. */
        else {
	  block -> size = taille_block - size;
	  block -> content = (void *) (((char *) block_get_pointer(block) ) + size);
	}
	
	return SUCCES;
    }
    
    /* Effectue la fusion entre les blocs de mémoires contigus */
    void freem_clean() {
      /* Cette fonction ne cessera pas de comparer deux blocs de la liste. Je déclare ces blocs */
        block_t *bloc1, *bloc2;
	char *pc1, *pc2; /* Les pointeurs respectifs des blocs 1 et 2 */
        unsigned int sc1,sc2; /* La taille des blocs 1 et 2 */
    
        bloc1 = free_memory.first;
	bloc2 = (bloc1)? bloc1 -> next : NULL;
	
	while (bloc1 && bloc2) { /* Tant que l'on peut encore fusionner deux blocs ... */
            pc1 = (char *) block_get_pointer(bloc1);
	    pc2 = (char *) block_get_pointer(bloc2);
	    
	    sc1 = get_size(bloc1);
	    sc2 = get_size(bloc2);
	    
	    if (pc1 + sc1 == pc2) { /* Si l'on doit fusionner... */
                block_list_block_del(&free_memory,bloc2); /* La bloc 2 devient inutile */
                bloc1 -> size = sc1 + sc2; /* On augmente la taille de la bloc 1. */
                bloc2 = bloc1 -> next;
	    } else {
	      bloc1 = bloc1 -> next;
	      bloc2 = (bloc1)? bloc1 -> next : NULL;
	    }
	    
	    
	}
    }
    
    /* Affiche sur la sortie standard l'état de free_memory */
    void freem_print() {
      printf("FM :");
      block_list_print(&free_memory);
      printf("\n");
    }


/*---------------------------------------------------------------------------------------------------------------*/
				  /* gestions des blocks occupés*/
/*---------------------------------------------------------------------------------------------------------------*/




/* Ajoute un nouveau bloc de mémoire allouée, pointant vers pointeur et de taille size. */
block_t *busym_add(void *pointeur, unsigned int size){
  block_t *bloc;
  bloc = newblock(pointeur,size);
  busym_block_add(bloc);
  return bloc;
}

/* Ajoute le bloc à la liste de blocksde blocs de mémoire allouée. */
void busym_block_add(block_t *block){
  block_t *a_block;
  a_block = busy_memory.first;
  
  if (!a_block) { /* Si la liste de blocksest vide */
        block_list_fist_add(&busy_memory,block);
  } else { /* Je cherche le premier bloc dont le pointeur est plus grand que celui du bloc à ajouter */
        while(a_block && block_get_pointer(a_block) < block_get_pointer(block)) {
	  a_block = a_block -> next;
	}
	
	/* Il y en a un, j'insère mon bloc avant lui */
        if (a_block) {
	  block_list_block_insert_before(&busy_memory,block,a_block);
	} else {
	  block_list_last_add(&busy_memory,block);
	}
  }
}


/* Supprime le bloc passé en paramètre. Retourne ECHEC si block n'existe pas */
int busym_block_del(block_t *block){
  return block_list_block_del(&busy_memory, block); 
}

/* Renvoie le block_t dont le pointeur est égal à celui passé en paramètre. Renvoie NULL si une telle block_t n'existe pas */
block_t *busym_search(void * pointeur){
  block_t *a_block = busy_memory.first;
  
  while (a_block) {
    if (block_get_pointer(a_block) == pointeur){
      return a_block;
    }
    a_block = a_block -> next;
  }
  return NULL;
}

/* Affiche sur la sortie standard l'état de type de memoire choisi*/
void memory_print(int free){
   

  if (free==1)
  {if (block_list_is_free(&free_memory))
  {printf("memoire disponible : %d \n ",BYTES_USER_MAX);
  return;
  }
	else{
		printf("la memoire disponible  :");
 	 	block_list_print(&free_memory);
  		printf("\n");
  		}
  }
  else 
    if (free==0)
      {if (block_list_is_free(&busy_memory))
  	{printf("memoire allouee   : 0 \n");
  	return;
       }
	else{
		printf("la memoire allouee  :");
 	 	block_list_print(&busy_memory);
  		printf("\n");
		return;
  	     }
    }
    else 
    {printf("type de memoire a afficher inconnu \n");
    return;
    }

}
/*---------------------------------------------------------------------------------------------------------------*/
