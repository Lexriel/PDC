#include <stdio.h>
#include <unistd.h>
#include <stdarg.h>
#include <stdlib.h>
#include "memoryblock.h"



/* Désalloue le pointeur passé en paramètre */
/* Retourn ECHEC en cas d'echec (ex: ce pointeur n'a jamais été alloué) */
int myfree(void * pointeur) {
    block_t *blocvise = busym_search(pointeur);
    int i;
    char *c;
    
    if (!blocvise) {
        return ECHEC;
    } else {
        /* On déménage le bloc dans la liste des blocs libres */
        c = block_get_pointer(blocvise);
        
        for (i = 0;  i < get_size(blocvise); i++){
        	*(c+i)='0';
        }
        
        busym_block_del(blocvise);
        freem_block_add(blocvise);
        freem_clean();
    }
    
    return SUCCES;
}
