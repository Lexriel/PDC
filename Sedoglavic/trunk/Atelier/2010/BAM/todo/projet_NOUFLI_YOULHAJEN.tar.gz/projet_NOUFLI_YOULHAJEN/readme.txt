Bibliotheque d allocation d allocation memoire:

Auteurs :

Noufli Larbi

Youlhajen jamal dine 
        


----------
CONTENU:

dans ./:

makeFile : pour compiler
bam_test.c  : pour effectuer quelques test sur les fonctions  en dessous


DANS src/ :

mymalloc.c .h
myfree.c .h
mycalloc.c .h
myreaalloc.c .h

memoryblock.c .h : contient l ensemble de fonctions pour gerer les blocs de memoire:
						BYTES_USER_MAX :PARAM



-------------------------------------------------------------------------------

pour plus infos : voir fichhier pdf.



