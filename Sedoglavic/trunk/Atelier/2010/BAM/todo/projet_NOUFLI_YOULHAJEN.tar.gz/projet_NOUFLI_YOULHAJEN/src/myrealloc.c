#include <stdio.h>
#include <unistd.h>
#include <stdarg.h>
#include <stdlib.h>
#include "memoryblock.h"
#include "myfree.h"
#include "mymalloc.h"



/* Réalloue un espace attribué par un précédent malloc, à une nouvelle taille size */
void *myrealloc (void *pointeur, unsigned int size) {
    void *nouvellezone;
    char *p_old_a,*p_new_a;
    unsigned int i;
    
    /* Cas spéciaux */
    if (pointeur == NULL) {
        return mymalloc(size);
    }
    
    if (size == 0) {
        myfree(pointeur);
        return NULL;
    }
    
    /* recopie sur le nouvelle zone le contenu qui était pointé par pointeur */
    nouvellezone = mymalloc(size);
    p_old_a = (char *) pointeur;/*pointeur vers l ancienne zone*/
    p_new_a = (char *) nouvellezone;/*pointeur vers la nouvelle zone*/
    
    /* on copie la zone  pointée par p_old_a dans la zone pointée par p_new_a*/
    for (i = 0; i < size ; i ++) {
        *p_new_a = *p_old_a;
        p_new_a++;
        p_old_a++;
    }
    
    /* liberation de  l'ancienne zone */
    myfree(pointeur);
    return nouvellezone;
}
