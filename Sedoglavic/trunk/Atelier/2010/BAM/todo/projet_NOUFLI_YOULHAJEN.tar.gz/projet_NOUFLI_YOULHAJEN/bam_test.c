/* Bam.c
 * Ma bibliothèque d'allocation dynamique de mémoire 
 */

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>

#include "src/memoryblock.h"

#include "src/myfree.h"
#include "src/mymalloc.h"
#include "src/mycalloc.h"
#include "src/myrealloc.h"


struct variable_m
    {
        char nom[20];       /* Taille du bloc */   
	int memo;
    };

typedef struct variable_m variable_t;

variable_t tab[10][2];


int print_all_memory()
{
    memory_print(1);    
    memory_print(0);
    return SUCCES;
}

int test3(){
    
    void *a;
    void *b;
       printf(" ----------------------------  test :  ---------------------------\n \n");
  printf("         project C - Ma bibliotheque d''allocation de la memoire\n");
  printf("         cree par le binome : NOUFLI Larbi & YOULHAJEN Jamal dine \n");
  printf("                    Licence 3 informatique Groupe2 \n");
      printf(" --------------------------------------------------------------\n \n");
    
    print_all_memory();
    
    a = malloc(10);
    
    print_all_memory();  
    
    b = malloc(200);
    
    print_all_memory();
    
    free(a);
    
    print_all_memory() ;
    
    free(b);
    
    print_all_memory(); 
    
    exit(EXIT_SUCCESS);
} 


int test2()
{


void *a;
void *b;
   printf(" ----------------------------  test :  ---------------------------\n \n");
  printf("         project C - Ma bibliotheque d''allocation de la memoire\n");
  printf("         cree par le binome : NOUFLI Larbi & YOULHAJEN Jamal dine \n");
  printf("                    Licence 3 informatique Groupe2 \n");
      printf(" --------------------------------------------------------------\n \n");
    
  printf(" #Au debut :memoire libre 10000 , memoire occuppe: 0 ;   void *a; \n");
  /* tester le malloc :qd on demande une memoire libre disponible, et quand  */
  a = malloc(1);   
    printf(" #apres :   a = malloc(1); \n");
  memory_print(1);    
  memory_print(0);
  printf(" #ensuite :      b = malloc(10006);  \n");
  b = malloc(10006); 
    print_all_memory();
  printf(" #et puis :  free(a); \n");   
  free(a);
    print_all_memory();
 printf(" #enfin :     b = realloc(b,100);  \n");  
  b = realloc(b,100); 
    print_all_memory();

  exit(EXIT_SUCCESS);
}





int main (int argc, char const *argv[])
{
   test2();
  /*test3();*/
  
    exit(EXIT_SUCCESS);
}
