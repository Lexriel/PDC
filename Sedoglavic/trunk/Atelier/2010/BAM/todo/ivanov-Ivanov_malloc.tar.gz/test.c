#include "mymalloc.h"



int 
main
(void)
{

  int *ipt,*yes;
  char *cpt;
  
  cpt=(char *)mymalloc(sizeof(char));
  ipt=(int *)mymalloc(sizeof(int));
  yes=(int *)mymalloc(sizeof(int)*10);
  ipt=mrealloc(ipt,sizeof(int)*100);
  ipt=mrealloc(ipt,0);
  
  mfree(ipt);
  mfree(yes); 
  mfree(cpt);
  
  return 0;
}
