#define MEMSIZE 10*1024*1024
 
extern void* mymalloc (unsigned int size);
extern void mfree (void *ptr);
extern int mallopt(int cmd,int val);
extern void* mrealloc (void* ptr,unsigned size);
