#include <stdio.h>
#include "listeDC.h"

int main (void) {
  liste_t l;
  element_t e, f, g, h;

  l = NULL;


  e = makeElement(1);
  h = makeElement(4);
  g = makeElement(3);
  f = makeElement(2);

  insert(&l, &e);
  afficher(l);
  insert(&l, &g);
  afficher(l);
  insert(&l, &f);
  afficher(l);
  insert(&l, &h);
  afficher(l);

  delete (&l, &g);
  afficher(l);
  afficher(&g);

  return 0;
}
