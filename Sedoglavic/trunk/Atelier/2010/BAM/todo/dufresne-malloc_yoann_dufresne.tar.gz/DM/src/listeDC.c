#include <stdio.h>
#include <stdlib.h>
#include "listeDC.h"



/* Definition des fonctions */

element_t makeElement (int s) {
  element_t e;
  e.next = NULL;
  e.previous = NULL;
  e.size = s;
  return e; 
}

liste_t getNext (liste_t l) {
  return l->next;
}

liste_t getPrevious (liste_t l) {
  return l->previous;
}

unsigned int getSize (element_t e) {
  return e.size;
}

/* Insere au bon endroit (tri par adresse d'element */
void insert (liste_t * l, element_t * p_e) {
  liste_t copie;

  copie = *l;

  if (*l == NULL) {
    *l = p_e;
    return ;
  }

  while (copie->previous != NULL) {
    copie = copie->previous;
  }

  if (copie > p_e) {
    *l = p_e;
    p_e->next = copie;
    copie->previous = p_e;
  } else {
    while ((copie->next != NULL) && (copie->next < p_e)) {
      copie = copie->next;
    }

    p_e->previous = copie;
    p_e->next = copie->next;
    if (copie->next != NULL) {
      (copie->next)->previous = p_e;
    }
    copie->next = p_e;
  }
}




void delete (liste_t * l, element_t * e) {
  liste_t copie;

  copie = *l;

  if ((copie == NULL) || (copie->next == copie)) {
    e->next = NULL;
    e->previous = NULL;
    *l = NULL;
    return ;
  }

  while (copie->previous != NULL) {
    copie = copie->previous;
  }

  while ((copie != e) && (copie != NULL)) {
    copie = copie->next;
  }

  if (copie != NULL) {
    if (*l == copie) {
      *l = (*l)->next;
    }

    if (copie->previous != NULL) {
      (copie->previous)->next = copie->next;
    }
    if (copie->next != NULL) {
      (copie->next)->previous = copie->previous;
    }
  }

  e->next = NULL;
  e->previous = NULL;
}



void afficher (liste_t l) {
  liste_t copie;

  if (l == NULL) {
    printf("liste vide\n");
    return;
  }
  
  copie = l;

  while (copie->previous != NULL) {
    copie = copie->previous;
  }

  while (copie != NULL) {
    printf("%d [%u] <> ", copie->size, copie);
    copie = copie->next;
  }

  printf("\n");

}
