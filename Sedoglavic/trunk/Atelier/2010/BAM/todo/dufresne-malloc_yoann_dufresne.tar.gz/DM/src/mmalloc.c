#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include "listeDC.h"
#include "mmalloc.h"

#define TAILLE_DEMANDE 1000


char * memoryZone;
liste_t alloues;
liste_t libres;
unsigned int taille;

/* Decoupe un element en deux dont la taille du premier element est passee en parametre */
void decouper (element_t *, unsigned int);
element_t * estDisponible (unsigned int);
void fusionner (element_t *, element_t *);


void * mmalloc (unsigned int taille) {
  element_t * p_el, * save;
  int ancienneTaille;
  char * p_retour, * newMemoryZone, * retour;

  p_el = (element_t *) estDisponible (taille);
  if (p_el) {
    decouper(p_el, taille);
    delete(&libres, p_el);
    insert(&alloues, p_el);
    retour = (char *) (sizeof(element_t) + (int) p_el);
    return retour;
  } else {
    ancienneTaille = taille;
    
    while (!estDisponible (taille)) {
      /* Creation d'un nouvel espace memoire */
      newMemoryZone = (char *) sbrk (TAILLE_DEMANDE * sizeof(char));
      if (memoryZone == NULL) {
	memoryZone = newMemoryZone;
      }
      
      /* Insertion des infos dans le nouvel espace memoire */
      p_el = (element_t *) newMemoryZone;
      *p_el = makeElement(TAILLE_DEMANDE - sizeof(element_t));
      insert(&libres, p_el);
      if (p_el->previous != NULL)
	save = p_el->previous;

      fusionner(p_el->previous, p_el);

      if (save != NULL)
	p_el = save;
    }

    /* Renvoie de la zone allouable */
    decouper(p_el, taille);
    delete (&libres, p_el);
    insert(&alloues, p_el);

    p_retour = (char *) (sizeof(element_t) + (int) p_el);
    return p_retour;
  }

  return NULL;
}



void mfree (void * ptr) {
  liste_t copie, aSupprimer;

  aSupprimer = (liste_t) ((char *) ptr - sizeof(element_t));

  copie = aSupprimer ;
/*   copie = alloues; */
/*   while (copie) { */
/*     if (copie == aSupprimer) { */
      delete (&alloues, copie);
      insert (&libres, copie);
      fusionner(copie->previous, copie);
      fusionner(copie, copie->next);
      return ;
/*     } */
/*     copie = copie->next; */
/*   } */
}



element_t * estDisponible (unsigned int size) {
  liste_t copie;

  copie = libres;

  if (copie != NULL) {
    do {
      if (copie->size >= size) {
	return copie;
      }
      copie = copie->next;
    } while (copie != NULL);
  }
  
  return NULL;
}




/* Ne remplis pas son office */
void afficherPlageMemoire () {
  int i;
  
  for (i = 0 ; i < taille ; i++) {
    printf ("[%c]", memoryZone[i]);
  }

  printf("\n");
}



/* Ne remplis pas son office */
void afficherOccupation () {
  int i;
  char c;
  
  for (i = 0 ; i < taille ; i++) {
    if (memoryZone[i] == 0) {
      c = ' ';
    } else {
      c = 'x';
    }
    
    printf ("[%c]", c);
  }
  
  printf("\n");
}


void decouper (element_t * p_el, unsigned int size) {
  int taillePremier;
  element_t * suivant, * premier, * second;
  
  if (p_el) {
    printf("size : %u\n", p_el->size);
    if (p_el->size >= (sizeof(element_t) + size)) {
      taillePremier = sizeof(element_t) + size;
      
      suivant = p_el->next;
      premier = p_el;
      second = (element_t *) ((char *) p_el + size + sizeof(element_t));
      
      /* Construction du deuxieme element */
      *second = makeElement (p_el->size - taillePremier);
      second->next = p_el->next;
      second->previous = premier;
      if (suivant != NULL) {
	suivant->previous = second;
      }
      
      /* Rectification premier element */
      premier->next = second;
      premier->size = size;
    }
  }
}



void fusionner (element_t * p_el1, element_t * p_el2) {
  if (!p_el1 || !p_el2)
    return ;


  if ((element_t *) ((char *) p_el1 + p_el1->size + sizeof(element_t)) == p_el2) {
    p_el1->size += p_el2->size + sizeof(element_t);

    delete(&libres, p_el2);
  }
}


void tests() {
  afficher(libres);
  afficher(alloues);
}
