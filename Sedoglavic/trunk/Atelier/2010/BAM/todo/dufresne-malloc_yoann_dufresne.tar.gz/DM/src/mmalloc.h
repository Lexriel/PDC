

void * mmalloc (unsigned int);
void afficherPlageMemoire ();
void afficherOccupation ();
void tests ();
void mfree (void *);
