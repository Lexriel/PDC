#include <stdlib.h>
#include <stdio.h>

void imprimer (char * s, int taille) {
  int i;
  for (i = 0 ; i < taille ; i++) {
    printf ("[%c]", s[i]);
  }
  printf ("\n");
}

int main (void) {
  char * s;


  s = (char *) sbrk (4);
  printf("%u\n", s);
  s = (char *) sbrk (4);
  printf("%u\n", s);

  return 0;
}
