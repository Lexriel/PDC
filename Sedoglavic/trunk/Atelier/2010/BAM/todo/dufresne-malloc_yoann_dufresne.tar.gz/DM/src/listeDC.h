/* Declarations */

struct element_m {
  unsigned int size;
  struct element_m * next;
  struct element_m * previous;
};
typedef struct element_m element_t;
typedef element_t * liste_t;




/* Element maker */
element_t makeElement (int) ;

/* Function to acces next */
liste_t getNext (liste_t);

/* Function to acces previous */
liste_t getPrevious (liste_t);

/* Function to acces size */
unsigned int getSize (element_t);

/* Function to insert a new element before an already exist in list */
void insertBefore (liste_t *, element_t *);

/* Function to insert a new element after an already exist in list */
void insertAfter (liste_t *, element_t *);

void insert (liste_t *, element_t *);

/* Function to delete an element in the list */
void delete (liste_t *, element_t *);

/* Function to print list */
void afficher (liste_t);

void free (void *);
