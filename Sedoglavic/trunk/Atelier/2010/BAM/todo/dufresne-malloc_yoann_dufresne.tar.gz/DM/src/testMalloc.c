#include <stdio.h>
#include "mmalloc.h"


int main (void) {
  char * maVariable, * maSecondeVariable, * maTroisiemeVariable;

  maTroisiemeVariable = (char *) mmalloc (1000 * sizeof(char));

  maVariable = (char *) mmalloc (1000 * sizeof(char));

  maSecondeVariable = (char *) mmalloc (1000 * sizeof(char));

  tests();

  mfree(maVariable);
  mfree(maSecondeVariable);
  mfree(maTroisiemeVariable);

  printf("\n");
  tests();
  
  getchar();

  return 0;
}
