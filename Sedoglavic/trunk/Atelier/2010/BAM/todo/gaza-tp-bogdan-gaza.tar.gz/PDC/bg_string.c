#include<stdlib.h>
#include<stdio.h>

#include "bg_malloc.h"
#include <string.h>
#include "tools.h"

/* strcpy with memory alocation detection */
char * bg_strcpy(char *s1, const char *s2){
  int i;
  int len;

  bg_check_addr((void *)s1);
  bg_check_addr((void *)s2);

  len = strlen(s2);

  for(i=0;i<=len;i++){
    s1[i]=s2[i];
  }
  return NULL;
}

/* memory cpy with unalocated pointer detection */
char * bg_memcpy(void *s1,void *s2,size_t n){
  char *p1 = (char *)s1;
  char *p2 = (char *)s2;
  int i;

  bg_check_addr(s1);
  bg_check_addr(s2);

  for(i=0;i<n;i++){
    p1[i]=p2[i];
  }

  return NULL;

}
