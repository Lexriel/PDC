#ifndef _BG_STRING_H
#define _BG_STRING_H

/* functions that have build in checker for pointers */
char * bg_strcpy(char *, const char *);
char * bg_memcpy(void *,void *,size_t);

#endif
