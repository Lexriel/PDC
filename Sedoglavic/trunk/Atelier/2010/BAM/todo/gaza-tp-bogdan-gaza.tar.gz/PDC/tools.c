/*
 * @author Bogdan Gaza - 7 Dec 2010
 * BG's (Bogdan Gaza) Malloc implementation
 * PDC TP Project
 * tools.c - Tools to manage memory structures
 */

#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>

#include "bg_malloc_memory.h"

/* chunck of 10 */
#define BG_BLOCK_MAP_CHUNCK 9000

struct block_map_s {
  block_t *b_map;
  int size;
};

typedef struct block_map_s block_map_t;

static int sbrk_count;

block_map_t map;

void * bg_get_memory(block_t *memory,size_t s,int *rem);
block_t * bg_alocate_get_block();

void bg_alocate_small_size(block_t *memory,int size,int count){
  block_t *n_block;
  int i;
  void *p;
  
  p = sbrk(size*count);
  for(i=0;i<count;i++){
    n_block = bg_alocate_get_block();
    n_block->size = size;
    n_block->block_type = FREE_BLOCK;
    n_block->next = memory->next;
    n_block->prev = memory;
    
    if(memory->next != NULL)
      memory->next->prev = n_block;

    memory->next = n_block;
  }
}

void bg_alocate_block_map(int size,int nb){
  /* calls sbrk to alocate another BG_BLOCK_MAP_CHUNCK
   * of block_t */
  int count = BG_BLOCK_MAP_CHUNCK;
  if(size != 0)
    count += size * nb;

  map.b_map = sbrk(sizeof(block_t) * BG_BLOCK_MAP_CHUNCK);
  map.size = 0;

  sbrk_count = 0;
}

block_t * bg_alocate_get_block(){
  map.size++;
  return &map.b_map[map.size-1];
}

void * bg_add_memory(block_t *memory, size_t s, int *rem,int *add){
  int size;
  void *p;
  block_t *n_block;
  block_t *n_block_two;

  if(s <= BG_MALLOC_MIN_SIZE){
    size = BG_MALLOC_MIN_SIZE;
  }else{
    size = s + BG_MALLOC_MIN_SIZE;
  }
  
  n_block = bg_alocate_get_block();

  p = sbrk(size);

  sbrk_count += 1;

  n_block->size = s;
  n_block->block_type = RESERVED_BLOCK;
  n_block->addr = p;
  n_block->next = memory->next;
  n_block->prev = memory;
  if(memory->next != NULL)
    memory->next->prev = n_block;

  n_block->chunck = sbrk_count;


  if(memory->size == 0){
    memory->next = n_block;
    memory->size = size - s;
    memory->addr = (char *)p + s;

    memory->chunck = sbrk_count;
  }else{
    n_block_two = bg_alocate_get_block();

    n_block_two->size = size-s;
    n_block_two->block_type = FREE_BLOCK;
    n_block_two->addr = (char *)p + s;
    n_block_two->next = n_block;
    n_block_two->prev = memory;
    n_block->prev = n_block_two;

    n_block_two->chunck = sbrk_count;

    memory->next = n_block_two;
  }

  *rem = size -s;
  *add = size;

  return p;
}

/* search first free block of memory with the size s
 * return address to block of memory */
void * bg_get_memory(block_t *memory,size_t s,int *rem){
  /* pointer to return with the memory block */
  void *p;
  /* flag to see if free memory was found */
  int found = 0;
  block_t *tmp = memory;
  /* new block */
  block_t *n_block;
  while(tmp != NULL){
    /* if memory block is free and has the required size
     * then return the address of the block */
    if(tmp->block_type == FREE_BLOCK && tmp->size >= s){
      p = tmp->addr;
      /* mark the block as found */
      found = 1;
      /* create new node and mark it as reserved */
      n_block = bg_alocate_get_block();
      n_block->size = s;
      n_block->block_type = RESERVED_BLOCK;
      n_block->addr = p;
      n_block->next = memory->next;
      n_block->prev = memory;
      n_block->chunck = memory->chunck;

      if(memory->next != NULL)
        memory->next->prev = n_block;

      memory->next = n_block;
      memory->size -= s;
      memory->addr = (char *)memory->addr + s;

      *rem = *rem - s;
      break;
    }
    tmp = tmp->next;
  }

  if(found == 1){
    return p;
  }

  return NULL;
}

void bg_check_addr(void *ptr){
  int i;
  int found = 0;

  for(i=0;i<map.size;i++){
    if(map.b_map[i].addr <= ptr && (char *)ptr <= ((char *)map.b_map[i].addr+map.b_map[i].size)){
      found = 1;
    }
  }

  if(found == 0){
    fprintf(stderr,"Invalid pointer");
    exit(EXIT_FAILURE);
  }
}
