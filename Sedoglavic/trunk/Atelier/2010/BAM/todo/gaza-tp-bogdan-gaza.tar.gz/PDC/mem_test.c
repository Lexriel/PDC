#include<stdlib.h>
#include<stdio.h>
#include<string.h>

#include "bg_malloc.h"
#include "bg_string.h"

int main(){
  char *c = malloc(1024);
  char *d = malloc(1024);
  char *p;

  strcpy(c,"HELLOWORLD");
  /* works */
  bg_memcpy((void *)d,(void *)c,strlen(c)+1);

  /* fails */
  bg_memcpy((void *)p,(void *)c,strlen(c)+1);


  return 0;
}
