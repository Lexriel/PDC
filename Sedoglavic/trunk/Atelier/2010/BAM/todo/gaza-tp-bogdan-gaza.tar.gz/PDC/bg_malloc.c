/*
 * @author Bogdan Gaza - 7 Dec 2010
 * BG's (Bogdan Gaza) Malloc implementation
 * PDC TP Project
 */

#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>
#include<string.h>

#include "bg_malloc.h"
/* header file for memory structures */
#include "bg_malloc_memory.h"
#include "tools.h"

/* block_t of memory - first element in linked list */
block_t memory;

/* flags to store the free and total memory
 * used to check if the local memory structure is
 * correct */
static int free_memory;
static int total_memory;

void print();
void print_debug();

static int maxfast = 0;
static int numblks = 100;
static int malloc_calls;

/*
 *
 */
void * bg_malloc_normal(size_t size, char *filename, unsigned line){
    /* first call to initialize memory structures */
  static int first_call = 1;
  /* pointer to be returned to the user */
  void *p = NULL;
  /* store the added memory if necessary */
  int added_memory;
  
  /* first call of malloc */
  if(first_call){
    first_call = 0;

    /* free and total memory are the minimum allocated
     * size */
    free_memory = BG_MALLOC_MIN_SIZE;
    total_memory = BG_MALLOC_MIN_SIZE;

    /* first block of memory has the size of the
     * minimum memory allocated */
    memory.size = free_memory;
    /* first block is always free */
    memory.block_type = FREE_BLOCK;
    /* allocate the min memory */
    memory.addr = sbrk(BG_MALLOC_MIN_SIZE);
    /* memory has no next element */
    memory.next = NULL;
    memory.prev = NULL;

    memory.chunck = 0;

    if(maxfast != 0){
      bg_alocate_small_size(&memory,maxfast,numblks);
    }
  }

  /* check if free memory is larger than required memory */
  if(size <= free_memory){
     p = bg_get_memory(&memory,size,&free_memory);
     /* block of memory large enough not found */
     if(p == NULL){
       p = bg_add_memory(&memory,size,&free_memory,&added_memory);
     }
  }else{
    /* if there is not enough free memory alocate a new 
     * memory block */
     p = bg_add_memory(&memory,size,&free_memory,&added_memory);
  }

  return p;
}


void bg_free(void *p, char *filename, unsigned line){
    /* search the memory structure for address p */
  block_t *t = &memory;
  block_t *current;
  int found = 0;
  int current_block;


  while(t!=NULL){
    if(t->addr == p && t->size != 0){
      t->block_type = FREE_BLOCK;
      found = 1;
      /* merge left */
      break;
    }
    t = t->next;
  }

  if(found == 1){
    current_block = t->chunck;
    current = t;

    t = current->prev;

    while(t != NULL && t->chunck == current_block){
      if(t->block_type != FREE_BLOCK) break;

      if(t->prev != NULL){
        t->prev->next = current;
        current->prev = t->prev;
        current->size += t->size;
      }else{
        memory.next = current->next;
        if(current->next != NULL) current->next->prev = &memory;
        memory.size += current->size;
        current = &memory;
      }
      
      t = t->prev;
    }

    t = current->next;
    
    while(t != NULL && t->chunck == current_block){
      if(t->block_type != FREE_BLOCK) break;
      current->next = t->next;
      t->next->prev = current;
      current->size += t->size;
      current->addr = t->addr;
      t = t->next;
    }

  }

}

/*
 *
 */
int mallopt(int cmd,int val){
  if(malloc_calls != 0){
    return -1;
  }

  if(cmd == M_MXFAST){
    maxfast = val;
  }else if(cmd == M_NLBLKS){
    numblks = val;
  }

  return 0;
}

void * bg_malloc(size_t size, char *filename, unsigned line){
  static int first_call = 0;

  if(first_call == 0){
    first_call = 1;
   
    bg_alocate_block_map(maxfast,numblks);
  }

  return bg_malloc_normal(size,filename,line);
}

void * bg_calloc(size_t count,size_t size,char *file,unsigned line){
  
  void *p;
  int i;
  int total;

  p = malloc(count*size);

  total = size*count;
  for(i=0;i<total;i++){
    *((char *)p+i) = 0;
  }
  return p;
}

void * bg_realloc(void *ptr,size_t size,char *file,unsigned line){
  
  void *p = bg_malloc(size,file,line);
  int i;

  if(ptr == NULL){
    return p;
  }

  for(i=0;i<(int)size;i++){
    *((char *)p + i) = *((char *)ptr + i);
  }


  return p;
}

/*
 * DEBUG FUNCTIONS
 *
 */

/* print memory state */
void print(){
  block_t *tmp = &memory;
  while(tmp != NULL){
    printf("Type: %d, Size %d Addr %p Chunck %d => ",(int)tmp->block_type,(int)tmp->size,tmp->addr,tmp->chunck);
    tmp = tmp->next;
  }
}

void check_memory(){
  block_t *tmp = &memory;
  block_t *prev;

  prev = NULL;

  while(tmp != NULL){
    if(prev != tmp->prev){
      fprintf(stdout,"Problem with linked-list");
    }

    prev = tmp;

    tmp = tmp->next;
  }
  printf("MEMORY OK!");
}

void print_debug(){
  block_t *tmp = &memory;
  printf("PRINT DEBUG STARTED\n");

  while(tmp != NULL){
    printf("Current %p, Type: %d, Size %d Addr %p Chunck %d Prev %p Next %p \n",(void *)tmp,(int)tmp->block_type,(int)tmp->size,tmp->addr,tmp->chunck,(void *)tmp->prev,(void *)tmp->next);
    tmp = tmp->next;
  }
  printf("\n");
}
