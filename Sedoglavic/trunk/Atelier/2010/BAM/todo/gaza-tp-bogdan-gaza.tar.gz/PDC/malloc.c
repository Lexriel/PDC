#include <stddef.h>
#include "bg_malloc.h"

/* Forget definition of malloc wrappers */
#ifdef malloc
#undef malloc
#undef free
#undef realloc
#endif

/* Redefinition of malloc () */
void *
malloc (size_t size)
{
    return bg_malloc(size, (char *)0, 0); 
}

/* Redefinition of free () */
void
free (void *ptr) 
{
    bg_free(ptr, (char*) 0, 0); 
}

void *
realloc (void *ptr, size_t size){
  return bg_realloc(ptr,size, (char *)0, 0); 
}
