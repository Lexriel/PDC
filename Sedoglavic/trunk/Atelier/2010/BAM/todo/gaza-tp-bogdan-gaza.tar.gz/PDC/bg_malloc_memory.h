#ifndef _BG_MALLOC_MEMORY_H
#define _BG_MALLOC_MEMORY_H

/* types of memory blocks */
enum block_t {FREE_BLOCK=0,RESERVED_BLOCK=1};

/* linked list prototype */
struct block_s {
  unsigned int size;
  enum block_t block_type;
  void * addr;
  struct block_s * next;
  struct block_s * prev;
  int chunck;
};

typedef struct block_s block_t;

#define BG_MALLOC_MIN_SIZE 1024

#endif
