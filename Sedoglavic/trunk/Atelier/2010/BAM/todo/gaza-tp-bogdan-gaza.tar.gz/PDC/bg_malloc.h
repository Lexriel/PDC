#ifndef _BG_MALLOC_H
#define _BG_MALLOC_H

#define M_MXFAST 1
#define M_NLBLKS 2

void * bg_malloc(size_t , char *,unsigned );
void bg_free(void *ptr, char *filename, unsigned line);

int mallopt(int, int);

void * bg_calloc(size_t,size_t,char *,unsigned);
void * bg_realloc(void *,size_t, char *,unsigned);

void print_debug();
void check_memory();

#define malloc(size) bg_malloc(size, __FILE__, __LINE__)
#define free(p) bg_free(p, __FILE__, __LINE__)
#define calloc(size,sz) bg_calloc(size,sz,__FILE__,__LINE__)
#define realloc(ptr,size) bg_realloc(ptr,size,__FILE__,__LINE__)

#endif
