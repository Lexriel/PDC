#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "bg_malloc.h"

#define NMAX 10

#define R_STR "HELLOWORLD"

int main(){
  char *s, *p;
  int *m;
  int i;

  s = (char *)malloc(strlen(R_STR)); /* alocate string */
  
  strcpy(s,R_STR); /* copy dummy string into buffer */

  p = strdup(s); /* malloc call here ? */

  printf("%s \n\n%s\n",s,p); /* show strings */

  print_debug(); /* print memory map before free */

  free(s);
  free(p);


  print_debug(); /* print memory map */
  check_memory(); /* check memory map */

  srand ( time(NULL) );

  printf("\n");
  m = (int *)calloc(NMAX, sizeof(int)); /* alocate array */
  for(i=0;i<NMAX;i++){
    m[i] = rand() % 1000; /* fill it with random numbers */
    printf("%d ",m[i]);
  }
  printf("\n");
  m = (int *)realloc(m,2 * NMAX * sizeof(int)); /* relocate array */
  for(i=0;i<NMAX;i++){
    printf("%d ",m[i]); /* printf array */
  }
  printf("\n");
  print_debug(); /* print memory map before free */
  check_memory();

  free(m);

  print_debug(); /* print final memory map */
  return 0;
}
