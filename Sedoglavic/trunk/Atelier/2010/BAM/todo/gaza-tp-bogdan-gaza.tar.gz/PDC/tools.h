#ifndef _BG_MALLOC_TOOLS_H
#define _BG_MALLOC_TOOLS_H

#include "bg_malloc_memory.h"

void * bg_add_memory(block_t *,size_t,int *,int *);
void * bg_get_memory(block_t *,size_t,int *);

void bg_alocate_block_map(int,int);

void bg_alocate_small_size(block_t *,int ,int);

void bg_check_addr(void *);

#endif
