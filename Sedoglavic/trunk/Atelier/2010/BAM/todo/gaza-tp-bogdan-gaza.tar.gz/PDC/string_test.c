#include<stdlib.h>
#include<stdio.h>
#include<string.h>

#include "bg_malloc.h"
#include "bg_string.h"

int main(){
  char *c = malloc(1024);
  char *d = malloc(1024);
  char *p;

  strcpy(c,"HELLOWORLD");
  /* works */
  bg_strcpy(d,c);

  /* fails */
  bg_strcpy(p,c);


  return 0;
}
