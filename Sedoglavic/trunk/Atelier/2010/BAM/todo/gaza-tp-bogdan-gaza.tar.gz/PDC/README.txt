# Author Bogdan Gaza
# Groupe 2
# L3S5
# Erasmus
# Language: English

Project ideas:

You have a list of memory blocks like:
First of all by default:
no malloc  : 1000Free
malloc(100): 100 R - 900 Free
malloc(100): 100 R - 100 R - 800 Free
malloc(100): 100 R - 100 R - 100R - 700 Free

free(2nd 100): 100 R - 100 Free - 100R - 700 Free

Keep a trace of all malloc calls.
If blocks of the same sbrk block then merge
=====

Implementation details:
---------------------

HEADERS
=======
bg_malloc.h = Header to load, includes macros for malloc/free/calloc/realloc
bg_malloc_memory.h = Shared header for bc_malloc and tools
bg_string.h = Header in witch strcpy and memcpy - Proof of Concept for pointer
              verification
tools.h = Header of different tools - actual sbrk is done here

SOURCE FILES
===========
bg_malloc.c = Source file in witch malloc/free/calloc/realloc/print_debug/check_memory/mallopt are defined
tools.c = Different tools used by bg_malloc
bg_string.c = Source for strcpy, memcpy Proof of Concept
mem_test.c and string_test.c = Source of binary used for testing memcpy/strcpy
main.c = Source of main binary used to show  an example of using the implement malloc/free/realloc/calloc

DETAILS
=======
Malloc: checks if mallopt was called.
        allocates a linked list in witch it keeps track of diferent memory segments.
        For all segments of the same sbrk block the CHUNCK param in the linked list is the same.
        Keeps track of free and total memory used. If free_memory < required it does not search for
        the block it adds it directly.
        If free_memory > required than it researched the block. It it finds cuts the block to necessary
        length and returns address. If not it adds it.
        Used algorithm: first-fit
Free: frees memory.
      Checks in the linked-list if prev and next are of the same CHUNCK described earlier. merges it into
      one big block.
      List used is double it has next and prev. It keeps the right state of the memory linked list.
Mallopt: modified global static variables
Calloc/Realloc: uses malloc to make the necessary functionality
Realloc: it uses malloc, free and a simple copy algorithm
Strcpy/Memcpy: Use a tool defined in the tools.c that searched if a pointer is in the memory list
               between addr and addr+size. If it does not find, it exists and shows and error to stderr
Print_debug: shows the current state of the linked list. All details are present like next and prev address
             to check for problems.
Check_memory: it automatically checks memory for prev/next problems in the linked list.

This library uses macros, a library will be tried to be created at the TP. Development done on a MAC and
.so generation flags are totally different and not cross-platform.

USAGE
=====
make - to compile the software
./main to test the library
./mem_test to test the memcpy
./string_test to test the strcpy

KNOWN ISSUES
============
Some problems regarding the .so library and freeing pointers next the the first element
