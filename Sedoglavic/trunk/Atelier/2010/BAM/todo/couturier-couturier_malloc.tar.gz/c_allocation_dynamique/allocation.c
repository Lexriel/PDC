#include "tools.h"
#include "allocation.h"
#ifdef malloc
#undef malloc
#undef free
#endif

void * malloc(unsigned int size)
{
  void * aRetourner;
  aRetourner = search_mem(size);
  if (aRetourner == NULL)
    {
      return alloue_mem(size);
    }
  return aRetourner;
}

void free(void * adresse)
{
  libere_memoire(adresse);
}
