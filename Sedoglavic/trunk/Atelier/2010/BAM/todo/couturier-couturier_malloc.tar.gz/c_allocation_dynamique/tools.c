#include "tools.h"
#include "allocation.h"
#include <stdio.h>

liste_chaine liste_mem;

void * search_mem(unsigned int size)
{
  liste_chaine * tmp;

  if (liste_mem.debut != NULL)
    {
      tmp = &liste_mem;
      while ((tmp->nb_octets < size) || (tmp->estAllouee == TRUE))
	{
	  tmp = tmp->suivant;
	  if (&(tmp->debut) == &(liste_mem.debut))
	    {
	      return NULL;
	    }
	}
      tmp->estAllouee = 1;
      return tmp->debut;
    }
  else
    {
      return NULL;
    }
}

void * alloue_mem(unsigned int size)
{
  char * tmp = (char*)sbrk(SBRK_ADD);
  char * aRenvoyer = tmp;
  ajout_liste_mem(tmp, size, TRUE);
  ajout_liste_mem(tmp+size, SBRK_ADD-size, FALSE);
  return aRenvoyer;
}

void ajout_liste_mem(void * adresse, unsigned int size, unsigned int estAllouee)
{
  liste_chaine * tmp;
  liste_chaine * aAjouter;

  if (liste_mem.debut == NULL)
    {
      liste_mem.debut = adresse;
      liste_mem.nb_octets = size;
      liste_mem.estAllouee = estAllouee;
      liste_mem.suivant = &liste_mem;
    }
  else
    {
      tmp = &liste_mem;
      while (&tmp->suivant->debut < &adresse)
	{
	  printf("while\n");
	  tmp = tmp->suivant;
	  if (&tmp->suivant->debut == &liste_mem.debut)
	    {
	      break;
	    }
	}
      aAjouter->suivant = tmp;
      tmp->suivant = &aAjouter;
      aAjouter->nb_octets = size;
      aAjouter->debut = adresse;
      aAjouter->estAllouee = estAllouee;;
    }
}

void fusionne_mem()
{
  liste_chaine * tmp;

  if ((liste_mem.debut != NULL) && (&liste_mem.debut != &liste_mem.suivant->debut))
    {
      tmp = &liste_mem;
      do {
	if ((tmp->estAllouee == 0) && (tmp->suivant->estAllouee == 0))
	  {
	    tmp->nb_octets += tmp->suivant->nb_octets;
	    tmp->suivant = tmp->suivant->suivant;
	  }
	tmp->debut = tmp->suivant;
      } while (tmp->suivant != liste_mem.debut);
    }
}

void libere_memoire(void * adresse)
{
  int stop = FALSE;
  liste_chaine * tmp = &liste_mem;

  while ((&tmp->debut != &adresse) && (stop == FALSE))
    {
      tmp = tmp->suivant;
      if (&(tmp->debut) == &(liste_mem.debut))
	{
	  stop = TRUE;
	}
    }
  if (stop == FALSE)
    {
      tmp->estAllouee = FALSE;
    }
}
