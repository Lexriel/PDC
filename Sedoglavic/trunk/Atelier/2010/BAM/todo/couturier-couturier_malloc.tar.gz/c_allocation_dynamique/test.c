#include "allocation.h"
#include "tools.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#define SUPER	"Supercalifragilisticexpialidocious\n"

int main(void)
{
  char *str, *strcp; 

  /* Un appel direct à malloc */
  str = malloc(strlen(SUPER)+10); /* pourquoi 9 de trop ? pourquoi pas ! */
  
  strcpy(str, SUPER) ; 
  
  printf("%s\n",str);
  /* Un appel a malloc dans cet appel */
  strcp = strdup(str); 
  
  /* Print is not debug, nevertheless */
  printf("%s\n%s\n", str, strcp); 
  
  /*  On libere la memoire allouee sur str est strcp*/

  /*char * tmp1 = (char*)malloc(20);*/
  free(str);
  free(strcp);
  /*free(tmp1);*/
  exit(EXIT_SUCCESS);
}
