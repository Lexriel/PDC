#ifndef ALLOCATION_H
#define ALLOCATION_H

void * malloc(unsigned int size);

void free(void * adresse);

#endif

