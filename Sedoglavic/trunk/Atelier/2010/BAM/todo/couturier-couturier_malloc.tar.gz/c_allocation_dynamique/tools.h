#ifndef TOOLS_H
#define TOOLS_H
#define SBRK_ADD 65536
#define TRUE 1
#define FALSE 0
#include <unistd.h>

/* La liste chainee qui permet de contenir les blocs
 * memoire de la bibliotheque.
 * -debut est l'adresse memoire du debut du bloc
 * -nb_octets est la taille en octet du bloc
 * -est_allouee est un booleen qui permet de savoir si le
 *  bloc a ete retourne a l'utilisateue ou non.
 * -suivant pointe sur le bloc suivant de la liste.
 */
typedef struct liste_chaine
{
  void *debut;
  int nb_octets;
  int estAllouee;
  struct liste_chaine *suivant;
}liste_chaine;

/* Recherche une zone memoire de taille size dns la liste
 * chainée et la retourne.
 * Retourne NULL sinon.
 */
void * search_mem(unsigned int size);


/* Execute sbrk et retourne un pointeur sur le debut
 * de la zone retournée par sbrk, de taille size.
 * Ajoute le reste de la memoire dans la liste.
 */
void * alloue_mem(unsigned int size);

/* Ajoute la memoire dont l'adresse est passée en parametre
 * dans la liste (parcours la liste et ajoute l'adresse
 * au bon endroit).
 * Fusionne les blocs qui peuvent être fusionnés.
 */ 
void ajout_liste_mem(void * adresse, unsigned int size, unsigned int estAllouee);

/* parcours la liste puis fusionne les blocs si possible */
void fusionne_mem();

/* utilisé pour free, met estAllouee a TRUE
 * l'adresse passée en paramètre doit avoir ete alloue par l utilisateur
 */
void libere_memoire(void * adresse);

#endif
