#include <stdlib.h>
#include <stdio.h>

typedef long Align; /* pour le cadrage sur un long */
union en_tete { /* bloc d'en tete : */
	struct {
		union en_tete *ptr; /* pointe sur le suivant si le bloc est dans la liste des blocs libres */
		unsigned taille; /* taille du bloc */
	} s;
	Align x; /* force l'alignement des blocs */
};

typedef union en_tete En_tete;


static En_tete base; /* liste vide pour commencer */
static En_tete *plibre = NULL; /* debut liste libre, memorise *pprec a chaque fois */

/* mfree : met le bloc pa dans la liste des blocs libres */
void mfree(void *pa) {
	En_tete *pb, *p;

	pb = (En_tete *)pa -1; /* pointe sur l'en tete */
	for (p=plibre; !(pb > p && pb < p->s.ptr); p=p->s.ptr)
		if (p >= p->s.ptr && (pb > p || pb < p->s.ptr))
			break; /* bloc libéré au debut ou a la fin */

	if (pb + pb->s.taille == p->s.ptr) {
		/* jointure par le haut */
		pb->s.taille += p->s.ptr->s.taille;
		pb->s.ptr = p->s.ptr->s.ptr;
	} else
		pb->s.ptr = p->s.ptr;

	if (p + p->s.taille == pb) {
		/* jointure par le bas */
		p->s.taille += pb->s.taille;
		p->s.ptr = pb->s.ptr;
	} else
		p->s.ptr = pb;

	plibre = p;
}


#define NALLOUE 1024 /* nombre d'unites demandees au minimum */

/* plusmem : demande plus de memoire au systeme */
static En_tete *plusmem(unsigned nu) {
	char *pc, *sbrk(int);
	En_tete *pu;

	if (nu < NALLOUE)
		nu = NALLOUE;
	pc = sbrk(nu * sizeof(En_tete));
	if (pc == (char *) -1) /* pas d'espace du tout */
		return NULL;
	pu = (En_tete *) pc;
	pu->s.taille = nu;
	mfree((void *) (pu+1));
	return plibre;
}



/* mmalloc : allocateur de memoire a usage general */
void *mmalloc(unsigned noctets) {
	En_tete *p; /* utile pour le for(), designe le pointeur que l'on retourne */
	En_tete *pprec; /* explore la liste, en commencant par plibre */
	En_tete *plusmem(unsigned);
	unsigned nunites;

	nunites = (noctets + sizeof(En_tete) - 1) / sizeof(En_tete) + 1;
	if ((pprec = plibre) == NULL) {
		/* il n'existe pas encore de liste */
		base.s.ptr = plibre = pprec = &base;
		base.s.taille = 0;
	}
	for (p = pprec->s.ptr; ; pprec = p, p = p->s.ptr) {
		if (p->s.taille >= nunites) {
			/* assez grand */
			if (p->s.taille == nunites)
				/* tout juste */
				pprec->s.ptr = p->s.ptr;
			else {
				p->s.taille -= nunites;
				p += p->s.taille;
				p->s.taille = nunites;
			}
			plibre = pprec;
			return (void *)(p+1);
		}
		if (p == plibre)
			/* liste libre rebouclee */
			if ((p = plusmem(nunites)) == NULL)
				return NULL; /* il n'en reste plus */
	}
}
