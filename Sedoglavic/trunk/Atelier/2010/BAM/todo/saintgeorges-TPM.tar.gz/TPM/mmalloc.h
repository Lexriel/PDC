void *mmalloc(unsigned noctets);
void mfree(void *pa);
