#include <stdlib.h>
#include <stdio.h>
#include "mmalloc.h"

int main(int argc, char *argv[]) {

	int *p, *q;

	p = (int *) mmalloc(sizeof(int));
	printf("p ok\n");

	*p = 7;

	q = (int *) mmalloc(sizeof(int));
	*q = 8;
	
	printf("p = %d\nq = %d\n", *p, *q);

	mfree(p);
	mfree(q);
	printf("liberation de p et q\n");
	

	printf("\n\n\n");
	return EXIT_SUCCESS;

}
