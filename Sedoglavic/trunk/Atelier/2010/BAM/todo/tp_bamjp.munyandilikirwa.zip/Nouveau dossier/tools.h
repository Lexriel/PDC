extern  void *mon_malloc(int);
extern  void* mon_free(void*);
extern  void *mon_calloc(int,int);
extern  void *realloc(void*,int);
extern  int mon_mallopt(int,int);
