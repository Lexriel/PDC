



#include<stdio.h>       
#include<stdlib.h>
#include<malloc.h>

/*  dans ce fichier et TP  il n y a pas  des fonctions sous forme de Macro */
 /*  dans ce fichier et TP  il n y a pas  des fonctions sous forme de Macro */
 
 
#define COEFF_TAILLE_MALLOC  (20)  /* taille constant utilis� pas malloc() pour demander une taille plus grande que celle demandee*/
#define COEFF_DIVISION_MEMOIRE_SUFFISANT (2)
struct un_block
{
char* taille_adresse;
int compteur_taille;   /*size*/
un_block *precedent;     
un_block * suivant;
/*il est a 0 si le block est libre*/
int status;

}

Struct block_void_m
{
 void * suivant;
 void * data;
}

typedef struct un_block block_m;

typedef block_m * block_memoire_t;
int le_DRAPEAU; /*ce drapeau est uniquement manipule par mon_malloc*/


/* pour mon_mallopt  avec l option d un certain nombre de block a respecter*/
block_memoire_t   liste_blocks_libre_non_optimisee ;


int  compteur_mallopt,le_Drapeau;    

void  *taleau_de_blk_optimisee;


/*pour l allocaton optimal mallopt */
le_Drapeau=0;/* uniquement manipuler par -calloc -mon_mallopt  */
compteur_mallopt=0;
taleau_de_blk_optimisee=NULL;



le_DRAPEAU=0;

/*---------------------------------------------------------------------------------------------------------------------------*/
block_memoire_t
creer_taille_espace_allouee
(int taille_demandee)
{
    /* le premier appel de malloc  utilise cette fonction  et cette fonction gere et conserve la taille qui reste apres sbrk()*/
    /* cette  liste creee peut etre rallongee si la taille demandee la enieme fois  est plus grande que celle gardee  ou conservee*/
	int taille_donnee_parSysteme;   block_memoire_t  blck_taille_octroyee_parSysteme;
	
	taille_donnee_parSysteme =0;
	blck_taille_octroyee_parSysteme=sbrk(sizeof(block_m));
	if (errno==-1)
			{
			return NULL;
			}
	                                       
	blck_taille_octroyee_parSysteme->taille_adresse =sbrk(taille_demandee); 
	if (errno==-1){
	             return NULL;
				  }
	
	blck_taille_octroyee_parSysteme->compteur_taille     =taille_demandee;
	blck_taille_octroyee_parSysteme->suivant     =NULL;
	blck_taille_octroyee_parSysteme->precedent =NULL;
	
	
	return blck_taille_octroyee_parSysteme;
  
					 
}

/*-------------------------------------------------------------------------------------------------------------------*/

block_m *
parcours_liste_au_dernier_block         /* la fonction restitue une adresse du dernier block qui contient la quantite de memoire a donner */
( block_memoire_t liste_a_parcourir)
{


	block_memoire_t tempo_liste ;
	
	tempo_liste =liste_a_parcourir;
	while((tempo_liste->suivant)==NULL)
		{
		tempo=tempo->suivant;
		}
	return (tempo);
	
}

/*--------------------------------------------------------------------------------------------------------------------------------------*/




block_memoire_t             /* ici on cree un block dans la liste qui est deja creee lors du premier appel de sbrk et on restitue son adresse*/
creation_block_utilisateur                        /* arguments sont taille du block a creer et  la liste en question */
( int taille_de_block, block_memoire_t la_Liste)
{
    block_memoire_t tempo;    /* parcours de la liste jusque au dernier */
                           /* au dernier je cree le block proprement dit */
	char * pointeur_espace_ supplement_a_donner;	           block_m   le_block_a _creer;
	 
	 
	 
	pointeur_espace_ supplement_a_donner =NULL;
    tempo =parcours_liste_au_dernier_block (la_Liste);
	le_block_a_creer.suivant=NULL;
	
	
	
	
							/* si la taille donnee par le systeme est suffisant  on met a jour sa taille et on cree le block pour l utilisateur*/
	if ((tempo->compteur_taille > taille_de_block)||(tempo->compteur_taille == taille_de_block))
	    {
		    /*mettre a jour le controle de taille du bloc */
	     le_block_a _creer.compteur_taille  =taille_de_block;
		 le_block_a_creer.taille_adresse    =tempo->taille_adresse;
		 
		   /* on avance la adresse  pour  pointer vers une region libre de la memoire pour le prochain appel de malloc */
		 tempo->taille_adresse  =tempo->taille_adresse + (taille_de_block*sizeof(char));
		 
		 
		    /* mettre a jour les taille et compteur de la memoire restant pour malloc */
		 tempo->compteur_taille  =(tempo->compteur_taille)  - taille_de_block;
		 le_block_a_creer.suivant =tempo;
		 
		 le_block_a_creer.precedent =tempo->precedent;
		 le_block_a_creer.status=1;
		 tempo->precedent  =*le_block_a_creer;
		
		 
		 return le_block_a_creer;
		}
		
		/*si taille  d espace restant n est pas suffisant */
	else {
	      
		  pointeur_espace_ supplement_a_donner=sbrk(taille_de_block);
		  if (errno==-1){
		   return NULL;
		   }
		   tempo->compteur_taille =(tempo->compteur_taillev)+ (taille_de_block);
		   
		      /*mettre a jour le controle de taille du bloc */
	     le_block_a _creer.compteur_taille  =taille_de_block;
		 le_block_a_creer.taille_adresse    =tempo->taille_adresse;
		 
		   /* on avance la adresse  pour  pointer vers une region libre de la memoire pour le prochain appel de malloc */
		 tempo->taille_adresse  =tempo->taille_adresse + (taille_de_block);
		 ((taille_de_block/COEFF_DIVISION_MEMOIRE_SUFFISANT)*sizeof(char));
		 
		 
		    /* mettre a jour les taille et compteur de la memoire restant pour malloc */
		 tempo->compteur_taille  =(tempo->compteur_taille)  + taille_de_block;
		 le_block_a_creer.suivant =tempo;
	     le_block_a_creer.precedent =tempo->precedent;
		 tempo->precedent  =*le_block_a_creer;
		 
		 return le_block_a_creer;
		}
	
	
	
	
	
	
 
}/* fin de creation  du block */

/*------------------------------------------------------------------------------------------------------------------------------------*/

void 
creer_Liste_block_libre
(block_memoire_t les_blocs_libre)
{
     les_blocs_libre=sbrk(sizeof(block_m));
	 if (errno==-1)block_memoire_t
	 {
	   les_blocs_libre=NULL;
	  }
	return ;
}
/*-------------------------------------------------------------------------------------------------------------------------------------*/

void 
ajout_block_libere
(block_memoire_t   liste_des_Libres, block_memoire_t   le_block_libre)
{    
     if (liste_des_Libres !=NULL)
	 {
     while   (liste_des_Libres->taille_adresse >le_block_libre->taille_adresse)
		{
		 liste_des_Libres=liste_des_Libres->suivant;
		}
	le_block_libre->suivant =liste_des_Libres->suivant;
	liste_des_Libres->suivant =le_block_libre;
	
	}
	/* si elle vide  alores*/
	le_block_libre->suivant=NULL;
	liste_des_Libres->suivant=le_block_libre;
	return ;
}
/*--------------------------------------------------------------------------------------------------------------------------------------*/
 

/*--------------------------------------------------------------------------------------------------------------------------------------*/
block_memoire_t   /* attention a l ordre de passage de parametres  block1 et block2 c est important*/
fusion_de_Deux_blocks
( block_memoire_t block1, block_memoire_t block2)
{
	block_memoire_t  block_du_fusion;
	block_du_fusion->taille_adresse=block1->taille_adresse;
	block_du_fusion->compteur_taille= (block1->compteur_taille) + (block2->compteur_taille);
	block_du_fusion->suivant=block2->suivant;
	block_du_fusion->precedent=block1->precedent;
	block_du_fusion->status=0;
	return block_du_fusion;
}
/*----------------------------------------------------------------------------------------------------------------------------------------------*/
/* la fonction verifie si deux blocks possede les adresse adjacent*/
int               /* retourne 1 en cas de succes sinon  zero */
deux_blocks_adresse_adjacent
( block_memoire_t liste)
{
	if (( (liste->suivant)->taille_adresse - (liste->compteur_taille )== liste->taille_adresse )
	  return 1;
	return 0;
}

/*-------------------------------------------------------------------------------------------------------------------------------------*/
 /* renvoi NULL si un block convenable n est pas trouve*/
block_memoire_t
recherche_Block_convenable_Dans_DesLibres

(block_memoire_t      la_liste_des_libres,
											int    taille_recherchee)
{
    block_memoire_t la_liste;
	la_liste =la_liste_des_libres;
	while(1)
	{
		if ((la_liste->compteur_taille == taille_recherchee)||(la_liste->compteur_taille > taille_recherchee))
			{
			 
			return (la_liste); /* le block  de taille convenable */
			}
		else if( la_liste_des_libres!=NULL)
		                     { if( deux_blocks_adresse_adjacent(la_liste)==1)
							         {
									  la_liste =fusion_de_Deux_blocks(la_liste,la_liste->suivant);
									  
									  if ((la_liste->compteur_taille == taille_recherchee)||(la_liste->compteur_taille > taille_recherchee))
									  return la_liste;
									 }
								la_liste  =la_liste->suivant ;
							}
			 else 
				return NULL;
	}
	
}
/*---------------------------------------------------------------------------------------------------------------------------------------------*/

 /*--------------------------------------------------------------------------------------------------------------------------------------------*/

}
/*---------------------------------------------------------------------------------------------------------------------------------------------*/

/*-----------------------------------------optimisation de la allocation dynamique-------------------------------------------------------------*/

int 
mon_mallopt
(const int taille_cmd, int value)
{

	if (le_Drapeau==0)   /*a zero  on peut creer les tableaux*/ 
	{
	int tempo;
    tempo_fast= maxfast	;
	tempo_numlblks=numblks;	
	if (taille_cmd==M_MXFAST)
	    {
		     maxfast=value;
			 while(1)
			 {
			 if (compteur_mallopt==numblks)
								break;
			
			
			
			*(taleau_de_blk_optimisee+(compteur_mallopt++))=sbrk(maxfast*sizeof(char));
			compteur_mallopt++;
			}
			max_fast=tempo_fast;
			compteur_mallopt=0;
			le_Drapeau=1;/*  pour  controller l apres allocationcar il n y aura plus d appel de mon_mallopt*/
			return 0;
		}	  
	else
		{
			if (taille_cm==M_NLBLKS)
						{
						    numblks=value;
							while(1)
							{
								if (compteur_mallopt==numblks)
								break;
								*(taleau_de_blk_optimisee+(compteur_mallopt++))=sbrk(maxfast*sizeof(char));
								compteur_mallopt++;
							}
							numblks=tempo_numlblks;
							compteur_mallopt=0;
							le_Drapeau=1;/*  pour  controller l apres allocationcar il n y aura plus d appel de mon_mallopt*/
							return 0;
						}
						
			return 1;  /*cas d echec*/				
		}
	} else {
				return 0; /*mon_malloc devra gerer ce cas pour mettre a jour l etat de la liste  et du tableau*/ 
			}
		
		
				
			
}
/*-----------------------------------------------------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------------------------------------------*/
                        /*creation de variable globale comme drapeau  pour gerer le travail  de mon_malloc  */
void*

mon_malloc
( int taille)
{
	void *old_break;   block_memoire_t   blk_of_user, liste, les_liberes;
	int taille_supplement;
	
	
	old_break=sbrk(0);  /*le debut*/
	
if (taille < M_MXFAST)
	{
	  if ( mon_mallopt(M_MXFAST,1)==0)
					{
					 
					 return taleau_de_blk_optimisee;
					}
	}
	else{
			les_liberes =creer_Liste_block_libre(block_memoire_t les_blocs_libre);
			if (blk_of_user==NULL)
				return NULL;
	
			return blk_of_user->taille_adresse;
		
			else 
			{                /* on recherche ds la reserve la taille qui convient  si liste des liberes est vide */
		                 /* si liste des liberes n est pas vide  on fait la recherche ds celle la puis 
						                   ds la reserve si aucun des blocks s y trouvant ne satisfait la recherche*/
						 /* si la reserve n est pas suffisant  on utilise creation_block_utilisateur*/
						 /* en attendant on modelise mon_free  apres quoi si necessaire poursuivre les draapeau*/
				if (le_DRAPEAU==1)
					{   if ( les_liberes==NULL)
							{		
								return (blk_of_user  =creation_block_utilisateur(  taille, liste));
							}
						else {
								blk_of_user =recherche_Block_convenable_Dans_DesLibres(la_liste_des_libres, taille);
								if (blk_of_user ==NULL)
									blk_of_user  =creation_block_utilisateur(  taille, liste);
								return blk_of_user;
							}
					}
			}
		
			if (le_DRAPEAU==3)    /* pour remettre a zero  le travail de sbrk*/
		         brk(old_break);
			return NULL;
		}	
	
}

/*------------------------------------------------------------------------------------------------------------------------------------------*/
/* recherche  block de pointeur qui existe deja ds la liste  des block alloues */
block_memoire_t
recherche_block_de_ptr
( void *ptr, block_memoire_t liste )
{
	while   ((liste->taille_adresse !=ptr) && (liste!=NULL))
		{
		 liste_des_Libres=liste_des_Libres->suivant;
		}
	if (liste->taille_adresse ==ptr)
		return liste;
    
}

/*-------------------------------------------------------------------------------------------------------------------------------------------*/

void 
mon_free
( block_m * pointeur)
{    
	block_memoire_t  blck_ptr;

    blck_ptr =recherche_block_de_ptr(pointeur,liste);
	ajout_block_libere(liste_blocks_libre, blck_ptr );
	return ;
  
}
/*http://wiki-prog.kh405.net/index.php/Programmation:C:Memoire:Malloc*/

/*----------------------------------------------------------------------------------------------------------------------------------------*/


/* --------------------------------------- calloc -----------------------------------------------------------------------------------*/

void *
mon_calloc
(int nbr, int size)

{
	 int nombre = 0;  
     int *tableau = NULL;
	 tableau=mon_malloc(nbr*size);
	 return tableau;
}


/*-----------------------------------------------------------------realloc-------------------------------------------------------------------*/


void * 
mon_realloc
( void ptr,int size)
{
	(&ptr)->compteur_taille+=size;
	 le_DRAPEAU=1;
	 return mon_malloc((&ptr)->compteur_taille);
}

/*--------------------------------------------------------------*/