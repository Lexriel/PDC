package ava.arbreAbstrait;

/** Bouche tant que d'un programme Ava.
 * @author M. Nebut
 * @version 11/07
 *
 * edité par Mr.YOULHAJEN Jamal dine
 * Licence 3 informatique - Groupe 2
 */
public class Boucle implements Instruction {


   /* les attributs */

    private Expression expr;
    private ListeInstruction listeInstructions;

    /** Construit une bouce while de condition booléenne
     * <tt>cond</tt> et de listeInstructions <tt>listeInstructions</tt>.
     * @param cond l'expression booléenne de cette conditionnelle
     * @param listeInstructions la liste d'instructions pour cette boucle while.
     * @throws IllegalArgumentException si <tt>cond</tt> vaut null.
     */
     
     /* Constructeur de l objet boucle */
     
    public Boucle(Expression cond, ListeInstruction listeInstructions) {
	if (cond == null)
	    throw new IllegalArgumentException();
	this.expr = cond;
	this.listeInstructions = listeInstructions;
    }

    /** Retourne la condition booléenne de cette boucle.
     * @return l'expression booléenne de cette boucle
     */
     /* methode retourne l expression de la boucle */
    public Expression getCondition() {
	return this.expr;
    }

    /** Retourne la liste d'instructions de cette boucle.
     * @return le listeInstructions de cette boucle
     */

      /* methode retourne la listeInstructions de la boucle */
    public ListeInstruction getListeInstr() {
	return this.listeInstructions;
    }

    /** Permet la visite de cette boucle par un visiteur passé en
     * paramètre.
     * @param v le visiteur pour cette boucle.
     * @throws IllegalArgumentException si <tt>v</tt> vaut null
     */
    public void visite(Visiteur v) throws VisiteurException{
	if (v == null)
	    throw new IllegalArgumentException();
	v.visiteBoucle(this);

    }

}
