package ava.arbreAbstrait;




/** Impression d'un programme Ava.
 * @author M. Nebut
 * @version 11/07
 */
public interface Impression extends Instruction {


}
