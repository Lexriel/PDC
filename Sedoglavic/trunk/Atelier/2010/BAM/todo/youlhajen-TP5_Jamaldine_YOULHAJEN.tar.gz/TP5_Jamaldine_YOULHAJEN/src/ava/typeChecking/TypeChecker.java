package ava.typeChecking;

import ava.tableSymboles.*;
import ava.arbreAbstrait.*;

import java.util.Iterator;


/** Contrôle de type pour Ava, qui prend en entrée un arbre abstrait
 * et remplit la table des symboles vide passée en
 * paramètre. L'analyse lève une exception de type
 * <tt>TypeChecking</tt> en cas d'erreur de typage, ne fait rien sinon
 * (à part compléter la table des symboles).
 * @version 04/07 - Revu le 11/10
 * @author M. Nebut
 *
 * edité par Mr.YOULHAJEN Jamal dine
 * L3 Informatique Groupe 2s
 */

/* TypeChecker est   un visiteur  : revient à dire que TypeChecker implements Visiteur*/

public class TypeChecker implements Visiteur { // COMPLETER

	/* la table des symboles*/
	private TableSymboles tableSymboles;

	/* l'arbre abstrait*/
	private Programme program;

	// le type de la derniere expression visitée
	private Type dernierTypeExpression;


	/** Builds a type analyzer which fills the symbol table tableSymboles.
	 * @param tableSymboles the table to be filled
	 * @param p the abstract tree to be analyzed
	 */
	 
	public TypeChecker(TableSymboles tableSymboles, Programme p) {
		this.tableSymboles = tableSymboles;
		this.program = p;
		this.dernierTypeExpression = Type.NOTYPE;
	}

	/** Executes the type analysis.
	 * @throws TypeCheckingException if p is badly typed.
	 */
	public void typeCheck() throws TypeCheckingException, VisiteurException {
		this.visiteProgramme(this.program);
	}

	/** Visite d'un programme. */
	public void visiteProgramme(Programme p) throws TypeCheckingException, VisiteurException {
		String nom = p.getNom();
		AttributsIdentificateur id_att = this.tableSymboles.ajoutIdentificateur(nom);
		id_att.setType(Type.PROGRAM);
		ListeDeclaration ld = p.getListeDecl();
		this.visiteListeDecl(ld);

		ListeInstruction linst = p.getListeInstr();
		this.visiteListeInstr(linst);
		this.dernierTypeExpression = Type.PROGRAM;
	}


	/************************ Déclarations ************************/

	/** Visite d'une liste de déclarations. */
	public void visiteListeDecl(ListeDeclaration ld) throws VisiteurException {

		Iterator it = ld.iterator();
		while (it.hasNext()) {
			Declaration declaration = (Declaration) it.next();
			declaration.visite(this);
		}
	}

	/** Visite d'une déclaration de type entier. */
	public void visiteDeclInt(DeclarationEntier decl) throws VisiteurException {
		String name = decl.getIdent();
		if (this.tableSymboles.contientIdentificateur(name))
			throw new TypeCheckingException(name + " est deja declare");
		AttributsIdentificateur id_att =
			this.tableSymboles.ajoutIdentificateur(name);
		id_att.setType(Type.ENTIER);
	}

	/** Visite d'une déclaration de type booléen. */
	public void visiteDeclBool(DeclarationBooleen bdec) throws VisiteurException {
		String name = bdec.getIdent();
		if (this.tableSymboles.contientIdentificateur(name)) {
			  throw new TypeCheckingException(name + " est deja declare");
		}
		AttributsIdentificateur id_att = this.tableSymboles.ajoutIdentificateur(name);
		id_att.setType(Type.BOOLEEN);
	}

	/************************ Instructions ************************/

	/** Visite d'une liste d'instructions. */
	public void visiteListeInstr(ListeInstruction linstr) throws VisiteurException {
	  
		Iterator it = linstr.iterator();
		while (it.hasNext()) {
			Instruction i = (Instruction) it.next();
			i.visite(this);
		}
	}

	/** Visite d'une affectation. */
	public void visiteAffect(Affectation a) throws VisiteurException {
		Expression e = a.getExpr();
		String s = a.getIdent();
		if (!this.tableSymboles.contientIdentificateur(s)) {
			throw new TypeCheckingException( s + " n'a pas ete declaree");
		}
		AttributsIdentificateur attribut = this.tableSymboles.getAttributsIdentificateur(s);
		Type type_att = attribut.getType();
		e.visite(this);
		if (type_att != this.dernierTypeExpression) {
			throw new TypeCheckingException(s + " est un " + type_att + " or l'affectation est de type  " + this.dernierTypeExpression);
		}
	}


	/** Visite d'une lecture. */
	public void visiteLecture(Lecture l) throws VisiteurException {

		String s = l.getIdent();
		if (!this.tableSymboles.contientIdentificateur(s)) {
			throw new TypeCheckingException( s + " n'a pas ete declaree");
		}
		AttributsIdentificateur attribut = this.tableSymboles.getAttributsIdentificateur(s);
		if (attribut.getType() != Type.ENTIER) {
			throw new TypeCheckingException(s + " n est pas un entier ");
		}
	}

	/** Visite d'une conditionnelle sans partie else. */
	public void visiteConditionnelleSimple(ConditionnelleSimple l)
	throws VisiteurException {
	  
		Expression cond = l.getCondition();
		cond.visite(this);
		if (this.dernierTypeExpression != Type.BOOLEEN) {
			throw new TypeCheckingException("L expression ne renvoie pas un  BOOLEEN");
		}
		ListeInstruction linst = l.getListeInstrAlors();
		linst.visite(this);
	}

	/** Visite d'une conditionnelle avec partie else. */
	public void visiteConditionnelleAvecAlternative(ConditionnelleAvecAlternative l)
	throws VisiteurException {
	  
		Expression cond = l.getCondition();
		cond.visite(this);
		if (this.dernierTypeExpression != Type.BOOLEEN) {
		      throw new TypeCheckingException("L expression ne renvoie pas un  BOOLEEN");
		}
		ListeInstruction linstAlors = l.getListeInstrAlors();
		linstAlors.visite(this);
		ListeInstruction linstSinon = l.getListeInstrSinon();
		linstSinon.visite(this);
	}

	/** Visite d'une boucle while. */
	public void visiteBoucle(Boucle b)
	throws VisiteurException {

		Expression cond = b.getCondition();
		cond.visite(this);
		if (this.dernierTypeExpression != Type.BOOLEEN) {
		  throw new TypeCheckingException("L expression ne renvoie pas un  BOOLEEN");
		}
		ListeInstruction linst = b.getListeInstr();
		linst.visite(this);
	}

	/** Visite d'une impression de type entier. */
	public void visiteImpressionEntierSansSautDeLigne(ImpressionEntierSansSautDeLigne i)
	throws VisiteurException {

		Expression expr = i.getExpr();
		expr.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER) {
			throw new TypeCheckingException("L'expression n est pas de type ENTIER");
		}
	}

	/** Visite d'une impression avec retour à la ligne de type entier. */
	public void visiteImpressionEntierAvecSautDeLigne(ImpressionEntierAvecSautDeLigne i)
	throws VisiteurException {

		ImpressionEntierSansSautDeLigne imp = new ImpressionEntierSansSautDeLigne(i.getExpr());
		imp.visite(this);
	}

	/** Visite d'une impression de type booleen. */
	public void visiteImpressionBooleenSansSautDeLigne(ImpressionBooleenSansSautDeLigne i)
	throws VisiteurException {
	
		Expression expr = i.getExpr();
		expr.visite(this);
		if (this.dernierTypeExpression != Type.BOOLEEN) {
			throw new TypeCheckingException("L'expression ne renvoit pas  BOOLEEN");
		}
	}

	/** Visite d'une impression avec retour à la ligne de type booleen. */
	public void visiteImpressionBooleenAvecSautDeLigne(ImpressionBooleenAvecSautDeLigne i)
	throws VisiteurException {
	
		ImpressionBooleenSansSautDeLigne newImpression = new ImpressionBooleenSansSautDeLigne(i.getExpr());
		newImpression.visite(this);
	}

	/** Visite d'une impression de type chaine. */
	public void visiteImpressionChaineSansSautDeLigne(ImpressionChaineSansSautDeLigne i)
	throws VisiteurException {

	}

	/** Visite d'une impression avec retour à la ligne de type chaine. */
	public void visiteImpressionChaineAvecSautDeLigne(ImpressionChaineAvecSautDeLigne i)
	throws VisiteurException {

	}


	/** Visite d'une impression de retour à la ligne. */
	public void visiteImpressionSautDeLigne(ImpressionSautDeLigne i)
	throws VisiteurException {

	}


	/************************ Expressions ************************/

	/** Visite d'un entier. */
	public void visiteEntier(Entier e) throws VisiteurException {
		this.dernierTypeExpression = Type.ENTIER;
	}

	/** Visite d'un identificateur. */
	public void visiteIdentExpr(IdentExpr i) throws VisiteurException {

		String nom = i.getNom();
		if (!this.tableSymboles.contientIdentificateur(nom))
			throw new TypeCheckingException("La variable "+nom+" n'a pas ete declaree");
		AttributsIdentificateur attribut = this.tableSymboles.getAttributsIdentificateur(nom);
		this.dernierTypeExpression = attribut.getType();
	}

	/** Visite d'une constante vrai. */
	public void visiteExprTrue(ExprTrue i) throws VisiteurException {
		this.dernierTypeExpression = Type.BOOLEEN;
	}

	/** Visite d'une constante faux. */
	public void visiteExprFalse(ExprFalse i) throws VisiteurException {
		this.dernierTypeExpression = Type.BOOLEEN;
	}

	/** Visite d'une addition. */
	public void visiteAddition(Addition i) throws VisiteurException {
	
		Expression exprGauche = i.getExprGauche();
		exprGauche.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
		  throw new TypeCheckingException("Le type de l'operande gauche  n est pas de  type ENTIER");
		Expression exprDroite = i.getExprDroite();
		exprDroite.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
		  throw new TypeCheckingException("Le type de l'operande droite  n est pas de  type ENTIER");
	}

	/** Visite d'une soustraction. */
	public void visiteSoustraction(Soustraction i) throws VisiteurException {
		
		Expression exprGauche = i.getExprGauche();
		exprGauche.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
		  throw new TypeCheckingException("Le type de l'operande gauche  n est pas de  type ENTIER");
		Expression exprDroite = i.getExprDroite();
		exprDroite.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
		  throw new TypeCheckingException("Le type de l'operande droite  n est pas de  type ENTIER");
	}

	/** Visite d'une multiplication. */
	public void visiteMultiplication(Multiplication i) throws VisiteurException {

		Expression exprGauche = i.getExprGauche();
		exprGauche.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
		  throw new TypeCheckingException("Le type de l'operande gauche  n est pas de  type ENTIER");
		Expression exprDroite = i.getExprDroite();
		exprDroite.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
		  throw new TypeCheckingException("Le type de l'operande droite  n est pas de  type ENTIER");
	}

	/** Visite d'une division. */
	public void visiteDivision(Division i) throws VisiteurException {

		Expression exprGauche = i.getExprGauche();
		exprGauche.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
		  throw new TypeCheckingException("Le type de l'operande gauche  n est pas de  type ENTIER");
		Expression exprDroite = i.getExprDroite();
		exprDroite.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
		  throw new TypeCheckingException("Le type de l'operande droite  n est pas de  type ENTIER");
	}


	/** Visite d'un modulo. */
	public void visiteModulo(Modulo i) throws VisiteurException {
		
		Expression exprGauche = i.getExprGauche();
		exprGauche.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
		  throw new TypeCheckingException("Le type de l'operande gauche  n est pas de  type ENTIER");
		Expression exprDroite = i.getExprDroite();
		exprDroite.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
			throw new TypeCheckingException("Le type de l'operande droite n est pas de  type ENTIER");
	}


	/** Visite d'un moins unaire. */
	public void visiteMoinsUnaire(MoinsUnaire i) throws VisiteurException {
		
		Expression expr = i.getExpr();
		expr.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
		  throw new TypeCheckingException("Le type de l'expression  n est pas de  type ENTIER");
	}

	/** Visite d'une négation. */
	public void visiteNegation(Negation i) throws VisiteurException {

		Expression expr = i.getExpr();
		expr.visite(this);
		if (this.dernierTypeExpression != Type.BOOLEEN)
			throw new TypeCheckingException("Le type doit etre de type BOOLEEN");
	}

	/** Visite d'une disjonction. */
	public void visiteDisjonction(Disjonction i) throws VisiteurException {

		Expression exprGauche = i.getExprGauche();
		exprGauche.visite(this);
		if (this.dernierTypeExpression != Type.BOOLEEN)
		  throw new TypeCheckingException("L'operande gauche de || doit etre de type BOOLEEN");
		Expression exprDroite = i.getExprDroite();
		exprDroite.visite(this);
		if (this.dernierTypeExpression != Type.BOOLEEN)
			throw new TypeCheckingException("L'operande droite de || doit etre de type BOOLEEN");
	}

	/** Visite d'une conjonction. */
	public void visiteConjonction(Conjonction i) throws VisiteurException {

		Expression exprGauche = i.getExprGauche();
		exprGauche.visite(this);
		if (this.dernierTypeExpression != Type.BOOLEEN)
			throw new TypeCheckingException("L'operande gauche de  & doit etre de type BOOLEEN");
		Expression exprDroite = i.getExprDroite();
		exprDroite.visite(this);
		if (this.dernierTypeExpression != Type.BOOLEEN)
			throw new TypeCheckingException("L'operande droite de & doit etre de type BOOLEEN");
	}

	/** Visite d'une égalité. */
	public void visiteEgal(Egal e) throws VisiteurException {
	
		Expression exprGauche = e.getExprGauche();
		exprGauche.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
			 throw new TypeCheckingException("L expression gauche de = n'est pas de type ENTIER");
		Expression exprDroite = e.getExprDroite();
		exprDroite.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
			 throw new TypeCheckingException("L expression droite de = n'est pas de type ENTIER");
		this.dernierTypeExpression = Type.BOOLEEN;
	}

	/** Visite d'une différence. */
	public void visiteDifferent(Different e) throws VisiteurException {
		
		Expression exprGauche = e.getExprGauche();
		exprGauche.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
		  throw new TypeCheckingException("L expression gauche de  != n'est pas de type ENTIER");
		Expression exprDroite = e.getExprDroite();
		exprDroite.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
			 throw new TypeCheckingException("L expression droite de != n'est pas de type ENTIER");
		this.dernierTypeExpression = Type.BOOLEEN;
	}

	/** Visite d'un supérieur strict. */
	public void visiteSuperieurStrict(SuperieurStrict e) throws VisiteurException {

		Expression exprGauche = e.getExprGauche();
		exprGauche.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
		  throw new TypeCheckingException("L expression gauche du > n'est pas de type ENTIER");
		Expression exprDroite = e.getExprDroite();
		exprDroite.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
		  throw new TypeCheckingException("L expression droite du > n'est pas de type ENTIER");
		this.dernierTypeExpression = Type.BOOLEEN;
	}

	/** Visite d'un supérieur ou egal. */
	public void visiteSuperieurOuEgal(SuperieurOuEgal e) throws VisiteurException {
	
		Expression exprGauche = e.getExprGauche();
		exprGauche.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
			 throw new TypeCheckingException("L expression gauche du >= n'est pas de type ENTIER");
		Expression exprDroite = e.getExprDroite();
		exprDroite.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
			 throw new TypeCheckingException("L expression droite du >= n'est pas de type ENTIER");
		this.dernierTypeExpression = Type.BOOLEEN;
	}

	/** Visite d'un inferieur ou egal. */
	public void visiteInferieurOuEgal(InferieurOuEgal e) throws VisiteurException {
	
		Expression exprGauche = e.getExprGauche();
		exprGauche.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
			 throw new TypeCheckingException("L expression gauche du <= n'est pas de type ENTIER");
		Expression exprDroite = e.getExprDroite();
		exprDroite.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
			 throw new TypeCheckingException("L expression droite du <= n'est pas de type ENTIER");
		this.dernierTypeExpression = Type.BOOLEEN;
	}

	/** Visite d'un inferieur strict. */
	public void visiteInferieurStrict(InferieurStrict e) throws VisiteurException {
		
		Expression exprGauche = e.getExprGauche();
		exprGauche.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
			 throw new TypeCheckingException("L expression gauche du < n'est pas de type ENTIER");
		Expression exprDroite = e.getExprDroite();
		exprDroite.visite(this);
		if (this.dernierTypeExpression != Type.ENTIER)
			 throw new TypeCheckingException("L expression droite du <  n'est pas de type ENTIER");
		this.dernierTypeExpression = Type.BOOLEEN;
	}
}
