package ava.arbreAbstrait;

public interface ImpressionAvecSautDeLigne extends Impression {}