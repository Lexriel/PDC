DUFOUR Clement

bonjour,
malloc ne marche pas pour deux appel successif.