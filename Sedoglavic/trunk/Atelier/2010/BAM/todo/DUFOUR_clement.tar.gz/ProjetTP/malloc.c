/*DUFOUR Clement*/

#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
 
#define SUPER "Supercalifragilisticexpialidocious"
#define SUPER2 "gooooooooooooooooooooooal"


#define MAXSIZE 100000
#define BLOCKSIZE (sizeof(block_t))

/* Gestion de la memoire */
 struct block_m {
    int size;
    struct block_m *next;
  };
typedef struct block_m block_t;


char *memoire  = NULL;
block_t *leblock;
  block_t essai;

/* Variable générales */
int nb_block = 0;


static void init() {
  memoire = sbrk(MAXSIZE);

  leblock = (block_t *)memoire;
  leblock->size = MAXSIZE - BLOCKSIZE;
  leblock->next = leblock;
    essai = *leblock;
}




void *mon_malloc (unsigned size) {


//   int units;
  
  if (memoire == NULL) 
    init();
  
  if (size == 0) 
    return NULL;

  leblock = &essai;

  while (leblock->next != (void *)memoire){
    leblock = leblock->next;
      printf("taille : %i\n",(leblock->size));

  }

 printf("%d\n",leblock);
  printf("%i\n",(leblock->size) - ((size - 1) + BLOCKSIZE));
 printf("%i\n",((size - 1) + BLOCKSIZE));

  
//   units = ((size-1) / BLOCKSIZE) + 1;
 if (leblock->size >= ((size - 1) + BLOCKSIZE)) {
    leblock->size = ((size - 1) + BLOCKSIZE);
    leblock->next = (void *)(leblock + size + 1);
    (leblock->next)->size = (leblock->size) - ((size - 1) + BLOCKSIZE);
    leblock->next->next = (void *)memoire;
    nb_block++;
 } else {
    printf ("plus d'espace\n");
 }
 

  

    
    return leblock;

}



int
main(void)
{
    char *str, *strcp, *str2, *strcp2; 

    /* Un appel direct � malloc */
    str = mon_malloc(strlen(SUPER)+10);
    str2 = mon_malloc(strlen(SUPER2)+10);

    strcpy(str, SUPER) ; 
        strcpy(str, SUPER2) ; 

    /* Un appel a malloc dans cet appel */
    strcp = strdup(str); 
        strcp2 = strdup(str2);

    /* Print is not debug, nevertheless */
    printf("%s\n%s\n", str, strcp); 
        printf("%s\n%s\n", str2, strcp2);

    /* On libere la memoire allouee sur str est strcp*/
//     free(str);
//     free(strcp);

      
return 0; 
}