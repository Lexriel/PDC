/*LarakiAlien*/

#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
 
#define SUPER "Supercalifragilisticexpialidocious"
#define SUPER2 "Vraaaiiiiiiimmmeeeennnnt"


#define MAXSIZE 100000
#define BLOCKSIZE (sizeof(block_t))

/* Gestion de la memoire */
 struct block_m {
    int size;
    struct block_m *next;
  };
typedef struct block_m block_t;


char *memoire  = NULL;
block_t *leblock;


/* Variable générales */
int nb_block = 0;


static void init() {
  memoire = sbrk(MAXSIZE);

  leblock = (block_t *)memoire;
  leblock->size = MAXSIZE - BLOCKSIZE;
  leblock->next = leblock;
}




void *mon_malloc (unsigned size) {
  block_t *courant;
  

//   int units;
  
  if (memoire == NULL) 
    init();
  
  if (size == 0) 
    return NULL;
  
  courant = leblock;
  while (courant->next != leblock){
    courant = courant->next;
  }

// printf("%i\n",courant->size);
// printf("%i\n",((size - 1) + BLOCKSIZE));

  
//   units = ((size-1) / BLOCKSIZE) + 1;
 if (courant->size >= ((size - 1) + BLOCKSIZE)) {
    courant->size = ((size - 1) + BLOCKSIZE);
    courant->next = (void *)(courant + size + 1);
    courant->next->size = (courant->size) - ((size - 1) + BLOCKSIZE);
    courant->next->next = leblock;
    nb_block++;
 } else {
    printf ("plus d'espace\n");
 }
 
//   leblock = courant->next->next;
/* 
  for (int i=0; i!=nb_block ; i++) {
    
    
  }*/


    
    return courant;

}



int
main(void)
{
    char *str, *strcp, *str2, *strcp2; 

    /* Un appel direct � malloc */
    str = mon_malloc(strlen(SUPER)+10);
    str2 = mon_malloc(strlen(SUPER2)+10);

    strcpy(str, SUPER) ; 
        strcpy(str, SUPER2) ; 

    /* Un appel a malloc dans cet appel */
    strcp = strdup(str); 
        strcp2 = strdup(str2);

    /* Print is not debug, nevertheless */
    printf("%s\n%s\n", str, strcp); 
        printf("%s\n%s\n", str2, strcp2);

    /* On libere la memoire allouee sur str est strcp*/
//     free(str);
//     free(strcp);

      
return 0; 
}
