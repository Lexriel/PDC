#include "bibli.h"
#include <stdio.h>
 


 struct coord{
    int x;
    int y;
 };
  

  typedef struct coord *coord_t;

int
main
(void)
{
  char *t,*t2;


  mmallopt(M_MXFAST,20);
  mmallopt(M_NLBLOCKS,30);

  t=mmalloc(1000); 
  printf("\n t=mmalloc(1000);\n");
  affichemem(); 

 
  t2=mmalloc(2);
  printf("\n t2=mmalloc(2);\n");

  affichemem();  

  mfree(t);
  printf("\n free(t)\n");
   affichemem();
  mfree(t2);
  affichemem();
  
  return 0;
}
