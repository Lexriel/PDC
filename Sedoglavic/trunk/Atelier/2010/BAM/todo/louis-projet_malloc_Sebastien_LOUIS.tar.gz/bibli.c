#include "bibli.h"
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>


void *lesegment,*lesblocks;/* les données */
unsigned int tailleDuSegment; /* la taille totale du segment de données*/
int initie,dejafait,premierblockalloue,dejamaxfast,dejamblocks,dejamallopt,paspremierefois;/*les booleens*/
int maxfast,numblks;/* pour mallopt */
int i;

/*fonction d'initialisation du segment de données*/
void
init
(void)
{
  if(!dejamaxfast)
    maxfast = 100;
  if(!dejamblocks)
    numblks = 100;

  initie=1;
 
  lesegment = sbrk(TAILLE_BLOCK);
  tailleDuSegment = TAILLE_BLOCK;
  ((tlibre) lesegment)->laTaille = TAILLE_BLOCK;
  ((tlibre) lesegment)->suivant = NULL;
  lesblocks=NULL;
}



/*ma fonction malloc*/
void* 
mmalloc 
(unsigned int size) 
{
  unsigned int size2;
  void * res;


  if (!initie)
    init();

  if(size<maxfast){
    if(!dejamallopt)
      initMmallopt();
    return allocrapide();
  }

  if(size<(sizeof(struct libre)-sizeof(int)))
    size2=(sizeof(struct libre)-sizeof(int));
  else
    size2=size;
  

  res = chercheEspaceDispo(size2);
  return res;
}



/*fonction qui cherche un espace dispo dans le segment et qui l'alloue*/
void *
chercheEspaceDispo
(unsigned int size)
{

  int i,tailletemp,size2;
  tlibre temp;
  void *res;

  size2=size+sizeof(int);
  temp = (tlibre)lesegment;
  while ((temp) && ((temp->laTaille)<size2))
    temp = temp->suivant;
  if(!temp){
    temp=alloueNouvelleTaille();
    while((temp->laTaille)<size2){
      temp=alloueNouvelleTaille();
    }
  }
  if((temp->laTaille)>size+sizeof(tlibre*)) {
    res=((char*)temp)+((temp->laTaille)-size2);
    (temp->laTaille)-=size2;
  }
  else if((temp->laTaille)>size2) {
    res=(void*)temp;
    tailletemp=(temp->laTaille)-size2;
    for(i=0;i<tailletemp;i++)
      ((char*)temp)[(temp->laTaille)-i-1]='\0';
  }
  *((int*) res)=size2;
  return ((void*)(((char*)res)+sizeof(int)));
}



/*augmente la taille du segment de donnée de TAILLE_BLOCK*/
void*
alloueNouvelleTaille
(void)
{
  tlibre temp;
  void *lenew,*res;
  
  
  temp = (tlibre)lesegment;
  while(temp->suivant){
    temp = temp->suivant;
  }
  
  lenew=sbrk(TAILLE_BLOCK);

  temp->suivant=lenew;
  ((tlibre)lenew) -> laTaille=TAILLE_BLOCK;
  ((tlibre)lenew)->suivant=NULL;
  ((tlibre)lenew)->precedent=temp;



  if((((char*)temp)+(temp->laTaille))==lenew){
    fusioner(&temp, (tlibre*) &lenew);
    res = temp;
  }
  else res = lenew;

   tailleDuSegment += TAILLE_BLOCK;

  return res;
}



/* ma fonction free*/
void
mfree
(void *ptr)
{
  void *temp;
  int size;
  tlibre it,*bidon;
  tblock leblock;
  listeListe ll;
  
  ll=(listeListe)lesblocks;
  
  while(ll){
    leblock = ll -> laListe;
    if ((((char*)ptr) >= ((char*)leblock)) && (((char*)ptr) <= (((char*) leblock)+ maxfast * numblks))){
      fastfree(ptr,leblock);
      return ;
    }
    ll=ll->next;
  }
  
  temp = ((char*)ptr)-sizeof(int);
  size= *((int *)temp);
  it = (tlibre) lesegment;
  while((it->suivant)&&(it<(tlibre)temp))
    it=it->suivant;
  
  ((tlibre)temp)->laTaille = size;
  ((tlibre)temp)->precedent= it;
  if(it)
    ((tlibre)temp)->suivant = it->suivant;
  else
    ((tlibre)temp)->suivant = NULL;
  if(it)
    it -> suivant = ((tlibre)temp);
  if((((char*)it)+(it->laTaille))==temp){
    bidon =(tlibre*)(&temp);
    fusioner(&it,bidon);
  }
}




/*la fonction de fusion entre deux structures p1 doit etre avant p2*/
void
fusioner
(tlibre *p1, tlibre *p2)
{

  ((*p1) -> laTaille)+= ( (*p2) -> laTaille);
  ((*p1)->suivant) = ((*p2)->suivant);
  if((*p2)->suivant)
    (((*p2)->suivant)->precedent)=(*p1);
}



/*procedure d'affichage de la mémoire*/
void
affichemem 
(void)
{
  tlibre temp;

  printf("\ntaille du segment : %u\n",tailleDuSegment);
  
  printf(" Les Libres : \n");
  temp = (tlibre)lesegment;
  while(temp){
    printf("taille : %u, emplacement : %u----",(unsigned int)(temp->laTaille),(unsigned int)temp);
    temp=temp->suivant;
  }
  printf("\n");
}




/*ma fonction mallopt*/
void
mmallopt
(int cmd,int val)
{
 

  if(premierblockalloue)
    return;

  if(cmd == M_MXFAST){
    dejamaxfast=1;
    if(val>sizeof(struct block))
      maxfast=val;
    else
      maxfast=sizeof(struct block);
  }
  else if(cmd == M_NLBLOCKS){
    numblks=val;
    dejamblocks=1;
  }
}



/* ma fonction d'allocation rapide grace à mallopt*/
void* 
allocrapide 
(void)
{
  tblock temp;
  listeListe ll;


  

  if(!dejafait)
    creeblocks();


  ll=lesblocks;

  while(ll){
    if(ll->laListe)
      break;
    ll=ll->next;
  }

  if(!ll){
    creeblocks();
    ll=lesblocks;
  }

  premierblockalloue=1;

  temp = (ll->laListe);
  ll->laListe = (temp->suivant);
  return (void*)temp;
}


/*fonction de creation des blocks*/
void
creeblocks
(void)
{
  listeListe temp;
  tblock lenew;

  dejafait = 1;



  lenew=(tblock)(mmalloc(maxfast*numblks));
 
  temp=(listeListe)(mmalloc(maxfast+1));
  temp->next=lesblocks;
  temp->laListe=lenew;
  lesblocks=temp;

  while(((char*)lenew) < (((char*)(temp->laListe))+ (maxfast*(numblks-1)))){
    (lenew -> suivant) = ((tblock)(((char*)lenew) + maxfast));
    lenew=lenew->suivant;
  }
  (lenew->suivant)=NULL;

  paspremierefois=1;

}

/*fonction de desallocation rapide*/
void
fastfree
(void *ptr, tblock laListe)
{
  tblock temp;
  temp = (tblock) laListe;
  
  while(temp->suivant)
    temp=temp->suivant;
  temp->suivant = ptr;
  (((tblock) ptr) -> suivant)=NULL;
}


/*fonction d'initiation pour les petits blocks*/
void
initMmallopt
(void)
{
  creeblocks();
}


