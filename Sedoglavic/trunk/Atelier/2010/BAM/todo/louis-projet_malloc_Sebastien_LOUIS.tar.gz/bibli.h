/* Projet de PDC sur malloc et free */
/* Sebastien LOUIS                  */
/* Groupe INFO 2                    */


#define TAILLE_BLOCK 300
#define M_MXFAST 0
#define M_NLBLOCKS 1

/* 
 *Les définissions de types
 */

struct libre {
  unsigned int laTaille;
  struct libre *suivant;
  struct libre *precedent;
};/* structure de base de la liste des espaces libres*/


typedef struct libre * tlibre; /* pointeur dessus pour faciliter l'utilisation*/

struct block{
  struct block *suivant;
};/* structure de base des blocks de petite taille */

typedef struct block * tblock;/*pointeur et typedef pour faciliter l'utilisation*/

struct listeListe_m{
  tblock laListe;
  struct listeListe_m * next;
};

typedef struct listeListe_m * listeListe; /* pour gérer le cas où il y a plusieurs "tableaux de blocks"*/



/*
 *les fonctions
 */


/*
 *----pour malloc et free
 */


/* pour initialiser le segment de donnees que l'on aura a disposition*/
void init(void);


/* ma fonction malloc*/
void * mmalloc (unsigned taille);


/* ma fonction free*/
void mfree (void * ptr);


/*ma fonction de recherche d'un espace qui convient*/
void * chercheEspaceDispo(unsigned int size);


/*pour aggrandir le segment de donnees*/
void * alloueNouvelleTaille (void);


/*pour fusionner deux cellules*/
void fusioner (tlibre *p1, tlibre *p2);


/* affiche un resume de la memoire*/
void affichemem(void);


/*
 *----pour mallopt
 */

/*ma fonction mallopt*/
void mmallopt(int cmd, int val);


/* fonction pour allouer rapidement un block*/
void * allocrapide (void);


/*fonction d'initialisation de la liste de blocks*/
void creeblocks (void);


/*le free des blocks*/
void fastfree (void *ptr,tblock laListe);


/*la fonction d'initialisation des petits blocks*/
void initMmallopt(void);
