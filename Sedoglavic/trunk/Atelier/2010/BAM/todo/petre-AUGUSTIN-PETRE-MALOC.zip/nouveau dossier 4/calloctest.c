#include "bam.h"
#include "stdio.h"
#include "liste.h"

int main(void){

	char *p;
	
	p=(char *)calloc(2,sizeof(char));
	p[0]='e';
	p[1]='t';
	afficheMem();
	printf("la premiere case %c,la seconde  %c\n",p[0],p[1]);

		
return 1;
}
