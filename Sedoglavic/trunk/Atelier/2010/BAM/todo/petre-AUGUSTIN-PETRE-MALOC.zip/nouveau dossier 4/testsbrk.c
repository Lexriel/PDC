#include <stdio.h>
#include <unistd.h>





extern void *sbrk(int );

int main(){

	int *c;
	char *ch;


	c=(int *)sbrk(sizeof(int));
	*c=3;
	ch=(char *)sbrk(sizeof(char));
	*ch='a';
	printf("%d",*c);

	printf("%c",*ch);

return 1;
}
