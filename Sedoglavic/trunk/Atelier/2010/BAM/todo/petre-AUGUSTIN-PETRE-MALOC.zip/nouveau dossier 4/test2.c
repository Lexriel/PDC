#include "liste.c"
#include "stdio.h"
extern void *malloc(unsigned);
extern void free(void *);
extern void afficheMem(void);

int main(void){

	int y,*p;
	y=3;
	
	/*DEFINIT QUE d'orenavant les demandes aux blocks de log <4 produiront une serie de 100 petits blocs de longeux 4*/
	mallopt(M_MAXFAST,4);
	
	p=(int *)malloc(sizeof(int));
	*p=y;
	printf("\ndddddddddddddd%dddddddddddddddd\n",*((int *)(firstc->espace)));	
	printf("\n----------------%d----------\n",mallopt(M_MAXFAST,4));
	free(p);
	afficheMem();
	

		
return 1;
}
