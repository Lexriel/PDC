#include "liste.c"
#include "stdio.h"
extern void *malloc(unsigned);
extern void free(void *);
extern void afficheMem(void);

int main(void){

	char *g,*p,u;
	u='g';
	/*t=2;*/
	p=(char *)malloc(sizeof(char));
	/**g=t;*/
	*p=u;
/*
	printf("%d\n",*g);*/
	afficheMem();
	/*free(g);*/
	g=(char *)realloc(p,sizeof(char)*2);
	*(g+1)='t';
	printf("tareeeeeeee");
	/*p=(int *) calloc(2,sizeof(int));
	p[0]=10;
	p[1]=12;*/
	printf("ddddddddddddddddddddd---%c *****%c---%c \n",g[0],g[1],g[2]);
	/*free(p);*/

		
return 1;
}
