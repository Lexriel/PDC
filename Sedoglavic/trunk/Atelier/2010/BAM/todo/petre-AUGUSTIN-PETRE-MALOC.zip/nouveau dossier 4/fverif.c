
/*-------------------------------------FONCTION DE VERIFICATION--------------------------------------------------------------------------------------*/

/*affiche ce que contient l'espace memmoire*/
/*teste*/
void afficheMem(void){
	cellule *iterateur=liste;
	int i;
	i=1;
	while(iterateur){
		printf("Taille de  %d cellule est : %d ,statut : %d , adresse espace memoire : %p ,adresse prochaine cellule: %p\n",i,iterateur->size,iterateur->status,(void *)iterateur->espace,(void *)iterateur->suiv);
		i++;
		iterateur=iterateur->suiv;
	}
}

/******************************************************************************************************************************************************/
/******************************************************************************************************************************************************/


