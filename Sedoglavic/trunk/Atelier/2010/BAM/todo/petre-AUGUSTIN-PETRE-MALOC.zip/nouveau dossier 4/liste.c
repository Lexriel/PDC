#include "unistd.h"
#include <stdio.h>
#include <string.h>
#include "liste.h"


#define meta ((sizeof(int)*2)+sizeof(struct cellule_t *)+sizeof(void*)) 
#define bigblock 100 
#define M_MAXFAST 0
#define M_NLBLOCKS 1


/********************************************************Variables source******************************************************************************/
/**variable d'environnement***/
 int  nlblocks=100;
 int maxfast=null;

/******************************/


/*************pointeur pour malloptc****************/
cellule *firstc=null;
/***************************************************/

/*************************************liste qui gere les espaces memoires allouer par sdbk() ******************/
 cellule *liste=null;
/**************************************************************************************************************/

/******************************************************************************************************************************************************/



/***********************************************Predifinitions**************************************************************************************/
/*
extern void *sbrk(int);
*//* extern void *memcpy(void*,const void*,int); */
/*cellule * scinderblock(cellule *,int);
void * serieblock(cellule **);
int estScindable(cellule *,int);
void copyBlock(cellule *,cellule*,int);
*//*****************************************************************************************************************************************************/



/*------------------------------------------------------mallocc-------------------------------------------------------------------------------------*/
/*mallocc permet d'avoir un pointeur sur l'espace requis*//*teste*/
void *mallocc(unsigned taille){/*si taille<maxfast malloptc est activee et freec rapide aussi*/

	cellule *iterateur,*new,*res,*last;
	/*si la  liste des espace est vide on fait recour a sdbk pour de l'espace*/

	if(!liste){
		if ((maxfast==null) || (taille>maxfast)){
		liste=(cellule *) sbrk(bigblock);
		liste->size=bigblock-meta;
		liste->status=0;/*occupee*/
		liste->suiv=null;
		liste->espace=liste+meta;
		res=scinderblock(liste,taille);

		return res->espace;


		}else{	/*maxfast n'est pas null*/
			/*condition malloptc*/
			/*allocation de nlblocks*maxfast blocs*/
			return serieblock(&liste);
			
			

		}
	}else{
		last=iterateur=liste;/*ne pas oublier pour les autres*/
		/*sinon on recherche de l'espace jusque l'on est arrive en bout de liste */
		while(iterateur  && (iterateur->size<=taille && iterateur->status==1)){
				
			last=iterateur;	/*si arrive en bout de liste on memorise la dernier position*/
			iterateur=iterateur->suiv;
		}
					
		/*recherche arrive en bout de liste*/
		if(!iterateur){
	
			if ((maxfast==null) || (taille>maxfast)){
				/*on n'a pas trouve unn bloc de taille recherchee,on fait recour a sbrk*/
				new=(cellule *) sbrk(bigblock);
		
				new->size=bigblock-meta;
				new->status=0;/*occupee*/
				new->suiv=null;
				new->espace=liste+meta;
				res=scinderblock(new,taille);
				/*on racorde la cellule a la liste qui gere les espaces allouer*/
				last->suiv=res;
				return res->espace;

			} else {/*condition malloptc*/
				/*on cree une serie de petits block*/
				return serieblock(&iterateur);
				
			}


		}else{/*on essaye de recuperer de l'espace a la cellule trouver et on le memorise dans la liste*/
			return scinderblock(iterateur,taille)->espace;
		

		}
		

	}
	

}

/*******************************************************************POUR mallocc*********************************************************************/





/*scide un gros bloc et renvoi un pointeur sur la cellule de taille demander*/
/*l'appelle a cette fonction suppose que le bloc et au moin saussi grand que taille*/
/*teste*/
cellule * scinderblock(cellule *block,int taille){
	cellule *b=block,*new;
	
	if (estScindable(b,taille)){
		/*traitements pour la nouvelle cellule*/
		new=(cellule *)b+meta+taille;
		new->size=b->size-(meta+taille);

		printf("%d",(int) ((sizeof(int)*2)+sizeof(struct cellule_t *)+sizeof(void*))); 
		new->status=0;
		new->suiv=b->suiv;
		new->espace=new+meta;
		/*traitements pour l'ancienne cellule*/
		b->size=taille;
		b->status=1;/*occupe*/
		b->suiv=new;
	}	
	return b;	
	

}

/*verifie si le block peut etre scinder*/
/*teste*/
int estScindable(cellule *block,int taille){
	return ((block->size-(meta+taille))>0);

}

/****************************************************************************************************************************************************/
/*****************************************************************************************************************************************************/


/*------------------------------------------------------malloptc-------------------------------------------------------------------------------------*/
/*malloptc() systeme de optimisation pour des petites allocations*/
/*pour par exemple l'allocation d'une serie de int (on connait la taille en octets de int))*/
/*malloptc(M_MAXFAST,666) -> d'orenavant mallocc alloquera des blocs d'au plus 666 octets si l'on demande moin on procede a un scinderation
*/
int malloptc(int cmd,int val){
	if(firstc && (firstc->status==1)) return 1;/*si la premiere cellule a ete alouer*/
	if((cmd<0) || (cmd>1) || (val<0)) return 1;/*si parametres invalides*/
	if(M_MAXFAST && (val<=meta)) return 1;/*l'espace doit etre au moin egal a un octet*/
	switch ( cmd){
		case M_MAXFAST:
			maxfast=val;break;
		case M_NLBLOCKS:
			nlblocks=val;break;
				
	} 
	return 0;

}


/*******************************************************************POUR malloptc*********************************************************************/
/*cree une serie de block apres ce block en utilisant les valeurs de nlblocks et maxfast et renvoie un  pointeur vers le 1er block cree*/

void *serieblock(cellule **debut){
		cellule* tmp=null;
		int k;		
	/*allocation de nlblocks*maxfast blocs*/
			
				tmp=(cellule *) sbrk(meta+maxfast);/*l'espace requis +meta*/
				tmp->size=maxfast;
				tmp->status=1;/*occupee*/
				tmp->espace=tmp+meta;
				tmp->suiv=null;
				firstc=tmp;
			
		/*	tmp=tmp->suiv;*/

			for(k=0;k<nlblocks;k++){
				tmp->suiv=(cellule *) sbrk(meta+maxfast);/*l'espace requis +meta*/
				/*prec=tmp;*/
				tmp=tmp->suiv;
				tmp->size=maxfast;
				tmp->espace=tmp+meta;
				tmp->status=0;/*occupee*/
				/*tmp->suiv=null;*/
				/*tmp=tmp->suiv;*/
			}
			tmp->suiv=null;
		if(!*debut){
			*debut=firstc;
		}else{
			tmp->suiv=(*debut)->suiv;
			(*debut)->suiv=firstc;
		}
			return firstc->espace;

}
/******************************************************************************************************************************************************/
/******************************************************************************************************************************************************/


/*------------------------------------------------------freec------------------------------------------------------------------------------------------*/
/*libere l'espace memoire alouer==reactive la cellule qui contient l'adresse inserer*/
/*si ptr n'a pas ete aloquer par une fction d'allocation de cette biblioteque ne fait rien*/
/*presque teste*/
void freec(void *ptr){
	cellule *iterateur=liste,*prev,*suivant;
	/* on recherche la cellule qui contient l'adresse de l'espace*/
	prev=liste;
	while (iterateur &&(iterateur->espace!=ptr)){
		prev=iterateur;
		iterateur=iterateur->suiv;
	}
	/*si la cellule a ete trouvee*/
	if (iterateur){
		if( (iterateur<firstc) ||(firstc==null) || (iterateur>firstc+(maxfast*nlblocks)) ) {/*si la cellule est en dehort de la serie de block*/
			iterateur->status=0;
			/*gestion defragmentation*/
			/*gestion de la cellule precedente*/
			if(((prev+meta+prev->size)==iterateur) && (prev->status==0)  ){
				prev->size+=meta+iterateur->size;
				prev->suiv=iterateur->suiv;
				iterateur=prev;
			}
		
			/*gestion de la cellule suivate*/
			suivant=iterateur->suiv;
			if(((iterateur+meta+iterateur->size)==suivant) && (suivant->status==0) && suivant ){
				iterateur->size+=meta+suivant->size;
				iterateur->suiv=suivant->suiv;
				iterateur=prev;
			}
		}else{	/*mallop*/
			iterateur->status=0;/*on evite le recollement*/
		
		}
		
	}
}

/******************************************************************************************************************************************************/
/******************************************************************************************************************************************************/





/*------------------------------------------------------CALLOC---------------------------------------------------------------------------------------*/

/*Allocates a block of memory for an array of num elements, each of them size bytes long, and initializes all its bits to zero.

The effective result is the allocation of an zero-initialized memory block of (num * size) bytes.*/
/*teste*/
void *callocc(int nmemb,int size){

	void *res;
	int t;
	char *c;
	/*on prend de l'espace memoire*/
	res=(void *)mallocc(nmemb*size);
	c=(char *)res;
	/*on initialise tout a zero*/
	for (t=0;t<nmemb*size;t++){
		c[t]=0;/*a verifier*/
	}
	return res;
}



/******************************************************************************************************************************************************/
/******************************************************************************************************************************************************/





/*------------------------------------------------------realoc---------------------------------------------------------------------------------------*/

/* realloccate memory block*/
/*lloc() changes the size of the memory block pointed to by ptr to size bytes.  The contents will be unchanged to the minimum of the old and new
       sizes;  newly  allocated  memory  will be uninitialized.  If ptr is NULL, then the call is equivalent to mallocc(size), for all values of size; if
       size is equal to zero, and ptr is not NULL, then the call is equivalent to freece(ptr).  Unless ptr is NULL, it must have been returned by an  ear‐
       lier call to mallocc(), calloc() or reallocc().  If the area pointed to was moved, a freece(ptr) is done.
*/
/*
reallocc()  returns  a pointer to the newly allocated memory, which is suitably aligned for any kind of variable and may be different from ptr, or
       NULL if the request fails.  If size was equal to 0, either NULL or a pointer suitable to be passed to freece() is returned.  If reallocc() fails the
       original block is left untouched; it is not freeced or moved.*/
/*The ptr argument is a pointer to the original block of memory. The new size, in bytes, is specified by size. There are several possible outcomes with reallocc():

If sufficient space exists to expand the memory block pointed to by ptr, the additional memory is allocated and the function returns ptr.
If sufficient space does not exist to expand the current block in its current location, a new block of the size for size is allocated, and existing data is copied from the old block to the beginning of the new block. The old block is freeced, and the function returns a pointer to the new block.
If the ptr argument is NULL, the function acts like mallocc(), allocating a block of size bytes and returning a pointer to it.
If the argument size is 0, the memory that ptr points to is freeced, and the function returns NULL.
If memory is insufficient for the realloccation (either expanding the old block or allocating a new one), the function returns NULL, and the original block is unchanged.*/
/*teste*/

void  *reallocc(void *ptr,int size){

	cellule *iterator=liste,*suivant,*tmp,*aut;
	void *res;
	int tmptaille;	
	/*le cas ou ptr est null*/

	if(!ptr){
		return mallocc(size);
	}

	/*si ptr a deja ete allouer par mallocc ou calloc ou realoc*/
	/*recherche de la cellule qui comporte l'espace memoire designer par ptr*/
	tmp=liste;
	while (iterator && (iterator->espace!=ptr)){
		tmp=iterator;
		iterator=iterator->suiv;
	}

	/*si cellule trouver*/
	if (iterator){
		tmptaille=iterator->size;
		/*le cas ou size est 0 ou */	
		if (size==0 && ptr!=null){
			freec(ptr);
			return null;
		}
		
		if (iterator->size<size){/*realoc est active seulement si la realocation porte sur une taille plus grande que celle actuelle*/
		/*on recherche a faire une expension*/
			suivant=iterator->suiv;
			
			if(suivant &&(suivant->status==0)){/*si  la cellule suivante n'est pas null et n'est pas allouer on fusione*/
				
				iterator->size+=meta+suivant->size;
				iterator->suiv=suivant->suiv;
				/*si le bloc memoire peut etre rajuster a l'exacte taille demandee on scinde*/
				aut=(scinderblock(iterator,size));/*a voir si marche*/
				res=aut->espace;
			}else{
				/*recherche dans les cellules qui suivent un espace adapter*/
				/*on elibera l'espace*/
				tmp=iterator;
				tmp->status=0; 
				while(iterator && (iterator->size<size)){
				/*tans que l'on est pas arriver au bout de la liste et que la taille ne correspond pas*/
				iterator=iterator->suiv;
				}
				if (iterator){/*si taille trouver*/
					/*on tente de recuperer le surplus d'espace*/
				
					res=scinderblock(iterator,size)->espace;/*a voir si marche*/
				}else{/*sinon pas le choix, on fais appel a mallocc*/ 
					res=mallocc(size);
				}
			}
				/*finallement on recopie les donnees dans le nouveaux espace allouer*/
				copyBlock(tmp->espace,res,tmptaille);
			return res;		

			}
		
	}
	return null;
}

/************************************************************POUR reallocc******************************************************************************/

/*la nouvelle cellule doit avoir une taille memoire superieure a l'ancienne*/
/*pas teste*/
void copyBlock(cellule *anc,cellule* nouv,int y){
	int asize;
	char *a,*s;
	
	asize=anc->size-1;
	if(nouv->size>=asize){/*triger de surete*/
		a=(char *) anc->espace;
		s=(char *) nouv->espace;
		
			memcpy (nouv,anc,asize);
			/*s[i]=a[i];*/
		
	}
}
/******************************************************************************************************************************************************/
/******************************************************************************************************************************************************/







/*-------------------------------------FONCTION DE VERIFICATION--------------------------------------------------------------------------------------*/

/*affiche ce que contient l'espace memmoire*/
/*teste*/
void afficheMem(void){
	cellule *iterateur=liste;
	int i;
	i=1;
	while(iterateur){
		printf("Taille de  %d cellule est : %d ,statut : %d , adresse espace memoire : %p ,adresse prochaine cellule: %p\n",i,iterateur->size,iterateur->status,(void *)iterateur->espace,(void *)iterateur->suiv);
		i++;
		iterateur=iterateur->suiv;
	}
}

/******************************************************************************************************************************************************/
/******************************************************************************************************************************************************/




