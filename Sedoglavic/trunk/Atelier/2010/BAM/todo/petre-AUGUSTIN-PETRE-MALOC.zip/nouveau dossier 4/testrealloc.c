#include "bam.h"
#include "stdio.h"
#include "liste.h"


int main(void){

	char *g,*p,u;
	u='g';

	p=(char *)malloc(sizeof(char));
	*p=u;
	afficheMem();
	/*free(g);*/
	g=(char *)realloc(p,sizeof(char)*2);
	*(g+1)='t';
	afficheMem();
	printf("ddddddddddddddddddddd---%c *****%c---%c \n",g[0],g[1],g[2]);
	free(p);
	afficheMem();
		
return 1;
}
