#include "bam.h"
#include "stdio.h"
#include "liste.h"

int main(void){

	char *g,*p;
	
	p=(char *)malloc(sizeof(char));
	*p='e';
	afficheMem();
	
	g=(char *)malloc(sizeof(char));
	*g='r';
	afficheMem();
	free(g);
	afficheMem();
	free(p);
	afficheMem();

		
return 1;
}
