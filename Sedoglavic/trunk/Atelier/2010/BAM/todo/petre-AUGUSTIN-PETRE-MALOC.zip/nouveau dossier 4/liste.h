#define M_MAXFAST 0
#define M_NLBLOCKS 1
#define null 0

/*un bloc de la liste*/
typedef struct celule {
	int size;/*en octets*/
	int status;
	void *espace;
	struct celule *suiv;
	} cellule;


/*************pointeur pour malloptc****************/
extern cellule *firstc;
/***************************************************/

/*************************************liste qui gere les espaces memoires allouer par sdbk() ******************/
 extern cellule *liste;
/**************************************************************************************************************/

/******************************************************************************************************************************************************/

extern void *mallocc(unsigned);

extern cellule *scinderblock(cellule * cel ,int f );

extern int estScindable(cellule *block,int taille);

extern  int malloptc(int cmd,int val);

extern void *serieblock(cellule **debut);

extern void freec(void *ptr);

extern void *callocc(int nmemb,int size);

extern void  *reallocc(void *ptr,int size);

extern void copyBlock(cellule *anc,cellule* nouv,int y);

extern void afficheMem(void);
