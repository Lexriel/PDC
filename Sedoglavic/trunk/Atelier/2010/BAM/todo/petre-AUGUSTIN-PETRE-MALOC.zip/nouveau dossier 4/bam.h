
#define malloc(sz) bam_malloc(sz,__FILE__,__LINE__)
#define calloc(nmemb,size) bam_calloc(nmemb,size,__FILE__,__LINE__)
#define free(sz) bam_free(sz,__FILE__,__LINE__)
#define realloc(sz,size) bam_realloc(sz,size,__FILE__,__LINE__)
#define mallopt(cmd,in) bam_mallopt(cmd,in,__FILE__,__LINE__)

extern void *bam_malloc(int size,char *filename,unsigned line);

extern void *bam_calloc(int nmemb,int size,char *filename,unsigned line);

extern  void bam_free(void *ptr,char *filename,unsigned line);

extern void  *bam_realloc(void *ptr,int size,char *filename,unsigned line);

extern int bam_mallopt(int cmd,int val,char *filename,unsigned line);
