#include "liste.h"
#include "bam.h"




/*malloc() replacement */
void *bam_malloc(int size,char * filename,unsigned line){

	return mallocc(size);

}



/*calloc() replacement */
void *bam_calloc(int nmemb,int size,char *filename,unsigned line){
	return callocc(nmemb,size);
}

/*free() replacement */
 void bam_free(void *ptr, char *filename,unsigned line){
	freec(ptr) ;
}

/*malloc() replacement */
void  *bam_realloc(void *ptr,int size,char *filename,unsigned line){
	return reallocc(ptr,size);
}

/*malloc() replacement */
int bam_mallopt(int cmd,int val,char *filename,unsigned line){
	return malloptc(cmd,val);
}
