#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAXLINE 81

void fatal(int assert, const char *message, int status)
{
  if (assert == 0)
  {
    fprintf(stderr,"%s\n",message);
  }
    exit(status);
}

int readl(char line[])
{
    int size;
    if (fgets(line,MAXLINE,stdin) == NULL)
    {
      return EOF;
    }
    else
    {
      size = strlen(line);
      if (line[size-1] != '\n')
      {
	fatal(0,"il y a trop de caracteres",EXIT_FAILURE);
	return 0;
      }
      else
      {
	return size;
      }
    }
}

char * mcolrm(int col, int end){
  char line[MAXLINE + 1];
  char res [MAXLINE + 1];
  /*code pour couper le tableau entre col et end*/
  int i=0;int ecart=(end-col)+1;
  
  if (end != -1)
  {
    while (readl(line) != EOF){
      char res[]="";
      for (i=0;i<col;i++){
	res[i] = line[i];
      }
      for (i=end+1;i<strlen(line);i++){
	res[i-ecart] = line[i];
      }
      res[strlen(line)]='\0';
      fprintf(stdout,"%s\n",res);
    }    
  }
  else
  /*enleve le caractere col du tableau*/
  {
    while (readl(line) != EOF){
      for (i=0;i<col;i++){
	res[i] = line[i];
      }
      for (i=col+1;i<strlen(line);i++){
	res[i-1]=line[i];
      }
      res[strlen(line)]='\0';
      fprintf(stdout,"%s\n",res);
    }
  }

  exit(EXIT_SUCCESS);
}
    


int main (int argc, char *argv[])
{
 int end;int col;
 if ((argc != 2) && (argc != 3))
 {
    fatal(0,"nombre d'arguments incorrect",EXIT_FAILURE);
 }
 else
 {   
   if (strcmp(argv[0],"./mcolrm") != 0){
         fatal(0,"appel de la méthode incorrect",EXIT_FAILURE);
   }
   if ((atoi(argv[1])<=0) || (atoi(argv[1])>(MAXLINE-1)))
   {
      fatal(0,"premier argument incorrect",EXIT_FAILURE);
   }
      col = atoi(argv[1]);
   if (argc == 2)
   {
	end = -1;
   }
   else
   {
     if ((atoi(argv[2])<=0) || (atoi(argv[2])>(MAXLINE-1)))
     {
        fatal(0,"deuxieme argument incorrect",EXIT_FAILURE);
     }
	end = atoi(argv[2]);
   }
   mcolrm(col,end);
 }
 exit(EXIT_SUCCESS);
}