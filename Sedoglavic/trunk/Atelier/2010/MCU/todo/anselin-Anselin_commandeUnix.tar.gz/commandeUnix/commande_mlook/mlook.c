#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAXLINE 81

void fatal(int assert, const char *message, int status)
{
  if (assert == 0)
  {
    fprintf(stderr,"%s\n",message);
  }
    exit(status);
}

int readl(char line[])
{
    int size;
    if (fgets(line,MAXLINE,stdin) == NULL)
    {
      return EOF;
    }
    else
    {
      size = strlen(line);
      if (line[size-1] != '\n')
      {
	fatal(0,"il y a trop de caracteres",EXIT_FAILURE);
	return 0;
      }
      else
      {
	return size;
      }
    }
}

char * mlook(char * word){
  char line[MAXLINE+1];
  int cpt_ligne=0;
    while (readl(line) != EOF){
      if (strstr(line,word) != NULL){
	if (strcmp(strstr(line,word),line)==0){
	  cpt_ligne++;
	  fprintf(stdout,"%s\n",line);
	}
      }
    }
  if (cpt_ligne == 0){
    fatal(0,"aucune ligne n'a ete trouvee",EXIT_FAILURE);
  }
  exit(EXIT_SUCCESS);
}
    


int main (int argc, char *argv[])
{
 if (argc != 2)
 {
    fatal(0,"nombre d'arguments incorrect",EXIT_FAILURE);
 }
 else
 {   
   if (strcmp(argv[0],"./mlook") != 0){
         fatal(0,"appel de la méthode incorrect",EXIT_FAILURE);
   }
   else{
     mlook(argv[1]);
   }
 }
 exit(EXIT_SUCCESS);
}