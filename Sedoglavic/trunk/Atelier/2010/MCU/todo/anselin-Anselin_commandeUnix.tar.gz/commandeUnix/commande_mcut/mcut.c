#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAXLINE 81

void fatal(int assert, const char *message, int status)
{
  if (assert == 0)
  {
    fprintf(stderr,"%s\n",message);
  }
    exit(status);
}

int readl(char line[])
{
    int size;
    if (fgets(line,MAXLINE,stdin) == NULL)
    {
      return EOF;
    }
    else
    {
      size = strlen(line);
      if (line[size-1] != '\n')
      {
	fatal(0,"il y a trop de caracteres",EXIT_FAILURE);
	return 0;
      }
      else
      {
	return size;
      }
    }
}

char * mcut(char * delim,int argc,char * argv[]){
      char line[MAXLINE + 1];
      char * final_table[MAXLINE];
      int cpt=0;int i=1;
      char * tmp;
      readl(line);
      tmp = strtok(line,delim);
      final_table[0] = tmp;
      while (tmp!=NULL){
	tmp = strtok(NULL,delim);
	cpt++;
	final_table[cpt] = tmp;
      }
      while (i!=argc-1){
	i++;
	if ((atoi(argv[i])-1)<=cpt-1){
	  fprintf(stdout,"%s\n",final_table[atoi(argv[i])-1]);
	}
      }
      exit(EXIT_SUCCESS);
}
    


int main (int argc, char *argv[])
{
 if (argc < 3)
 {
    fatal(0,"nombre d'arguments incorrect",EXIT_FAILURE);
 }
 else
 {   
   if (strcmp(argv[0],"./mcut") != 0){
         fatal(0,"appel de la méthode incorrect",EXIT_FAILURE);
   }
   /*char delim = chaine_delim[0];*/
   mcut(argv[1],argc,argv);
 }
 exit(EXIT_SUCCESS);
}