#include <stdio.h>
#include <stdlib.h>
#define MAXLINE  80


int readl(char line[]) {
 char c;
 int i=0;
 while ((c=getchar()) != ',') {
   line[i]=c;
   i++;
   if (i>MAXLINE) {exit(EXIT_FAILURE);}
   }
   line[i]='\0';
 return i++;
}