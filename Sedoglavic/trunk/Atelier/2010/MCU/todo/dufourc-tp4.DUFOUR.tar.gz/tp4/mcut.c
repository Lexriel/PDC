/*Auteur : Dufour Clement & Laraki Alien*/
#include <stdio.h>
#include <stdlib.h>
#include "readl.h"
#define MAXLINE  80


int
main (int argc, char *argv[])
{
  
  
  int delim_debut;
  int delim_fin = 0;
  int delim_char;
  
  int cpt = 0; /*compteur de caractere par ligne*/
  int j = 0; /* compteur de caractere general */
  int bool = 0; /* variable booleen qui passe a 1 quand les caractere doivent être supprimés */
  char line[MAXLINE+1];
  int l;  /* longueur du texte saisie */
  int i=0;
  l = readl(line);
  printf("Pour tester le programme entrer vos caractere retour chariot compris , et terminer par une virgule\n");

  delim_char = *argv[1];
  delim_debut = atoi(argv[2]); 
  
   if (argc == 4) {
     delim_fin = atoi(argv[3]);
   }

   
    while (j <= l) { /* jusqu'a la fin de la saisie */
      if (delim_debut == 1) {bool =1;}
      cpt = 1;
      while (line[j] != '\n' && j <= l) { /* pour chaque ligne */
        if (line[j] == delim_char) {
          cpt++;
        }
        if ((cpt == delim_debut || cpt == delim_fin+1) && (line[j] == delim_char)) {
          if (bool == 0) {
            bool = 1;
          } else {
            bool = 0;
          }
        } else {
          if (bool == 0 ) {
            line[j] = '*';
          }
        }
        j++;
      }
      j++;
      bool = 0;

    }

  while (i <= l) { /* 'impression' */ 
    if (line[i]!='*') {
      printf("%c",line[i]);
    }
    i++;
   }
   printf("\n");  
   return 0;
}
  