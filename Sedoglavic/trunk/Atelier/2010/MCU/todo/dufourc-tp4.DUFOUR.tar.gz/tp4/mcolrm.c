/*Auteur : Dufour Clement & Laraki Alien*/
#include <stdio.h>
#include <stdlib.h>
#include "readl.h"
#define MAXLINE  80


int
main (int argc, char *argv[])
{
  int i=0;
  int delim_debut;
  int delim_fin;
  int cpt = 0; /*compteur de caractere par ligne*/
  int j = 0; /* compteur de caractere general */
  int bool = 0; /* variable booleen qui passe a 1 quand les caractere doivent être supprimés */
  char line[MAXLINE+1];
  int l;  /* longueur du texte saisie */
  l = readl(line);
  printf("Pour tester le programme entrer vos caractere retour chariot compris , et terminer par une virgule \n");

  delim_debut = atoi(argv[1]); 
  if (argc==2) {
   
    while (j <= l) { /* jusqu'a la fin de la saisie */
      cpt = 1;
      while (line[j] != '\n' && j <= l) { /* pour chaque ligne */
        if (cpt == delim_debut) {
          bool = 1;
        }
        if (bool == 1) {
          line[j] = '*';
        }
        cpt++;
        j++;
      }
      j++;
      bool = 0;
    }
    
  } else {

    delim_fin = atoi(argv[2]);
  
    while (j <= l) {
      cpt = 1;
      while (line[j] != '\n' && j <= l) {
        if (cpt == delim_debut) {
          bool = 1;
        }
        if (cpt == delim_fin+1) {
          bool = 0;
        }
        if (bool == 1) {
          line[j] = '*';
        }
        cpt++;
        j++;
        }
      j++;
      bool = 0;
    }
  }



  while (i <= l) { /* 'impression' */ 
    if (line[i]!='*') {
      printf("%c",line[i]);
    }
    i++;
   }
   printf("\n");  
   return 0;
}
  