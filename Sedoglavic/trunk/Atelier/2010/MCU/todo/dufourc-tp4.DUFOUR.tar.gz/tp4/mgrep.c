/*Auteur : Dufour Clement & Laraki Alien*/
/*Recherche de sous-chaînes
La fonction

    #include <string.h>
    char *strstr(const char *big, const char *little);

recherche la chaîne de caractères little dans la chaîne de caractères big. En particulier, elle retourne

    * NULL ssi little n'apparaît pas dans big ;
    * big ssi big débute par little. */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"
#define MAXLINE  80



int
main (int argc, char *argv[])
{

  char *resultat;
  char maligne[MAXLINE]; /* ligne courante */
  int i=0;
  int j=0;
  char line[MAXLINE];
  int l=readl(line);
  printf("Pour tester le programme entrer vos caractere retour chariot compris , et terminer par une virgule\n");

  while (i <= l) {
    while (line[i]!='\n' && i <= l) {
      maligne[j]=line[i];
      j++;
      i++;
    }
    j=0;
    resultat=strstr(maligne,argv[1]);
    if (resultat!=NULL) {
	printf("%s'\n'",maligne);
    }
    if (i <= l) {    i++;}

  }
  return 0;
}