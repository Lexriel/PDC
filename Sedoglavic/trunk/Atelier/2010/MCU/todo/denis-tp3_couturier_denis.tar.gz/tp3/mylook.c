#include "tools.h"

int main(int argc, char * argv[])
{
  char tab[MAXLINE];
  char *c;

  while ((readl(tab)) != EOF)
    {
      if ((c = (strstr(tab, argv[1]))) != NULL)
	{
	  if ((strcmp(tab, c)) == 0)
	    {
	      printf("%s", tab);
	    }
	}
    }  
  return EXIT_SUCCESS;
}
