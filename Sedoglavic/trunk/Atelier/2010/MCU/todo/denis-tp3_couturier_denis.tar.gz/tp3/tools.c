#include "tools.h"

int readl(char line[])
{

  if(!fgets(line, MAXLINE, stdin)){
    return EOF;
  }
  
  if(!(strlen(line) < 80)){
    if(line[MAXLINE-2] != '\n'){
      fprintf(stderr,"Ligne de plus de 80 caracteres\n");
      exit(EXIT_FAILURE);
    }
  }
  return strlen(line);
}

extern void fatal(int assert, const char *message, int status)
{
  if (!assert)
    {
      fprintf(stderr, "%s\n", message);
      exit(status);
    }
}
