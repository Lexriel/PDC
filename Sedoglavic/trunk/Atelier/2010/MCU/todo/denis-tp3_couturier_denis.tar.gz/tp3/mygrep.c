#include "tools.h"

int main(int argc, char * argv[])
{
  char tab[MAXLINE];

  while ((readl(tab)) != EOF)
    {
      if (strstr(tab, argv[1]))
	{
	  printf("%s", tab);
	}
    }
  
  return EXIT_SUCCESS;
}
