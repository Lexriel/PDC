#include "tools.h"

int main(int argc, char * argv[])
{
  char tab[MAXLINE];
  int min, max, cpt;

  switch(argc)
    {
    case 3:
      max = atoi(argv[2]);
      min = atoi(argv[1]);
      break;
    case 2:
      max = MAXLINE;
      min = atoi(argv[1]);
      break;
    default:
      fatal(0, "Usage: mycolrm col_debut [col_fin]\n", EXIT_FAILURE);
    }

  fatal(!(max < min), "Usage: mycolrm col_debut [col_fin]\nErr: l indice de depart doit etre inferieur a l indice de fin.", EXIT_FAILURE);

  while ((readl(tab)) != EOF)
    {
      cpt = 0;
      while ((tab[cpt] != '\0') && (tab[cpt] != '\n'))
	{
	  if (((cpt < min) || (cpt >= max)))
	    {
	      putchar(tab[cpt]);
	    }
	  cpt++;
	}
      putchar('\n');
    }
  
  return EXIT_SUCCESS;
}
