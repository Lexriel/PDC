#include "tools.h"

int main(int argc, char * argv[])
{
  char tab[MAXLINE];
  int min, max, cpt, cpt_delim;
  char delimiteur;

  switch(argc)
    {
    case 4:
      max = atoi(argv[3]);
      min = atoi(argv[2]);
      delimiteur = argv[1][0];
      break;
    case 3:
      max = MAXLINE;
      min = atoi(argv[1]);
      delimiteur = argv[1][0];
      break;
    default:
      fatal(0, "Usage: mycut delimiteur col_debut [col_fin]", EXIT_FAILURE);
    }

  /* si le minimum est plus grand que le maximum */
  fatal(!(max < min), "Usage: mycut delimiteur col_debut [col_fin]\nErr: l indice de depart doit etre inferieur a l indice de fin.", EXIT_FAILURE);

  while ((readl(tab)) != EOF)
    {
      cpt = 0;
      cpt_delim = 0;
      while ((tab[cpt] != '\0') && (tab[cpt] != '\n'))
	{
	  if (tab[cpt] == delimiteur)
	    {
	      cpt_delim ++;
	      if (cpt_delim == min)
		{
		  putchar(tab[cpt]);
		}
	    }
	  if (((cpt_delim < min) || (cpt_delim >= max)))
	    {
	      putchar(tab[cpt]);
	    }
	  cpt++;
	}
      putchar('\n');
    }
  
  return EXIT_SUCCESS;
}
