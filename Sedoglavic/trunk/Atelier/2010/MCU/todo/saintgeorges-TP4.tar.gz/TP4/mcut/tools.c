#include <stdio.h>
#include <stdlib.h>

#define MAXLINE 81

void mcolrm(int col, int end) {
	int c;
	int nbC; /* indique la place du caractere courant */

	nbC = 0;
	
	if (col > end) {
		fprintf(stderr,"Erreur d'argument !\n");
		exit(EXIT_FAILURE);
	}

	if ((col == 0) || (end == 0)) {
		fprintf(stderr,"Erreur d'argument (zero interdit) !\n");
		exit(EXIT_FAILURE);
	}

	while((c=getchar()) != EOF) {

		nbC++;
		if (nbC >= MAXLINE) {
			fprintf(stderr,"Ligne trop grande !\n");
			exit(EXIT_FAILURE);
		}

		switch (c) {
			case '\n':
				nbC = 0;
			default:
				if (!((nbC >= col) && (nbC <= end)))
					fprintf(stdout,"%c",c);
				break;
		}
	}
}

void mcut(int separator,int col, int end) {
	int c;
	int nbC; /* indique la place du caractere courant */
	int nbCol; /* indique la colonne courante */

	nbC = 0;
	nbCol = 1;

	if (col > end) {
		fprintf(stderr,"Erreur d'argument !\n");
		exit(EXIT_FAILURE);
	}

	if ((col == 0) || (end == 0)) {
		fprintf(stderr,"Erreur d'argument (zero interdit) !\n");
		exit(EXIT_FAILURE);
	}

	while((c=getchar()) != EOF) {

		nbC++;
		if (nbC >= MAXLINE) {
			fprintf(stderr,"Ligne trop grande !\n");
			exit(EXIT_FAILURE);
		}

		switch (c) {
			case '\n':
				nbC = 0;
				nbCol = 1;
				fprintf(stdout,"%c",c);
			default:
				if (c != separator) {
					if (!((nbCol >= col) && (nbCol <= end)))
						fprintf(stdout,"%c",c);
				}
				else { 
					nbCol++;
				}
				break;
		}
	}
}
