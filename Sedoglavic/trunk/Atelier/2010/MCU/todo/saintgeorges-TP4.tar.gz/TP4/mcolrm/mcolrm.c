#include <stdlib.h>
#include <stdio.h>
#include "tools.h"

#define MAXLINE 81

int main(int argc, char *argv[]) {
	int col; /* debut de colonne a supprimer */
	int end; /* fin de colonne a supprimer */

	if(argc>1)
		col = atoi(argv[1]);
	else
		col = MAXLINE;
	if(argc>2)
		end = atoi(argv[2]);
	else
		end = MAXLINE;

	mcolrm(col,end);

	return EXIT_SUCCESS;
}
