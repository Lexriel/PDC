#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXLINE 81

void init(char* tab) {
	int i;
	for (i=0;i < MAXLINE;i++) {
		tab[i] = '\0';
	}
}

int mgrep(char* word) {
	int c;
	int nbC; /* indique la place du caractere courant */
	char line[MAXLINE];
	int valeurRetour;
	
	valeurRetour = EXIT_FAILURE;
	nbC = 0;
	

	init(line);


	while((c=getchar()) != EOF) {

		
		if (nbC >= MAXLINE) {
			fprintf(stderr,"Ligne trop grande !\n");
			exit(EXIT_FAILURE);
		}

		switch (c) {
			case '\n':
				nbC = 0;
				if (strstr(line,word) != NULL) {
					fprintf(stdout,"%s\n",line);
					valeurRetour = EXIT_SUCCESS;
				}
				init(line);
				break;
			default:
				line[nbC] = c;
				nbC++;
				break;
		}
	}
	return valeurRetour;

}
