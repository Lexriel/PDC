#include <stdlib.h>
#include <stdio.h>
#include "tools.h"

#define MAXLINE 81

int main(int argc, char *argv[]) {
	int separator; /* caractere separateur */
	int col; /* debut de colonne a supprimer */
	int end; /* fin de colonne a supprimer */

	if(argc>1)
		separator = argv[1][0];
	else {
		fprintf(stderr,"Aucun caractere separateur specifie !\n");
		exit(EXIT_FAILURE);
	}
	if(argc>2)
		col = atoi(argv[2]);
	else
		col = MAXLINE;
	if(argc>3)
		end = atoi(argv[3]);
	else
		end = MAXLINE;
	mcut(separator,col,end);

	return EXIT_SUCCESS;
}
