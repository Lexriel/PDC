void mcolrm(int col, int end);
void mcut(int separator,int col, int end);
