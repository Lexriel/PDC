void init(char* tab);
int mlook(char* word);
