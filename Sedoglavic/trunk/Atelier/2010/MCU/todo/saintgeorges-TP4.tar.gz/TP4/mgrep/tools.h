void init(char* tab);
int mgrep(char* word);
