#include <stdlib.h>
#include <stdio.h>
#include "tools.h"

#define MAXLINE 81

int main(int argc, char *argv[]) {

	if(argc>1)
		return mlook(argv[1]);
	else {
		fprintf(stderr,"Aucun mot a rechercher !\n");
		return EXIT_FAILURE;
	}
}
