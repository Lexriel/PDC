#include <stdio.h>
#include <stdlib.h>

#define MAXLINE 81

void init(char* tab) {
	int i;
	for (i=0;i < MAXLINE;i++) {
		tab[i] = '\0';
	}
}

int mlook(char* word) {
	int c;
	int nbC; /* indique la place du caractere courant */
	char line[MAXLINE];
	int maybe; /* detecteur pour word */
	int valeurRetour;
	
	valeurRetour = EXIT_FAILURE;
	maybe = 0;
	nbC = 0;
	

	init(line);


	while((c=getchar()) != EOF) {

		
		if (nbC >= MAXLINE) {
			fprintf(stderr,"Ligne trop grande !\n");
			exit(EXIT_FAILURE);
		}

		switch (c) {
			case '\n':
				nbC = 0;
				if (maybe == -1) {
					fprintf(stdout,"%s\n",line);
					valeurRetour = EXIT_SUCCESS;
				}
				maybe = 0;
				init(line);
				break;
			default:
				if ((c == word[maybe]) && (nbC == maybe) && (maybe < sizeof(word))) {
					maybe++;
				}
				if (maybe == sizeof(word))
					maybe = -1;
				line[nbC] = c;
				nbC++;
				break;
		}
	}
	return valeurRetour;

}
