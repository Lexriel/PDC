#include <stdio.h>
#include <stdlib.h>
#include "readl.h"


int
main(int argc, char **argv){ 
  
  char line[MAXLINE]; /* tableau de 80 caracteres */
  int j,size;
  
  if ( argc >= 2){
    if (argc == 2){
      while((size = readl(line)) != 0){/* tantque je lis des lignes*/
	for (j = 0; j < size; j++){
	  if (j+1 != atoi(argv[1])){
	    printf("%c",line[j]);
	  }
	}
      }
    }else 
      if (argc == 3){
	while((size = readl(line)) != 0){/*tant que je lis des lignes*/
	  for (j = 0; j < size; j++){
	    if (!((j+1 >= atoi(argv[1]))&&(j+1 <= atoi(argv[2])))){
	      printf("%c",line[j]);
	    }
	  }
	} 
      }
    printf("%s" ,"\n");
    exit(EXIT_SUCCESS);
  }   
  else{
    exit(EXIT_FAILURE);
  }
}

  
