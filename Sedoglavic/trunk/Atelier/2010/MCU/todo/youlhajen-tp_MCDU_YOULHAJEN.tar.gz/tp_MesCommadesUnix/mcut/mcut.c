#include <stdio.h>
#include <stdlib.h>
#include "readl.h"
#include <string.h>


int main(int argc, char **argv)
{
  
  int size,i,j,col;
  char line[MAXLINE];
  int numCol=-1;
  char delim;
  int precedenteValeurCol;

  if (argc >= 3){
    while((size = readl(line)) !=0){/*pour chaque ligne du fichier*/
      delim = *argv[1];
      for (j=2;j<argc;j++){
	numCol = atoi(argv[j]);
	col = 1;
	precedenteValeurCol = col;
	for(i=0; i < size;i++){
	  if (line[i] == delim)
	    col++;
	  if ((col == numCol)&&(line[i] != delim))
	    printf("%c",line[i]);
	}
	if ((col != precedenteValeurCol)&&(j != argc-1)){/*pour separer les colonnes par un delimiteur*/
	  /*(j != argc-1) pour ne pas afficher le delimoteur à la fin de la derniere colonne*/
	  printf("%c",delim);
	} 	
      }
      printf("%s","\n");
    }
    
    exit(EXIT_SUCCESS);
  }
  else{
    printf("%s","utilisation: mcut delim col1 [col'n'] \n");
    exit(EXIT_FAILURE);
  }

}
