#include <stdio.h>
#include <stdlib.h>
#include "readl.h"
#include <string.h>

int main(int argc, char **argv)
{
  
  int size,i,j;
  char line[MAXLINE];
  int comp = 1;
  char *chaine;


  if (argc == 2){
    while((size = readl(line)) !=0){/*pour chaque ligne du fichier*/
      chaine = argv[1];
      i = strlen(chaine);
      comp=1;
      if (i <= size){/* avant tout, il faut que la taille de chaine soit infereure à celle de la ligne*/ 
	for (j=0 ; j < i ; j++){/*pacourir la chaine tout en comparant si la ligne debute par "chaine"*/
	  if (line[j] != chaine[j])
	    comp = 0;/*dès qu'il ya un caractère qui differe alors la ligne ne commence pas par chaine*/
	}
	if (comp) {
	  printf("%s",line);
	}
      }
    }
    exit(EXIT_SUCCESS);
  }
  else{
    printf("%s","utilisation: mlook string \n");
    exit(EXIT_FAILURE);
  }

}

