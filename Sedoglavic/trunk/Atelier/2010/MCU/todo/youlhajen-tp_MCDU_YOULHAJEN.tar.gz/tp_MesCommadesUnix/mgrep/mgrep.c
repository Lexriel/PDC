#include <stdio.h>
#include <stdlib.h>
#include "readl.h"
#include <string.h>

int main(int argc, char **argv)
{
  
  int size;
  char line[MAXLINE];
  char *chaine, *res;
 
  if (argc == 2){
    while((size = readl(line))!=0){/*pour chaque ligne du fichier*/
      chaine = argv[1];
      if (strlen(chaine) <= size){
	res = strstr(line,chaine);
	if (res){ 
	  printf("%s",line);
	}
      }
    }
      exit(EXIT_SUCCESS);
    }
  else{
    printf("%s","utilisation: mgrep string \n");
    exit(EXIT_FAILURE);
  }
}


