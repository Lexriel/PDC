#include "readl.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>


int readl(char line[]){
  char *tab;
  int i , size;
  i = 0;
  
  /*printf("tapez votre texte : \n");*/
  tab = fgets(line,MAXLINE,stdin);
  if (tab != NULL) {
    size= strlen(line);
    /*printf("\non ne conserve que cette partie de texte : \n");*/
    /* printf("%s",line);*/
    return size;
    /*printf("%d \n",size);*/
  } else {
    return 0;
  } 
}

/*int
main()
{
  char line[MAXLINE];
  return  readl(line);
  exit(EXIT_SUCCESS);
}*/
