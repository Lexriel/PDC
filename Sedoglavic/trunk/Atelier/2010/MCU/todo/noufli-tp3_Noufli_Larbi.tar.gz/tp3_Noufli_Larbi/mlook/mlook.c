#include <stdio.h>
#include <stdlib.h>
#include "tools.h"
#include "readl.h"
#include <string.h>


int main(int argc, char *argv[]){
  char buffeur [MAXLINE];
  char alphabetique[MAXLINE];
  int indice;
  int trouve;
  /* Gestion des erreurs */

  /* On teste d'abord s'il n'y a pas trop d'argument */
  if ( argc != 2 ) {
    fatal(-1,"Probleme d'argument\nmlook word\n",EXIT_FAILURE);
  }
  trouve=0;
  while ( readl(buffeur,sizeof(buffeur)) != -1 ) {
    if ( alphabetique==NULL) { strcpy(alphabetique,buffeur);}
    else {
      if (strcmp(alphabetique,buffeur)==1){
	fatal(-1,"Le fichier n'est pas dans l'ordre alphabetique",EXIT_FAILURE);
      }
      strcpy(alphabetique,buffeur);
    }
    indice=0;
    while (1==1) {
      if ( argv[1][indice]!=buffeur[indice]){
	break;
      }
      indice++;
      if (indice==(strlen(argv[1])-1)) {
	printf("%s\n",buffeur);
	trouve++;
	break;
      }
    }
  }
  if (trouve > 0) {exit(EXIT_SUCCESS);}
  exit(EXIT_FAILURE);
}
