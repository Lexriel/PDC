#include <stdio.h>
#include <stdlib.h>
#include "tools.h"
#include "readl.h"
#include <string.h>


int main(int argc, char *argv[]){
  char buffeur [MAXLINE];
  int indice;
  int trouve;
  int courant;
 
  /* Gestion des erreurs */

  /* On teste d'abord s'il n'y a pas trop d'argument */
  if ( argc != 2 ) {
    fatal(-1,"Probleme d'argument\nmgrep word\n",EXIT_FAILURE);
  }
  trouve=0;
  while ( readl(buffeur,sizeof(buffeur)) != -1 ) {
    indice=0;
    courant=0;
    while (buffeur[indice]!='\0') {
      if (courant==(strlen(argv[1])-1)) { 
	printf("%s\n",buffeur);
	trouve++;
	break;
      }
      else if ( argv[1][courant]==buffeur[indice]){
	courant++;
      }
      else{
	courant=0;
	if(argv[1][courant]==buffeur[indice]){courant++;}
      }
      indice++;
    }
  }
  if (trouve > 0) {exit(EXIT_SUCCESS);}
  exit(EXIT_FAILURE);
}
