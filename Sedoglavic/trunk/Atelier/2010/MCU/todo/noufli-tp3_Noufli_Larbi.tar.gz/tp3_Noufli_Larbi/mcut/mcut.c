#include <stdio.h>
#include <stdlib.h>
#include "tools.h"
#include "readl.h"
#include <string.h>
#define SIZE 82

int main(int argc, char *argv[]){
  int i;
  int j;
  int cpt;
  char buffeur [SIZE];
  
  /* Gestion des erreurs */

  /* Test le nombre d'argument */
  if ( argc < 3 ) {
    fatal(-1,"Pas assez d'argument\nmcut delim col1 col2 ...",EXIT_FAILURE);
  }
  
  /* On test si le delimiteur est bien un seul caractere */ 
  if (strlen(argv[1]) > 1) { fatal(-1,"Erreur de delimiteur",EXIT_FAILURE);}

  /* On test si les arguments donné sont des entiers */
  for (i=2;i<argc;i++){
    if (atoi(argv[i])==0) { fatal(-1,"Erreur de colonne",EXIT_FAILURE); }
  }

  cpt =1;
  while ( readl(buffeur,sizeof(buffeur)) != -1 ) {
    for(i=0;i<strlen(buffeur);i++){
      if(buffeur[i]==*argv[1]){cpt++;}
      for(j=2;j<argc;j++){
	if(cpt==atoi(argv[j])){printf("%c",buffeur[i]);}
      }
    }
    printf("\n");
  }
  return(0);
}
    
