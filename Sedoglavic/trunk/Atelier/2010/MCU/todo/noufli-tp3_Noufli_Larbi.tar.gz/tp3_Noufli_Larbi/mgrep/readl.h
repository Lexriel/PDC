#define MAXLINE 81

/* Lit une chaine sur l'entree standerd.
   Cette ligne doit comproter moins de MAXLINE caracteres.
    
   Un resultat est retourne dans la line.
   Un \0 est ecrit en fin de cette chaine.

   Le tableau line doit etre de taille au moins MAXLINE+1.

   Retourne le nombre de caracteres lu, non compris le \0 final.
   Retourrne EOF si la fin du fichier est atteinte.

   Termine le programme sur une erreur si rencontre une ligne de plus de MAXLINE caracteres.

*/

extern int readl(char line[] , int taille);
