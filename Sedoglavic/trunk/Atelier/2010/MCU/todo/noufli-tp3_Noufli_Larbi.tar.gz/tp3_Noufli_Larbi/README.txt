Noufli Larbi
Le 13 octobre 2010


 	The colrm utility removes selected columns from the lines of a file.  A
     	column is defined as a single character in a line.  Input is read from
     	the standard input.  Output is written to the standard output.

     	
	cut 
	Print selected parts of lines from each FILE to standard output.


	grep  searches the named input FILEs (or standard input if no files are
       	named, or if a single hyphen-minus (-) is given as file name) for lines
       	containing  a  match to the given PATTERN.  By default, grep prints the
       	matching lines.

       
	The look utility displays any lines in file which contain string as a
    	prefix.



	



