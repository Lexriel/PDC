#include <stdio.h>
#include <stdlib.h> 
#include <string.h>
#include "readl.h"
#include "tools.h"

int readl (char line [] , int taille) {
  char * caractere;

  if (taille < MAXLINE ) {
    fatal(-1,"Tableau trop petit",EXIT_FAILURE);
  }

  if (fgets(line,MAXLINE,stdin)  == NULL ){ 
    return EOF;
  }

  if (line == NULL ) {
    fatal(-1,"Pointeur null",EXIT_FAILURE);
  }

  caractere = strstr(line,"\n");
  if (line == NULL) {
    fatal(-1,"Trop de caractere",EXIT_FAILURE);
  }

  *caractere ='\0';
  
  return strlen(line);
}
