#include <stdio.h>
#include <stdlib.h>
#include "tools.h"
#include "readl.h"
#include <string.h>
#define SIZE 82 
int main(int argc, char *argv[]){
  int i;
  int col1;
  int col2;
  char buffer [SIZE];

  /* Gestion des erreurs */

  /* Test du nombre d'arguments */
  if ( argc > 3 ) {
    fatal(-1,"vous avez rentrez trop d'argument\nmcolrm col1 col2",EXIT_FAILURE);
  }

  /* Verification que les arguments rentré sont bien des entiers*/
  for (i=1;i<argc;i++){
    if (atoi(argv[i])==0) { fatal(-1,"Erreur de colonne",EXIT_FAILURE); }
  }

  if (argc >=2) {col1=atoi(argv[1]);}
  if (argc ==3) {col2=atoi(argv[2]);}
  
  while ( readl(buffer,sizeof(buffer)) != -1 ) {
    if (argc==1) {printf("%s",buffer);}
    else {
      if (argc ==2 ) { col2=strlen(buffer);} 
      for(i=1;i<strlen(buffer)+1;i++){
	if(i<col1 || i > col2 ){printf("%c",buffer[i-1]);}
      }
    }
    printf("\n");
  }
  return(0);
}
    
