#define MAXLINE 81
extern int readl(char line[] , int taille);
