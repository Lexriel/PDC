#include <stdio.h>
#include <string.h>
#include "readl.h"

int main(int argc, char * argv[])
{

  char* mot;
  char buffer_ligne[MAXLINE];
  char* tmp;
 
  if (argc!=2)
    {
      fprintf(stderr, "probleme d'argument, un seul argument requis\n");
    }
  else 
    {
      mot = argv[1];

       while (readl(buffer_ligne))
	{
	  tmp = strstr(buffer_ligne, mot);
	  if (tmp == buffer_ligne)
	    {
	      fprintf(stdout,"--> %s", tmp);
	    }
	}
    } 
  return 0;
}

