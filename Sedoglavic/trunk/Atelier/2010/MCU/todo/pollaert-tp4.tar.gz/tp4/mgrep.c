#include <stdio.h>
#include <string.h>
#include "readl.h"

int main(int argc, char * argv[])
{

  char* mot;
  char buffer_ligne[MAXLINE];

 
  if (argc!=2)
    {
      fprintf(stderr, "probleme d'argument, un seul argument requis\n");
    }
  else 
    {
      mot = argv[1];

      while (readl(buffer_ligne))
	{
	  if (strstr(buffer_ligne, mot))
	    {
	      fprintf(stdout,"--> %s", buffer_ligne);
	    }
	}
    } 
  return 0;
}

