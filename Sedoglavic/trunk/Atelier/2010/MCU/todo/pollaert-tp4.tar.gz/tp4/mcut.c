#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"


int main(int argc, char * argv[])
{

  char buffer_ligne[MAXLINE];
  char tmp[MAXLINE];
  char * delim;
  int debut,fin, idx, cpt, nb, taille;
  enum {ETAT_DEBUT, ETAT_ERASE, ETAT_OK} 

  etat= ETAT_DEBUT;
  idx=0;
  cpt=0;
  nb=0;
  
  /****** Cas Erreur: aucun ou plus de deux arguments ******/
  if ((argc <3) || (argc >4))
    {
      fprintf(stderr, "probleme d'arguments \n");
    }
 
  /****** Cas: 2 argument --> ou initialisation fin = debut ******/
  if (argc==3)
    {
      delim = argv[1];
      debut = atoi(argv[2]);
      fin = debut;
    }
  
  /****** Cas: 3 argument ******/
  if (argc==4)
    {
      delim = argv[1];
      debut = atoi(argv[2]);
	  fin = atoi(argv[3]);
    }
  /* on lit les lignes une par une */
  while (taille = readl(buffer_ligne))
    {
      idx = 0;
      etat = ETAT_DEBUT;
      nb=1;
      for (cpt=0; cpt<taille ; cpt++)
	{
	  switch(etat)
	    {   
	    case ETAT_DEBUT:
	      if (buffer_ligne[cpt]==delim[0])
		{
		  nb++;
		  if (nb==debut)
		    {
		      etat=ETAT_ERASE;
		    }
		  else 
		    {
		      tmp[idx]= buffer_ligne[cpt];
		      idx++;
		    }
		} 
	      else 
		{
		  tmp[idx]= buffer_ligne[cpt];
		  idx++;
		}
	      break;
	    case ETAT_ERASE:
	      if (buffer_ligne[cpt]==delim[0])
		{
		  if (nb==fin)
		    {
		      etat=ETAT_OK;
		    }
		  nb++;
		}
	      break;
	    case ETAT_OK:
	      tmp[idx]= buffer_ligne[cpt];
	      idx++;
	      break;
	    }
	}
      tmp[idx] = '\0';
      fprintf(stdout, "--> %s\n",tmp);
    }

  return 0;
}
      
