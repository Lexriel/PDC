#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"


int main(int argc, char * argv[])
{

  char buffer_ligne[MAXLINE];
  char tmp[MAXLINE];
  int i, j, cpt,idx;
  idx = 0;

  /****** Cas: 1 argument ******/
  if (argc==2)
    {
      i = atoi (argv[1]);

      while (readl(buffer_ligne))
	{
	  for (cpt=0; cpt<MAXLINE ; cpt++)
	    {
	      if (cpt>=i-1)
		{
		 tmp[cpt]=buffer_ligne[cpt+1]; 
		}  
	      else
		{
		  tmp[cpt]=buffer_ligne[cpt];
		}
	    }
	  fprintf(stdout, "--> %s\n", tmp);
	}
    }
  else
    {
      /****** Cas: 2 arguments ******/
      if (argc==3)
	{
	  i = atoi (argv[1]);
	  j = atoi (argv[2]);

	  while (readl(buffer_ligne))
	    {
	      idx=0;
	      for (cpt=0; cpt<MAXLINE ; cpt++){
		if ( !( (cpt>=i-1)&&(cpt<=j-1) ) ){
		  tmp[idx]= buffer_ligne[cpt];
		  idx++;
		}
	      }
	      fprintf(stdout, "--> %s\n",tmp);
	    }
	}
      
      /****** Cas: aucun ou plus de deux arguments ******/
      else 
	{
	  fprintf(stderr, "probleme d'arguments \n");
	} 
    }
  return 0;
}
      
