#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXLINE 81

extern int readl(char line[])
{
  if (fgets(line, MAXLINE, stdin)==NULL){
    exit(EXIT_FAILURE);
  }
  else 
    {
      return strlen(line);
    }
  return 0;
}
