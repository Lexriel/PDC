/** NOM = YASAR
    PRENOM = Abdurrahman
    GROUPE 2
    ETUDIANT ERASMUS
*/

#include "tools.h"
#include <string.h>

int main(int argc, char *argv[])
{
	char *s1=NULL;
	char *s2=NULL;
	char s[83];
	int len=0,ctrl=1;

	if(argc==2){
		/*there is one argument*/
		s1=argv[1];
		len=strlen(s1);
		while(readline(s)!=NULL && ctrl){
			if(strlen(s)<=80){			
				s2=strstr(s, s1);
				if(s2!=NULL)
					printf("%s",s);
			}
			else{
				printf("line is too long\n");
				ctrl=0;
			}
		}		
	}	
	else {
		printf("wrong argument\n");
	}
	return EXIT_SUCCESS;
}
