/** NOM = YASAR
    PRENOM = Abdurrahman
    GROUPE 2
    ETUDIANT ERASMUS
*/

#include "tools.h"
#include <string.h>

int main(int argc, char *argv[])
{	
	char delim;
	int col_start,col_end;
	int stflag=0,endflag=0;
	char a[3],b[3];
	char s[90],s2[90];
	int count=0;
	int i=0,j=0,ctrl=1;

	if(argc==1){
		printf("ERROR - PARAMETER\n");
	}
	else{
		if(argv[1][1]=='\0'){
			delim=*argv[1];
		
			if(options(2,argv,a)==1){
				col_start=atoi(a);
				stflag=1;
				
				if(options(3,argv,b)==1){
					col_end=atoi(b);
					endflag=1;
				}

				if( (stflag && col_start) && (endflag && col_end) ){
					/*there are 2 arguments*/
					while(readline(s)!=NULL && ctrl){
						if(strlen(s)<=80){
							count=0;
							i=0;
							j=0;
							while(s[i]!='\0'){		
								if( (count>=col_start-1) && (count<=col_end-1) ){
									s2[j]=s[i];
									j++;
								}	
								if(s[i]==delim)
									count++;
								i++;
							}
							s2[j-1]='\0';	
							printf("%s\n",s2);
							s2[0]='\0';
						}
						else{
							printf("line is too long\n");
							ctrl=0;
						}
					}
				}
				else if ( (stflag && col_start) && !endflag) {
					/*there is one argument*/
					while(readline(s)!=NULL && ctrl){
						if(strlen(s)<=80){
							count=0;
							i=0;
							j=0;
							while(s[i]!='\0'){		
								if( (count>=col_start-1) ){
									s2[j]=s[i];
									j++;
								}	
								if(s[i]==delim)
									count++;
								i++;
							}
							s2[j-1]='\0';	
							printf("%s\n",s2);
							s2[0]='\0';
						}
						else{
							printf("line is too long");
							ctrl=0;
						}						
					}
				}
				else{
					if( !(col_end && col_start) && (endflag && stflag) ){	
        		                	usage(-2);
		      	         	}	
		      		        if (!(stflag && col_start) && !(endflag && col_end)) {
       		 		                usage(-2);
       		 	        	}
				}
			}
			else{
				printf("you must specify a colonne\n");
			}	
				
		}
		else{
			printf("delimeter must be one character\n");
		}
		
	}	
	return EXIT_SUCCESS;
}
