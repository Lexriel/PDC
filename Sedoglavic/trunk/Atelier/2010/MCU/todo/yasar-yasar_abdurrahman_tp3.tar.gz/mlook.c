/** NOM = YASAR
    PRENOM = Abdurrahman
    GROUPE 2
    ETUDIANT ERASMUS
*/

#include "tools.h"
#include <string.h>

int main(int argc, char *argv[])
{
	char *s1=NULL;
	char *s2=NULL;
	char *s3=NULL;
	char s[83];
	int count=0,i=0,len=0,ctrl=1;

	if(argc==2){
		/*there is one argument*/
		s1=argv[1];
		len=strlen(s1);
		while(readline(s)!=NULL && ctrl){
			if(strlen(s)<=80){
				s2=s;			
				count=0;
				i=0;			
				while(s[i]!=' '){
					count++;
					i++;
				}
				s2=(char*)malloc(count*sizeof(char));
				mstrcpy(s,s2,count);
				if( (len==count) && !strcmp(s1,s2)){
					printf("%s",s);	
				}
				else if(len<count){
					s3=(char*)malloc(len*sizeof(char));
					mstrcpy(s,s3,len);
					if( !strcmp(s1,s3)){
						printf("%s",s);
					}		
				}

			}
			else{
				printf("the line is too long\n");
				ctrl=0;
			}			
		}		
	}	
	else {
		printf("wrong argument\n");
	}
	return EXIT_SUCCESS;
}
