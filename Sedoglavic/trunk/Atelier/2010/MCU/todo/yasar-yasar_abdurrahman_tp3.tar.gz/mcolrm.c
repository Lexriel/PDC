/** NOM = YASAR
    PRENOM = Abdurrahman
    GROUPE 2
    ETUDIANT ERASMUS
*/

#include "tools.h"
#include <string.h>

int main(int argc, char *argv[])
{
	char a[3];char b[3];
	int col_start,col_end;
	int stflag=0,endflag=0;
	char s[81];	
	int i,ctrl=1;
	/*if there is more than 3 arguments return an error message*/
	if(argc>3)
		usage(-3);
	else {	
		if(argc==1){
			/*there is no argument*/
			while(readline(s)!=NULL && ctrl){
				if( strlen(s)<=80)
					printf("%s",s);
				else{
					printf("the line is too long\n");
					ctrl=0;
				}
			}
		}
		else{
			if(options(1,argv,a)==1){
				col_start=atoi(a);
				stflag=1;
			}
			if(options(2,argv,b)==1){
				col_end=atoi(b);
				endflag=1;
			}
			
			if( (stflag && col_start) && (endflag && col_end) ){
				/*there are 2 arguments*/
				while(readline(s)!=NULL && ctrl){	
					if( strlen(s)<=79){
						i=col_start-1;
						while(s[i]!='\0'){		
							s[i]=s[i+col_end-col_start+1];
							i++;
						}	
						printf("%s",s);
					}
					else{	
						printf("the line is too long\n");
						ctrl=0;
					}
				}
			}
			else if ( (stflag && col_start) && !endflag) {
				/*there is one argument*/
				while(readline(s)!=NULL && ctrl){
					if(strlen(s)<=80){	
						i=col_start-1;
						while(s[i]!='\0'){		
							s[i]=s[i+1];
							i++;
						}	
						printf("%s",s);
					}
					else{
						printf("the line is too long\n");
						ctrl=0;
					}
				}
			}
			else{
				if( !(col_end && col_start) && (endflag && stflag) ){	
	                        	usage(-2);
 		               	}	
		                if (!(stflag && col_start) && !(endflag && col_end)) {
       		 	                usage(-2);
       		 	        }
			}
		}
	}
	
	return EXIT_SUCCESS;
}
