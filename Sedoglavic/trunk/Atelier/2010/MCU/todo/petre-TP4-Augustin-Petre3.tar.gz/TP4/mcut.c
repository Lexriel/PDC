#include <stdio.h>
#include <stdlib.h>
#include "readl.h"
#include "tools.h"
#include <string.h>


int
main (int argc, char *argv[])
{			
    	int j,h,cptc,arg,arg2;
    	char l[MAXLINE];
    	cptc=0;
	

	/*gere la situation quand on donne qu'un seul argument*/
	arg=atoi(argv[2]);
	if (argv[3]==NULL){
		arg2=arg;
	}else {
		arg2=atoi(argv[3]);
	
	}


	
	if ( (arg2<arg) ) fatal(0,"argument 2 est inferieure au argument 1!!",EXIT_FAILURE);
	

	/*lit le texte ligne par ligne*/
	while((j=readl(l))!=EOF){
		
		for (h=0;(l[h]!='\0');h++){
			
			if ( l[h]==*argv[1]){
				cptc++;
			}
		

			if ( (cptc<(arg-1)) || ((arg2-1)<cptc) ||(cptc==(arg2-1) && (l[h]==*argv[1]) ) ) {
				
				fprintf(stdout,"%c",l[h]);
			}
			
			
		}	
	fprintf(stdout,"\n");

	}

exit(EXIT_SUCCESS);
}

