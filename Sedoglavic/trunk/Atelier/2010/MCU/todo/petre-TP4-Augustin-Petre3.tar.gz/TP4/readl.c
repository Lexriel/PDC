#define MAXLINE 81
#define EOF (-1)
#include "tools.h"
#include <stdio.h>
#include <stdlib.h>

extern int readl( char line[] ) {
	int cpt,i;
	char c;
	cpt=i=0;
	while(((c=getchar())!='\n')&&(c!=EOF)&& (cpt<MAXLINE )){ /*getchar lit les char de stdin l'entre standar*/
		
		line[i]=c;
		i++;
		cpt++;	
	}


	line[cpt]='\0';	
	if(c=='\n')return cpt;
	if (c==EOF) return EOF;
	fatal(0,"Erreure ligne trop grande \n",EXIT_FAILURE);	

exit(EXIT_SUCCESS);

}
