#define MAXLINE 81
#include <stdio.h>
#include "tools.h"


extern int readl( char line[] );
