#include <stdio.h>
#include <stdlib.h>
#include "readl.h"
#include "tools.h"
#include <string.h>


int
main (int argc, char *argv[])
{

			
    	int j,h,cpt;
    	char l[MAXLINE];
	char *c;	
	cpt=0;
	while ((j=readl(l))!=EOF){
		cpt++;
       
		for (h=0;h<MAXLINE;h++){
			if (l[h]==*argv[1]){
				c=strstr((l+h),argv[1]);
				if(c!=NULL){
					printf("L'argument apparait a la ligne : %d \n",cpt);
				}
			}
		}
	}	

exit(EXIT_SUCCESS);
}

