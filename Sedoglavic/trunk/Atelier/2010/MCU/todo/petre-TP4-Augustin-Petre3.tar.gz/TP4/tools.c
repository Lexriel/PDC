#include <stdio.h>
#include <stdlib.h>

extern void fatal(int assert,const char *message,int status){
	if (!assert){
	fprintf(stderr, "%s",message);
	}
	
	exit(status);
}
