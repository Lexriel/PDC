#include <stdio.h>
#include <stdlib.h>
#include "readl.h"
#include "tools.h"
#include <string.h>



int
main (int argc, char *argv[])
{

			
    	int j,h,cpt,arg,arg2;
    	char l[MAXLINE];
	cpt=0;
	arg=atoi(argv[1])-1;

	/*gere la situation quand on donne qu'un seul argument*/
	
	if (argv[2]==NULL){
		arg2=arg;
	}else {
		arg2=atoi(argv[2])-1;
	}

	if ( (arg2>(MAXLINE-1)) ||  (arg>(MAXLINE-1)) ) fatal(0,"arguments superieurs au nombres de colonnes !!",EXIT_FAILURE);
	if ( (arg2<arg) ) fatal(0,"argument 2 est inferieure au argument 1!!",EXIT_FAILURE);

	/*lit le texte ligne par ligne*/
	while((j=readl(l))!=EOF){
	
		for (h=0;l[h]!='\0';h++){
			if ( (h<(arg-1)) || ((arg2)<=h) ) {
				fprintf(stdout,"%c",l[h]);
			}
		}
	}
	
		fprintf(stdout,"\n");
exit(EXIT_SUCCESS);
}

