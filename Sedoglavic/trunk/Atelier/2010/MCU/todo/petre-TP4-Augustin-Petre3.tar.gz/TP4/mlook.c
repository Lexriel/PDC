#include <stdio.h>
#include <stdlib.h>
#include "readl.h"
#include "tools.h"
#include <string.h>

int
main (int argc, char *argv[])
{

			
    	int j,cpt;
    	char l[MAXLINE];
	char *c;	
	cpt=0;
	while ((j=readl(l))!=EOF){/*on lit ligne par ligne*/
		cpt++;
      		c=strstr(l,argv[1]);/*compare le mot qui est en debut de ligne avec notre argument*/
		if(c!=NULL){
		printf("L'argument apparait a la ligne : %d \n",cpt);
		}
	}
exit(EXIT_SUCCESS);
}

