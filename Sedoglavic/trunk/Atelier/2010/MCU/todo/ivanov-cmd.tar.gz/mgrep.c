
#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include "tools.h"

#include "readl.h"



int
main
(int argc,char *argv[])
{
  int i,c;
  char tab[MAXLINE];;
  char *mot;
  int line_length;

  if(argc<2)
    fatal(0==0,"Not enough arguments \n",1);
  if(argc>4){
    fatal(0==0,"Too many arguments \n",1);
  }				    
  while((c=getchar())!=EOF){
    line_length=readl(tab);
    
    mot=strstr(tab,argv[1]);
    
    if(mot){
      for(i=0;i<line_length;i++){
	putchar(tab[i]);
      }
      putchar('\n');
    }
  }
  
  return 0;
}
    
