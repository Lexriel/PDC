#include <stdio.h>
#include <stdlib.h>

#include "tools.h"
#include "readl.h"


int
main
(int argc,char *argv[])
{
  int i,c;
  char tab[MAXLINE];;
  int line_length;
 
  if(argc<2)
    fatal(0==0,"Not enough arguments \n",1);
  if(argc>3)
    fatal(0==0,"Too many arguments \n",1);
  else{
  
    while((c=getchar())!=EOF){
      line_length=readl(tab);
      
      if(argc==2)
	for(i=0;i<atoi(argv[1]);i++){
	  putchar(tab[i]);
	}
      if(argc==3){
	for(i=0;i<atoi(argv[1]);i++){
	  putchar(tab[i]);
	}
	for(i=atoi(argv[2]);i<line_length;i++){
	  putchar(tab[i]);
	}
      }
      putchar('\n');
    }
  }
    return 0;
}
    
    
    
    

