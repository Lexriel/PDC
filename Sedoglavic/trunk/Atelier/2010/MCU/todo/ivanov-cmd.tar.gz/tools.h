extern void fatal(int assert, const char *message, int status);
