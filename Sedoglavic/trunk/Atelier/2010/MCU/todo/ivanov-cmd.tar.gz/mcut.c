#include <stdio.h>
#include <stdlib.h>

#include "tools.h"
#include "readl.h"


int
main
(int argc,char *argv[])
{
  int i,c;
  int delim_count;
  char tab[MAXLINE];
  int line_length;
  
  if(argc<3)
    fatal(0==0,"Not enough arguments \n",1);
  if(argc>4){
    fatal(0==0,"Too many arguments \n",1);
  }
  while((c=getchar())!=EOF){ 
    
  line_length=readl(tab);
  delim_count=0; /* pour arriver a delimiteur numero x */

  /* On compte les delimiteurs dans la ligne */ 
  
  if(argc==3){
    for(i=0;i<line_length;i++){
      if(tab[i]==*argv[1]){
	delim_count++;
      }
      if(delim_count>=atoi(argv[2])){
	putchar(tab[i]);
      }
     
    } 
  }
  if(argc==4) {/* si on a +3 arguments et <4 */
    for(i=0;i<line_length;i++){
      if(tab[i]==*argv[1]){
	delim_count++;
      }
      if(delim_count>=atoi(argv[2]) && delim_count<atoi(argv[3])){
	putchar(tab[i]);
	}
    }
  } 
  }  
  putchar('\n');
  return 0;
}
