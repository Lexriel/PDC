#include <stdlib.h>
#include <stdio.h>


void
fatal
(int assert,const char*message,int status){
  
  if(assert)
    printf("%s",message);
    exit(status);
  
}
