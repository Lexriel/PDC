Author:Iliya Ivanov G3

Notes:L'archive contient les fichier mlook.c mcolrm.c mcut.c mgrep.c readl.c tools.c readl.h, tools.h et Makefile

Pour compiler tous les fichier executez "Make all".

Pour supprimet tous les fichier .o executez "make clean" :)
