#include <stdio.h>
#include <stdlib.h>

#include "tools.h"

#define MAXLINE 81

int
readl
(char line[])
{
  int c;
  int i;

  i=0;
  /* si on a lu plus que 81 chars et on quitte le programme*/
  while((c=getchar())!='\n'){
    line[i]=c;
    i++;
    if(c==EOF){
      return EOF;
    }
  }
  line[i+1]='\0';
  

  
  
  if(i>MAXLINE)
    fatal(1==1,"81 char max \n",1);
  else
    return (i);
}

 
    
    
    
    
    
    
