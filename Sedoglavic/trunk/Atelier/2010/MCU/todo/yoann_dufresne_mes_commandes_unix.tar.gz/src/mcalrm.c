#include <stdio.h>
#include <stdlib.h>
#include "tools.h"
#include "readl.h"

#define MAXLINE 80



int main (int argc, char * argv[]) {
  int nbChars, i, premierChar, finFichier;
  char ligne[MAXLINE + 1];
  
  if (argc < 2)
    fatal(1==2, "pas assez de parametres\n", EXIT_FAILURE);

  premierChar = atoi(argv[1]);
  finFichier = !42;
  
  while (!finFichier) {
    for (i = 0 ; i < MAXLINE + 1 ; i++)
      ligne[i] = '\0';
    nbChars = readl(ligne);
 
    for (i = 0 ; i < premierChar ; i++)
      putchar(ligne[i]);

    if (argc > 2) {
      for (i = atoi(argv[2]); i < MAXLINE ; i++)
	putchar(ligne[i]);
    }

    putchar('\n');

    if (nbChars == EOF)
      finFichier = 42;
  }

  return 0;
}
