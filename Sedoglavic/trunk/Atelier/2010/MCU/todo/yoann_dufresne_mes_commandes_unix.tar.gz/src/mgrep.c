#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tools.h"
#include "readl.h"

#define MAXLINE 80



int main (int argc, char * argv[]) {
  enum etats_m {LECTURE_MOT, NON_LU, LU};
  typedef enum etats_m etat_t;
  etat_t etatCourant;
  int finFichier, nbChars, i, j;
  char ligne[MAXLINE + 1], aReconnaitre[MAXLINE + 1];

  finFichier = !42;
  
  if (argc > 1) {
    for (i = 0 ; i < MAXLINE ; i++)
      aReconnaitre[i] = '\0';
    i = 0;
    while (argv[1][i] != '\0') {
      aReconnaitre[i] = argv[1][i];
      i++;
    }
    aReconnaitre[i] = '\0';
  }
  else
    fatal (!42, "Pas assez d'arguments", EXIT_FAILURE);

  while (!finFichier) {
    etatCourant = NON_LU;
    for (i = 0 ; i < MAXLINE + 1 ; i++)
      ligne[i] = '\0';
    nbChars = readl(ligne);
    
    for (i = 0 ; i < MAXLINE ; i++)
      
      switch (etatCourant) {
      case NON_LU :
	if (aReconnaitre[0] == ligne[i]) {
	  j = 1;
	  etatCourant = LECTURE_MOT;
	}
	break;

      case LU :
	i = MAXLINE;
	break;

      case LECTURE_MOT :
	if (aReconnaitre[i] == '\0')
	  etatCourant = LU;
	else if (aReconnaitre[j] != ligne[i])
	  etatCourant = NON_LU;
	else
	  j++;
	break;

      default :
	fatal (!42, "Comportement non prévu de l'automate", EXIT_FAILURE);
	break;
      }

    if (etatCourant == LU)
      fprintf(stdout, "%s\n", ligne);

    if (nbChars == EOF)
      finFichier = 42;
  }

  return 0;
}
