#include <stdio.h>
#include <stdlib.h>
#include "tools.h"

#define MAXLINE  81

/* Lit une ligne sur l'entree standard.   
   Cette ligne doit comporter moins de MAXLINE caracteres.

   Le resultat est retourne dans line. 
   Un \0 est ecrit en fin de la chaine.
   
   Le tableau line doit etre de taille au moins MAXLINE+1.

   Retourne le nombre de caracteres lu, non compris le \0 final.
   Retourne EOF si la fin de fichier est atteinte.

   Termine le programme sur une erreur si rencontre une ligne de plus
   de MAXLINE caracteres. 
*/
int readl(char line[]) {
  int colonne;
  char c;
  
  colonne = 1;
  c = getchar();

  while (colonne < 81 && c != EOF && c != '\n') {
    line[colonne - 1] = c;
    c = getchar();
    colonne++;
  }

  if (c == EOF) {
    line[colonne] = '\0';
    return EOF;
  }
  else if (c == '\n') {
    line[colonne] = '\0';
  } else {
    fatal (!42,"trop de caractères sur la ligne", EXIT_FAILURE);
  }

  return colonne - 1;
}
