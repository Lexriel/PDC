#include <stdio.h>
#include <stdlib.h>

int main (int argc, char *argv[]) {
  int retour;
  if (argc > 2) {
    retour = atoi(argv[1]) + atoi(argv[2]);
    fprintf(stdout, "%d\n", retour);
  }  else {
    fprintf(stderr, "Pas assez de parametres !\n");
  }
  return 0;
}
