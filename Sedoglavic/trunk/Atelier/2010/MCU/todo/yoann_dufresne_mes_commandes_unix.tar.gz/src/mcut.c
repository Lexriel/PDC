#include <stdio.h>
#include <stdlib.h>
#include "tools.h"
#include "readl.h"

#define MAXLINE 80


int main (int argc, char * argv[]) {
  int nbChars, i, finFichier, nbDelimsLus, debutCut, finCut;
  char ligne[MAXLINE + 1], delim;
  
  if (argc < 3)
    fatal(1==2, "pas assez de parametres\n", EXIT_FAILURE);

  delim = argv[1][0];
  debutCut = atoi(argv[2]);
  if (argc > 3)
    finCut = atoi(argv[3]);
  else
    finCut = MAXLINE + 10;
  finFichier = !42;
  
  while (!finFichier) {
    for (i = 0 ; i < MAXLINE + 1 ; i++)
      ligne[i] = '\0';
    nbChars = readl(ligne);
    nbDelimsLus = 0;

    for (i = 0 ; i < MAXLINE + 1 ; i++) {
      if (ligne[i] == delim)
	nbDelimsLus++;
      if (nbDelimsLus < debutCut || nbDelimsLus > finCut)
	putchar(ligne[i]);
    }
    putchar('\n');
    
    if (nbChars == EOF)
      finFichier = 42;
  }
  
  return 0;
}
