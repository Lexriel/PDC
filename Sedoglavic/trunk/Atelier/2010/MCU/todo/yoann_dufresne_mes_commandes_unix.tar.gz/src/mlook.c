#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tools.h"
#include "readl.h"

#define MAXLINE 80



int main (int argc, char * argv[]) {
  enum etats_m {DEBUT_LIGNE, LECTURE_MOT, NON_LU, LU};
  typedef enum etats_m etat_t;
  etat_t etatCourant;
  int finFichier, nbChars, i;
  char ligne[MAXLINE + 1], aReconnaitre[MAXLINE + 1];

  finFichier = !42;
  
  if (argc > 1) {
    for (i = 0 ; i < MAXLINE ; i++)
      aReconnaitre[i] = '\0';
    i = 0;
    while (argv[1][i] != '\0') {
      aReconnaitre[i] = argv[1][i];
      i++;
    }
    aReconnaitre[i] = '\0';
  }
  else
    fatal (!42, "Pas assez d'arguments", EXIT_FAILURE);

  while (!finFichier) {
    etatCourant = DEBUT_LIGNE;
    for (i = 0 ; i < MAXLINE + 1 ; i++)
      ligne[i] = '\0';
    nbChars = readl(ligne);
    
    for (i = 0 ; i < MAXLINE ; i++)
      
      switch (etatCourant) {
      case DEBUT_LIGNE :
	if (aReconnaitre[0] == ligne[0])
	  etatCourant = LECTURE_MOT;
	else
	  etatCourant = NON_LU;
	break;

      case LU :
      case NON_LU :
	i = MAXLINE;
	break;

      case LECTURE_MOT :
	if (aReconnaitre[i] == '\0')
	  etatCourant = LU;
	else if (aReconnaitre[i] != ligne[i])
	  etatCourant = NON_LU;
	break;

      default :
	fatal (!42, "Comportement non prévu de l'automate", EXIT_FAILURE);
	break;
      }

    if (etatCourant == LU)
      fprintf(stdout, "%s\n", ligne);

    if (nbChars == EOF)
      finFichier = 42;
  }

  return 0;
}
