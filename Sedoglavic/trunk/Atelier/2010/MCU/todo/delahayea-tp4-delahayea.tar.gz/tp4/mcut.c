#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "readl.h"

int main (int argc, char *argv[]){
  char tab[81],retour[81];

  int i,idx,idxcol,taille,debut,fin;

  if(argc < 3 || argc > 4){
    fprintf(stderr, "Err : Arguments manquants\n");
    exit(EXIT_FAILURE);
  }else{
    
    debut = atoi(argv[2]); 
    if(argc == 3){        
      fin = debut;
    }else{
      fin = atoi(argv[3]); 
    }
 
    idx = 0;
    idxcol = 1;
    while((taille=readl(tab))!=EOF){
      
      for(i=0;i<taille;++i){
	
	if(tab[i] == argv[1][0]){	 
	  idxcol++;
	}
	
	
	if((idxcol >= debut && idxcol <= fin)){
	  if(!(idxcol == debut && tab[i]==argv[1][0])){
	    retour[idx] = tab[i];
	    idx++;
	  }
	}
	
      }
      retour[idx] = '\0';
      fprintf(stdout,"%s\n",retour);
      idx = 0;
      idxcol = 1;
    }
    exit(EXIT_SUCCESS);
  }
}
