#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "readl.h"

int main (int argc, char *argv[]){
  char tab[81],retour[81];
  int i,idx,debut,fin;

  if(argc <= 1){
    fprintf(stderr, "Err : Arguments manquants\n");
    exit(EXIT_FAILURE);
  }else{
    
    debut = atoi(argv[1]); 
    if(argc == 2){        
      fin = debut;
    }else{
      fin = atoi(argv[2]); 
    }
 
    idx = 0; 
    while(readl(tab)!=EOF){ 

      /*fprintf(stdout,"mcolrm.c : %s\n",tab);*/   
  
      for(i=0;i<81;++i){
	if(!(i>=debut && i<=fin)){
	  retour[idx]=tab[i];
	  idx++;  
 	}
      }
      fprintf(stdout,"%s",retour);
      idx = 0;
    }
    exit(EXIT_SUCCESS);
  }
}
