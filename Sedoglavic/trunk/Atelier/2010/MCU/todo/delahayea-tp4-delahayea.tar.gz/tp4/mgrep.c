#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "readl.h"

int main (int argc, char *argv[]){
  char tab[81];
  int b_trouve;
  char * retour;

  b_trouve=0;

  if(argc <= 1){
    fprintf(stderr, "Err : Arguments manquants\n");
    exit(EXIT_FAILURE);
  }else{

    while((readl(tab)!=EOF)){
      retour = strstr(tab,argv[1]);
      if(retour != NULL){
	b_trouve=1;
	fprintf(stdout,"\n%s\n",tab);
      }
    }
    if(!b_trouve){
      exit(EXIT_FAILURE);
    }
    exit(EXIT_SUCCESS);
  }
}
