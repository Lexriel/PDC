#define MAXLINE  81

/* Lit une ligne sur l'entree standard.   
   Cette ligne doit comporter moins de MAXLINE caracteres.

   Le resultat est retourne dans line. 
   Un \0 est ecrit en fin de la chaine.
   
   Le tableau line doit etre de taille au moins MAXLINE+1.

   Retourne le nombre de caracteres lu, non compris le \0 final.
   Retourne EOF si la fin de fichier est atteinte.

   Termine le programme sur une erreur si rencontre une ligne de plus
   de MAXLINE caracteres. 
*/
extern int readl(char line[]){
  int taille;
  char * retour;
  if ((retour=fgets(line,MAXLINE,stdin))!=NULL) {
    taille = strlen(line);
    /* if(line[taille-1] == '\n'){*/
      /*      printf("readl.h %d %s  ##  %s\n",taille-1,line,retour);*/
      return taille-1;
      /*  }else{
      printf("EOF\n");
      return EOF;
      }*/
  }else{
    return EOF;
    /*    printf("Erreur readl.h\n %s\n",retour);*/
    /*exit(EXIT_FAILURE);
      return 1;*/
  }
}
