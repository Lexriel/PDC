COMMANDES UNIX
date : 19.10.2010
Auteur : LOUIS Sebastien

L'archive rendue est composée de 4 sous dossiers, un par commande unix.

Chaque dossier contient 4 fichiers : 
       - le makefile correspondant à la commande.
       - le le fichier readl.c qui contient le code de la fonction accessoire : readl, utilisée dans les quatres commandes.
       - le fichier readl.h qui contient la signature de readl.c ainsi que les déclarations des macros.
       - le fichier contenant le code de la commande.
       

Il y a donc 5 fonctions disctinctes : 
   - la fonction readl
   - la fonction mcolrm
   - la fonction mcut
   - la fonction mlook
   - la fonction mgrep

La fonction readl retourne une chaine de caracteres, elle lit, à l'aide de la fonction getchar jusqu'à lire un EOF, ou un retour à la ligne, et elle rajoute le caractere '\0' a la fin, qui symbolisera la fin de la chaine. Si elle a lu un EOF(fin de fichier), alors ce sera sa valeur de retour, sinon elle retourne le nombre de caracteres lus.

Chacune des quatres fonctions suivantes fait la vérification du nombre d'arguments passés lors de l'appel de la fonction dans le terminal.

La fonction mcolrm vérifie d'abord le nombre de parametre passés à l'appel, afin d'établir le bon comprtement. à l'aide de deux boucles for, elle afiche à l'aide d'un putchar, les caractères qui doivent l'etre.

La fonction mcut a à peu pres le meme comportement que mcolrm si ca n'est que le chaine lue par readl est parcourue en entier et, à l'aide d'une variable servant de booléen, les caractères sont affichés ou non.
   
La fonction mlook parcourt tout le fichier, lis ligne par ligne grace à readl. Et, en utilisant la transitivité de l'opérateur inferieur ou égal, compare chaque ligne avec sa précédente, et ainsi vérifie que les lignes sont ordonnées. ensuite, l'affichage se fait si le test : strstr == t2. car strstr retourne la chaine dans laquelle on recherche, si la souschiane recherchée est préfixe que celle-ci.

La fonction mgrep fait la meme chose que la fonction mlook, mais ne vérifie par l'ordonnace des lignes, et l'affichage se fait si la fonction strstr ne retourne pas null, donc si la chaine recherchée est une sous-chaine...
