#include "readl.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int
main
(int argc, char * argv[])
{
  char t1[MAXLINE+1],t2[MAXLINE+1],*mot;
  int i;
  if (argc!=2){
    fprintf(stderr,"le nombre d'arguments est le mauvais\n");
    exit(EXIT_FAILURE);
  }
  mot=argv[1];
  readl(t1);
  while(readl(t2)!=EOF){
    if (strcmp(t1,t2)>0){
      fprintf(stderr,"les lignes ne sont pas triees\n");
      exit(EXIT_FAILURE);
    }
    if(strstr(t2,mot)==t2){
      printf("%s\n",t2);
    }
    if (strcmp(mot,t2)>0)
      return 0;
    for (i=0;i<=MAXLINE;i++)
      t1[i]=t2[i];
  } 
  if (strstr(t2,mot)==t2)
    printf("%s\n",t2);
  return 0;
}
