#include "readl.h"
#include <stdio.h>
#include <stdlib.h>
int
main
(int argc, char * argv[])
{
  int debut,fin,i;
  char t[MAXLINE+1];
  fin=0;
  if ((argc<2)||(argc>3)){
    fprintf(stderr,"le nombre d'arguments est mauvais\n");
    exit(EXIT_FAILURE);
  }
  if (argc==2)
    fin=MAXLINE;
  else
    fin=atoi(argv[2])-1;
  debut=atoi(argv[1])-1;
  while (readl(t)!=EOF) {
    for(i=0;(t[i]!='\0')&&(i<debut);i++){
      putchar(t[i]);
    }
    for (i=fin;(t[i]!='\0')&&(i<MAXLINE+1);i++){
      putchar(t[i]);
    }
    putchar('\n');
  }
  for(i=0;(t[i]!='\0')&&(i<debut);i++){
    putchar(t[i]);
  }
  for (i=fin;(t[i]!='\0')&&(i<MAXLINE+1);i++){
    putchar(t[i]);
  }
  return 0; 
}
