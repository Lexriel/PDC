#include <stdio.h>
#include <stdlib.h>
#include "readl.h"
int
readl
(char line[])
{
  int i,c;
  i=0;
  while ((i<MAXLINE)&&((c=getchar())!=EOF)&&(c!='\n'))
    line[i++]=c;
  line[i]=c;
  if ((line[i]!='\n')&&(line[i]!=EOF))
    fprintf(stderr,"trop de caracteres\n");
  else
    line[i]='\0';
  if (line[i-1]==EOF)
    return EOF;
  else
    return i-1;
}
