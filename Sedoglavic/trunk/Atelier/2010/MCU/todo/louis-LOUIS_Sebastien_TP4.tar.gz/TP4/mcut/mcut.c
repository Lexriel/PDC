#include "readl.h"
#include <stdio.h>
#include <stdlib.h>
int
main
(int argc, char * argv[])
{
  int i,a_garder[MAXLINE],j,k,ecrire;
  char t[MAXLINE+1],delim;
  if (argc<3){
    fprintf(stderr,"le nombre d'arguments est mauvais\n");
    exit(EXIT_FAILURE);
  }
  delim=argv[1][0];
  for(i=0;i<argc-3;i++)
    a_garder[i]=atoi(argv[i+2])-1;
  while (readl(t)!=EOF) 
    {
      j=0;
      for(i=0;(t[i]!='\0')&&(i<MAXLINE+1);i++){
	ecrire=0;
	if(t[i]==delim)
	  j++;
	for(k=0;k<argc-2;k++)
	  if (j==a_garder[k])
		 ecrire++;
	if (ecrire)
	  putchar(t[i]);
      }
      putchar('\n');
    }
  j=0;
  for(i=0;(t[i]!='\0')&&(i<MAXLINE+1);i++){
    ecrire=0;
    if(t[i]==delim)
      j++;
    for(k=0;k<argc-2;k++)
      if (j==a_garder[k])
	     ecrire++;
    if (ecrire)
      putchar(t[i]);
  }
  return 0;
}
