#include "readl.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int
main
(int argc, char * argv[])
{
  char t[MAXLINE+1],*mot;
  if (argc!=2){
    fprintf(stderr,"le nombre d'arguments est le mauvais\n");
    exit(EXIT_FAILURE);
  }
  mot=argv[1];
  while(readl(t)!=EOF){
    if(strstr(t,mot)!=NULL){
      printf("%s\n",t);
    }
  }
  if (strstr(t,mot)!=NULL)
    printf("%s\n",t);
  return 0;
}
