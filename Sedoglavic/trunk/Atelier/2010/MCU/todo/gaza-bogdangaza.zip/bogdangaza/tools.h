#ifndef TOOLS_H
#define TOOLS_H

extern void fatal(int assert, const char *message, int status);
extern char ** tokenize(char *, char *, int *);

#endif
