#include <stdio.h>
#include "readl.h"
#include "tools.h"
#include <stdlib.h>

int
main(int argc, char * argv[]){

  char line[1024]; /* line buffer */
  int size; /* size of each line */

  char **p; /* double pointer returned by tokenize tool */
  char *delim=NULL; /* provided delimitator */
  int pos=0; /* length of token */
  int i=0;
  int start;
  int end;

  /* verify that the provided arguments are there */
  if(argc<2){
    printf("You have pass at least 2 arguments to the function");
    return 0;
  }

  start = atoi(argv[1])-1;
  if(argc==3) end = atoi(argv[2])-1;
  else end = start;

  /* read all lines then output to the screen the required columns */
  while((size = readl(line)) != EOF){
    p = tokenize(line,delim,&pos);

    for(i=0;i<size;i++){
      if(!(i>=start && i<=end)){
        printf("%s",p[i]);
      }
    }
    printf("\n");
  }

  
  return 0;
}
