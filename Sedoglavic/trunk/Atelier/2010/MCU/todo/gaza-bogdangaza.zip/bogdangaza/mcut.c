#include <stdio.h>
#include "readl.h"
#include "tools.h"
#include <stdlib.h>

int
main(int argc, char * argv[]){

  char line[1024]; /* line buffer */
  int size; /* size of each line */

  char **p; /* double pointer returned by tokenize tool */
  char *delim; /* provided delimitator */
  int i;
  int pos=0; /* length of token */

  /* verify that the provided arguments are there */
  if(argc<3){
    printf("You have pass at least 2 arguments to the function");
    return 0;
  }

  delim = argv[1];

  /* read all lines then output to the screen the required columns */
  while((size = readl(line)) != EOF){
    p = tokenize(line,delim,&pos);

    for(i=2;i<argc;i++){
      if(atoi(argv[i])-1<=pos) printf("%s ",p[atoi(argv[i])-1]);
    }
    printf("\n");
  }

  
  return 0;
}
