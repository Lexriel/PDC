Nom: Bogdan Gaza
Groupe: 2
Annee: L3S5
Erasmus

1) In order to compile all the binaries use:
make

2) To compile each of the binaries:
make mcut
make mcolrm
make mgrep
make mlook

3) Execute and test each binary:
./mcut " " 1 2 3  < spec/test.txt
./mcolrm 1 10 < spec/test.txt
./mgrep ipsum < spec/test.txt
./mlook Lorem < spec/test.txt
