#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "tools.h"

/* if assertion is failse then output the message and
   exit the program with the provided status */
extern void fatal(int assert, const char *message, int status){
  if(assert==0){
    printf("ERROR: %s",message);
    exit(status);
  }
}

/* returns and array of pointers
   each location is a slice of the line between
   start - delim OR
   delim - delim OR
   delim - end
*/
extern char ** tokenize(char *line, char *delim, int *size){
  char *p;
  char *aux = calloc(strlen(line),sizeof(char));

  char **result = (char **)calloc(81,sizeof(char *));

  int offset=0;
  int pos=0;
  int i = 0;
  char d[2];

  /* if delim is null then place each character in a location
     of the output vector */
  if(delim == NULL){
    offset = strlen(line);
    for(i=0;i<offset;i++){
      /* make fake string with just 1 char in it */
      d[0] = line[i];
      d[1] = '\0';
      /* alocate the required memory */
      result[i] = (char *)calloc(2,sizeof(char));
      /* copy the content of the memory */
      strcpy(result[i],d);
    }
    return result;
  }
  /* make backup copy of the line into aux */
  strcpy(aux,line);

  while((p=strstr(line,delim))!=NULL){
    /* calculate total offset */
    offset += p-line;
    /* allocate memory for current token size */
    result[pos] = (char *)calloc(p-line,sizeof(char));

    /* put end of line character at current offset */
    line[p-line] = '\0';
    /* copy token to result */
    strcpy(result[(pos)],line);
    /* increment number of tokens */
    pos++;

    /* move pointer to new position */
    line = p;
    /* move pointer across delim */
    line += strlen(delim);
    /* update global offset */
    offset += strlen(delim);
  }

  /* alocate memory and copy for the last token - EOL portition */
  result[pos] = (char *)calloc(strlen(line),sizeof(char));
  strcpy(result[pos],line);

  *size = pos;
  return result;
}
