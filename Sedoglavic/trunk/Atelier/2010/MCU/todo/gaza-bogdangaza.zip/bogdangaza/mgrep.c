#include <stdio.h>
#include "readl.h"
#include <string.h>
#include <stdlib.h>

int
main(int argc, char * argv[]){

  char line[1024]; /* line buffer */
  int size; /* size of each line */

  char *p;
  int i=0;

  /* verify that the provided arguments are there */
  if(argc<2){
    printf("You have pass at least 1 argument to the function");
    return 0;
  }
  
  /* read all lines then output to the screen the required columns */
  while((size = readl(line)) != EOF){
    p = strstr(line,argv[1]);
    if(p!=NULL){
      printf("%s \n",line);
      i=1;
    }
  }

  if(i==0) fprintf(stderr,"No lines found");

  return 0;
}
