#ifndef READL_H
#define READL_H

#define MAXLINE 81

extern int readl(char []);

#endif
