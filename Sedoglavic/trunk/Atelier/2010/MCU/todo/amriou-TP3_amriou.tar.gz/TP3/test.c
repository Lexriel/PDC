#include <stdio.h>
#include <stdlib.h>
#include "readl.h"

#define MAXLINE 81


int main (void)
{
  int j; 
  char test[MAXLINE+2];    
  int i =  readl(test);
  for(j =0; j < MAXLINE + 2; j++)    
    printf("%c,  ", test[j]); 
  printf("le nbre decaractere lu est de :  %d\n", i); 
  return(EXIT_SUCCESS);
}

