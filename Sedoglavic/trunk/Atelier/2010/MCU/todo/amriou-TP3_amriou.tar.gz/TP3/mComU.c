#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"

#define MAXLINE 81 

int main(int argc, char *argv[])
{

  /* commande corect
     ./nom mgrep word 
     => argc = 3 && *(argv + 1) = "mgrep" && *(*argv +2) = word 
   */
  printf("%d\n",argc);
  if ((argc == 3) && (strcmp(argv[1],"mgrep")== 0))
  {
    static char line[MAXLINE];
    int NbLine = 0;
    int a = 0;
    int b;

    while ( (a = readl(line)) != EOF)
    {
      if (strstr(line,argv[2]) != NULL)
      {
	for (b =0; b < a; b++)
	{
	  printf("%c",*(line + b));
	}
	NbLine++;
      }
    }

    exit(NbLine > 0 ? EXIT_SUCCESS : EXIT_FAILURE);
  }

 
  
  fprintf(stderr,"%s","veuilliez taper une commande correcte :\n");
  fprintf(stderr,"%s","./nom mcolrm col [end]\n");
  fprintf(stderr,"%s","./nom mcut delim fieldno [fielno] ...\n");
  fprintf(stderr,"%s","./nom mlook word\n");
  fprintf(stderr,"%s","./nom mgrep word \n");
  exit(EXIT_FAILURE);
}

    
    

	  
	

  
	
	

	  
      
      
	  
	
    
	
