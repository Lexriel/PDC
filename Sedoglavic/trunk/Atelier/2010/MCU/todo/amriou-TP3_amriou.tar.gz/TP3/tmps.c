 /* commande corect
     ./nom mlook word 
     => argc = 3 && *(*argv + 1) = "mlook" && *(*argv +2) = word 
   */  
  /*  if ( strcmp(arg[1]; "mlook") && (argc = 3))
  {
    static char line[MAXLINE];
    int NbLine = 0;
    int i = 0;

    while(readl(line) != EOF)
    {
      if (strstr(line,argv[2]) != NULL)
      {
	printf("%s",line); 
	NbLine++;
      }
    }

    exit(NbLine > 0 ? EXIT_SUCCESS : EXIT_FAILURE);
  }  

  /* commande corect
     ./nom mcolrm word [end] 
     => argc = 3|4 && *(*argv + 1) = "mcolrm" && *(*argv +2) = NumCol && NULL | *(*argv + 3) = NUMCOL  
   */
  /*  if((*(*argv + 1) == "mcolrm") && (argc == 3)) 
  {
    int entier1 = atoi(*argv +2);
    int i;
    static line[MAXLINE];

    while(readl(line) != EOF)
    {
      for (i = 0; i < entier1; i++)
      {
	fprintf(stdout,"%c", *(line + i));
      }
      for (i = entier1 + 1, i < sizeof(line), i++)
      {
	fprintf(stdout, "%c", *(line + i));
      }
    }
   
    exit(EXIT_SUCCESS);
  }

  if ((*(*argv + 1) == "mlook") && (argc == 4))
  {
    int entier1 = atoi(*argv + 2);
    int entier 2 = atoi(*argv + 3); 
    int i;
    static line[MAXLINE];

    while(readl(line) != EOF)
    {
      for (i = 0; i < entier1; i++)
      {
	fprintf(stdout,"%c", *(line + i));
      }
      for (i = entier2 + 1, i < sizeof(line), i++)
      {
	fprintf(stdout, "%c", *(line + i));
      }
    }
   
    exit(EXIT_SUCCESS);
  }

   /* toute les commandes fausse
     ./nom
     ./nom (mgrep| mlook| mcolrm | mcut) NULL 
   */
