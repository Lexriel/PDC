#include <stdio.h>
#include <stdlib.h>
#include "tools.h"

#define MAXLINE 81

/*
  Lit une ligne sur l'entree standart.
  Cette ligne doit comporter moins de MAXLINE carateres.
  
  Le resultat est retourner dans line.
  Un \0 est ecrit en fin de chaine.

  Le tableau line doit etre de taille au moins MAXLINE+1.

  Retourne le nombre de caractere lu, non compris le \0 final.
  Retourne EOF si la fin  de fichier et atteinte.
  
  Termine le programme sur une erreur si rencontre d'une ligne de plus
  de MAXLINE  
 */

int readl(char line[])
{
  int NbCarLu = 0;
  char * null;
  
  null = fgets(line,MAXLINE+2, stdin);
 
  while ((line[NbCarLu-1] != '\0') && (line[NbCarLu] != EOF))
    NbCarLu++;
  
 
  if (NbCarLu > MAXLINE)
    fatal(0,"le nbr de caractere est superieur a MAXLINE\n",EXIT_FAILURE);

  if (null == NULL)
    return EOF;
  else
    return NbCarLu;
}
  


	  
        
	

 
