#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"

#define MAXLINE 81 

int main(int argc, char *argv[])
{

  /* commande corect
     ./mcolrm entier [end] 
     => argc = 2 && *(argv) = "mgrep" && *(*argv + 1) = entier1 | argc = 3 && *(argv) = "mgrep" && *(*argv + 1) = entier1 && *(*argv + 1) = entier1    
   */
  if((argc == 2) && (strcmp(argv[0],"./mcolrm") == 0)) /*ici on compare le premiere arguement sur stdin avec la syntaxe accepter ./mcolrm ==0 est du a strcmp qui renvoi soit -< 0= +>, 2argument du type ./mcolrm 1   salut --> alut */ 
  {
    int entier1 = atoi(argv[1])-1;
    int i;
    static char line[MAXLINE];

    while(readl(line) != EOF)
    {
      for (i = 0; i < entier1; i++)
      {
	fprintf(stdout,"%c", line[i]);
      }
      for (i = entier1+1 ; i < MAXLINE; i++)
      {
	fprintf(stdout, "%c", line[i]);
      }
    }
   
    exit(EXIT_SUCCESS);
  }


  if((argc == 3) && (strcmp(argv[0],"./mcolrm") == 0)) /*ici on compare le premiere arguement sur stdin avec la syntaxe accepter ./mcolrm ==0 est du a strcmp qui renvoi soit -< 0= +>, 3argument du type ./mcolrm 1 2  salut --> lut */ 
  {
    int entier1 = atoi(argv[1])-1;
    int entier2 = atoi(argv[2]);
    int i;
    static char line[MAXLINE];

    while(readl(line) != EOF)
    {
      for (i = 0; i < entier1; i++)
      {
	fprintf(stdout,"%c", line[i]);
      }
      for (i = entier2 ; i < MAXLINE; i++)
      {
	fprintf(stdout, "%c", line[i]);
      }
    }
   
    exit(EXIT_SUCCESS);
  }




 
  
  fprintf(stderr,"%s","veuilliez taper une commande correcte :\n");
  fprintf(stderr,"%s","./nom mcolrm col [end]\n");
  exit(EXIT_FAILURE);
}
