#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"

#define MAXLINE 81 

int main(int argc, char *argv[])
{

 /* commande corect
     ./mlook word 
     => argc = 2 && *(argv) = "mgrep" && *(*argv +1) = word 
   regarde si la ligne courante contient comma premier chaine le mot rechercher*/
  if ((argc == 2) && (strcmp(argv[0],"./mlook")== 0))
  {
    static char line[MAXLINE];
    int NbLine = 0;
    while (( readl(line)) != EOF)
    {
      if (strstr(line,argv[1]) == line)
      {
	printf("%s",line);
	NbLine++;
      }
    }

    exit(NbLine > 0 ? EXIT_SUCCESS : EXIT_FAILURE);
  }
  
  fprintf(stderr,"%s","veuilliez taper une commande correcte :\n");
  fprintf(stderr,"%s","./mlook word\n");
  exit(EXIT_FAILURE);
}
