#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"

#define MAXLINE 81 

int main(int argc, char *argv[])
{
  /* commande corect
     ./mgrep word 
     => argc = 2 && *(argv) = "mgrep" && *(*argv + 1) = word 
   recherche dans la ligne courante le mot passé en parametre (argv[1])=1*/
  if ((argc == 2) && (strcmp(argv[0],"./mgrep")== 0))
  {
    static char line[MAXLINE];
    int NbLine = 0;
    while ( ( readl(line)) != EOF)
    {
      if (strstr(line,argv[1]) != NULL) /*renvoi */
      {
	printf("%s",line);
	NbLine++;
      }
    }

    exit(NbLine > 0 ? EXIT_SUCCESS : EXIT_FAILURE);
  }
 
  fprintf(stderr,"%s","veuilliez taper une commande correcte :\n");
  fprintf(stderr,"%s","./mgrep word \n");
  exit(EXIT_FAILURE);
}

    
    

	  
	

  
	
	

	  
      
      
	  
	
    
	
