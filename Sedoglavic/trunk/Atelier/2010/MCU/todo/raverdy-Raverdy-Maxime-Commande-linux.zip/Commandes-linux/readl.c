#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tools.h"
#include "readl.h"

int readl(char line[]){
  int nb_caractere;
  int i;
  char *c;
  c = fgets(line , MAXLINE, stdin);
  if (c == NULL)
    return EOF;
  nb_caractere = strlen(c);
  /*  if (line[MAXLINE] != '\n')
      fatal(0,"Depassement des 80 caractere",EXIT_FAILURE);*/
  /* Ligne normalement jamais atteinte */
  return nb_caractere; 
  /* Si il n'y a pas de caractère il retourne 0 */
}
