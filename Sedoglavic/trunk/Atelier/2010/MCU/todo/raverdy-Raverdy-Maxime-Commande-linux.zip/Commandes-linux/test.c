bonour,je suis une phrase qui déchire
Je ense que c'est dommage que les 
manhots ne volent pas 
