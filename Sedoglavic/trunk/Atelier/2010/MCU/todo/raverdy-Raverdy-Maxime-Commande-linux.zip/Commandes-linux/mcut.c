#include <stdio.h>
#include <stdlib.h>
#include "readl.h"

int main(int argc, char *argv[]){
  int nb_caract;
  char line[MAXLINE];
  int cptArg;
  int j;
  int cptPartie;
  
  cptPartie = 1;
  while ((nb_caract = readl(line)) != EOF){
    /* cherchons la argv[cptArg] partie */
    for (cptArg = 2; cptArg < argc ; cptArg++){				
      /*Parcours de la chaine*/
      for (j = 0; j < nb_caract; j++){	
	/* si le symbole de line[j] est different et que l'on est dans la bonne partie alors on imprime */
	if ((cptPartie == atoi(argv[cptArg])) && (line[j] != *argv[1])){
	  printf("%c",line[j]);
	}
	/* si on rencontre le symbole, on incremente cptPartie*/
	if (line[j] == *argv[1]){
	  cptPartie++;
	  if ((cptPartie == atoi(argv[cptArg])) && (line[j] != *argv[1])){	
	    printf("%c",line[j]);
	  }
	}
      }
      cptPartie = 1;
      
    }
    putchar('\n');
	}
  exit(EXIT_SUCCESS);
}
