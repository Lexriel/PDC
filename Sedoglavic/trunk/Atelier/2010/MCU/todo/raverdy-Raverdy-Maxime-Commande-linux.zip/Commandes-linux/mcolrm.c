#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "readl.h"
#include "tools.h"

int main(int argc, char *argv[]){
  int nb_caractere;
  char line[MAXLINE+1];
  int i;
  int carac_sup_deb;
  int carac_sup_fin;
  i= 0;
  switch (argc){
  case 2 :
    carac_sup_deb = atoi(argv[1]);
    while ((nb_caractere=readl(line)) != EOF){
      /* Parcours de la ligne */
      while((i < nb_caractere) && (i < carac_sup_deb-1)){
	/* Si i est different de la colonne */
	printf("%c",line[i]);
	i++;
      }
      /* Passons à la ligne suivante */
      putchar('\n');
    }
    break;
  case 3 :
    carac_sup_deb = atoi(argv[1]);
    carac_sup_fin = atoi(argv[2]);
    while((nb_caractere=readl(line)) !=EOF){
      /*Parcours de la ligne */
      for(i=0;i<nb_caractere;i++){
	if((i<carac_sup_deb-1) || (i>carac_sup_fin-1)) {
	  /*On affiche que les caractere qui ne sont pas entre les deux parametre */
	  printf("%c",line[i]);
	}
      }
      putchar('\n');
    }
    break;
  default :
    fatal(0,"mauvais nombre de parametre",EXIT_FAILURE);
    break;
  }
  
  exit(EXIT_SUCCESS);
}
