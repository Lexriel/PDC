#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"

int main(int argc, char *argv[]){
	int nb_caract;
	char line[MAXLINE];
	int i;

	while ((nb_caract = readl(line)) !=EOF){
		if ((strstr(line,argv[1]) == line) || (strstr(line,argv[1]) != NULL)){
			for (i = 0; i<nb_caract; i++)
				printf("%c",line[i]);
			putchar('\n');
		}
	}

	exit(EXIT_SUCCESS);
}
