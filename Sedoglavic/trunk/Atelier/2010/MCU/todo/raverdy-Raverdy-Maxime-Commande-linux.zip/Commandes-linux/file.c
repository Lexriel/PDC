bonjour,je suis une phrase qui déchire
Je pense que c'est dommage que les 
manchots ne volent pas 
