#include<stdio.h>
#include<stdlib.h>
#include <string.h>
#include"readl.h"

char lines[MAXLINE];
char*uneligne;
int i;




int 
main(int argc , char **argv)
{
        int i;
        char * caractere;
    
	if (argc<2)
		  {
		    fprintf(stderr, "   argc = %d\n", argc);
		    exit(EXIT_FAILURE);
		}
         else {
                caractere=argv[1];
		i=readl(lines);
               while(i!=EOF)
		{
		 
                    
                      
                      if(strcmp(caractere[0],lines[0])==0){
                    
                           uneligne=strstr(lines,caractere);
                          if (strcmp(uneligne,lines)==0){
                            printf("%s \n",lines);
                            }
                          i=readl(lines);
                          
                         }
                   
               }  
            } 
   exit(EXIT_SUCCESS);    
 }
               
