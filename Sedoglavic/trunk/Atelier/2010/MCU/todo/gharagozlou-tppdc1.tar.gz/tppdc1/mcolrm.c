#include<stdio.h>
#include<stdlib.h>
#include <string.h>
#include"readl.h"


int debut;
int fin,i;
char * caractere,line[MAXLINE] ;















 

int 
main
( int argc , char **argv)
{

 int i;


 if (argc<3)
  {
     fprintf(stderr, "   argc = %d\n", argc);
     exit(EXIT_FAILURE);
  }

  else 
       {

	debut=atoi(argv[1]);
	fin =atoi(argv[2]);

       

	i=readl(line);
   
        if (i!= EOF)
	  {
	  printf(" le nombre de caractere %d \n",i);
          }
       else{
            fprintf(stderr, " erreur\n");
            exit(EXIT_FAILURE);
             }

	
        printf(" debut a %c\n",line[debut]);
        printf(" fin a %c\n",line[fin]);
         
       printf(" debut a %c\n",line[debut]);
        printf(" fin a %c\n",line[fin]);

        i=0;
        while( fin<strlen(line)){
         
                      fin++;
                      line[debut]=line[fin];
                       debut++;
            }
         

  
	printf("%s",line);

    }
printf("%s",line);


exit(EXIT_SUCCESS);
}