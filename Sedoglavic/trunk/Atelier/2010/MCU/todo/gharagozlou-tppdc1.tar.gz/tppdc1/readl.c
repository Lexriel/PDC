
# include<stdio.h>
#include<stdlib.h>
#include<string.h>


 int 
readl
(char line[])
{
char i;
int char_counter;
char*caractere;
char_counter=0;


caractere=fgets( line,MAXLINE,stdin);

if (caractere!=NULL)
{

while(char_counter<strlen(caractere))
      {
        
        if (char_counter>MAXLINE)
                {
                printf("erreur depassement de MAXLINE");
                exit(EXIT_FAILURE);
               }
        else
             {
              line[char_counter]=caractere[char_counter];
	      char_counter++;
              }
        }
}

else { fprintf(stderr," erreur de la lecture fgets %d", 2);
}

*(line+char_counter)='\0';
if (i==EOF)
    return EOF;
else
  return char_counter-1;

}
