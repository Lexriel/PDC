#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tools.h"


int main(int argc, char *argv[]){
	
	char line[MAXLINE];
	int min;
	int max;
	int col;
	fatal((argc != 2 || argc != 3), "mauvais nombre d'arguments", EXIT_FAILURE);	
	min = atoi(argv[1]);	
	max = MAXLINE;
	if(argc == 3){
		max = atoi(argv[2]);
	}
	
	while(readl(line) != EOF){
		for(col = 0; col < strlen(line); col++){
			if(col < min || col > max){			
				putchar(line[col]);
			}
		}	
	}	
	return EXIT_SUCCESS;
}
