#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tools.h"

int main(int argc, char *argv[]){
	char line[MAXLINE];
	int col;
	while(readl(line) != EOF){
		if(strstr(line, argv[1]) != NULL){
			for(col=0; col < strlen(line); col++){
				putchar(line[col]);
			}
		}
		
	}	
	return EXIT_SUCCESS;
}
