#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXLINE 81

int readl(char line[]);
extern void fatal(int assert, const char *message, int status);

