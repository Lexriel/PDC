#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tools.h"


int main(int argc, char *argv[]){
	
	char line[MAXLINE];
	char malettre;
	int min;
	int max;
	int tmp;
	int col;
	fatal((argc != 3 || argc != 4), "mauvais nombre d'arguments", EXIT_FAILURE);
	malettre = argv[1][0];
	min = atoi(argv[2]);
	max = MAXLINE;
	tmp = 0;
	
	if(argc == 4){
		max = atoi(argv[3]);
	}
	
	while(readl(line) != EOF){
		
		for(col=0; col < strlen(line); col++){
			if(line[col] == malettre){			
				tmp++;
			}
			if(tmp < min || tmp > max){
				putchar(line[col]);
			}			
		}
		
	}	
	return EXIT_SUCCESS;
}
