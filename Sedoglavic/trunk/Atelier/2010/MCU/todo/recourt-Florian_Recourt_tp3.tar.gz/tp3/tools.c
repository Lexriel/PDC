#include "tools.h"

extern void fatal(int assert, const char *message, int status){
	if(!assert){
		fprintf(stderr, "%s", message);
		exit(status);	
	}
}

int readl(char line[]){
	int cpt = 0;
	fgets(line, MAXLINE, stdin);
	while(line[cpt] != '\n' || line[cpt] != EOF || cpt <= MAXLINE){

		cpt++;
	}
	fatal(cpt < MAXLINE, "error : trop de lignes", EXIT_FAILURE); 
	if(line[cpt] == EOF){
		return EOF;
	}else if(line[cpt] == '\n'){
		return cpt-1;
	}else{
		return strlen(line);
	}	


}
