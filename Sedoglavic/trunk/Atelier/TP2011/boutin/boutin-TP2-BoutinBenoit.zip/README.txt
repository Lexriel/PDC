Boutin Benoit G2
TP2