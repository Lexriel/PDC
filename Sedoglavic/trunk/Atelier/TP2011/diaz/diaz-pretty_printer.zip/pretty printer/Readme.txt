J�r�my diaz
Groupe 2
pour lanc� le programme faire pp<file.C >filei.c