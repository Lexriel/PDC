#include <stdio.h>

int main (void){
      char c='b';
  char                  k=         'k';
  putchar(k)   ;
    putchar(c)    ;
  c=         (char)97   ;
  char j;
  j=(char)97;
  if(j){
    putchar(c);
}
     putchar(c);

  putchar('\n')    ;


  return 0;
}
