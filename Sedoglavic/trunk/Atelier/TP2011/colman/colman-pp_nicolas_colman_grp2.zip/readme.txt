Nicolas COLMAN       gr2
PDC : TP1 - Pretty Printer


Code fonctionnel se compilant sans warning et dont l'�x�cution correspond � l'�nnonc�.

Note : on suppose que le fichier contient des commentaires uniquement de la forme       /*   ...... */     et non de la forme    // ..........   
	pour des raisons de compl�xit�.

Pour compiler : gcc -o pp pp.c