int main(int argc, char*argv[]){char c;/*coucou Je suis un commentaire car je suis entourée de balises et je vais a la ligne tous les 50 caracteres cela me permet d etre lisible et de tenir sur une seule page, alors que dans le fichier de test, c est le bordel, je tiens sur une ligne est il est difficile de me lire, mais heureusement le programme me remet dans une forme tres cool*/if(i< a && i>b){if(){ prizoefb; if(){coucou; if{test; }else if(){aie;}}}putchar('\n');putchar(c); } else if(2){putchar('\n');putchar(c);putchar('\n');}else{putchar(c);}return 0;}


