#include <stdio.h>
#include <stdlib.h>

int
main()
{
  int c,i,j,colone;
  j=0,colone=0;
  enum {ETAT_DBT_LIGNE, ETAT_NORMAL,ETAT_BIZAR } etat = ETAT_DBT_LIGNE;
    while ((c=getchar()) != EOF) {
      switch (etat) {
      case ETAT_DBT_LIGNE:
	      switch (c) {
	      case '{':  
		for(i=0;i<colone;i++)		
		  putchar('\t');
		putchar('{');
		putchar('\n');
		colone++;
		break;	                    
	      case '\n':
		putchar('\n');
		break;
	      case ' ':
		break;
	      case '\t':
		putchar('\t');
		break;
	      case '}':
		colone--;  
		for(i=0;i<colone;i++)		
		  putchar('\t');
		putchar('}');
		putchar('\n');
		break;	
	      case '/':
		j++;
		putchar('\n');
		for(i=0;i<colone;i++)		
		  putchar('\t');
		putchar('/');
		etat=ETAT_BIZAR;
		break;     
	      default:		
		for(i=0;i<colone;i++)		
		  putchar('\t');
		putchar(c);
		etat = ETAT_NORMAL;
		break;
	      }
	      break;
      case ETAT_NORMAL:
	  switch (c) {
	  case '\n':
	    putchar('\n');
	    etat=ETAT_DBT_LIGNE;
	    break;	
	  case '/':
	    j++; 
	    putchar('\n');
	    for(i=0;i<colone;i++)		
	      putchar('\t');
	    putchar('/');
	    etat=ETAT_BIZAR;	             
	    break;
	  case '{':
	    putchar('\n');
	    for(i=0;i<colone;i++)		
	      putchar('\t');
	    putchar('{');
	    putchar('\n');	
	    colone++;
	    etat=ETAT_DBT_LIGNE;
	    break;
	  case '}':
	    putchar('\n');
	    colone--; 
	    for(i=0;i<colone;i++)		
	      putchar('\t');
	    putchar('}');
	    putchar('\n');
	    etat=ETAT_DBT_LIGNE;
	    break;	   
	  default :
	    putchar(c);
	    break;
	  }break;
      case ETAT_BIZAR:
	switch(c)
	  {
	  case '/':
	    j++;
	    if(j%2==0){
              putchar('/');
	    }
            else
	      {
		putchar('\n');
	       	for(i=0;i<colone;i++)		
		  putchar('\t');
		putchar('/');
	      }
	    etat=ETAT_DBT_LIGNE;
	    break;
	case ',':
	  putchar(',');
	  putchar('*');
	  putchar('/');
	  putchar('\n');
	  for(i=0;i<colone;i++)
	    putchar('\t');
	  putchar('/');
	  putchar('*');
       	  break;
	  case '\n':
	    break;
	  default:
	    putchar(c);
            break;
	  }
	break;
      }
    }
    exit(EXIT_SUCCESS);
}
