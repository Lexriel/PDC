#include <stdio.h>
#include <stdlib.h>
                              
#define INDENTATION ('\t')

void reIndent(int valeurIndentation)
{
  int iterator;
  iterator = 0;
  for (iterator =0; iterator<valeurIndentation;iterator++)
    putchar(INDENTATION);
}

int main(void){
  /* dernierCaractere : contient le caractere precedement lu. On
     l'initialise a ' '*/
  /* caractereLu : contient le caractere actuellement lu par la methode
   getchar(). Pas d'initialisation*/
  char dernierCaractere, caractereLu;
  
  /* nbIndentation : compte le nombre d'indentation. Ici l'indentation
     est egal a 4 espaces ' '. Initialise a 0 */
  /* parentheseOuvrante :Compte le nombre de parenthese ouvrante,
       Initialise a 0 */
  /* parentheseFermante : Compte le nombre de parenthese fermante,
     Initialise a 0 */
  /* accoladeOuvrante : Compte le nombre d'accolade ouvrante,
     Initialise a 0 */
  /* accoladeFermante : Compte le nombre d'accolade fermante,
     Initialise a 0 */
  /* commentaireOuvert : Compte le nombre de commentaire ouvert,
     Initialise a 0 */
  /* commentaireFerme  : Compte le nombre de commentaire ferme ,
     Initialise a 0 */
    int nbIndentation, parentheseOuvrante,parentheseFermante, accoladeOuvrante, accoladeFermante;
    int commentaireOuvert, commentaireFerme ;
   
 /* erreur est utiliser pour indiquer a PP si il y a eu une erreur ou
       non lors du traitement du texte.  
       - erreur est a 1 : erreur lors du traitement 
       - erreur est a 0 : pas d'erreur lors du traitement
       (valeur par defaut a l'initialisation*/
    int erreur;
    
    /*INITIALISATION DES VARIABLES */
    dernierCaractere = ' ';
    nbIndentation = 0;
    parentheseOuvrante = parentheseFermante = 0;
    accoladeOuvrante = accoladeFermante = 0;
    commentaireOuvert = commentaireFerme = 0;
    erreur = 0;
    /* etat : enumeration de tous les �tats possibles */
    /*      DEBUT_LIGNE : le pretty printer est au debut d'une
	    ligne */
    /*      NORMAL : le pretty printer est en mode normal, c'est a
	    dire pas de commentaire. Dans ce mode le pretty printer
	    analyse tout les caracteres */
    /*      COMMENTAIRE : le pretty printer est en mode
	    commentaire.Dans ce mode le pretty printer renvoi les
	    caracteres tels qu'il les lit*/
    typedef enum Etat Etat;
    enum Etat {DEBUT_LIGNE, NORMAL, COMMENTAIRE, CHAINE};
    Etat etat = DEBUT_LIGNE;
    
    /* Temps que le caractere lu n'est pas la fin du
       fichier, on fait ...*/
    while( (caractereLu=getchar()) != EOF )
      {  
	/* ... en fonction de l'etat dans lequel est pretty
	   printer */
	switch(etat)
	  {
	    /*.. si pp est en debut de ligne alors */
	  case DEBUT_LIGNE :
	    /*... si le caractere lu est soit un ' ' soit un \t alors
	      on ne renvoi rien sur la sortie standart (stdout) mais
	      on sort de la conditionnelle applique au caractereLu*/
	    switch(caractereLu)
	      {
	      case ' ':
	      case '\n':
	      case '\t':
		etat = DEBUT_LIGNE;
		break;
	      case'}':
		etat = NORMAL;
		accoladeFermante ++;
		if(accoladeFermante>accoladeOuvrante){
		  printf("#!ERREUR, } expected before!#");
		  erreur = 1;
		}
		putchar('\n');
		nbIndentation --;
		reIndent(nbIndentation); /* on repositionne le curseur
					    en fonction de
					    l'intentation courante */		
		putchar(caractereLu);
		dernierCaractere = caractereLu;
		break;
	      default:
		/* ... sinon dans tous les autres cas (une lettre, un
		   chiffre ou un symbole quel qu'il soit on le renvoi
		   sur stdout, l'etat de pretty printer passe dans
		   l'etat NORMAL et on memorise le dernier caractere
		   lu*/
		putchar(caractereLu);
		etat = NORMAL;
		dernierCaractere = caractereLu;
		break;
	      }
	    break;
	    
	    /* .. si pp est en mode NORMAL alors */
	  case NORMAL :
	    switch(caractereLu)
	      {
		/* ..si le caractere lu est un retour a la ligne(\n)
		   alors */
	      case'\n':
		/* ...alors on envoi sur la sortie standart un retour a
		   la ligne, Pretty Printer passe en mode debut de
		   ligne, on memorise le dernier caractere lu et on sort
		   du switch*/
		putchar(caractereLu);
		etat = DEBUT_LIGNE;
		dernierCaractere = caractereLu;
		reIndent(nbIndentation); /* on repositionne le curseur
					    en fonction de l'intentation
					    courante */
		break;
		
		/* ..si le caractere lu est une etoile '*' alors */
	      case'*':
		/* ...on teste le dernier caractere lu. Si il sagit
		   d'une oblique '/' alors nous sommes en presence d'un
		   commentaire. Ainsi Pretty Printer passe en mode
		   COMMENTAIRE.Mais quoi qu'il arrive, pp renvoi le
		   caractere lu sur stdout et sort de la conditionnel*/
		if(dernierCaractere == '/'){
		  etat = COMMENTAIRE;
		  commentaireOuvert ++;
		}
		putchar(caractereLu);
		dernierCaractere =caractereLu; 
		break;
		
		/* ..si le caractere lu est une accolade ouvrante
		   alors */	
	      case'{':
		/* ...on incremente le nombre d'accolade ouvrante, on
		   envoi le caractere lu sur la sortie standart, on
		   retourne a la ligne.*/
		accoladeOuvrante ++;
		putchar(caractereLu);
		dernierCaractere = caractereLu;
		putchar('\n');
		nbIndentation ++;
		reIndent(nbIndentation); /* on repositionne le curseur
					    en fonction de l'intentation
					    courante */
		break;
		
		/* .. si le caractere lu est une accolade fermante alors */
	      case'}':
		accoladeFermante ++;
		if(accoladeFermante>accoladeOuvrante){
		  printf("#!ERREUR, { expected before!#");
		  erreur = 1;
		}
		putchar('\n');
		nbIndentation --;
		reIndent(nbIndentation); /* on repositionne le curseur
					    en fonction de l'intentation
					    courante */		
		putchar(caractereLu);
		dernierCaractere = caractereLu;
		
		/* ..si le caractere lu est une parenthese ouvrante
		   alors */	
	      case'(':
		/* ...on incremente le nombre de parenthese ouvrante, on
		   envoi le caractere lu sur la sortie standart*/
		parentheseOuvrante ++;
		putchar(caractereLu);
		dernierCaractere = caractereLu;
		break;
		
		/* .. si le caractere lu est une parenthese fermante
		   alors */
	      case ')':
		parentheseFermante ++;
		if(parentheseFermante>parentheseOuvrante){
		  printf("#!ERREUR, ( expected before!#");
		  erreur = 1;
		}
		putchar(caractereLu);
		dernierCaractere = caractereLu;
		break;
		
		/* .. si le caractere lu est une tabulation alors */
	      case '\t':
		/* ...on remplace cette tabulation par un esapce ' ' et on
		   memorise cette espace comme etant le dernier caractere
		   lu*/
		putchar(INDENTATION);
		dernierCaractere = '\t';
		break;
		
		/* .. si on tombre sur un guillemet simple ou un
		   apostrophe alors */
		/* ...on inscrit le caractere, PP passe en mode CHAINE et
		   on memorise le dernier caractere lu*/
	      case '\"' :
	      case '\'' :
		etat = CHAINE;
		putchar(caractereLu);
		dernierCaractere = caractereLu;
		break;
		/* .. dans tous les autres cas (une lettre, un chiffre, ou
		   tout autre symbole autre que ceux listes ci dessus)*/
	      default:
		/* pretty printer se contente de renvoyer le caractere lu
		   sur la sortie standart et de memoriser ce caractere dans
		   la variable dernierCaractere */
		etat = NORMAL;
		putchar(caractereLu);
		dernierCaractere = caractereLu;
		break;
	      }break;
	    /* ..si PP est en mode COMMENTAIRE */
	  case COMMENTAIRE:
	    switch(caractereLu)
	      {
		/*..si le caractere est une oblique '/' alors */
	      case '/':
		/* ...on teste le dernier caractere lu. Si il sagit
		   d'une etoile '*' alors nous sommes en presence d'un
		   symbole de fin de commentaire. Ainsi Pretty Printer
		   passe en mode NORMAL .Mais quoi qu'il arrive, pp
		   renvoi le caractere lu sur stdout et sort de la
		   conditionnel*/
		if(dernierCaractere == '*'){
		  etat = NORMAL;
		  commentaireFerme ++;
		}
		putchar(caractereLu);
		dernierCaractere =caractereLu; 
		break;
	      case '\t':
		/* ...on remplace cette tabulation par un espace ' '
		   et on memorise cette espace comme etant le dernier
		   caractere lu*/
		putchar(' ');
		dernierCaractere = ' ';	
		break;
	      case '\n':
		putchar('*');
		putchar('/');
		putchar('\n');
		reIndent(nbIndentation);
		putchar('/');
		putchar('*');
		dernierCaractere = caractereLu;
		break;
	      default:
		/* ... sinon dans tous les autres cas (une lettre, un
		   chiffre ou un symbole quel qu'il soit on le renvoi
		   sur stdout, l'etat de pretty printer passe dans
		   l'etat NORMAL et on memorise le dernier caractere
		   lu*/
		putchar(caractereLu);
		dernierCaractere = caractereLu;
		break;
	      }
	    break;
	    /*.. si PP est en mode CHAINE */
	  case CHAINE:
	    switch(caractereLu)
	      { 
		/* .. si on tombre sur un guillemet simple ou un apostrophe
.		   alors */
		/* ...on inscrit le caractere, PP passe en mode CHAINE et on
		   memorise le dernier caractere lu*/
	      case '\"' :
	      case '\'' :
		etat = CHAINE;
		putchar(caractereLu);
		dernierCaractere = caractereLu;
		break;
	      default:
		/* pretty printer se contente de renvoyer le caractere lu
		   sur la sortie standart et de memoriser ce caractere dans
		   la variable dernierCaractere */
		putchar(caractereLu);
		dernierCaractere = caractereLu;
		break;							
	      }break;
	  }
      }
    /*PP va maintenant verifier si il y a eu des erreurs lors du
      traitements */
    if (erreur == 1){
      fprintf(stderr, "Erreur lors du traitement de votre fichier... Verifier si toutes les accolades et parentheses que vous fermez sont bien ouvertes avant!\n");
    }else if(parentheseOuvrante!=parentheseFermante){
      fprintf(stderr, "Erreur lors du traitement de votre fichier... Verifier si toutes les parentheses que vous ouvrez sont bien fermer a la fin du programme!\n");
      erreur = 1;
    }else if(accoladeOuvrante!=accoladeFermante){
      fprintf(stderr,"Erreur lors du traitement de votre fichier... Verifier si toutes les accolades que vous ouvrez sont bien fermer a la fin du programme!\n");
      erreur = 1;
    }else if(commentaireOuvert != commentaireFerme ){
      fprintf(stderr,"Erreur lors du traiement de votre fichier... Verifier que tous les commentaires ouverts sont bien fermes\n Ouvert %d -- Ferme %d", commentaireOuvert, commentaireFerme );
      erreur = 1;
    }

    if(erreur ==1)
      return EXIT_FAILURE;
    else
      return 1;
}
