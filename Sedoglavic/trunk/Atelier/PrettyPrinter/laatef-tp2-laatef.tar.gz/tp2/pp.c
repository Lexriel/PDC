#include <stdio.h>
#include <stdlib.h>

void decale(int nbEspace){
  int i;
  if(nbEspace < 0){
    fprintf(stderr,"Un probleme est survenue, certainement un probleme d'indentation\n");
  }else{
    for(i = 0 ; i <= nbEspace ; i++){
      putchar(' ');
    }
  }
}

int main(void){

  int nbEspace, nbAccoladeOuv, nbAccoladeFerm, flagErrInd, flagEspCommApresEtoile;
  char c;
  enum {debutLigne,commPossible, commentaire, finCommPossible, normal, dsChaine, dsDiese, debutInd, finInd} etat;

  nbEspace = nbAccoladeOuv = nbAccoladeFerm = flagErrInd = flagEspCommApresEtoile = 0;
  etat = debutLigne;

  while((c=getchar()) != EOF){
    
    switch(c){

    case '#' : {
      if(etat == debutLigne){
	etat = dsDiese;
	
      }
      putchar(c);
    }break;
    case '\n' : {
      if((etat == commentaire) || (etat == finCommPossible)){
	putchar('*');
	putchar('/');
	putchar('\n');
	decale(nbEspace);
	putchar('/');
	putchar('*');
	flagEspCommApresEtoile = 1;
	break;
      }
      etat = debutLigne;
      
      putchar(c);
      decale(nbEspace);
    }break;
    case '"' : {
      if(etat == dsChaine){
	etat = normal;
      }else if((etat != dsDiese) && (etat!=commentaire)){
	etat = dsChaine;
      }
      putchar(c);
    }break;
    case '/' : {
      if(etat == dsChaine || etat == dsDiese){
	putchar(c);
	break;
      }
      if(etat == finCommPossible){
	putchar(c);
	etat = debutLigne;
	break;
      }else if(etat != commentaire){
	etat = commPossible;
      }
      
    }break;
    case '*' : {
      if(etat == dsChaine || etat == dsDiese){
	putchar(c);
	break;
      }
      if(etat == commPossible){
	putchar('\n');
	decale(nbEspace);
	putchar('/');
	etat = commentaire;
	flagEspCommApresEtoile = 1;
      }else if(etat == commentaire){
	etat = finCommPossible;
      }
      putchar(c);
    }break;
    case '{' : {
      if(etat == dsChaine || etat == dsDiese){
	putchar(c);
	break;
      }
      if(nbAccoladeOuv < nbAccoladeFerm){
	flagErrInd = 1;
	fprintf(stderr,"Probleme d'indentation\n");
      }
      if((etat != commentaire) && (etat != finCommPossible)){
	etat = debutLigne;
	nbAccoladeOuv++;
	nbEspace += 4;
	putchar(c);
	putchar('\n');
	decale(nbEspace);  
      }
    }break;
    case '}' : {
      if(etat == dsChaine || etat == dsDiese){
	putchar(c);
	break;
      }
      if(nbAccoladeOuv < nbAccoladeFerm + 1){
	flagErrInd = 1;
	fprintf(stderr,"Probleme d'indentation\n");
      }
      if((etat != commentaire) && (etat != finCommPossible)){
	etat = debutLigne;
	nbAccoladeFerm++;
	nbEspace -= 4;
	
	putchar('\n');
	decale(nbEspace);
	putchar(c);
      }
    }break;
    case ' ' : {
      if(etat == debutLigne || flagEspCommApresEtoile == 1){
	break;
      }else {
	putchar(c);
      }break;
    }
    case '\t' : {
      if(etat == debutLigne){
	break;
      }else {
	putchar(c);
      }break;
    }
      /*case ';' : {
      if(etat != commentaire && etat != finCommPossible && etat != dsDiese && etat != dsChaine){
	
	putchar(c);
	putchar('\n');
	decale(nbEspace);
      }break;
      }*/
    default : {
      if(etat == commPossible){
	putchar('/');
	etat = normal;
      }else if(etat == finCommPossible){
	etat = commentaire;
      }else if(etat == debutLigne){
	etat = normal;
      }else if(etat == commentaire){
	flagEspCommApresEtoile = 0;
      }
      putchar(c);
    }/*  fin du default */
    }/* fin du switch */

  }/* fin du while */

  if((etat == commentaire)|| (etat == finCommPossible)){
    fprintf(stderr,"Commentaire non ferme\n");
    return(EXIT_FAILURE);
  }else if(flagErrInd){
    fprintf(stderr,"Probleme d'indentation\n");
    return(EXIT_FAILURE);
  }
    return(0);
}
	  
