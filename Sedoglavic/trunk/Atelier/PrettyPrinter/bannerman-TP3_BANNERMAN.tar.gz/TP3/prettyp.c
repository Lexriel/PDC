#include <stdio.h>
#include <stdlib.h>
#include "fctannexe.h"

int 
main()
{
    int acc,tab;
    char c;
    enum {DBT_LIGNE,NORMAL,DIR,DBT_COMM,COMM,FIN_COMM,CHAINE,PAR } etat =DBT_LIGNE;
    acc=0;
    tab=0;

    while ((c=getchar()) != EOF) 
    {
        switch (etat) 
        {
            case DBT_LIGNE:
            switch (c) 
            {
                case ':' :
                putchar(c);
                tab+=4;
                putchar('\n');
		tabu(tab);
                etat=DBT_LIGNE;
                break;
                case '{' :
                acc++;
		tabu(tab);
                putchar(c);
                tab+=4;
                putchar('\n');
                etat=DBT_LIGNE;
                break;
                case '}' :
                acc--;
                putchar('\n');
                tab-=4;
		tabu(tab);
                putchar(c);
                break;
                case '#' :
                putchar(c);
                etat=DIR;
                break;
                case '/' :
                etat=DBT_COMM;
                break;
                case '\n':
                case ' ':
                case '\t':
                break;
                default:
		tabu(tab);
                putchar(c);
                etat = NORMAL;
                break;

            }            break;
            case NORMAL:
            switch (c) 
            {
                case '\n': 
                putchar(c);
                etat=DBT_LIGNE;
                break;
                case '\t':
                break;
                case ';': 
                putchar(c);
                putchar('\n');
                etat=DBT_LIGNE;
                break;
                case '(': 
                putchar(c);
                etat=PAR;
                break;
                case '{' :
                acc++;
                putchar('\n');
		tabu(tab);
                putchar(c);
                tab+=4;
                putchar('\n');
                etat=DBT_LIGNE;
                break;
                case '}' :
                acc--;
                putchar('\n');
                tab-=4;
		tabu(tab);
                putchar(c);
                break;
                case '/' :
                etat=DBT_COMM;
                break;
                case '\'':
		    case '\"':
                putchar(c);
                etat=CHAINE;
                break;
                default :  
                putchar(c);
                break;

            }            break;
            case DIR:
            switch (c) 
            {
                case '\n':
                putchar(c);
                etat = DBT_LIGNE;
                break;
                default:
                putchar(c);
                break;

            }            break;
            case DBT_COMM:
            switch (c) 
            {
                case '*':
                putchar('\n');
		tabu(tab);
                putchar('/');
                putchar(c);
                etat = COMM;
                break;
                default:
                putchar('/');
                putchar(c);
                etat = NORMAL;
                break;

            }            break;
            case COMM:
            switch (c) 
            {
                case '\n':
                putchar('*');
                putchar('/');
                putchar(c);
		tabu(tab);
                putchar('/');
                putchar('*');
                putchar(' ');
                break;
                case '*':
                etat = FIN_COMM;
                break;
                default:
                putchar(c);
                break;

            }            break;
            case FIN_COMM:
            switch (c) 
            {
                case '/':
                putchar('*');
                putchar(c);
		tabu(tab);
                etat = NORMAL;
                break;
                default:
                putchar('*');
                putchar(c);
                etat = COMM;
                break;

            }            break;
            case CHAINE:
            switch (c) 
            {
                case '\'':
		    case '\"':
                putchar(c);
                etat=NORMAL;
                break;
                default:
                putchar(c);
                break;

            }            break;
            case PAR:
            switch (c) 
            {
                case ')':
                putchar(c);
                etat=NORMAL;
                break;
                default:
                putchar(c);
                break;

            }            break;

        }
    }    if (acc!= 0) 
    {
        fprintf(stderr,"\n ATTENTION : Nombre d'accolades ouvrantes DIFFERENT du nombres d'accolades fermantes !!!");
        exit(EXIT_FAILURE);

    }    exit(EXIT_SUCCESS);

}
