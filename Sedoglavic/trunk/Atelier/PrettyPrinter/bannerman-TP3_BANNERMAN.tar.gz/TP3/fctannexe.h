int tabu(int n);
int  main();
