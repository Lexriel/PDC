#include "fctannexe.h"
#include <stdio.h>
#include <stdlib.h>


int tabu(int n) 
{
 int i;
 for(i=1;i<=n;i++) putchar(' ');
 return 0;
}
