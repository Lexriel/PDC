#include <stdio.h>

/* blalbla*/
/*  bloblbobbli*/      
void main()
{
    int n;
    char c;
    c = getchar();

    /* on lit un caractere */     
    /* sur stdin */    
    if (c=='')
    {
        n++;
        putchar(c);

    }    else
    {
        write;
        {
            sfs;

        }        dsvd;

    }
    /* sinon,*/
    /*              on ne fait rien */    

}