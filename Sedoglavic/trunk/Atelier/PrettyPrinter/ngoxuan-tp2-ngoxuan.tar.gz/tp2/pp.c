#include <stdio.h>
#include <stdlib.h>

/**Affiche la tabulation, par defaut 4 espaces*/
void tabule(int nbIndent)
{
  int i;
  for(i=0; i<nbIndent;i++)
    printf("    ");
}

int 
main()
{
  enum 
  {
    ETAT_DBT_LIGNE, 
    ETAT_NORMAL,
    SLASH,
    COMMENTAIRE_OUVERT,
    ETAT_DBT_COMMENTAIRE,
    ETOILE,
    ACC_OUVERTE
  } 
  etat = ETAT_DBT_LIGNE;

  int indent, caractere, nbAcc, nbCom;

  indent = 0;
  nbAcc = 0;
  nbCom = 0;

  while ((caractere=getchar()) != EOF) 
    {
      switch (etat) 
	{
	case ETAT_DBT_LIGNE:
	  switch (caractere) 
	    {
	    case '\n': putchar('\n');
	    case ' ':
	    case '\t': break;
	    case '{': 
	      nbAcc++;
	      tabule(indent);
	      etat = ACC_OUVERTE;
	      putchar(caractere);
	      break;

	    case '}':	
	      nbAcc--;
	      indent--;
	      tabule(indent);
	      putchar(caractere);
	      etat = ETAT_DBT_LIGNE;
	      break;

	      /*Affiche la tabulation et le caractere*/
	    default:
	      tabule(indent);
	      putchar(caractere);
	      etat = ETAT_NORMAL;
	      break;
	    }
	  break;

	  /* Commentaire en debut de ligne*/
	case ETAT_DBT_COMMENTAIRE:
	  switch (caractere) 
	    {	
	      /*Suppression des blancs*/
	    case '\n':
	    case ' ':
	    case '\t': break;

	    case '*': 
	      etat = SLASH;
	      putchar(caractere);
	      break;
	    default:
	      putchar(caractere);
	      etat = COMMENTAIRE_OUVERT;
	      break;
	    }
	  break;

	case ETAT_NORMAL:
	  switch (caractere) 
	    {
	    case '\n': 
	      putchar('\n');	    
	      etat = ETAT_DBT_LIGNE; 
	      break;

	    case '*': 
	      etat = ETOILE;
nbCom++;
	      putchar(caractere);
	      break;
		  
	    case '/': 
	      etat = SLASH;
	      putchar('\n');
	      tabule(indent);
	      putchar(caractere);
	      break;
		  
	      /*Accolade imbriquee*/
	    case '{':
	      nbAcc++;
	      etat = ACC_OUVERTE;
	      putchar('\n');
	      tabule(indent);
	      putchar(caractere);
	      break;
		  
	      /*Fin accolade imbriquee*/
	    case '}': 
	      nbAcc--;
	      putchar('\n');
	      indent--;
	      tabule(indent);
	      putchar(caractere);
	      etat = ETAT_DBT_LIGNE;
	      break;

	    default : putchar(caractere); break;
	    }
	  break;

	  /*Indentation*/
	case ACC_OUVERTE:
	  switch(caractere)
	    {
	    case '\n': break;
	    default:
	      putchar('\n');
	      indent++;	
	      etat = ETAT_DBT_LIGNE;
	      break;
	    }
	  break;

	case SLASH:
	  switch(caractere)
	    {
	    case '*':
	      nbCom++;
	      etat = COMMENTAIRE_OUVERT;
	      putchar(caractere); 
	      break;
	    default : 
	      putchar(caractere);
	      etat = ETAT_NORMAL;
	      break;
	    }
	  break;

	case ETOILE:
	  switch(caractere)
	    {	 
	      /*le bloc de commentaire se ferme*/
	    case '/': 
	      nbCom--;
	      putchar(caractere);
	      etat = ETAT_DBT_LIGNE;
	      break;
	    default :
	      putchar(caractere);
	      etat = COMMENTAIRE_OUVERT;
	      break;
	    }
	  break;
	
	case COMMENTAIRE_OUVERT:
	  switch(caractere)
	    {
	    case '\n': 	 	/*fermer le commentaire en ouvrir un autre sur la ligne suivante*/
	      putchar('*');
	      putchar('/');
nbCom--;
	      putchar(caractere); 	/*caractere == \n*/
	      tabule(indent);
	      putchar('/');
	      putchar('*');
nbCom++;
	      etat = ETAT_DBT_COMMENTAIRE;

	      break;

	    case '*': 
	      etat = ETOILE;
	      putchar(caractere);
	      break;
	    default : 
	      putchar(caractere);
	      break;
	    }

	}
    }
  if(nbAcc != 0)
    {
      fprintf(stderr, "Fichier mal accolade!\n");
      exit(EXIT_FAILURE);
    }
  if(nbCom != 0)
    {
      fprintf(stderr, "Fichier mal commente!\n");
      exit(EXIT_FAILURE);
    }
  exit(EXIT_SUCCESS);
}
