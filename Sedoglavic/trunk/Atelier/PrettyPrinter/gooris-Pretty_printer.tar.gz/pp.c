#include <stdio.h>
#include <stdlib.h>

void insere_tab(int n){
int i=0;
for (i;i<n;i++) { putchar(' ');putchar(' ');putchar(' ');putchar(' ');}
}


int main ()
{
    int c;
    int nb_acc; nb_acc = 0;
    int nb_comm; nb_comm = 0;
    enum {DEPART,LIGNE,AO,AF,SLASH,SLASH2,BLANC,ETOILE,COMMENTAIRE,RC} etat = DEPART;
   

    while ((c=getchar()) != EOF) {
        switch (etat) {
            case DEPART:
                switch (c) {
	        case '{': nb_acc++;
			  etat = AO; break;

	        case '}': nb_acc--;
			  etat = AF; break;

	        case '\n' : putchar(c);
			    etat = RC; break;

	        case ' ' : break;

		case '/' : etat = SLASH; break;

	        default : insere_tab(nb_acc);
		          putchar(c);	
		          etat = LIGNE;
		} break;

	  case RC : 
		switch (c) {
	        case '{': nb_acc++;
			  etat = AO; break;

	        case '}': nb_acc--;
			  etat = AF; break;
		case '\n' : break;
	        case ' ' : break;
		case '/' : etat = SLASH; break;
		default : etat = LIGNE;insere_tab(nb_acc);
			  putchar(c); break;
		} break;


	  case SLASH : 
		switch (c) {
		case '*' : etat = COMMENTAIRE;
			  nb_comm ++;
			   insere_tab(nb_acc);
			   putchar('/');
			   putchar(c); break;
		default : etat = LIGNE;
			  putchar('/');
			  putchar(c); break;
		} break;

	  case SLASH2 : 
		switch (c) {
		case '*' : etat = COMMENTAIRE;
			nb_comm ++;
			   putchar('\n');
			   insere_tab(nb_acc);
			   putchar('/');
			   putchar('*'); break;
		default : etat = LIGNE;
			  putchar('/');
			  putchar(c); break;
		} break;

	  case COMMENTAIRE :
		switch (c) { 
		case '*' : etat = ETOILE; break;

		case ' ' : putchar(c);
			   etat = BLANC; break;

		case '\n' : putchar('*');
				putchar('/');
				putchar('\n');
				insere_tab(nb_acc);
				putchar('/');
				putchar('*');
				etat = COMMENTAIRE; break;

		case '\t' : break;

		default :  putchar(c); break;

		} break;

	  case BLANC :
		switch (c) {
		case ' ' : break;

		case '\n' : putchar('*');
				putchar('/');
				putchar('\n');
				insere_tab(nb_acc);
				putchar('/');
				putchar('*');
				etat = COMMENTAIRE; break;

		case '*' : etat = ETOILE; break;

		default : putchar(c);
			  etat = COMMENTAIRE;

		} break;
	 
	  case ETOILE :
		switch (c) {
		case '/' : putchar('*');
			   putchar('/');
			   putchar('\n');
			   nb_comm--;
			   etat = DEPART; break;
		default : etat = COMMENTAIRE;
			  putchar('*');
			  putchar(c); break;
		} break;		

	  case LIGNE:
	      switch (c) { 
	        case '{' : nb_acc++;putchar('\n');
			   etat = AO; break;

	        case '}' : nb_acc--;putchar('\n');
			   etat = AF; break;
    
	        case '\n' : putchar(c);
			etat = DEPART; break;

	        case '/' : etat = SLASH2; break;

	        default : putchar(c);

	    	} break;
	
	  case AO : insere_tab((nb_acc)-1);
		    putchar('{');
		    putchar('\n');
		    etat = DEPART; break;

	  case AF : insere_tab(nb_acc);
		    putchar('}');
		    putchar('\n');
		    etat = DEPART; break;
      } 
    }



  if ((nb_comm!=0) || (nb_acc!=0)) {
	if (nb_acc != 0)
	{
	    fprintf(stderr,"Programme mal accolade\n");
	} 
	if (nb_comm != 0)
	{
		fprintf(stderr,"Commentaire non termine\n");
	}
		exit(EXIT_FAILURE);
  } else {
	exit(EXIT_SUCCESS);
	}
}

