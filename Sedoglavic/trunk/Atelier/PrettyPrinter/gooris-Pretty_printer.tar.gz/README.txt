Adrien GOORIS G1 
22 Octobre 2008

Bonjour, 
En principe, tout doit fonctionner :
Prise en charge de l'indentation et des commentaires.
Gestion des erreurs sur le stderr.

J'ai mis un fichier test.c pour tester le pp.

Cordialement.


