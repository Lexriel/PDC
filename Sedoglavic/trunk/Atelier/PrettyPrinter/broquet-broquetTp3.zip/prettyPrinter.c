#include <stdio.h>
#include <stdlib.h>


void blancs( int i);

int 
main(){
  
  int comp = 0;
  char c;
  char ancienCar[10];
  
  enum {DBT_LIGNE, NORMAL,COMMENTAIRE,CHAINE } etat = DBT_LIGNE;

  while ((c=getchar()) != EOF) {
    switch (etat) {
    case DBT_LIGNE:
      switch (c) {
      case ' ':
	break;
      case '\n':
	if(ancienCar[0]!=c){
	  putchar(c);
	  ancienCar[0]=c;
	}
	break;
      case '\t':
	break;
      case '\'':
	ancienCar[0]=c;
	ancienCar[1]=c;
	blancs(comp);
	putchar(c);
	etat=CHAINE;
	break;
      case '"':
	ancienCar[0]=c;
	ancienCar[1]=c;
	blancs(comp);
	putchar(c);
	etat=CHAINE;
	break;	
      case '/':
	ancienCar[0]=c;
	etat=NORMAL;
	break;
      case '{':
	blancs(comp);
	putchar(c);
	comp++;
	putchar('\n');
	ancienCar[0]='\n';
	break;
      case '}': 
	comp--; 
	blancs(comp);
	putchar(c);
	putchar('\n');
	ancienCar[0]='\n';
	break;
    default:
	blancs(comp);
	putchar(c);
	ancienCar[0]=c;
	etat = NORMAL;
	break;
      }
      break;
      
    case NORMAL:
      switch (c) {
      case '\n':
	putchar(c);
	ancienCar[0]=c;
	etat=DBT_LIGNE;
	break;
      case '\t':
	break;
      case '\'':
	ancienCar[0]=c;
	ancienCar[1]=c;
	putchar(c);
	etat=CHAINE;
	break;
      case '"':
	ancienCar[0]=c;
	ancienCar[1]=c;
	putchar(c);
	etat=CHAINE;
	break;
      case ' ':
	if ((ancienCar[0]!=' ') || (ancienCar[0]!='\t') || (ancienCar[0]!='\n'))
	  putchar(c);
	ancienCar[0]=c;
	break;
      case '/':
	ancienCar[0]=c;
	break;
      case '*':
	if (ancienCar[0]=='/') {
	  etat=COMMENTAIRE;
	  putchar('\n');
	  blancs(comp);
	  putchar(ancienCar[0]);
	  putchar(c);
	  putchar(' ');
	  ancienCar[0]=' ';
	  break;
	}
	ancienCar[0]=c;
	break;
      case ';' :
	putchar(c);
	putchar(' ');
	ancienCar[0]=' ';
	break;
      case '{' :
	putchar('\n');
	blancs(comp);
	putchar(c);
	putchar('\n');
	comp++;
	etat=DBT_LIGNE;
	ancienCar[0]='\n';
	break;
      case '}' :
	putchar('\n');
	comp--;
	blancs(comp);
	putchar(c);
	putchar('\n');
	etat=DBT_LIGNE;
	ancienCar[0]='\n';
	break;
      default :
	if (ancienCar[0]== '/') {
	  putchar(ancienCar[0]);
	}
	putchar(c);
	ancienCar[0]=c;
	break;
      }
      break;
      
    case COMMENTAIRE:
      switch(c){
      case '\n' : 
	putchar('*');
	putchar('/');
	putchar('\n');
    	blancs(comp);
	putchar('/');
	putchar('*');
	etat= COMMENTAIRE;
	break;
      case' ':
	if (ancienCar[0]!=c){
	  putchar(c);
	  ancienCar[0]=c;
	}	
	break;
      case '\t' :
	break;
      case '*' :
	ancienCar[0]=c;
	break;
      case '/':
	if (ancienCar[0]=='*') {
	  putchar(ancienCar[0]);
	  putchar(c);
	  putchar('\n');
	  ancienCar[0]= c;
	  etat=DBT_LIGNE;
	  break;
	}
      default :
	if (ancienCar[0]=='*') {
	  putchar(ancienCar[0]);
	}
	putchar(c);
	ancienCar[0]=c;
	break;
      }
      break;
	
    case CHAINE:
      switch(c){
      case '\'':
	putchar(c);
	if ((ancienCar[0]=='\\') || (ancienCar[1]!=c)) {
	  ancienCar[0]=c;
	  break;
	}
	etat=NORMAL;
	ancienCar[0]=c;
	ancienCar[1]=' ';
	break;
      case '\\':
	putchar(c);
	if (ancienCar[0]=='\\') {
	  ancienCar[0]=' ';
	  break;
	}
	ancienCar[0]=c;
	break;
      case '"':
	putchar(c);
	if ((ancienCar[0]=='\\') || (ancienCar[1]!=c)) {
	  ancienCar[0]=c;
	  break;
	}
	etat=NORMAL;
	ancienCar[0]=c;
	ancienCar[1]=' ';
	break;
      default :
	putchar(c);
	ancienCar[0]=c;
	break;
      }
      break;
    }
  }
  
  exit(EXIT_SUCCESS);
}

void blancs(int c) {
  
  int i,j;
  i=0;
  
  while(i!=c) {
    for (j=0;j<4;j++)
      putchar(' ');
    i++;
  }
}
