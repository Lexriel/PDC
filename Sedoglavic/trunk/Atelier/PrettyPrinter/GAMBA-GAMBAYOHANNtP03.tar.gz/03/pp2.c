#include <stdio.h>
#include <stdlib.h>
int 
main()
{
    int d,i,ind;
    char c;
    d=0;
    ind=0;
    enum 
    {
        ETAT_DBT_LIGNE, ETAT_NORMAL, DIRECTIVES, DBT_COMMENTAIRE, COMMENTAIRE, FIN_COMMENTAIRE 
    } etat = ETAT_DBT_LIGNE;
    while ((c=getchar()) != EOF) 
    {
        switch (etat) 
        {
            case ETAT_DBT_LIGNE:
            switch (c) 
            {
                case '
                {
                    ' :
                    ++d;
                    for(i=1;
                    i<=ind;
                    i++) putchar(' ');
                    putchar(c);
                    ind+=4;
                    putchar('\n');
                    etat=ETAT_DBT_LIGNE;
                    break;
                    case '
                }' :
                --d;
                putchar('\n');
                ind-=4;
                for(i=1;
                i<=ind;
                i++) putchar(' ');
                putchar('
            }');
            break;
            case '#' :
            putchar('#');
            etat=DIRECTIVES;
            break;
            case '/' :
            etat=DBT_COMMENTAIRE;
            break;
            case '\n':
            case ' ':
            case '\t':
            break;
            default:
            for(i=1;
            i<=ind;
            i++) putchar(' ');
            putchar(c);
            etat = ETAT_NORMAL;
            break;

        }        break;
        case ETAT_NORMAL:
        switch (c) 
        {
            case '\n': 
            putchar('\n');
            etat=ETAT_DBT_LIGNE;
            break;
            case '\t':
            break;
            case ';
            ': 
            putchar(';
            ');
            putchar('\n');
            etat=ETAT_DBT_LIGNE;
            break;
            case '
            {
                ' :
                ++d;
                putchar('\n');
                for(i=1;
                i<=ind;
                i++) putchar(' ');
                putchar('
                {
                    ');
                    ind+=4;
                    putchar('\n');
                    etat=ETAT_DBT_LIGNE;
                    break;
                    case '
                }' :
                --d;
                putchar('\n');
                ind-=4;
                for(i=1;
                i<=ind;
                i++) putchar(' ');
                putchar('
            }');
            break;
            case '/' :
            etat=DBT_COMMENTAIRE;
            break;
            default :  
            putchar(c);
            break;

        }        break;
        case DIRECTIVES:
        switch (c) 
        {
            case '\n':
            putchar('\n');
            etat = ETAT_DBT_LIGNE;
            break;
            default:
            putchar(c);
            break;

        }        break;
        case DBT_COMMENTAIRE:
        switch (c) 
        {
            case '*':
            putchar('\n');
            for(i=1;
            i<=ind;
            i++) putchar(' ');
            putchar('/');
            putchar('*');
            etat = COMMENTAIRE;
            break;
            default:
            putchar('/');
            putchar(c);
            etat = ETAT_NORMAL;
            break;

        }        break;
        case COMMENTAIRE:
        switch (c) 
        {
            case '\n':
            putchar('*');
            putchar('/');
            putchar('\n');
            for(i=1;
            i<=ind;
            i++) putchar(' ');
            putchar('/');
            putchar('*');
            putchar(' ');
            break;
            case '*':
            etat = FIN_COMMENTAIRE;
            break;
            default:
            putchar(c);
            break;

        }        break;
        case FIN_COMMENTAIRE:
        switch (c) 
        {
            case '/':
            putchar('*');
            putchar('/');
            for(i=1;
            i<=ind;
            i++) putchar(' ');
            etat = ETAT_NORMAL;
            break;
            default:
            putchar('*');
            putchar(c);
            etat = COMMENTAIRE;
            break;

        }        break;

    }
}if (d != 0) 
{
    printf("\n\nATTENTION :\n\nLe nombre d'accolades ouvrantes et fermantes ne semblent pas correspondre !",stderr);
    exit(EXIT_FAILURE);

};
exit(EXIT_SUCCESS);

}

ATTENTION :

Le nombre d'accolades ouvrantes et fermantes ne semblent pas correspondre !