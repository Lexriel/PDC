#include <stdio.h>
#include <stdlib.h>

int 
main()
{
  int d,i,ind;
  char c; 
  
  enum {ETATDBTLIGNE, ETATNORMAL, DIRECTIVES, DBTCOMMENTAIRE, COMMENTAIRE, FINCOMMENTAIRE, ESPACE} etat = ETATDBTLIGNE;
  
  d=0;
  ind=0;
  while ((c=getchar()) != EOF) {
    switch (etat) {
    case ETATDBTLIGNE:
      switch (c) {
      case '{' :
	++d;
	for(i=1;i<=ind;i++) putchar(' ');
	putchar(c);
	ind+=4;
	putchar('\n');
	etat=ETATDBTLIGNE;
	break;
      case '}' :
	--d;
	putchar('\n');
	ind-=4;
	for(i=1;i<=ind;i++) putchar(' ');
	putchar('}');
	break;
      case '#' :
	putchar('#');
	etat=DIRECTIVES;
	break;
      case '/' :
	etat=DBTCOMMENTAIRE;
	break;
      case '\n':
      case ' ':
      case '\t':	
	break;
      default:
	for(i=1;i<=ind;i++) putchar(' ');
	putchar(c);
	etat = ETATNORMAL;
	break;
      }
      break;
      
    case ETATNORMAL:
      switch (c) {
      case '\n': 
	putchar('\n');
	etat=ETATDBTLIGNE;
	break;
      case '\t':
	break;
      case ';': 
	putchar(';');
	putchar('\n');
	etat=ETATDBTLIGNE;
	break;
      case '{' :
	++d;
	putchar('\n');
	for(i=1;i<=ind;i++) putchar(' ');
	putchar('{');
	ind+=4;
	putchar('\n');
	etat=ETATDBTLIGNE;
	break;
      case '}' :
	--d;
	putchar('\n');
	ind-=4;
	for(i=1;i<=ind;i++) putchar(' ');
	putchar('}');
	break;
      case '/' :
	etat=DBTCOMMENTAIRE;
	break;
      default :  
	putchar(c);
	break;
      }
      break;
      
    case DIRECTIVES:
      switch (c) {
      case '\n':
	putchar('\n');
	etat = ETATDBTLIGNE;
	break;
      default:
	putchar(c);
	break;
      }
      break;
      
    case DBTCOMMENTAIRE:
      switch (c) {
       case '*':
	putchar('\n');
	for(i=1;i<=ind;i++) putchar(' ');
	putchar('/');
	putchar('*');
	putchar(' ');
	etat = ESPACE;
	break;
      default:
	putchar('/');
	putchar(c);
	etat = ETATNORMAL;
	break;
      }
      break;
      
    case COMMENTAIRE:
      switch (c) {
      case '\n':
	putchar('*');
	putchar('/');
	putchar('\n');
	for(i=1;i<=ind;i++) putchar(' ');
	putchar('/');
	putchar('*');
	putchar(' ');
	etat = ESPACE;
	break;
      case '*':
	etat = FINCOMMENTAIRE;
	break;
      default:
	putchar(c);
	break;
      }
      break;
      
    case FINCOMMENTAIRE:
      switch (c) {
      case '\n':
	putchar(' ');
	putchar('*');
	putchar('/');
	putchar('\n');
	for(i=1;i<=ind;i++) putchar(' ');
	putchar('/');
	putchar('*');
	putchar(' ');
	etat = COMMENTAIRE;
	break;
      case '*':
	putchar('*');
	break;
      case '/':
	putchar(' ');
	putchar('*');
	putchar('/');
	for(i=1;i<=ind;i++) putchar(' ');
	etat = ETATNORMAL;
	break;
      default:
	putchar('*');
	putchar(c);
	etat = COMMENTAIRE;
	break;
      }
      break;

    case ESPACE:
      switch (c) {
      case ' ':
      case '\t':
	break;
      case '*':
	etat = FINCOMMENTAIRE;
	break;
      default:
	putchar(c);
	etat=COMMENTAIRE;
	break;
      }
      break;
      
    }
  }
  if (d != 0) {
    printf("\n\nATTENTION :\n\nLe nombre d'accolades ouvrantes et fermantes ne semblent pas correspondre !");
    exit(EXIT_FAILURE);
  };
  exit(EXIT_SUCCESS);
}

