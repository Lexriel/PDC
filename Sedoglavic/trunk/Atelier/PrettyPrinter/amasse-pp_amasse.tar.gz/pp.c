#include <stdio.h>
#include <stdlib.h>

void decaler(int n){
  int i;
  for(i=0;i<n;i++){
    putchar(' ');
  }
}

int 
main()
{
    int c;
    int incr=0;
    enum {ETAT_DBT_LIGNE, ETAT_NORMAL, ETAT_ACCOLADE, ETAT_COMMENTAIRE_POSSIBLE, ETAT_FIN_COMMENTAIRE_POSSIBLE, COMMENTAIRE, ETAT_COMMENTAIRE_PAS_FINI, ETAT_CPP, ETAT_CHAINE } etat = ETAT_DBT_LIGNE;
  
    while ((c=getchar()) != EOF) {
      switch (etat) {
      case ETAT_DBT_LIGNE:
	switch (c) {
	case ' ':
	case '\t':
	  break;
	case '\n':  
	  putchar('\n');
	  break;
	case '{':
	  etat=ETAT_ACCOLADE;
	  putchar('\n');
	  decaler(incr);
	  putchar('{');
	  putchar('\n');	
	  incr = incr + 4;
	  break;
	case '}':
	  incr = incr - 4;
	  decaler(incr);
	  putchar('}');
	  putchar('\n');
	  break;
	case '/' :
	  etat = ETAT_COMMENTAIRE_POSSIBLE;
	  break;
	case '#':
	  putchar('#');
	  etat = ETAT_CPP;
	  break;
	default:   
	  decaler(incr);
	  putchar(c);
	  etat = ETAT_NORMAL;
	  break;
	}
	break;
      case ETAT_NORMAL:
	switch (c) {
	  
	case '\n': 
	  putchar('\n');
	  etat=ETAT_DBT_LIGNE;
	  break;
	case '{':
	  putchar('\n');
	  decaler(incr);
	  putchar('{');
	  putchar('\n');
	  incr = incr+4;
	  etat=ETAT_DBT_LIGNE;
	  break;
	case '}':
	  incr = incr-4;
	  putchar('\n');
	  decaler(incr);
	  putchar('}');
	  putchar('\n');
	  etat=ETAT_DBT_LIGNE;
	  break;
	case '/' :
	  etat = ETAT_COMMENTAIRE_POSSIBLE;
	  break;
	case '"':
	  putchar('"');
	  etat=ETAT_CHAINE;
	  break;
	default :
	  putchar(c);
	  break;
	}
	break;
      case ETAT_ACCOLADE:
	switch(c){
	case '}':
	  incr = incr-4;
	  decaler(incr);
	  putchar('}');
	  putchar('\n');
	  etat=ETAT_DBT_LIGNE;
	  break;
	default:
	  decaler(incr);
	  putchar(c);
	  etat=ETAT_NORMAL;
	  break;
	}
	break;
      case ETAT_COMMENTAIRE_POSSIBLE:
	switch(c){
	case '*':
	  putchar('\n');
	  decaler(incr);
	  putchar('/');
	  putchar('*');
	  etat=COMMENTAIRE;
	  break;
	default:
	  putchar(c);
	  etat=ETAT_NORMAL;
	}
	break;
      case COMMENTAIRE:
	switch(c){
	case '\n':
	  putchar('*');
	  putchar('/');
	  putchar('\n');
	  etat = ETAT_COMMENTAIRE_PAS_FINI;
	  break;
	case '*':
	  putchar('*');
	  etat = ETAT_FIN_COMMENTAIRE_POSSIBLE;
	  break;
	case '}':
	case '{':
	  break;
	default :
	  putchar(c);
	  break;
	}
	break;
      case ETAT_FIN_COMMENTAIRE_POSSIBLE:
	switch(c){
	case '/':
	  putchar('/');
	  etat=ETAT_DBT_LIGNE;
	  break;
	default :
	  putchar(c);
	  etat = COMMENTAIRE;
	  break;
	}
	break;
      case ETAT_COMMENTAIRE_PAS_FINI:
	switch(c){
	case' ':
	case '\t':
	  break;
	default:
	  decaler(incr);
	  putchar('/');
	  putchar('*');
	  putchar(' ');
	  putchar(c);
	  etat=COMMENTAIRE;
	  break;
	}
	break;
      case ETAT_CPP:
	switch(c){
	case '\n':
	  putchar('\n');
	  etat=ETAT_DBT_LIGNE;
	  break;
	default : 
	  putchar(c);
	  break;
	}
	break;
      case ETAT_CHAINE:
	switch(c){
	case '"':
	  putchar('"');
	  etat=ETAT_NORMAL;
	  break;
	default : 
	  putchar(c);
	  break;
	}
      }
    }
    
    exit(EXIT_SUCCESS);
}
