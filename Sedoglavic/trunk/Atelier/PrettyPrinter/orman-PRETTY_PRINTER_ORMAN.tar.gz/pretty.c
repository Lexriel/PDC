#include <stdio.h>
#include <stdlib.h>


void Indente(int Identation)
{
  int i;
  i = 0;
  for (i =0; i<Identation;i++)
    {
      putchar('\t');
    }
}


int 
main()
{
  int c,dernier_carac_lu,nbParO,nbParF,nbAccOuv,nbAccF;
  int Indentation;
  Indentation=0;
  nbParO=nbParF=nbAccOuv=nbAccF=0;
  enum {ETAT_DBT_LIGNE, ETAT_NORMAL, COMMENTAIRE, STRING } etat = ETAT_DBT_LIGNE;
  while ((c=getchar()) != EOF) {
    switch (etat) {
      /* Debut d'une ligne */
      
      /*Definis les différents cas possible lorsque l'on se trouve en début de ligne
       * si on rencontre un espace, on incremente le compteur d'espace
       * Si on rencontre une tabulation, on increment le compteur d'espace de 4 car Tab=4espaces
       * si on lit un retour à la ligne, on va a la ligne.
       * Dans tous les autres cas, on affiche le caractere*/
    case ETAT_DBT_LIGNE:
      switch (c) {
      case ' ': 
      case'\n':
      case '\t':
	break;
      default:
	putchar(c);
	etat = ETAT_NORMAL;
	dernier_carac_lu=c;
	break;
      }
      break;
      
      /*etat normal */
      
      /*
       * Lorsque l'on rencontre un caractere de retour à la ligne, on l'effectue et on 	ajoute des espace 
       * jusqu'a correspondre a l'indentation courante. On passe ensuite à l'état debut de ligne et on effectue l'indentation.
       * 
       * Si on rencontre un {, on incremente le compteur d'accolade ouvrante, on affiche l'accolade, on effectue un saut de ligne et on indente.
       * 
       * Si on rencontre une }, on augmente le compteur d'acolade fermante, on teste alors les compteurs d'acolades afin de vérifier
       * que l'on a pas plus d'accolade fermante que d'accolade ouvrante, si c'est le cas, on renvoie une erreur. Si non, on affiche l'accolade
       * on effectue un retour à la ligne et on indente.
       * 
       * Si on rencontre une *, on verifie si le caractere precedent est un /, dans ce cas, on passe a l'etat commentaire, sinon, on ne fait rien.
       * 
       * Si on rencontre une (, on incremente le compteur de parenthere ouvrante, on affiche la parenthere.
       * 
       * Si on rencontre une ), tout comme pour les accolades, on verifie que le nombre de parenthese fermante n'est pas superieur au nombre de parenthese ouvrante.
       * Si tel est le cas, on affiche un message d'erreur.
       * */
    case ETAT_NORMAL:
      switch (c) {
      case '\n': 
	putchar(c);
	etat=ETAT_DBT_LIGNE;
	dernier_carac_lu=c;
	Indente(Indentation);
	break;
      case '{':
	nbAccOuv++;
	putchar(c);
	Indentation++;
	dernier_carac_lu=c;
	putchar('\n');
	Indente(Indentation);
	break;
	
      case '}':
	nbAccF ++;
	if(nbAccF>nbAccOuv){
	  fprintf(stderr,"Probleme avec les accolades fermantes }\n");
	 
	  
	}
	putchar('\n');
	Indentation--;
	putchar(c);
	if(dernier_carac_lu!='\'')
	  putchar('\n');
	dernier_carac_lu = c;
	Indente(Indentation);
	etat=ETAT_DBT_LIGNE;
	break;
      case '*':
	if(dernier_carac_lu=='/')
	  {
	    putchar(c);
	    etat=COMMENTAIRE;
	    dernier_carac_lu=c;}
	break;
	
      case'(':
	nbParO ++;
	putchar(c);
	dernier_carac_lu = c;
	break;
	
      case ')':
	nbParF ++;
	if(nbParF>nbParO){
	  fprintf(stderr,"Probleme avec les parentheses fermantes )\n");
	  
	  
	}
	putchar(c);
	dernier_carac_lu = c;
	break;
	
      case'\"':
	putchar(c);
	etat=STRING;
	break;
	
      default :  
	putchar(c);
	break;
      }
      break;
      
      /*String */
      /*
	etat String, si on rencontre le caractere " qui symbolise le debut d'une chaine de caracteres.
	On va alors ecrire toute les caracteres dans la chaine, peut importe ce qu'ils sont et ce, jusqu'a
	ce que l'on rencontre le caracteres " qui symbolisera la fin de la chaine.
      */
    case STRING:
      switch (c)
	{
	case '\"' :
	  putchar(c);
	  etat=ETAT_NORMAL;
	  break;
	  
	default :
	  putchar(c);
	  break;
	}
      break;
      
      /*commentaire */
      
      
      /*
       * Etat commentaire, si on rencontre un retour à la ligne, on ferme le commentaire.
       * On effectue un saut de ligne et on ouvre un nouveau commentaire.
       * 
       * Si on rencontre un /, on regarde le caractere precedent afin de verifier si il s'agit d'une *
       * Si c'est le cas, on sort du commentaire, on passe alors en etat debut de ligne.
       * 
       * Dans tous les autres cas, on affiche le caractere lu.
       * */
    case COMMENTAIRE:
      switch (c)
	{
	case '\n' :
	  putchar('*');
	  putchar('/');
	  putchar(c);
	  putchar('/');
	  putchar('*');
	  break;
	case '/' :
	  if(dernier_carac_lu=='*')
	    {
	      putchar(c);
	      putchar('\n');
	      etat=ETAT_DBT_LIGNE;
	    }    
	  break;
	default :
	  putchar(c);
	  break;
	}
      break;
    }
    dernier_carac_lu=c;
  }
  exit(EXIT_SUCCESS);
}
