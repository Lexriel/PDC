#include <stdio.h>
#include <stdlib.h>


void ajouterBlancs(int nbInc);

int 
main()
{
  int c,d,increment,n,typeChaine;
  enum {ETAT_DBT_LIGNE, ETAT_NORMAL,ETAT_COMMENTAIRE,ETAT_CHAINE } etat = ETAT_NORMAL;
  
  increment = 0;
  
    while ((c=getchar()) != EOF) 
      {
	
	if ((n == '\n') && (c == '\n'))
	  {
	    n='a';
	  }
	else
	  {
	    switch (etat) 
	      {
	      case ETAT_DBT_LIGNE:
		switch (c) 
		  {
		  case ' ':
		  case '\t':
		    
		    break;
		  case '"':
		    putchar(c);
		    etat=ETAT_CHAINE;
		    typeChaine = '"';
		    break;

		  case '\'':
		    putchar(c);
		    etat = ETAT_CHAINE;
		    typeChaine = '\'';
		    break;
		    
		  case '{':
		  
		    ajouterBlancs(increment++);
		    putchar(c);
		    putchar('\n');
		    n='\n';
		    break;
		    
		  case '}':
		    ajouterBlancs(--increment);
		    putchar(c);
		    putchar('\n');
		    n='\n';
		    break;
		    
		  case '\n':
		    putchar('\n');
		    break;
		    
		  case '/':
		    if ((d=getchar())!=EOF)
		      {
			ajouterBlancs(increment);
			if (d=='*')
			  etat = ETAT_COMMENTAIRE;
			else
			  etat = ETAT_NORMAL;
			
			putchar(c);
			putchar(d);
		      }
		    else
		      {
			exit(EXIT_SUCCESS);
		      }
		    break;
		    
		  default:   
		    ajouterBlancs(increment);  
		    putchar(c);
		    etat = ETAT_NORMAL;
		    break;
		  }
		break;
		
		
	      case ETAT_NORMAL:
		switch (c) 
		  {
		    
		  case '\n': 
		    putchar('\n');
		    etat=ETAT_DBT_LIGNE;
		    break;
		
		  case ' ':
		    if (d!=' ')
		      putchar(c);
		    
		    break;
		    
		  case '"':
		    putchar(c);
		    etat=ETAT_CHAINE;
		    typeChaine = '"';
		    break;

		  case '\'':
		    typeChaine = '\'';
		    putchar(c);
		    etat = ETAT_CHAINE;
		    break;

		    
		  case '{':
		    putchar('\n');
		    ajouterBlancs(increment++);
		    putchar('{');
		    putchar('\n');
		    n='\n';
		    etat=ETAT_DBT_LIGNE;
		    break;

		  case '}':
		    putchar('\n');
		    ajouterBlancs(--increment);
		    putchar('}');
		    putchar('\n');
		    n='\n';
		    etat=ETAT_DBT_LIGNE;
		    break;
		  
		  case '/':
		    if ((d=getchar())!=EOF)
		      {
			if (d=='*')
			  {
			    putchar('\n');
			    etat = ETAT_COMMENTAIRE;
			    ajouterBlancs(increment);
			  }
			
			putchar(c);
			putchar(d);
		      }
		    else
		      {
			exit(EXIT_SUCCESS);
		      }
		    break;
		  
		  default :  
		    putchar(c);
		  break;
		  }
		break;
		
	      case ETAT_COMMENTAIRE:
		switch (c)
		  {
		  case ' ':
		    if (d!=' ')
		      {
			putchar(c);
			
		      }
		    break;	      
		    
		  case '\n':
		    putchar('*');
		    putchar('/');
		    putchar('\n');
		    ajouterBlancs(increment);
		    putchar('/');
		    putchar('*');
		    break;
		  case '*':
		    if ((d=getchar())!=EOF)
		      {
			putchar(c);
			putchar(d);
			if (d==('/'))
			  {
			    putchar('\n');
			    n= '\n';
			    
			    etat = ETAT_DBT_LIGNE;
			  }  
		      }
		    else
		      {
			fprintf(stderr,"Fin de commentaire manquant");
			exit(EXIT_FAILURE);
		      }
		    break;
		  default :
		    putchar(c);
		    
		    break;
		    
		  }
		break;

	      case ETAT_CHAINE:
		switch (c)
		  {
		  case '\'':
		    if (typeChaine=='\'')
		      etat = ETAT_NORMAL;
		    putchar(c);
		    break;
		    		    
		  case '"':
		    if (typeChaine=='"')
		      etat = ETAT_NORMAL;
		    putchar(c);
		    break;
		    
		  default:
		      putchar(c);
		    break;
		  }
		break;
	      }
	    d = c;
	  }
      }

    if (etat == ETAT_COMMENTAIRE)
      {
	fprintf(stderr,"Fin de commentaire manquant\n");
	exit(EXIT_FAILURE);
      }
    
    if (!increment)
      {
	exit(EXIT_SUCCESS);
      }
    else
      {
	if (increment>0)
	  fprintf(stderr,"Accolades fermantes manquantes\n");
	else
	  fprintf(stderr,"Accolades ouvrantes manquantes\n");
	exit(EXIT_FAILURE);
      }


}


void ajouterBlancs(int nbInc)
{
  int j;
  for (j=0;j<nbInc*4;j++)
    putchar(' ');
    
}
