#include <stdio.h>
#include <stdlib.h>

void tabulation ( int i ) {
	int j;
	for (j=0; j<i; j++) {
		putchar(' ');
		putchar(' ');
		putchar(' ');
		putchar(' ');
	}
}

int main () {
	enum etat {Debut,Ligne,AO,AF,Debut_Comm,Comm,Fin_Comm,Comm_Deb_Ligne,Comm_Ligne,Comm_Fin_Ligne,Espace,Espace_Ligne,Autre_Comm}
	etat = Debut;
	char c;
	int tab;
	tab = 0;
	while ((c = getchar()) != EOF) {
		switch(etat) {
			case Debut :
				switch(c) {
					case '{' :	etat = AO;
							break;
					case '}' :	etat = AF;
							break;
					case ' ' :	
					case '\t' :	break;
					case '\n' :	putchar(c);
							break;
					case '/' :	etat = Comm_Deb_Ligne;
							break;
					default :	etat = Ligne;
							tabulation(tab);
							putchar(c);
				}
				break;
			case Ligne :
				switch(c) {
					case '{' :	etat = AO;
							break;
					case '}' :	etat = AF;
							break;
					case '\n' :	etat = Debut;
							putchar(c);
							break;
					case '/' :	etat = Debut_Comm;
							break;
					default :	putchar(c);
				}
				break;
			case AO :
				putchar('\n');
				tabulation(tab);
				putchar('{');
				tab++;
				switch(c) {
					case '{' :	break;
					case '}' :	etat = AF;
							break;
					case '\n' :	etat = Debut;
							putchar(c);
							break;
					case ' ' :
					case '\t' :	etat = Debut;
							putchar('\n');
							break;
					default :	etat = Ligne;
							putchar('\n');
							tabulation(tab);
							putchar(c);
				}
				break;
			case AF :
				putchar('\n');
				tabulation(--tab);
				putchar('}');
				switch(c) {
					case '{' :	etat = AO;
							break;
					case '}' :	break;
					case '\n' :	etat = Debut;
							putchar(c);
							break;
					case ' ' :
					case '\t' :	etat = Debut;
							putchar('\n');
							break;
					default :	etat = Ligne;
							putchar('\n');
							tabulation(tab);
							putchar(c);
				}
				break;
			case Debut_Comm :
				switch(c) {
					case '*' :	etat = Espace;
							putchar('\n');
							tabulation(tab);
							putchar('/');
							putchar(c);
							putchar(' ');
							break;
					default :	etat = Ligne;
							tabulation(tab);
							putchar('/');
							putchar(c);
				}
				break;
			case Comm :
				switch(c) {
					case '*' :	etat = Fin_Comm;
							break;
					case '\n' :	etat = Espace;
							putchar(' ');
							putchar('*');
							putchar('/');
							putchar(c);
							tabulation(tab);
							putchar('/');
							putchar('*');
							putchar(' ');
							break;
					default :	putchar(c);
				}
				break;
			case Fin_Comm :
				switch(c) {
					case '/' :	etat = Debut;
							putchar('*');
							putchar(c);
							putchar('\n');
							break;
					case '\n' :	etat = Comm;
							putchar(' ');
							putchar('*');
							putchar('/');
							putchar(c);
							tabulation(tab);
							putchar('/');
							putchar('*');
							putchar(' ');
							break;
					case '*' :	putchar(c);
							break;
					default :	etat = Comm;
							putchar('*');
							putchar(c);
				}
				break;
			case Comm_Deb_Ligne :
				switch(c) {
					case '*' :	etat = Espace_Ligne;
							tabulation(tab);
							putchar('/');
							putchar(c);
							putchar(' ');
							break;
					default :	etat = Ligne;
							putchar(c);
				}
				break;
			case Comm_Ligne :
				switch(c) {
					case '*' :	etat = Comm_Fin_Ligne;
							break;
					case '\n' :	etat = Espace_Ligne;
							putchar(' ');
							putchar('*');
							putchar('/');
							putchar(c);
							tabulation(tab);
							putchar('/');
							putchar('*');
							putchar(' ');
							break;
					default :	putchar(c);
				}
				break;
			case Comm_Fin_Ligne :
				switch(c) {
					case '/' :	etat = Autre_Comm;
							putchar('*');
							putchar(c);
							break;
					case '\n' :	etat = Comm_Ligne;
							putchar(' ');
							putchar('*');
							putchar('/');
							putchar(c);
							tabulation(tab);
							putchar('/');
							putchar('*');
							putchar(' ');
							break;
					case '*' :	putchar(c);
							break;	
					default :	etat = Comm_Ligne;
							putchar('*');
							putchar(c);
				}
				break;
			case Autre_Comm :
				switch(c) {
					case ' ' :	
					case '\t' :	break;
					case '{' :	etat = AO;
							break;
					case '}' :	etat = AF;
							break;
					case '/' :	etat = Comm_Deb_Ligne;
							putchar('\n');
							break;
					default :	etat = Debut;
							putchar(c);
				}
				break;
			case Espace :
				switch(c) {
					case ' ' :	
					case '\t' :	break;
					case '*' :	etat = Fin_Comm;
							break;
					default :	etat = Comm;
							putchar(c);
				}
				break;
			case Espace_Ligne :
				switch(c) {
					case ' ' :	
					case '\t' :	break;
					case '*' :	etat = Comm_Fin_Ligne;
							break;
					default :	etat = Comm_Ligne;
							putchar(c);
				}
		}
	}
	if (tab != 0) {
		if (tab > 0) {
			fprintf(stderr,"Il manque une ou plusieures accolades fermantes : %d\n",tab);
		} else {
			fprintf(stderr,"Il manque une ou plusieures accolades ouvrantes : %d\n",-tab);
		}
	}
	exit(EXIT_SUCCESS);
}
