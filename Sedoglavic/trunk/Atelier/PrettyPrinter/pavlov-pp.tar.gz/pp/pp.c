#include <stdio.h>
#include <stdlib.h>
#include "func.h"

int 
main()
{
  int ind;
  int c;
  int c2;


  enum {ETAT_DBT_LIGNE, ETAT_NORMAL, ETAT_COMMENTAIRE} etat = ETAT_DBT_LIGNE;

  ind=0;
  
  while ((c=getchar()) != EOF) {
    switch (etat) {

    case ETAT_COMMENTAIRE:
      switch (c)
	{
	case '*' :
	  if ( (c2=getchar()) != '/' ) {
	    putchar(c);
	    putchar(c2);
	  }
	  else {
	    printf(" */\n");
	    etat = ETAT_DBT_LIGNE;
	  }
	  break;
	case '\n' :
	  printf(" */\n");
	  indent(ind);
	  printf("/* ");
	  while ( (c2=getchar()) == ' ' || c2 == '\t' ) {}
	  putchar(c2);
	  break;
	default :
	  putchar(c);
	  break;
	}
      break;

    case ETAT_DBT_LIGNE:
      switch (c)
	{
	case ' ':
	case '\t':
	case '\n':
	  break;
	case '{':
	  indent(ind);
	  putchar('{');
	  putchar('\n');
	  ind++;
	  indent(ind);
	  etat=ETAT_NORMAL;
	  break;
	case '}':
	  ind--;
	  indent(ind);
	  putchar('}');
	  putchar('\n');
	  break;
	case '/':
	  if ((c2=getchar())!='*'){
	    indent(ind);
	    putchar(c);
	    putchar(c2);
	  }else{
	    indent(ind);
	    putchar('/');
	    putchar('*');
	    etat=ETAT_COMMENTAIRE;
	  }
	  break;
 
	default:
	  indent(ind);
	  putchar(c);
	  etat = ETAT_NORMAL;
	  break;
	}
      break;

    case ETAT_NORMAL:
      switch (c)
	{
	case '/' :
	  if ((c2=getchar()) != '*' ) {
	    putchar(c);
	    putchar(c2);
	  }
	  else {
	    printf("\n");
	    indent(ind);
	    printf("/* ");
	    etat = ETAT_COMMENTAIRE;
	  }
	  break;
	case '{':
	  putchar('\n');
	  indent(ind);
	  putchar('{');
	  putchar('\n');
	  ind++;
	  etat=ETAT_DBT_LIGNE;
	  break;
	case '}':
	  ind--;
	  putchar('\n');
	  indent(ind);
	  putchar('}');
	  putchar('\n');
	  etat=ETAT_DBT_LIGNE;
	  break;
	case ';':
	  putchar(';');
	  putchar('\n');
	  etat=ETAT_DBT_LIGNE;
	  break;
	case '\n':
	  putchar('\n');
	  etat=ETAT_DBT_LIGNE;
	  break;
	default :  
	  putchar(c);
	  break;
	}
      break;
    }
  }

  exit(EXIT_SUCCESS);
}
