bla bla;

/*                           */
{
  /* comment bla bla */
}
/*fin de fichier*/


