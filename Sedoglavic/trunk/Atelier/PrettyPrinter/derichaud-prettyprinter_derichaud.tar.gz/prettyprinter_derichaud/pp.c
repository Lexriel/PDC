#include <stdio.h>
#include <stdlib.h>

void tabule(int nbIndent)
{
  int i;
  for(i=0; i<nbIndent;i++)
    printf("    ");		/*tabulation == 4 espaces*/
}

int 
main()
{
  enum 
  {
    ETAT_DBT_LIGNE, 
    ETAT_NORMAL,
    SLASH,
    COMMENTAIRE_OUVERT,
    ACCOUVRANTE,
    ETAT_DBT_COMMENTAIRE,
    ETOILE
  } 
  etat = ETAT_DBT_LIGNE;

  int indent;
  int c;
  int nbAcc;
  int nbCom;

  indent = 0; 
  nbAcc = 0;
  nbCom = 0;

  while ((c=getchar()) != EOF) 
    {
      switch (etat) 
	{
	case ETAT_DBT_LIGNE:
	  switch (c) 
	    {
	    case '\n': putchar('\n');
	    case ' ':
	    case '\t': break;
	    case '{': /*si l'accolade est en début de ligne on passe directement dans l etat correspondant*/
	      nbAcc++;
	      tabule(indent);
	      etat = ACCOUVRANTE;
	      putchar(c);
	    break;

	      /*on revient a un niveau d intentation inferieur pour bien placer notre accolade*/
	    case '}':			
	      indent--;
	      nbAcc--;
	      tabule(indent);
	      putchar(c);
	      etat = ETAT_DBT_LIGNE;
	    break;

	      /*On se place au bon niveau d indentation avant de putcheter le reste des caracteres*/
	    default:
	      tabule(indent);
	      putchar(c);
	      etat = ETAT_NORMAL;
	    break;
	    }
	  break;

	  /* cas ou un commentaire commence une ligne*/
	case ETAT_DBT_COMMENTAIRE:
	  switch (c) 
	    {	
	      /*comme pour debut de ligne, on enleve les blancs*/
	    case '\n':
	    case ' ':
	    case '\t': break;

	    case '*': 
	      etat = SLASH;
	      putchar(c);
	      break;
	    default:
	      putchar(c);
		  
	      etat = COMMENTAIRE_OUVERT;
	      break;
	    }
	  break;

	case ETAT_NORMAL:
	  switch (c) 
	    {
	    case '\n': 
	      putchar('\n');	    
	      etat = ETAT_DBT_LIGNE; 
	      break;

	    case '*': 
	      etat = ETOILE;
	      nbCom++;
	      putchar(c);
	    break;
		  
	    case '/': 
	      etat = SLASH;
	      putchar('\n');
	      tabule(indent);
	      putchar(c);
	    break;
		  
	      /*On a trouve une accolade qui n est pas en debut de ligne, on saute une ligne et on passe en ACCOUVRANTE apres avoir indenter comme il faut l accolade*/
	    case '{':
	      nbAcc++;
	      etat = ACCOUVRANTE;
	      putchar('\n');
	      tabule(indent);
	      putchar(c);
	    break;
		  
	      /*on revient a un niveau d intentation inferieur pour bien placer notre accolade*/
	    case '}': 
	      nbAcc--;
	      putchar('\n');
	      indent--;
	      tabule(indent);
	      putchar(c);
	      etat = ETAT_DBT_LIGNE;
	    break;

	    default : putchar(c); break;
	    }
	  break;

	  /*on va indenter le contenu du bloc a partir de cette accolade*/
	case ACCOUVRANTE:
	  switch(c)
	    {
	      /*On ne veut qu'un seul saut de ligne apres l accolade, celui mis par ETAT_NORMAL ou
		DEBUT_LIGNE, donc dans cet etat on ne fait rien en cas de saut de ligne*/
	    case '\n': break;
	    default:
	      putchar('\n');
	      indent++;			/*on augmente l indentation du corps du bloc que l on vient de creer*/
	      etat = ETAT_DBT_LIGNE;
	    break;
	    }
	  break;

	case SLASH:
	  switch(c)
	    {
	      /*on passe a l etat commentaire ouvert uniquement dans le cas d une "*"  */
	    case '*':
	      nbCom++;
	      etat = COMMENTAIRE_OUVERT;
	      putchar(c); 
	    break;
	    default : 
	      putchar(c);
	      etat = ETAT_NORMAL;
	    break;
	    }
	  break;

	case ETOILE:
	  switch(c)
	    {	 
	      /*le bloc de commentaire se ferme*/
	    case '/': 
	      putchar(c);
	      nbCom--;
	      etat = ETAT_DBT_LIGNE;
	    break;
	    default :
	      putchar(c);
	      etat = COMMENTAIRE_OUVERT;
	    break;
	    }
	  break;
	
	case COMMENTAIRE_OUVERT:
	  switch(c)
	    {
	    case '\n': 	 	/*fermer le commentaire en ouvrir un autre sur la ligne d'apres*/
	      putchar('*');
	      putchar('/');nbCom--;
	      putchar(c); 	/*c == \n*/
	      tabule(indent);	/*touours au bon niveau d indentation*/
	      putchar('/');
	      putchar('*');nbCom++;
	      etat = ETAT_DBT_COMMENTAIRE;
	    break;

	      /*on rencontre une etoile on passe a l etat etoile qui verifiera si le bloc de commentaire se ferme*/
	    case '*': 
	      etat = ETOILE;
	      putchar(c);
	    break;
	    default : 
	      putchar(c);
	    break;
	    }
	}
    }

  /*verifier les accolades et commentaires*/
  if(nbAcc != 0)
    {
      fprintf(stderr, "Probleme sur les accolades\n");
      exit(EXIT_FAILURE);
    }
  if(nbCom != 0)
    {
      fprintf(stderr, "Fichier mal commente!\n");
      exit(EXIT_FAILURE);
    }
  exit(EXIT_SUCCESS);
}
