#include <stdio.h>
#include <stdlib.h>
#include "qsint.h"
#include "outils.h"

/**
 * main method of quicksort, it will call the quicksort_rec recursive method
 * @param tab : int array to sort
 * @param nelem : number of elements in the tab array
 */
void quicksort_int(int tab[], unsigned int nelem){
  quicksort_rec_int(tab, tab , (tab + nelem-1));
}

/**
 * recursive method of the quicksort
 * this method divised array between the "premier" and "dernier" pointers
 * @param premier : pointer to the first element of array
 * @param dernier : pointer to the last element of array
 */
void quicksort_rec_int(int tab[], int *premier, int *dernier){
  int *pivot;
  if (premier < dernier){
    pivot = partitionner_int(premier, dernier);
    quicksort_rec_int(tab, premier, pivot-1);
    quicksort_rec_int(tab, pivot+1,dernier);
  }
}

/**
 * Method to divise the array between "montant" and "descendant" pointers
 * @param montant : pointer to the first array element
 * @param descendant : pointer to the last array element
 */
int *partitionner_int(int *montant, int *descendant){
  int *pivot;
  pivot = montant;

  while (montant<descendant) {

    while (montant < descendant && *montant < *pivot)
      montant++;
    while (montant < descendant && *pivot <= *descendant)
      descendant--;
    if (montant < descendant){

      if (montant == pivot) pivot = descendant;
      else if (descendant == pivot) pivot = montant;

      swap(montant,descendant,sizeof(int)); 

    }
  }

  swap(pivot,descendant,sizeof(int)); 
  return descendant;
}
