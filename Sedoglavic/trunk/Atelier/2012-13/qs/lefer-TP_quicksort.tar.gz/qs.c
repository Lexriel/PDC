#include <stdio.h>
#include <stdlib.h>
#include "outils.h"
#include "qs.h"

/**
 * Methode de comparaison entre 2 entiers
 * @param fst : premier chiffre a comparer
 * @param snd : second chiffre a comparer
 * @return -1 0 ou 1 si le premier chiffre est respectivement plus petit, identique ou plus grand que le second
 */
int cmpInt(const void *fst,const void *snd){
  if (*(int *)fst < *(int *)snd)
    return -1;
  else if (*(int *)fst > *(int *)snd)
    return 1;
  else
    return 0;
}

/**
 * methode permettant de trier le tableau envoye en parametre, il sera necessaire d'envoyer
 *   egalement la taille des cellules
 * @param base   : pointeur vers le tableau que l'on souhaite trier
 * @param nelem  : le nombre d'elements presents dans le tableau
 * @param size   : la taille de chaque cellules du tableau
 * @param compar : pointeur vers la methode de comparaison entre les elements du tableau
 */
extern void quicksort(void *base, int nelem, int size, int(*compar)(const void *, const void *)){
  quicksort_rec(base,(void *)((char * )base + (size*nelem) - size),size,compar);
}

/**
 * methode recursive du quicksort qui va partitionner le tableau en 2 parties d'un cote inferieur et 
 *   de l'autre superieur a la valeur du pivot qui correspond a la premier cellule du tableau a trier
 *   Les appels recursives s'arretent lorsque le premier et dernier element du tableau se croisent.
 * @param premier : pointeur vers le premier element du tableau
 * @param dernier : pointeur vers le dernier element du tableau
 * @param size    : taille de chaque cellules du tableau
 * @param compar  : pointeur vers la methode de comparaison entre les elements du tableau
 */
void quicksort_rec(void *premier, void *dernier, int size,int(*compar)(const void *, const void *)){
  void *pivot;
  if (premier < dernier){
    pivot = partitionner(size, premier, dernier,compar);
    quicksort_rec(premier, (void *)((char *)pivot-size),size,compar);
    quicksort_rec((void *)((char *)pivot+size),dernier,size,compar);
  }
}


/**
 * methode de partitionnement d'un tableau se trouvant entre les pointeurs montant et descendant
 * @param size       : taille des elements composant le tableau
 * @param montant    : pointeur vers le premier element du tableau a trier
 * @param descendant : pointeur vers le dernier element du tableau a trier
 * @param compar     : methode de comparaison entre 2 elements du tableau
 */
void *partitionner(int size, void *montant, void *descendant, int(*compar)(const void *, const void *)){
  void *pivot;
  pivot = montant;
  while (montant < descendant ){

    while ((montant < descendant) && (*compar)(montant ,pivot) <0 )
      montant = (void *)((char *)montant + size) ;
    while ((montant < descendant) && (*compar)(pivot, descendant) <= 0)
      descendant= (void *)((char *)descendant - size);

    if (montant < descendant){
      if (montant == pivot) 
	pivot = descendant;
      else if (descendant == pivot) 
	pivot = montant;
      
      swap(montant,descendant,size);      
    }
  }

  swap(pivot,descendant,size);

  return descendant;
}
