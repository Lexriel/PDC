#ifndef QS_H
#define QS_H
int cmpInt(const void *,const void *);
extern void quicksort(void *base, int nelem, int size, int(*compar)(const void *, const void *));
void quicksort_rec(void *premier, void *dernier, int size,int(*compar)(const void *, const void *));
void *partitionner(int size, void *montant, void *descendant, int(*compar)(const void *, const void *));

#endif
