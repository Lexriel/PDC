#ifndef OUTILS_H
#define OUTILS_H

#define ARRAY_SIZE 1000 /* array size used to create the int array in tab_aleat function */
#define NMAXCHAR 70        /* maximum number of characters in each string composing the input stream */
#define NMAXLINE 50        /* maximum number of line composing the input stream */

void tab_aleat(int[],int);
void display_tab(int[], int);
extern int readl(char[]);
void swap(void *, void *, int);

#endif
