#ifndef QSINT_H
#define QSINT_H

int *partitionner_int(int*, int*);
void quicksort_rec_int(int[], int* , int*);
void quicksort_int(int[], unsigned int );

#endif
