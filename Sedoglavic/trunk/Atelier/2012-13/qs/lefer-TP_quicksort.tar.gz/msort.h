#ifndef MSORT_H
#define MSORT_H
int mystrcmp(const void *, const void *);
#endif
