#include <stdio.h>
#include <stdlib.h>
#include "outils.h"

/**
 * Method to generate a random int array of a definedd size
 * @param tab : int array to display
 * @param size : array size
 */
void tab_aleat(int tableau[], int size){
  int c;
  for (c = 0; c < size; c++)
    tableau[c] = rand()%100;
}

/**
 * Method to display an int array
 * @param tab : int array to display
 * @param size : array size
 */
void display_tab(int tab[], int size){
  int i;
  for ( i = 0; i < size; i++) {
    printf ("%d ", tab[i]);
  }
  printf ("\n");
}

/**
 * Method to read a line from the standard input and put it in the line in argument. The maximum line size is defined
 *  in the mreadl.h file.
 * If the line has a more character than NMAXCHAR then the programm finish with an exception
 * @return int presenting the number of character read, if the line is the character EOF then this value is returned.
 * @author LEFER Gregory
 */
extern int readl(char line[]){
  int c,cpt; 
  cpt = 0;

  /* while the end of file isn't reach or that the end of line isn't reach then record the character */
  while ((c=getchar()) != EOF && (c != '\n' ) && (c != '\0' ) && cpt <= NMAXCHAR) {
    line[cpt++] = c;
  }
  
  /* If the end of file is reach and it's the first character read for the line then return EOF */
  if ((c == EOF) && (cpt == 0))
    return EOF;

  /*if the line has more character than NMAXCHAR then an error is put in the stderr else the endline character
    is add and the number of character read is returned.*/
  if (cpt > NMAXCHAR){
    fprintf(stderr,"\nFailure :\nLa chaine lue fait plus de %d caracteres\n\n",NMAXCHAR);
    exit(EXIT_FAILURE);
  }
  else{
    line[cpt] = '\0';
    return cpt;
  }
}

/**
 * methode permettant d'échanger le contenu de 2 pointeurs envoyés en parametre
 * il sera necessaire de connaitre le nombre d'octets composant chaque cellule
 * @param premier : pointeur vers le premier element a echanger
 * @param second  : pointeur vers le second element a echanger
 * @param size    : taille de chaque element a echanger
 */
void swap(void *premier, void *second, int size){
  char swap;
  int i;
  for (i = 0; i < size; i++) {
    swap = *((char *)premier + i);
    *((char *)premier+ i) = *((char *)second + i);
    *((char *)second + i) = swap;
  }
}
