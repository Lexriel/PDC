#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "outils.h"
#include "qs.h"
#include "msort.h"



int main(int argc, char *argv[]) {
  char buffer[NMAXLINE][NMAXCHAR];
  int i,j;
  i =0;

  while((readl(buffer[i++]) != EOF) && i < NMAXLINE ){}
  
  quicksort(buffer,i,NMAXCHAR,mystrcmp);

  for (j = 0; j < i; j++) {
    printf (">> %s\n",buffer[j]);
  }

  return 0;
}

/**
 * Method to wrap the strcmp function with void arguments
 * @param fst : pointer to the fst element to compare
 * @param snd : pointer to the snd element to compare
 */
int mystrcmp(const void *fst, const void *snd){
  return strcmp((char *)fst,(char *)snd);
}
