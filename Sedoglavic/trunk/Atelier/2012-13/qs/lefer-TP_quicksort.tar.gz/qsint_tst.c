#include <stdio.h>
#include <stdlib.h>
#include "qsint.h"
#include "outils.h"

int main(int argc, char *argv[]) {
      int tab[ARRAY_SIZE];
      tab_aleat(tab,ARRAY_SIZE);

      printf ("Le tableau avant le tri :\n");
      display_tab(tab, ARRAY_SIZE);

      quicksort_int(tab, ARRAY_SIZE);

      printf ("Le tableau apres le tri :\n");
      display_tab(tab, ARRAY_SIZE);

  return 0;
}
