#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "qsint.h"

#define TABSIZE 1000


int main (void)
{

  int tab[TABSIZE];
  int i;


  for(i=0;i<TABSIZE;i++)
  {
        tab[i]=rand();
        printf("\n tab[%i] : %i",i,tab[i]);
  }

  printf("\n Après le tri : \n");


  quicksort_int(tab,TABSIZE);

  for(i=0;i<TABSIZE;i++)
  {
  	printf("\n tab[%i] : %i",i,tab[i]);
  }
	printf("\n");
}
