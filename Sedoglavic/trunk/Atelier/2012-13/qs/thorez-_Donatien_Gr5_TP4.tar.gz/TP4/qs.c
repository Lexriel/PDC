
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "qs.h"

#define TABSIZE 1000


void qu_sort(void *base,int size,int montant, int descendant,int(*compar)(const void *, const void *))
{
  void *pivot; 
  int tmpleft; 
  int tmpright;
  void *tmp;

  pivot = base;
  tmpleft = montant;
  tmpright = descendant;
	//printf("\n appel quicksort \n");
	//printf("\n pivot = %i \n",pivot);

  while (montant < descendant)
  {
    while (compar(base+(size*montant),pivot)<0)
      montant--;

    while (compar(pivot,base+(size*descendant))<0)
      descendant++;

    if (montant != descendant)
    {

      //printf("inversion de descendant : %i avec montant :%i \n",tab[descendant],tab[montant]);
     /* tmp = base+(size*montant);
      *(base+(size*montant)) = *(base+(size*(tmpright-descendant)));
      *(base+(size*(tmpright-descendant)))=tmp;*/

  	tmp = malloc(sizeof(size));
  	memcpy(tmp, (void*)base+(size*montant), size);
  	memcpy((void*)base+(size*montant), (void*)base+(size*descendant), size);
  	memcpy((void*)base+(size*descendant), tmp, size);
  	free(tmp);


    }
  }

	memcpy((void*)base+(size*descendant), pivot, size);
	pivot = (void*) base +(size*descendant);  

	montant = tmpleft;
	descendant = tmpright;

//  if (montant < pivot && montant<descendant)  
    if(montant<descendant)

    qu_sort(base,size, montant, descendant-1,compar);

//  if (descendant > pivot && montant<descendant)

    if(montant<descendant)
    qu_sort(base,size, descendant+1, descendant,compar);
}

void quicksort(void *base, int nelem, int size,
               int(*compar)(const void *, const void *)){


 qu_sort(base,size,0,nelem-1,compar);
}

int strcompare(const void *a, const void *b) {
    return strcmp(*(char**)a,*(char**)b);
}
