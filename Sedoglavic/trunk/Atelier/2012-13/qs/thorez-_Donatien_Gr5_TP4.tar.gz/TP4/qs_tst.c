
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "qs.h"

int main (void)
{

  int i;

  char *tab[5]={"a","z","c","b","j"};

  printf("\n Après le tri : \n");

/*Problème avec la méthode strcompare, je ne comprends pas pourquoi il dit qu'elle n'est pas déclaré
  quicksort(tab,5,sizeof(int),strcompare);*/

  for(i=0;i<5;i++)
  {
  	printf("\n tab[%i] : %c",i,*tab[i]);
  }
	printf("\n");
}
