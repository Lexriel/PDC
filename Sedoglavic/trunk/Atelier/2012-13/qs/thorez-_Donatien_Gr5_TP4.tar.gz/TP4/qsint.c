#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "qsint.h"

#define TABSIZE 1000


void q_sort_int(int tab[], int montant, int descendant)
{
  int pivot, tmpleft, tmpright,tmp;

  pivot = tab[montant];
  tmpleft = montant;
  tmpright = descendant;
	//printf("\n appel quicksort \n");
	//printf("\n pivot = %i \n",pivot);

  while (montant < descendant)
  {
    while ((tab[descendant] > pivot))
      descendant--;

    while ((tab[montant] < pivot))
      montant++;

    if (montant != descendant)
    {

      //printf("inversion de descendant : %i avec montant :%i \n",tab[descendant],tab[montant]);
      tmp = tab[montant];
      tab[montant]= tab[descendant];
      tab[descendant]=tmp;
    }
  }


  tab[descendant] = pivot;
  pivot =  descendant;

  montant = tmpleft;
  descendant = tmpright;

  if (montant < pivot && montant<descendant)
    q_sort_int(tab, montant, pivot-1);

  if (descendant > pivot && montant<descendant)
    q_sort_int(tab, pivot+1, descendant);
}

void quicksort_int(int tab[], unsigned int nelem)
{
  q_sort_int(tab, 0, nelem - 1);
}
