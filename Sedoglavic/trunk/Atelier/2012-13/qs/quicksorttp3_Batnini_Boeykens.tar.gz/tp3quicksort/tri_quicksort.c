#define TABSIZE 10
#include "tri_quicksort.h"
#include <stdlib.h>
#include <time.h>

/* Permet de comparer 2 entiers
 * Renvoi 1 si a est superieur a b
 * Renvoi 0 si a est egal a b
 * Renvoi -1 si a est inferieur a b
 */
int compare(int a, int b) {
	
	if (a < b) {
		return -1;
	}
	else if (a > b) {
		return 1;
	}
	else {
		return 0;
	}
}

/* Permet d'echanger 2 valeurs dans un tableau
 */
void echanger(int tab[], int a, int b) {
	
	int tmp;
	tmp = tab[a];
	
	tab[a] = tab[b];
	tab[b] = tmp;
	
}


/*
 * Permet d'initialiser un tableau avec des valeurs aleatoires
 */

void initialisation(int tab[]) {
	
	int i;
	
	srand(time(NULL));
	for (i=0; i<TABSIZE; i++) {
		tab[i] = (rand() % 100);
	}
	
}

/*
 * Tri un tableau d'entiers avec en parametre le tableau, le debut du tableau et la fin
 * du tableau
 */
void quicksort(int tab[], int debut, int fin) {

	int montant = debut-1;
	int descendant = fin+1;
	const int pivot = tab[debut];
	
	if (debut >= fin) {
		return;
	}
	
	while (1) {
		
		do {
			descendant--;
		} while (compare(tab[descendant], pivot) > 0);
		
		do {
			montant++;
		} while (compare(tab[montant], pivot) < 0);
		
		
		if (montant < descendant) {
			echanger(tab, montant, descendant);
		}
		else {
			break;
		}	
		
	}
	
	
	quicksort(tab, debut, descendant);
	quicksort(tab, descendant+1, fin);
	
	
}

/*
 * Tri un tableau d'entiers avec en parametre le tableau a trie et la taille
 */
void quicksort_int(int tab[], int n){
	quicksort(tab, 0, n-1);
}


