/* Permet de comparer 2 entiers
 * Renvoi 1 si a est superieur a b
 * Renvoi 0 si a est egal a b
 * Renvoi -1 si a est inferieur a b
 */
int compare(int a, int b);


/* Permet d'echanger 2 valeurs dans un tableau
 */
void echanger(int tab[], int a, int b);

/*
 * Permet d'initialiser un tableau avec des valeurs aleatoires
 */
void initialisation(int tab[]);

/*
 * Tri un tableau d'entiers avec en parametre le tableau, le debut du tableau et la fin
 * du tableau
 */
void quicksort(int tab[], int debut, int fin);

/*
 * Tri un tableau d'entiers avec en parametre le tableau a trie et la taille
*/
void quicksort_int(int tab[], int n);
