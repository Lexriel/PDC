#include "quicksort_generic.h"
#include <stdio.h>
#include <stdlib.h>

void echange(void *a, void *b, int n)
{

	int i;
	char tmp;
	for (i=0; i<n; i++) {
		tmp = *(((char*)a)+i);
		*(((char*)a)+i) = *(((char*)b)+i);
		*(((char*)b)+i) = tmp;
	}
	return;
	
}

void quicksort_generic 
(void *base, size_t nelem, size_t size, int (*compar)(const void*, const void*)){
	

    char *debut, *fin, *descendant; 
	debut = base-size;
    fin = debut+(size*nelem)-(size);
	char * montant = base;
	descendant = fin;
	
	char *pivot;
	pivot = &(*(debut+size));
	
	
	int compteurMontant, compteurDescendant;
	compteurMontant = 0;
	compteurDescendant = (nelem - 2);
	
		
	if (debut >= fin) {
		return;
	}
        
	while (1) {
	
		while (compar(descendant, pivot) > 0) {
			descendant -=size;
			compteurDescendant--;
		}
		
		while (compar(montant, pivot) < 0) {
			montant += size;
			compteurMontant ++;
		}
	
		if (compteurMontant < compteurDescendant) {
			
			if (pivot == montant) {
				pivot = descendant;
			}
			else if (pivot == descendant){
				pivot = montant;
			}

			echange(montant, descendant, size);
	
		}
	
		else {
			break;
		}
	 

	}
	
	quicksort_generic(base, (descendant - debut)/size, size, compar);
	quicksort_generic(&(*(descendant+size)), (fin - descendant)/size, size, compar);
	
        
}

