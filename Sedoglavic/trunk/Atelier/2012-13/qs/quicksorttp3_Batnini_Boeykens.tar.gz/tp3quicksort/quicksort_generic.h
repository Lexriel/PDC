#include <stdio.h>
#include <stdlib.h>
/*     

*/
void quicksort_generic 
(void *base, size_t nelem, size_t size, int (*compar)(const void*, const void *));
