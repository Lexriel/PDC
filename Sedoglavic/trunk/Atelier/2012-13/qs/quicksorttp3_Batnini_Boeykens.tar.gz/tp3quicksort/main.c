/*
Boeykens Matthieu 
Batnini Myriam	
*/
#include <stdio.h>
#include "tri_quicksort.c"
#define TABSIZE 10


int tab[TABSIZE];

int
cmpint(const void *a, const void *b)
{
    return compare((*(int *)a),(*(int *)b));
}


int main (int argc, const char * argv[]) {
	
	int i;
	
	initialisation(tab);
	
	for (i=0; i<TABSIZE; i++) {
		printf("tab[%d] = %d\n",i, tab[i]);
	}
	
	quicksort(tab, 0, TABSIZE-1);

	/*quicksort_generic(&tab[0], TABSIZE+1, sizeof(int), cmpint);
	*/
	putchar('\n');
	
	for (i=0; i<TABSIZE; i++) {
		printf("tab[%d] = %d\n",i, tab[i]);
	}
	
	return 0;
    
}
