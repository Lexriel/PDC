#include<stdlib.h>
#include<stdio.h>
#include<time.h>
#define TABSIZE 40000

int f(int a, int b){
	if( a == b ){
		return 0;
	}
	return (a > b) ? 1 : -1;
}
void echanger_int(int tab[], int x, int y){
	int tmp = tab[x];
	tab[x] = tab[y];
	tab[y] = tmp;
}

void tri_a_bulle(int tab[], unsigned int nelem){
	int i,j;
	for(i=1; i < nelem ; i++){
		j=i;
		while(j>0 && tab[j] < tab[j-1]){
			echanger_int(tab,j, j-1);
			j--;
		}
	}
}
void quicksort_int(int tab[], int nelem){
	int montant, descendant;
	int pivot = 0;
	montant = 0 ;
	descendant = nelem;
	
	if(nelem < 5){
		tri_a_bulle(tab,nelem);
	}else{
		while(montant < descendant){
			while((montant<nelem) && f(tab[montant], tab[pivot]) < 0){
				montant++;	
			}	
			while((descendant > 0) && f(tab[pivot], tab[descendant]) <= 0){
				descendant--;
			}
			if(montant >= descendant){
				break;
			}
			echanger_int(tab,montant,descendant);
		}
	
		/* on échange le pivot et le nb a l'indice descendant */
		echanger_int(tab,pivot,descendant);
	
		
		quicksort_int(tab,descendant);
		quicksort_int(&(tab[descendant + 1]), nelem - descendant - 1);
	}		
	


}

int main(int argc, char** argv){
	int nb_alea;
	srand(time(NULL));
/*	nb_alea = (rand()%TABSIZE) + 1;*/
	nb_alea = TABSIZE;
	int i = 0;
	int tab[nb_alea];
	for(;i<nb_alea;i++){
		tab[i] = rand()%5000;
		printf("%d   ", tab[i]);
	}
	quicksort_int(tab, nb_alea);
	/*
	int tabViteFait[] = { 5, 3, 7, 10 , 1 , 2, 3, 4};
	quicksort_int(tabViteFait, 8);*/
	i = 0;
	for(; i < nb_alea; i++){
		printf("%d \n ", tab[i]);
	}
	exit(EXIT_SUCCESS);
}

 
