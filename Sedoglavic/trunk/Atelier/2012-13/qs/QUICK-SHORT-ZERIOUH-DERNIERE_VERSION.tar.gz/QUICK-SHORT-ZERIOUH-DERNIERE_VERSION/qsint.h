

extern
void
affichage
(int *tab, int nelem);

extern 
void 
quicksort_int
(int tab[], unsigned int nelem);






