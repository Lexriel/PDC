#include<stdio.h>
#include<stdlib.h>
#include "qsint.h"
#include <string.h>

void 
echange
(int tab[], int a, int b)
	{
	int temp;
	temp=tab[a];
	tab[a]=tab[b];
	tab[b]=temp;

	}

void
affichage
(int *tab, int nelem)
{
	int i;
for(i = 0; i < nelem; i++)
    {

	printf(" (%d) ", tab[i]);
	printf("\n");

    }
	
}

void 
quicksort_int
(int tab[], unsigned int nelem)
{

int montant=1;
int descendant= nelem-1;
const int pivot=tab[0];
if(nelem<2)
  return ;
if(nelem==2)
 {
	if(tab[0]>tab[1])
	 echange(tab,0,1) ;
	return ;
  }

while(montant < descendant)
{
	while(pivot > tab[montant] && montant<nelem-1)
	{
	montant++;
	}
	while(pivot < tab[descendant] && descendant > 0)
	{
	descendant--;
	}
	if(montant < descendant)
		echange(tab, montant, descendant); 
        else break;			
 }
	
	echange(tab,0,descendant) ;
	quicksort_int(tab, montant);
	quicksort_int(tab+montant,nelem-montant);

return;	

}
   


