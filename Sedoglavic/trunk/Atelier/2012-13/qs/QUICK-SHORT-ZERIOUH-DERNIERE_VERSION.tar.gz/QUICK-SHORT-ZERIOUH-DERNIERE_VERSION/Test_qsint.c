#include<stdio.h>
#include<stdlib.h>
#include "qsint.h"
#include <string.h>
#define TABSIZE 20


int main(){
int tab[TABSIZE]; 
   int i;
	     
	   for(i = 0; i < TABSIZE; i++ ){
	       tab[i] = rand()%100;
                                        }

  printf("Le tableau non trié: \n");

	affichage(tab,TABSIZE);	
	quicksort_int(tab,TABSIZE);

        printf("Tableau trié: \n");

        affichage(tab,TABSIZE);


return 0;
}
