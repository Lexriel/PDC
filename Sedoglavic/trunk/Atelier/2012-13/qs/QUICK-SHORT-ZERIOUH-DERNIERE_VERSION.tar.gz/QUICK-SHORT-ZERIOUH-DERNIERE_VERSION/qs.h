extern
void 
quickSort
(char items[][10], int left, int right);

extern
void 
quickSortMain
(char items[][10], int count);
