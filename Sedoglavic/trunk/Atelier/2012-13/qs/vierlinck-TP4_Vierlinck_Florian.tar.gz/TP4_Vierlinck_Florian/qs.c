/* 	VIERLINCK Florian
 *	Licence 3 - Groupe 5
 */

#include <stdio.h>
#include <stdlib.h>
#define TABSIZE 20

int rand(void);

void echange (int t[], int a, int b){
	t[a] += t[b];
	t[b] = t[a] - t[b];
	t[a] -= t[b];	
}

void quicksortInt(int tab[], unsigned int nelem){

	int indM, indD, pivot, i, cpt, compteur;
/*	indM = 0;
	indD = nelem - 1;
*/	cpt = compteur = 0;
	pivot = 0;//nelem/2;

	/* Un tableau d'un élément est trié */
	if (nelem < 2){
		return;
	}

	indM = 1;
	indD = nelem - 1;

	/* Tant que les indices ne se croisent pas */
	while(indM < indD){
		printf("\nParcours n° %i \n", cpt++);

		/* Tant que la valeur à l'indice montant est plus petit que le pivot */
		while(tab[indM] <= tab[pivot] && indM < TABSIZE){
					printf("\n INCREMENTATION du MONTANT\n");

			indM++;
		}

		/* Tant que la valeur à l'indice descendant est plus grand que le pivot */
		while(tab[indD] > tab[pivot] && indD > 0){
					printf("\n decrementation du DESCENDANT \n");
			indD--;
		}

		if(indM < indD){

								printf("\nTableau provisoire 1:\n"); for(i=0; i<TABSIZE;i++) { printf("%i;",tab[i]); }
		printf("\nEchange des valeurs %i et %i \n", indM, indD);

			/* Echange des valeurs aux indices */
			echange(tab, indM, indD);
			printf("\nTableau provisoire 2:\n"); for(i=0; i<TABSIZE;i++) { printf("%i;",tab[i]); }

		}
	}
							
							printf("\nTableau provisoire 3:\n"); for(i=0; i<TABSIZE;i++) { printf("%i;",tab[i]); }
	printf("\nEchange Pivot\n");
	/* Echange de la valeur du pivot et de la valeur à l'indice descendant */	
	echange(tab, indD, pivot);
	printf("\nTableau après échange du pivot et descendant:\n"); for(i=0; i<TABSIZE;i++) { printf("%i;",tab[i]); }

	printf("\n                      Appel Recursif quicksortInt \n\n");
	quicksortInt(tab+1, (nelem -2));

}








int main (int argc, char* argv[]){

	int tab[TABSIZE] /*= {5,7,3,4,3}*/;
	int i;
	int tabSauv[TABSIZE];

	for(i=0; i<TABSIZE;i++){
		tabSauv[i]=tab[i] = TABSIZE - i +rand()%10;
	}
	
	/* Affichage du tableau entrant */
	printf("\nTableau entrant:\n"); for(i=0; i<TABSIZE;i++) { printf("%i;",tab[i]); }

	/* Execution du tri */
	printf("\n \nPremier appel de la fonction quicksortInt (Main)\n");
	quicksortInt(tab, TABSIZE);


	printf("\nTableau entrant:\n"); for(i=0; i<TABSIZE;i++) { printf("%i;",tabSauv[i]); }
	/* Affichage du tableau sortant */
	printf("\nTableau sortant:\n"); for(i=0; i<TABSIZE;i++) { printf("%i;",tab[i]); }
	

	/* */
	printf("\n\n");
	return 0;
}