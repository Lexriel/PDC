/* 	VIERLINCK Florian
 *	Licence 3 - Groupe 5
 */



ma fonction quicksortInt ne trie que partiellement.