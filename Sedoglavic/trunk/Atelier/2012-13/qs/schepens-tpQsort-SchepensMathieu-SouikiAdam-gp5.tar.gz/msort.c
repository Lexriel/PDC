/*
 * TP qsort, Schepens Mathieu, Souiki Adam, L3 GP5.
*/

#define NMAXLINE 81
#define NMAXCHAR 81

#include <stdio.h>
#include <string.h>

int
readl
(char line[])
{
  char c;
  int cpt=0;
  while((c=getchar()) != EOF && (c != '\0'))
  {
      switch(c)
      {
	case '\n' :
	  return cpt;
	break;
	default:
	  line[cpt]=c;
	  cpt++;
	break;
      }
  }
  if(cpt>NMAXCHAR)
  {
      return -2;
  }
  if(c==EOF)
  {
    return EOF;
  }
  if(c=='\0')
  {
    line[cpt]='\0';
  }
  return cpt;
}

int compareChaineCroissant(void *a, void*b)
{
	return strcmp(*(char **)a,*(char **)b);
}

void echangeDeuxElem(size_t size, void * a, void * b)
{
	char * pointeurA;
	char * pointeurB;
  
	pointeurA = a;
	pointeurB = b;
	
  	char tmp;
	int j;
	for (j=0; j<size;++j) // échange octets par octets, a démarre au premier octet du premier nombre, b au premier octet du deuxième nombre
	{
		tmp=pointeurA[j];
		pointeurA[j] = pointeurB[j];
		pointeurB[j] = tmp;
	}
}

void mqsortIntermediaire(void *base, char *deb, char *fin, char *piv, size_t size, int(*compar)(void *, void *))
{
	// pointeur sur le début d'un tableau, taille du tableau, taille d'un élément, pointeur sur une fonction pour la méthode de tri
	
	char * tab=base; // passage a un tableau d'octets, pas d'arithmétique de pointeurs avec void*	
	char * pivot=piv; // élément où je suis
	char * montant=deb; // élément suivant
	char * descendant=fin;
	
	if(montant==descendant)
	{
		if(compar((void *)pivot,(void *)montant) > 0)
		{
			echangeDeuxElem(size, pivot, montant);
		}
	}
	
	if(montant<descendant)
	{
		while(montant<descendant)
		{
			if(compar((void *)montant,(void *)descendant) > 0)
			{
				echangeDeuxElem(size, montant,descendant);
			}
			if(compar((void *)montant,(void *)pivot) < 0)
			{
				montant+=size;
			}
			if(compar((void *)pivot,(void *)descendant) <= 0)
			{
				descendant-=size;
			}
		}
		if(montant==descendant && compar((void *)pivot,(void *)montant)>0)
		{
			echangeDeuxElem(size,pivot,montant);
		}
		if(montant>descendant && compar((void *)pivot,(void *)descendant)>0)
		{
			echangeDeuxElem(size,pivot,descendant);
		}
		mqsortIntermediaire(tab,pivot+size,montant-size,pivot,size,compar);
		mqsortIntermediaire(tab,montant+size,fin,montant,size,compar);
	}
}

void mqsort(void *base, int nelem, size_t size, int(*compar)(void *, void *))
{
	mqsortIntermediaire(base,base+size,base+(nelem-1)*size,base,size,compar);
}

int main(int argc, char *argv[])
{
	char line[NMAXCHAR];
	char * tabATrier[NMAXLINE];
	
	int repReadl=readl(line);
	int i,j,cptNbLigne=0;

	while(repReadl!=EOF&&cptNbLigne<NMAXLINE)
	{
		if(repReadl>NMAXCHAR)
		{
			printf("Erreur, trop de caractère sur un ligne\n");
			return 1;
		}
		tabATrier[cptNbLigne]=line; /* Probleme ici, comment affecter valeur de line
		plutot que l'adresse de line ??? */
		printf("Essai Boucle %d : ",cptNbLigne);
		j=0;
		while(j<repReadl)
		{
			printf("%c",tabATrier[cptNbLigne][j]);
			j++;
		}
		printf("\n");
		if(cptNbLigne>0)
		{
			printf("Essai boucle %d, element %d : ",cptNbLigne,cptNbLigne-1);
			j=0;
			while(j<repReadl)
			{
				printf("%c",tabATrier[cptNbLigne][j]);
				j++;
			}
			printf("\n");
		}
		
		cptNbLigne++;
		
		repReadl=readl(line);
	}
	if(cptNbLigne==NMAXLINE)
	{
		printf("Erreur, trop de lignes dans le programme \n");
		return 2;
	}
	
	mqsort(tabATrier, cptNbLigne, sizeof(char *), compareChaineCroissant);
	for(i=0;i<cptNbLigne;i++)
	{
		j=0;
		printf("Ligne %d : ");
		while(tabATrier[i][j+1]!='\0')
		{
			printf("%c",tabATrier[i][j]);
			j++;
		}
		printf("\n");
	}
	return 0;
}

