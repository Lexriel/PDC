/*
 * TP qsort, Schepens Mathieu, Souiki Adam, L3 GP5.
*/

#define NBINT 1000

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int compareEntiers(void *a, void *b)
{
	return *(int*)a-*(int*)b;
}

void echangeDeuxElem(void * a, void * b)
{
	int elemA;
	int elemB;
  
	elemA = *(int *)a;
	elemB = *(int *)b;
	
  	int tmp;

	tmp=*(int *)a;
	*(int *)a = *(int *)b;
	*(int *)b = tmp;
}

void mqsortIntermediaire(int * base, int * deb, int * fin, int * piv, int(*compar)(void *, void *))
{
	// pointeur sur le début d'un tableau, taille du tableau, taille d'un élément, pointeur sur une fonction pour la méthode de tri
	
	int * tab=base;
	int * pivot=(int *)piv; // élément où je suis
	int * montant=(int *)deb; // élément suivant
	int * descendant=(int *)fin;
	
	if(montant==descendant)
	{
		if(compar((void *)pivot,(void *)montant) > 0)
		{
			echangeDeuxElem(pivot, montant);
		}
	}
	
	if(montant<descendant)
	{
		while(montant<descendant)
		{
			if(compar((void *)montant,(void *)descendant) > 0)
			{
				echangeDeuxElem(montant,descendant);
			}
			if(compar((void *)montant,(void *)pivot) < 0)
			{
				montant++;
			}
			if(compar((void *)pivot,(void *)descendant) <= 0)
			{
				descendant--;
			}
		}
		if(montant==descendant && compar((void *)pivot,(void *)montant)>0)
		{
			echangeDeuxElem(pivot,montant);
		}
		if(montant>descendant && compar((void *)pivot,(void *)descendant)>0)
		{
			echangeDeuxElem(pivot,descendant);
		}
		mqsortIntermediaire(tab,pivot+1,montant-1,pivot,compar);
		mqsortIntermediaire(tab,montant+1,fin,montant,compar);
	}
}

void mqsort(int *base, int nelem, int(*compar)(void *, void *))
{
	mqsortIntermediaire(base,base+1,base+nelem-1,base,compar);
}

int main(int argc, char *argv[])
{	
	int tab[NBINT];	
	int taille2 = NBINT;
	int i;
	srand(time(NULL));
	
	for (i=0; i<taille2; i++)
	{
		tab[i] = rand() % 10000;
	}

	printf("Tableau d'entiers initial : ");
	
	for (i=0; i<taille2; i++)
	{
		printf("%d ", tab[i]);
	}
	printf("\n\n");

	mqsort(tab,taille2,compareEntiers);
	
	printf("Tableau d'entiers final : ");
	
	for (i=0; i<taille2; i++)
	{
		printf("%d ", tab[i]);
	}
	printf("\n");
}
