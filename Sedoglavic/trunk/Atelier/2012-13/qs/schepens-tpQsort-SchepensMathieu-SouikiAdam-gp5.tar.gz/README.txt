Compte-rendu avancement du TP qsort de Schepens Mathieu et Souiki Adam, L3 GP5:

Partie sur le qsort d'entiers : fonctionnelle.

Partie sur le qsort générique : fonctionnelle.

Partie sur le msort : fonctionnelle mais problème au moment de récupérer les lignes,
la line qui est attribué dans chaque case de mon tableau tabATrier reste la même,
la lecture se fait donc bien, mais par exemple :
On lit la ligne d'indice 0 "maLigne a1a", tabATrier[0]="maLigne a1a" ; puis on lit 
la ligne d'indice 1 "maLigne c2c", tabATrier[1]="maLigne c2c" mais tabATrier[0]=
"maLigne c2c" également...


Pour les qsort, nous avons choisi de passer par une méthode qui appelle une 
méthode intermédiaire, celle-ci s'appelle récursivement ensuite pour effectuer le
tri du tableau.
Cela permet de mieux définir le pivot, le début et la fin à chaque appel de la
deuxième méthode, et de faciliter le raisonnement ensuite (évite de se dire "mais
ce 'tab+nelem-1' c'est quoi déjà ?" mais plutôt voir un "tab+fin" en se relisant).


Tests :
Pour le qsort d'entiers et le qsort génériques, tests intégrés dedans sous forme
de main.
Pour le msort, main intégrée mais faire : ./msort < testMSort

Makefile :
Possibilité de faire :
make qsortInt
make qsort
make msort
Pour compiler les fichiers un à un.
Ou alors make all pour tous les compiler à la fois. 
