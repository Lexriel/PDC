/*
 * TP qsort, Schepens Mathieu, Souiki Adam, L3 GP5.
*/

#include <stdio.h>
#include <stdlib.h>

int compareChaineCroissant(void *a, void*b)
{
	return strcmp(*(char **)a,*(char **)b);
}

int compareEntiers(void *a, void *b)
{
	return *(int*)a-*(int*)b;
}

int compareChar(void *a, void *b)
{
	return *(char*)a-*(char*)b;
}

void echangeDeuxElem(size_t size, void * a, void * b)
{
	char * pointeurA;
	char * pointeurB;
  
	pointeurA = a;
	pointeurB = b;
	
  	char tmp;
	int j;
	for (j=0; j<size;++j) // échange octets par octets, a démarre au premier octet du premier nombre, b au premier octet du deuxième nombre
	{
		tmp=pointeurA[j];
		pointeurA[j] = pointeurB[j];
		pointeurB[j] = tmp;
	}
}

void mqsortIntermediaire(void *base, char *deb, char *fin, char *piv, size_t size, int(*compar)(void *, void *))
{
	// pointeur sur le début d'un tableau, taille du tableau, taille d'un élément, pointeur sur une fonction pour la méthode de tri
	
	char * tab=base; // passage a un tableau d'octets, pas d'arithmétique de pointeurs avec void*	
	char * pivot=piv; // élément où je suis
	char * montant=deb; // élément suivant
	char * descendant=fin;
	
	if(montant==descendant)
	{
		if(compar((void *)pivot,(void *)montant) > 0)
		{
			echangeDeuxElem(size, pivot, montant);
		}
	}
	
	if(montant<descendant)
	{
		while(montant<descendant)
		{
			if(compar((void *)montant,(void *)descendant) > 0)
			{
				echangeDeuxElem(size, montant,descendant);
			}
			if(compar((void *)montant,(void *)pivot) < 0)
			{
				montant+=size;
			}
			if(compar((void *)pivot,(void *)descendant) <= 0)
			{
				descendant-=size;
			}
		}
		if(montant==descendant && compar((void *)pivot,(void *)montant)>0)
		{
			echangeDeuxElem(size,pivot,montant);
		}
		if(montant>descendant && compar((void *)pivot,(void *)descendant)>0)
		{
			echangeDeuxElem(size,pivot,descendant);
		}
		mqsortIntermediaire(tab,pivot+size,montant-size,pivot,size,compar);
		mqsortIntermediaire(tab,montant+size,fin,montant,size,compar);
	}
}

void mqsort(void *base, int nelem, size_t size, int(*compar)(void *, void *))
{
	mqsortIntermediaire(base,base+size,base+(nelem-1)*size,base,size,compar);
}

int main(int argc, char *argv[]) {
	
	const char *buffer[]={"Mohamed","Adam","Mathieu","David","Clement","Jeremy","Theo","Helene"};
	int taille = sizeof(buffer)/sizeof(char *);
	int i,j;

	printf("Tableau de string initial : ");

	for (i=0; i<taille; i++)
	{
		printf("%s ", buffer[i]);
	}

	printf("\n");
	
	mqsort(buffer,taille,sizeof(char *),compareChaineCroissant);
			
	printf("Tableau de string final : ");
	
	for (i=0; i<taille; i++)
	{
		printf("%s ", buffer[i]);
	}
	printf("\n");	
	
	printf("Tableau de char initial : ");
	
	char tab2[]={'a','D','B','e','c'};
	int taille3 = sizeof(tab2)/sizeof(char);
	for (i=0; i<taille3; i++)
	{
		printf("%c ", tab2[i]);
	}
	printf("\n");

	mqsort(tab2,taille3,sizeof(char),compareChar);
	
	printf("Tableau de char final : ");
	
	for (i=0; i<taille3; i++)
	{
		printf("%c ", tab2[i]);
	}
	printf("\n");
	
	int tab[]={11,6,15,7,2,22,13,18,5,12,28,38,25,12,37,42,1,999,-12,128,-97,-5,222,132,123};
	int taille2 = sizeof(tab)/sizeof(int);
		
	printf("Tableau d'entiers initial : ");

	for (i=0; i<taille2; i++)
	{
		printf("%d ", tab[i]);
	}
	
	printf("\n");
	
	// tab d'entiers, indice de debut, indice de fin, pointeur sur une fonction pour la méthode de tri
	mqsort(tab,taille2,sizeof(int),compareEntiers);
		
	printf("Tableau d'entiers final : ");

	for (i=0; i<taille2; i++)
	{
		printf("%d ", tab[i]);
	}
	printf("\n");
}

