/*
 *   David Demol Grp : 5
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "qsint.h"

int main(void)
{
  int taille = 10;
  int min = 0 , max = 100;
  int tab[taille];
  int i;
  srand(time(NULL));

  for(i=0; i<taille; i++)
    {
      tab[i] = min + (rand() % (max - min));
    }

  printf("Avant :");
  for(i=0; i<taille; i++)
    {
      printf(" %d ",tab[i]);  
    }
  printf("\n");
  quicksort_int(tab,taille);
 
  printf("Apres :");
  for(i=0; i<taille; i++)
    {
      printf(" %d ",tab[i]); 
    }
  printf("\n");
  return 0;
}
