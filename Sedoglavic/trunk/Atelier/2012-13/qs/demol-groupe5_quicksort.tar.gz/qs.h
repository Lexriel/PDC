/*
 *   David Demol Grp : 5
 */

#ifndef H_QSINT
#define H_QSINT

int compar(void *a, void *b);

void permut(void *a, void *b, int size); 

void quicksort(void *base, int nelem, int size,
               int(*compar)(void *, void *));

#endif 
