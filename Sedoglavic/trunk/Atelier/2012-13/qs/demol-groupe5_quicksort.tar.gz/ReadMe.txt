	Demol David Groupe: 5

* Le quicksort_int fonctionne et l'éxécutable d'un main utilisant cette fonction avec des valeurs choisis aléatoirement idem.

* Le quicksort générique ne fonctionne pas et donc par conséquence le msort non plus, l'idée globale est compris, les deux fonctions ( compar et permut ) me paraissent bonnes, le code et les commentaires expliquent tous les principes du msort mais d'un point de vue pratique une erreur de ségmentation n'a pas pu être corrigé.
