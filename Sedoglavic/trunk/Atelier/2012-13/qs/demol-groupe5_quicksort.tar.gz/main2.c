/*
 *   David Demol Grp : 5
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "qs.h"


int main(void)
{
  /*  int n=2, i;
    char *tab[n]={"zvb","cax"};
    quicksort(tab[0], n, sizeof(char *), compar);
    for(i=0;i<n;i++)
        printf(" %s ",tab[i]);
*/    return 0;
}
