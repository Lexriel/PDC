/*
 *   David Demol Grp : 5
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "qsint.h"

#define TABSIZE 1000

void quicksort_int(int tab[], unsigned int nelem)
{
  int pivot, mont, desc, tmp;
  int i;

  pivot = tab[0];
  desc = (nelem-1);
  mont = 1;
  tmp = 0;


  if(nelem == 1)
    return ;

  if(nelem == 2)
    {
      if(pivot > tab[desc])
	{
	  tmp = tab[desc];
	  tab[desc] = tab[0];
	  tab[0] = tmp; 
	}
      return ;
    }

  while(mont < desc)
    {
      if((tab[mont] > pivot) && (tab[desc] < pivot))
	{
	  tmp = tab[desc];
	  tab[desc] = tab[mont];
	  tab[mont] = tmp;
	}

      if(tab[mont] <= pivot)
	{
	  mont++;
	}

      if(tab[desc] >= pivot)
	{
	  desc--;
	}

    }

  if(((desc == 1) && (mont == 1)) || desc == 0)
    { 

      if(pivot > tab[desc])
	{
	  tmp = tab[desc];
	  tab[desc] = tab[0];
	  tab[0] = tmp; 
	}
      quicksort_int(&tab[1],nelem-1);
    }
  else  if(mont == (nelem-1))
    {
      tmp = tab[desc];
      tab[desc] = tab[0];
      tab[0] = tmp;
      quicksort_int(&tab[0],nelem-1);
    }
  else
    {
      if(pivot > tab[desc])
	{
	  tmp = tab[desc];
	  tab[desc] = tab[0];
	  tab[0] = tmp; 
	}
      quicksort_int(&tab[0],desc);
      quicksort_int(&tab[desc],(nelem-desc));
    }
}
