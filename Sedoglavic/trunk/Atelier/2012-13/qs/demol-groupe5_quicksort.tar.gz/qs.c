/*
 *   David Demol Grp : 5
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "qs.h"

int compar(void *a, void *b)
{
   return strcmp(*(char**)a,*(char**)b);
}

void permut(void *a, void *b, int size)
{
   int i;
   char tmp;
   for( i=0; i < size ; i++)
   {
     tmp = *(((char*)a) +i);
     *(((char*)a)+i) = *(((char*)b)+i);
     *(((char*)b)+i) = tmp;
   }

}

void quicksort(void *base, int nelem, int size,
               int(*compar)(void *, void *))
{
  void * pivot = malloc(size);
  int mont, desc;

  pivot = base;
  desc = (nelem-1);
  mont = 1;

  if(nelem == 1)
    return ;

  if(nelem == 2)
    {
      if(compar(pivot, ((void*)((char*)base)+(desc*size))) > 0)
	{
	   permut(pivot, ((void*)((char*)base)+(desc*size)), size);
	}
      return ;
    }


  while(mont < desc)
    {
      if((compar(pivot, ((void*)((char*)base)+(mont))) > 0) && (compar(pivot, ((void*)((char*)base)+(desc))) < 0))
	{
	  permut(((void*)((char*)base)+(mont*size)), ((void*)((char*)base)+(desc*size)), size);
	}

      if(compar(pivot, ((void*)((char*)base)+(mont*size))) <= 0)
	{
	  mont++;
	}

      if(compar(pivot, ((void*)((char*)base)+(desc*size))) >= 0)
	{
	  desc--;
	}
    }

  if(((desc == 1) && (mont == 1)) || desc == 0)
    { 

      if(compar(pivot, ((void*)((char*)base)+(desc*size))) > 0)
	{
	   permut(pivot, ((void*)((char*)base)+(desc*size)), size);
	}
      quicksort( ((void*)((char*)base)+(1*size)),nelem-1,size,compar);
    }
  else  if(mont == (nelem-1))
    {
      permut(pivot, ((void*)((char*)base)+(desc*size)), size);
      quicksort( ((void*)((char*)base)),nelem-1,size,compar);
    }
  else
    {
      if(compar(pivot, ((void*)((char*)base)+(desc*size))) > 0)
	{
	   permut(pivot, ((void*)((char*)base)+(desc*size)), size); 
	}
      quicksort( ((void*)((char*)base)),desc,size,compar);
      quicksort( ((void*)((char*)base)+(desc*size)),(nelem-desc),size,compar);
    }
}
