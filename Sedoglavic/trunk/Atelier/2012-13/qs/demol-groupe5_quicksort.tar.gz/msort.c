#include <stdio.h>
#include <stdlib.h>
#include <string.h>  
#include "qs.h"

#define NMAXLINE  10
#define NMAXCHAR  20

int main(int argc, char *argv[])
{
   char tab[NMAXLINE][NMAXCHAR];
   int c, cptLine, cptChar, i, j;

   cptLine = 0;
   cptChar = 0;

   /* Initialisation du tableau  */
   for(i = 0; i < NMAXLINE ; i++)
   {
      for(j = 0; j < NMAXCHAR ; j++)
      {
	 tab[i][j]= '\0';
      }
   }

   /* Stockage des lignes du fichier dans tableau */
   while(((c = getchar()) != EOF) && (cptLine != NMAXLINE) && (cptChar != NMAXCHAR))
   {
      tab[cptLine][cptChar] = c;    
      switch (c)
	{
        case '\n':
           cptLine++;
           cptChar = 0;
           break;
        default :
	   cptChar++;
           break;
        }
   }

   /* Trie des lignes */

   quicksort( tab[0] , NMAXCHAR ,sizeof(char*), compar );

   /* Ecrit sur l'entrée standard les lignes triées  */
   for(i = 0; i < NMAXLINE ; i++)
   {
      for(j = 0; j < NMAXCHAR ; j++)
      {
	 putchar(tab[i][j]);
      }
   }

   /* Test si erreurs  */
   if(cptLine == NMAXLINE)
   {
      printf(" - Nombres maximum de lignes atteintes (%d) \n",NMAXLINE);
   }
   else if(cptChar == NMAXCHAR)
   {
      printf(" - Nombres maximum de characteres atteintes (%d) : ligne %d \n",NMAXCHAR,cptLine+1);
   }

   return 0;
}
