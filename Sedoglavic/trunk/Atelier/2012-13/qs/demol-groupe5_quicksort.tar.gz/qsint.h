/*
 *   David Demol Grp : 5
 */

#ifndef H_QSINT
#define H_QSINT

void quicksort_int(int tab[], unsigned int nelem);

#endif 
