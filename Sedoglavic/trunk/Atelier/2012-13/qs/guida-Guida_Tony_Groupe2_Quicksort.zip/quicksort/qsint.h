#define TABSIZE 100
/*fonction de comparaiosn*/
int comparaison(int x,int y){
  if (x==y){
    return 0;
  }
  if (x>y){
    return 1;
  }
    return -1;
}
void tri_am(int tab[], unsigned int el){
	int i,j,tmp;
	for(i=1; i < el ; i++){
		j=i;
		while(j>0 && tab[j] < tab[j-1]){
			tmp=tab[j];
			tab[j]=tab[j-1];
			tab[j-1]=tmp;
			j--;
		}
	}
}

void aff(int tab[],int el){
    int i;
    for (i=0;i<el;i++){
        printf("%i\n",tab[i]);
    }
}
/*tab tableau a trier, nelem le nombre element*/
void quicksort_int(int tab[], unsigned int nelem){
	int montant, descendant,tmp,pivot;
	pivot=0;
	montant=0;
	descendant = nelem;
	if (nelem<5){
	    tri_am(tab,nelem);
	}
	else {
        while (montant < descendant){
            while((montant<nelem) && comparaison(tab[montant],tab[pivot])<0){
                montant++;
            }
            while ((descendant>0) && comparaison(tab[pivot],tab[descendant])<=0){
                descendant--;
            }
            /*condition d'arret*/
            if (montant>=descendant){
                break;
            }
            /*on echange montant descendant*/
            tmp=tab[montant];
            tab[montant]=tab[descendant];
            tab[descendant]=tmp;
        }
        /*on echange pivot et descendant*/
        tmp=tab[descendant];
        tab[descendant]=tab[pivot];
        tab[pivot]=tmp;
        /*affichage*/
        printf("affichage du tableau en cours\n");
        aff(tab,nelem);
        /*on rappelle la fonction sur les 2 parties du tableau*/
        quicksort_int(tab,descendant);
        quicksort_int(&(tab[descendant+1]), nelem-descendant-1);
	}

}
