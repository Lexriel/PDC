qsint.h contient les fonctions d'affichage et de trie.
qsint.c est l'initialisation du tableau d'entier au hasard et test le trie sur les entiers
Enfin qsg.c est le trie g�n�rique, il utilise les fonction d'affichage de qsint.h mais � sa propre fonction de trie et son main