#include <stdlib.h>
#include <stdio.h>
#include "qsint.h"

int rand(void);


int main (int argc, char *argv[])
{
  int tab[TABSIZE];
  int i;
  for (i=0;i<TABSIZE;i++){
    tab[i]=rand()%100;
    printf("%d\n",tab[i]);
  }
  quicksort_int(tab,TABSIZE);
  printf("Voici le tableau trier\n");
for (i=0;i<TABSIZE;i++){
    printf("%d\n",tab[i]);
  }

  return 0;
}
