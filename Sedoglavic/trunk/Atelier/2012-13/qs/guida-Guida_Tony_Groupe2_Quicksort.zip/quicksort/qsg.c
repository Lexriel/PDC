#include "qsint.h"
#include <stdio.h>


int compar(const void * x,const void * y){
  if(*(int*)x==*(int*)y)return 0;
  if(*(int*)x>*(int*)y)return 1;
  else return -1;
}

void quicksort(void *base, int nelem, int size,int(*compar)(const void *, const void *)){

  int pivot,montant,descendant;
  char* tab= base;
  unsigned int i=0;
  char tmp;
pivot=0;
montant=0;
descendant=nelem-1;
  /*fin de la recusivite*/
  if(nelem<=1){
    return;
  }
	printf("Voici le tableau en cours\n");
  aff((int*)tab,nelem);
  
  while(montant<descendant){
    while(montant <= descendant && compar((void*)&tab[pivot*size],(void*)&tab[montant*size])>=0 ){
      montant++;
    }
    while(montant <= descendant && compar((void*)&tab[pivot*size],(void*)&tab[descendant*size])<0){
      descendant--;
    }
	/*condition d'arret*/
    if(montant>=descendant){
		break;
	}
    else{
      /*echange montant et descendant*/
      for(i=0;i<size;i++){
		tmp=tab[montant*size+i];
		tab[montant*size+i]=tab[descendant*size+i];
		tab[descendant*size+i]=tmp;
      } 
    }

 
    /*echange pivot et descendant*/
    for(i=0;i<size;i++){
      tmp=tab[pivot*size+i];
      tab[pivot*size+i]=tab[descendant*size+i];
      tab[descendant*size+i]=tmp;
    }

    /*Rappel de la fonction*/
    quicksort(tab,descendant,size,compar);

    quicksort(&tab[(descendant+1)*size],nelem-descendant-1,size,compar);
  }
}

int main(){
  int tab[TABSIZE];
 int i;
  for (i=0;i<TABSIZE;i++){
    tab[i]=rand()%100;
    printf("%d\n",tab[i]);
  }
  printf("tableau de depart\n");
  aff(tab,TABSIZE);
  quicksort(tab,TABSIZE,sizeof(int),compar);
  printf("tableau trie\n");
  aff(tab,TABSIZE);
  return 0;
}
