#include <stdio.h>

void swap (int* a , int* b)
{
	int temp = *a;
	*a = *b ;
	*b = temp ;
}

int choix_pivot (int tab[] , unsigned int size)
{
	return 0 ;
}

void quicksort_int(int tab[] , unsigned int size)
{
	if (size > 1)
	{
	    int gauche = -1;
        int droite = size+1;

        unsigned int indice_pivot = choix_pivot (tab , size) ;

        while(1)
        {
            do droite--; while(tab[droite] > tab[indice_pivot]);
            do gauche++; while(tab[gauche] < tab[indice_pivot]);

            if(gauche < droite)
                swap(tab+gauche, tab+droite);
            else break;
        }

        quicksort_int (tab, gauche) ;
        quicksort_int (tab+droite+1, size-(droite+1) );
	}
}
