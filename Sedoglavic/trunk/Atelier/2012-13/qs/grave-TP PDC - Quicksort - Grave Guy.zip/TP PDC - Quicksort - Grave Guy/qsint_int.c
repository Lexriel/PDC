#include <stdlib.h>
#include <stdio.h>
#include "qsint.h"
#include <time.h>

#define SIZE 1000

int main (void)
{
    srand(time(NULL)) ;
	int tab[SIZE] ;

    for ( size_t i=0 ; i < SIZE ; ++i )
	{
		tab[i] = rand() ;
	}

	quicksort_int (tab , SIZE) ;

	/* pour tester si tableau est tri�, on regarde si tab[i] < tab[i+1] */

	for ( size_t i=0 ; i < SIZE ; ++i )
	{
        if ( tab[i] > tab[i+1] )
        {
                printf ("%s", "non-trie") ;
                return EXIT_FAILURE ;
        }
	}
	return EXIT_SUCCESS ;
}
