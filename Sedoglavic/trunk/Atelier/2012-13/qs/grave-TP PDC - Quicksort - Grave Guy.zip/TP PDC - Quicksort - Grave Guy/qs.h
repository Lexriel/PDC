
void quicksort(void *base , int nelem , int size , int(*compar)(const void *, const void *)) ;
