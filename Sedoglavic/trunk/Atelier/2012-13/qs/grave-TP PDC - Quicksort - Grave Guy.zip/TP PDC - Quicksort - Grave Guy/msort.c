#include <stdio.h>
#include <string.h>
#include "qs.h"

int compare (const void* str1, const void* str2)
{
    char* string1 = (char*) str1 ;
    char* string2 = (char*) str2 ;
    return strcmp (string1, string2) ;
}

int compare2 (short a , short b)
{
    if (a < b)
    {
        return 1 ;
    }
    else if (a > b)
    {
        return -1 ;
    }
    else
    {
        return 0 ;
    }
}

int main (int argc, char *argv[])
{
    short tab[200] ;
    quicksort ((void*)tab , 200 , sizeof(short) , compare2) ;

    for (size_t i = 0 ; i< 200 ; ++i)
    {
        printf ("%d\n", tab[i]) ;
    }


/*
    for (size_t i = 0 ; i< argc ; ++i)
    {
        printf ("%s\n", argv[i]) ;
    }

    quicksort ( (void*)argv , argc , sizeof ( char* ) , &compare) ;

    for (size_t i = 0 ; i< argc ; ++i)
    {
        printf ("%s\n", argv[i]) ;
    }
*/

    return 0 ;
}
