#include <stdio.h>
#include <string.h>

void swap (void* a , void* b , unsigned int size)
{
    char temp[size] ;
	memcpy (a , temp, size) ;
	memcpy (b , a, size) ;
	memcpy (temp, b , size) ;
}

int choix_pivot (void *tab , unsigned int size)
{
	return 0 ;
}

void quicksort(void *tab , int nelem , int size , int(*compar)(const void *, const void *))
{
    char* base = (char*) tab ;
	if (nelem > 1)
	{
	    int gauche = -1;
        int droite = nelem+1;

        unsigned int indice_pivot = choix_pivot (base , nelem) ;

        while(1)
        {
            do droite--; while( (*compar) ( base + droite * size , base + indice_pivot * size ) == 1 );
            do gauche++; while( (*compar) (base + gauche * size , base + indice_pivot * size ) == -1 );

            if(gauche < droite)
                swap(base + gauche * size , base + droite * size, size);
            else break;
        }

        quicksort (base, gauche , size , compar) ;
        quicksort (base+droite+1, nelem-(droite+1) , size , compar);
	}
}
