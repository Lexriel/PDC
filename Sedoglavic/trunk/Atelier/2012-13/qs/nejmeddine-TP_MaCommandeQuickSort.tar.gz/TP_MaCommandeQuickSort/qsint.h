/*******************
Sara EL ARBAOUI
	&
Ayoub NEJMEDDINE
Groupe 5
********************/

#define TABSIZE 20
#define RANDMAX 50


void quicksort_int(int tab[], unsigned int nelem);

void qs( int a[], int ascendent, int descendent);

int partitionnement( int a[], int ascendent, int descendent);
