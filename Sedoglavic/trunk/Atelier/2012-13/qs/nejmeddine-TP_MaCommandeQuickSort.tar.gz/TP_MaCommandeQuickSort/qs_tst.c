/*******************
Sara EL ARBAOUI
	&
Ayoub NEJMEDDINE
Groupe 5
********************/
#include <stdio.h>
#include<stdlib.h>
#include "qs.h"


int main() 
{
	char tab[TABSIZE] ;
	int i;
	
	printf ("\n\n ************************ DEBUT DE L'ALGORITHME ************************\n");
	  
		for(i = 0; i < TABSIZE; ++i) (char)( tab[i]=(rand()%26) + 65);
	printf("\n\nLE TABLEAU NON TRIE EST:                            \n\n");
	
             for(i = 0; i < TABSIZE; i++)
		if (tab[i]!='\0') printf("[%c]", tab[i]);
		

		
quickSort(tab,TABSIZE,comparaison);


	printf("\n\nLE TABLEAU TRIE EST:                               \n");
		for(i = 0; i <= TABSIZE; i++)
			if (tab[i]!='\0') printf("[%c]", tab[i]);
		
	printf ("\n\n ************************ FIN DE L'ALGORITHME ************************\n");
	
return 0;
} 
