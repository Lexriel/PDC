/*******************
Sara EL ARBAOUI
	&
Ayoub NEJMEDDINE
Groupe 5
********************/
#include <stdio.h>
#include "qs.h"



int comparaison(char x, char y){

if (x<y||x==y) return 1;
    else return -1;
            
}


void quickSort(char base[], int nmemb, int(*compar)(const void *, const void *))
{

 int montant =0, descendant =nmemb-1;
  qs( base,montant ,descendant,compar);
}


void qs( char tab[], int montant, int descendant, int(*compar)(const void *, const void *))
{
   int j;

   if( montant < descendant ) 
   {
        j = partitionnement( tab, montant, descendant,compar);
       qs( tab, montant, j-1,compar);
       qs( tab, j+1, descendant,compar);
   }
}


int partitionnement( char tab[], int montant, int descendant, int(*compar)(const void *, const void *)) {
   char pivot,t;
   int  i, j;
   pivot = tab[montant];
   i = montant; j = descendant+1;
		
   while( 1)
   {
   	do i++; while( (comparaison(tab[i] ,pivot)==1) && i <= descendant );
   	do j--; while( comparaison(tab[j] , pivot)==-1 );
      
        if( i >= j ) break;
   	t = tab[i]; tab[i] = tab[j]; tab[j] = t;
   }
   t = tab[montant]; tab[montant] = tab[j]; tab[j] = t;
   return j;
}


