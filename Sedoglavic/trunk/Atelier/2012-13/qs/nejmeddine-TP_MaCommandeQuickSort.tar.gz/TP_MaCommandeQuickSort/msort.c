/*******************
Sara EL ARBAOUI
	&
Ayoub NEJMEDDINE
Groupe 5
********************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "msort.h"




int comparerLigne(char l1[MAXLINE], char l2[MAXLINE]){
	if ( strcmp(l1,l2)<= 0)	return 1;
	else 	return 0;

}

void quickSort(char base[MAXLINE][MAXLINE], int nelem, int(*compar)(const void *, const void *))
{
	 int montant =0, descendant = nelem;
	 qs( base,montant ,descendant,compar);
}


void qs( char tab[MAXLINE][MAXLINE], int montant, int descendant, int(*compar)(const void *, const void *))
{
   int var;
   if( montant < descendant ) 
   {
       var = partitionnement( tab, montant, descendant,compar);
       qs( tab, montant, var-1,compar);
       qs( tab, var+1, descendant, compar);
   }
}


int partitionnement( char tab[MAXLINE][MAXLINE], int montant, int descendant, int(*compar)(const void *, const void *)) {
 
	char pivot[MAXLINE];
	char tab1[MAXLINE],tab2[MAXLINE];
	int i,j,k=0;

	for( k=0;k<MAXLINE;k++) 
		pivot[k] = tab[montant][k];

	i = montant; j = descendant+1;

	while(1)
	{
		do{ 
			i++ ; 
			for( k=0;k<MAXLINE;k++)
				tab2[k] = tab[i][k];  
		 } while( (comparerLigne(tab2 ,pivot)==1) && i <= descendant );

		do{
			j-- ;
			for( k=0;k<MAXLINE;k++)
				tab2[k] = tab[j][k];
		} while(comparerLigne(tab2 , pivot)==0 );

		if( i >= j ) break;

		for(k=0;k<MAXLINE;k++)
			tab1[k] = tab[i][k];
		for( k=0;k<MAXLINE;k++) 
			tab[i][k] = tab[j][k];
		for(k=0;k<MAXLINE;k++) 
			tab[j][k] = tab1[k];

	   }

		for(k=0;k<MAXLINE;k++) 
			tab1[k] = tab[montant][k];
		for(k=0;k<MAXLINE;k++) 
			tab[montant][k] = tab[j][k];
		for(k=0;k<MAXLINE;k++) 
			tab[j][k] = tab1[k];

	return j;

}




