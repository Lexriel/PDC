/*******************
Sara EL ARBAOUI
	&
Ayoub NEJMEDDINE
Groupe 5
********************/
#define MAXLINE  81


int comparerLigne(char x[MAXLINE], char y[MAXLINE]);
void quickSort(char base[MAXLINE][MAXLINE], int nelem, int(*compar)(const void *, const void *));
void qs( char tab[MAXLINE][MAXLINE], int montant, int descendant, int(*compar)(const void *, const void *));
int partitionnement( char tab[MAXLINE][MAXLINE], int montant, int descendant, int(*compar)(const void *, const void *)) ;
