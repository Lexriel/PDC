/*******************
Sara EL ARBAOUI
	&
Ayoub NEJMEDDINE
Groupe 5
********************/

#include <stdio.h>
#include<stdlib.h>
#include "qsint.h"



int main() 
{
	int tab[TABSIZE],i ;	

	
	printf("\n\n*********************************************************************\n");
	for(i = 0; i < TABSIZE;i++)
		tab[i]=rand() % RANDMAX ;   /*   Initialisation aléatoire dU tableau    */
	  
	printf("************************ Tableau Non Trié *****************************\n");

	for(i = 0; i < TABSIZE; i++)
		printf(" %d - ", tab[i]);		
	printf("\n\n");

        quicksort_int(tab, TABSIZE);
	
	printf("************************* Tableau Trié *********************************\n\n");
	for(i = 0; i < TABSIZE; i++)
		printf(" %d - ", tab[i]);
 

	printf("\n\n**********************************************************************\n\n");
	
return 0;
}
