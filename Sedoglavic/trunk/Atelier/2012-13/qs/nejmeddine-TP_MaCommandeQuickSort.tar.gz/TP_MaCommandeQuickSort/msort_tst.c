/*******************
Sara EL ARBAOUI
	&
Ayoub NEJMEDDINE
Groupe 5
********************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "msort.h"
#include "readl.h"


int main (int argc, char *argv[])
{
	char texte[MAXLINE][MAXLINE];
	 
	int i;
	int nbreligne=0,colonne=0; 
	int res=0;
	if(argc>1){
		fprintf(stderr,"USAGE  : msort n'a pas besoin d'argument \n");
		exit(EXIT_FAILURE);
	}
 
  fprintf(stderr,"\n *********************** Commande Msort *************************\n");
 
	int fin_lecture=0;

	while (fin_lecture==0){
		printf("\n Entrer Une Ligne SVP   :\n ");
		char line[MAXLINE];
		int indice = 0,nbrecolonne=0;
		 
		res= readl(line);  
		while(indice <res){
			texte[nbreligne][nbrecolonne]=line[nbrecolonne];nbrecolonne++;indice++;
		}	
		
		    nbreligne++;
		   printf ("si vous voulez saisir une autre ligne  tapez  (o)  sinon tapez (n)   ");
		   char reponse[2]; 
			res= readl(reponse);  
		  if (reponse[0]=='n') fin_lecture=1;
	}

	int  numligne=0;
 
	printf ("**************************************************************** \n");
	printf ("********************* Lignes saisies *************************** \n");
	while(numligne<nbreligne){

		int numcolonne=0;

		while( texte[numligne][numcolonne]!='\0'){
			printf("%c",texte[numligne][numcolonne]);
			numcolonne++;
		}
		numligne++;  printf ("\n");
	}


	quickSort(texte,nbreligne-1,comparerLigne);


	printf ("********************* Lignes triées **************************** \n");
	numligne=0;
	while(numligne<nbreligne){
		int numcolonne=0;
		while( texte[numligne][numcolonne]!='\0'){
			printf("%c",texte[numligne][numcolonne]);numcolonne++;
		}
		numligne++;  printf ("\n");
	}

	printf ("**************************************************************** \n");
	printf ("**************************************************************** \n");

	exit(EXIT_SUCCESS);
}
 
