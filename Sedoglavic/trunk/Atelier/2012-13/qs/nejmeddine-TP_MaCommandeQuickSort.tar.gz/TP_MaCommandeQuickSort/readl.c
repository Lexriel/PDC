/*******************
Sara EL ARBAOUI
	&
Ayoub NEJMEDDINE
Groupe 5
********************/
#include <stdio.h>
#include <stdlib.h>
#include "readl.h" 
#include "tools.h"
 
/* Lit une ligne sur l'entree standard.   
   Cette ligne doit comporter moins de MAXLINE caracteres.

   Le resultat est retourne dans line. 
   Un \0 est ecrit en fin de la chaine.
    
   Le tableau line doit etre de taille au moins MAXLINE+1.

   Retourne le nombre de caracteres lu, non compris le \0 final.
   Retourne EOF si la fin de fichier est atteinte.

   Termine le programme sur une erreur si rencontre une ligne de plus
   de MAXLINE caracteres. 
*/
 

int readl( char line[]){ 
 

 	int nbreChar=0,i=0;
 
 		
	 while((line[i] = getchar())!='\n'){
	 
		if(line[i] == EOF) {
			 
			return EOF;
		}
			
		else {
			nbreChar++;
		} 
		
		if(i > MAXLINE){
			
			fatal(0, "la ligne contient plus de MAXLINE carateres \n",1);  
			return 1;

		}

		i++;
	}line[i]='\0';
	return nbreChar;


}
