/*******************
Sara EL ARBAOUI
	&
Ayoub NEJMEDDINE
Groupe 5
********************/

#include <stdio.h>
#include <stdlib.h>
#include "qsint.h"

/*     Fonction quicksort_int pour le tri d’un tableau d’entiers    */

void 
quicksort_int
(int tab[], unsigned int nelem)
{
 	int montant =0, descendant = nelem-1;
 	qs( tab,montant ,descendant);
}


void 
qs 
(int *tab, int montant, int descendant)
{
   int k;
   if( montant < descendant ) 
   {	
       k = partitionnement( tab, montant, descendant);
	qs( tab, montant, k-1);
	qs( tab, k+1, descendant);
   }	
}


/*    méthode de partitionnement pour partitionner le tableau en deux zone   */

int 
partitionnement
(int *tab, int montant, int descendant) 
{
	int  i, j, pivot, var;
	i = montant;
	j = descendant + 1;
	pivot = tab[montant];	/*  on choisit comme pivot la valeur du premier élément   */

	while(1)
	{
		/*   on incrémente le  montant tant que l’élément du tableau référencé est inferieur ou egal au pivot  et que le montant est inferieur du descendant   */
	   	do		i++; 
		while( tab[i] <= pivot && i <= descendant );

		/*  on décrémente le  descendant tant que l’élément du tableau référencé est superieur au povot  */
	   	do 		j--; 
		while( tab[j] > pivot );

		/*  on quitte si le montant et le descendant se rencontrent  */		
	   	if( i >= j )		
			 break;

		/*	on échange les éléments référencés par le  montant et le descendant  */
	   	var = tab[i];
		tab[i] = tab[j];	
		tab[j] = var;
	}
	/* en fin,  on échange le pivot et descendant    */
	var = tab[montant];
	tab[montant] = tab[j];
	tab[j] = var;

   return j;

}


 
