/*******************
Sara EL ARBAOUI
	&
Ayoub NEJMEDDINE
Groupe 5
********************/
#define TABSIZE 16



int comparaison(char x, char y);
void quickSort(char base[], int nmemb, int(*compar)(const void *, const void *));
void qs( char a[], int montant, int descendant, int(*compar)(const void *, const void *));
int partitionnement( char a[], int montant, int descendant, int(*compar)(const void *, const void *));


