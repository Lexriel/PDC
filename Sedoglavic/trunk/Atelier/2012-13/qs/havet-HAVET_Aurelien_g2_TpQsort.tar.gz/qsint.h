/* Fonction de comparaison de 2 entiers x et y */
/* Retourne 1 si x > y, -1 si x < y, 0 si x = y */
int f (int x, int y);

/* Fonction qui permet d'inverser 2 entiers, dont les pointeurs sont passes en parametre, dans un tableau */
void permut (int *x, int *y);

/* Fonction qui permet de partitionner un tableau tab, entre les bornes pointees par debut et fin, de taille sizeoftab, en utilisant la fonction de comparaison f */
/*   Elle organise la partition en mettant tous les elements inferieurs au 1er element (le pivot) a gauche de celui-ci, et tous les elements superieurs a droite */
/* Retourne le pointeur de la place du pivot */
int* partitionner(int tab[], int *debut, int *fin, unsigned int sizeoftab, int(*compare)(int, int));

/* Fonction recursive qui effectue un trie rapide sur le tableau tab entre les bornes debut et fin, de taille size */
void quicksortrec (int tab[], int *debut, int *fin, unsigned int size);

/* Fonction qui effectue un tri rapide sur le tableau tab de taille nelem */
void quicksort (int tab[], unsigned int nelem);

