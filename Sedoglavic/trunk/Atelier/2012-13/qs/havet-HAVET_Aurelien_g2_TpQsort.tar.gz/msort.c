#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "qs.h"
#include "readl.h"


int
main()
{
  char tab[NMAXLINES][NMAXCHARS];
  int i,j;
  /* en initialisant i a -1, on evite l'affectation de la ligne correspondant au renvoi d'EOF */
  i = -1;
  while ((readl(tab[++i]) != EOF) && i<NMAXLINES);
  quicksort((char**)tab, i, NMAXCHARS, (int(*)(const void*, const void*))strcmp);
  for (j=0; j<i; j++)
      printf("%s\n", tab[j]);
  return 0;
}
