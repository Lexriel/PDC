

/**
 * Fonction de permutation de 2 elements passes par pointeurs
 * @param void *x
 * @param void *y
 * @param int size la taille en octets des elements
 */
void 
permut
(void *x, void *y, int size)
{
  int i;
  char tmp;
  for (i=0; i<size; i++){
    tmp = *(((char*) x) + i);
    *(((char*) x) + i) = *(((char*) y) + i);
    *(((char*) y) + i) = tmp;
  }
  return;
}

/**
 * Fonction de partitionnement d'une partie d'un tableau
 * @param void *debut le pointeur du debut de la partie a partitionner
 * @param void *fin le pointeur de la fin de la partie a partitionner
 * @param int size la taille en octets d'un element du tableau
 * @param int(*compare)(const void *, const void *) la fonction de comparaison utilisee pour le partitionnement
 * @return void * le pointeur sur le pivot de la partition
 */
void*
partitionner
(void *debut, void *fin, int size, int(*compare)(const void *, const void *))
{
  void *pivot;
  void *montant;
  void *descendant;

  pivot = debut;
  montant = (void *)(((char *) debut) + size);
  descendant = fin;

  if (((char*) fin)-((char*) debut) < 2*size)
    if ((*compare)(pivot, montant)<0)
      return pivot;

  while (montant < descendant)
    {
      while ((*compare)(montant,pivot)<0 && montant<fin)
	  montant = (void *)(((char *) montant) + size);
      while ((*compare)(pivot,descendant)<=0 && debut<descendant)
	  descendant= (void *)(((char *) descendant) - size);
      if (montant>descendant)
	{
	  break;
	}
      else
	{
	  permut(montant, descendant, size);
	}      
    }
  permut(descendant, pivot, size);
  return descendant;
} 

/**
 * Fonction de tri rapide recursif d'une partie d'un tableau
 * @param void *debut le pointeur du debut de la partie a trier
 * @param void *fin le pointeur de la fin de la partie a trier
 * @param int size la taille en octets d'un element du tableau
 * @param int(*compare)(const void *, const void *) la fonction de comparaison utilisee pour le partitionnement
 */
void
quicksortrec 
(void *debut, void *fin, int size, int(*compare)(const void*, const void*))
{
  if (fin>debut)
    {
      void *pivot = partitionner(debut, fin, size, compare);
      quicksortrec (debut, (void*)((char*)pivot - size), size, compare);
      quicksortrec ((void*)((char*)pivot + size), fin, size, compare);
    }
  return;
}

/**
 * Fonction de tri rapide d'un tableau
 * @param void *base le pointeur du tableau a trier
 * @param unsigned int nelem le nombre d'elements du tableau
 * @param int size la taille en octets d'un element du tableau
 * @param int(*compare)(const void *, const void *) la fonction de comparaison utilisee pour le partitionnement
 */
void 
quicksort 
(void *base, unsigned int nelem, int size, int(*compare)(const void*, const void*))
{
  quicksortrec (base,(void *)(((char *) base) + (nelem-1)*size), size, compare);
  return;
}

