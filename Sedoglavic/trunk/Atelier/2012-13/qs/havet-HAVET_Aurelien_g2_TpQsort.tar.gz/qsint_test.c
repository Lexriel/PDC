#include <stdlib.h>
#include <stdio.h>
#include "qsint.h"

/* bibliotheque necessaire a la mesure du temps d'execution */
#include <time.h>

#define TABSIZE 1000000


/**
 * imprime le temps d'execution d'un processus
 * @param clock_t start clock du processeur avant l'execution
 * @param clock_t stop clock du processeur apres l'execution
 */
void
imprimtps
(clock_t start, clock_t stop)
{
  double tps;
  tps = (double)(stop - start)/CLOCKS_PER_SEC;
  printf( "Execution du processus en %2.2f seconds\n", tps );
}


/**
 * imprime un tableau sur la sortie standard
 * @param tab[] le tableau d'entiers a imprimer
 * @param size la taille du tableau
 */
void
imprimtab 
(int tab[], unsigned int size)
{
  int i;
  printf("[");
  for (i=0; i<size; i++)
    {
      printf(" %d ;",tab[i]);
    }
  printf("]\n");
}

/**
 * cree un tableau aleatoire
 * @param tab[] le tableau d'entiers a remplir
 * @param size la taille du tableau
 * @param init parametre d'initialisation du randomize
 */
void
createrandtab 
(int tab[], unsigned int size, int init)
{
  int i;
  srand(init);
  for (i=0; i<size; i++)
    {
      *(tab + i) = rand()%1000000;
    }
}

/**
 * test si un tableau d'entiers est trie
 * @param tab[] le tableau d'entiers a tester
 * @param size la taille du tableau
 * @return char* 'OK' si le tableau est trie, 'KO' sinon
 */
char* ordertest
(int tab[], unsigned int size)
{
  int *i = tab;
  while (++i < tab + size)
    if (*(i-1)>*i) return "KO";
  return "OK";
}



int
main
()
{
  unsigned int k;
  int i;
  int tab[TABSIZE];
  /* variables necessaires au calcul du temps d'execution */
  clock_t start, stop;

  i=0;
  k=TABSIZE;

  for (k = 50000; k <= TABSIZE; k+=50000)
   {
      createrandtab(tab, k, i++);
      /* imprimtab(tab, k); */
      start = clock();
      quicksort(tab,k);
      stop = clock();
      /* imprimtab(tab, k); */
      printf("Test sur un tableau de %d entiers. Resultat : %s\n", k, ordertest(tab,k));
      imprimtps(start, stop);
   }
  printf("-->Fin d'execution du programme de test\n");
  return 0;
}  
