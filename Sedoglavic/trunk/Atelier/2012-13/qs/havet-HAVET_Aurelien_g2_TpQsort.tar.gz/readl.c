#include <stdio.h>
#include <stdlib.h>
#include "readl.h"

extern int 
readl
(char line[])
{
  int i;
  char c;

  i = 0;
  while (((c=getchar()) != EOF) && (c != '\n') && (i<NMAXCHARS))
    {
       line[i++] = c;
    }
 
 line[i] = '\0';

  if ((c == EOF) && (i == 0))
    return EOF;

  if (i == NMAXCHARS){
    fprintf(stdout,"\n!!! Le fichier contient une ligne de plus de 80 caracteres !!!\n");
    exit(EXIT_FAILURE);
  }
  return i;
}
