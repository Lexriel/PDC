/**
 * Fonction de comparaisons de 2 entiers
 * @param int x
 * @param int y
 * @return -1 si x<y, 0 si x=y, 1 si x>y
 */
int 
f 
(int x, int y)
{
  if (x == y)
    return 0;
  else
    if (x > y)
      return 1;
    else
      return -1;
}

/**
 * Fonction de permutation de 2 entiers passes par pointeurs
 * @param int *x
 * @param int *y
 */
void 
permut
(int *x, int *y)
{
  int tmp;

  tmp = *x;
  *x = *y;
  *y = tmp;
}

/**
 * Fonction de partitionnement d'une partie d'un tableau d'entiers
 * @param int tab[] le tableau dans lequel on souhaite faire une partition
 * @param int *debut le pointeur du debut de la partie a partitionner
 * @param int *fin le pointeur de la fin de la partie a partitionner
 * @param int(*compare)(int, int) la fonction de comparaison utilisee pour le partitionnement
 * @return int* le pointeur sur le pivot de la partition
 */
int*
partitionner
(int tab[], int *debut, int *fin, int(*compare)(int, int))
{
  int *pivot;
  int *montant;
  int *descendant;

  pivot = debut;
  montant = debut + 1;
  descendant = fin;

  if (fin-debut<2)
    if (compare(*pivot, *montant)<0) 
      return pivot;

  while (montant < descendant)
    {
      while ((compare(*montant,*pivot)<0)&&(montant<fin))
	  montant++;
      while ((compare(*pivot,*descendant)<=0)&&(debut<descendant))
	  descendant--;

      if (montant>descendant)
	  break;
      else
	  permut(montant, descendant);
    }
  permut(descendant, pivot);
  return descendant;
} 

/**
 * Fonction de tri rapide recursif d'une partie d'un tableau d'entiers
 * @param int tab[] le tableau dans lequel on souhaite faire une partition
 * @param int *debut le pointeur du debut de la partie a trier
 * @param int *fin le pointeur de la fin de la partie a trier
 */
void
quicksortrec 
(int tab[], int *debut, int *fin)
{
  if (fin>debut)
    {
      int *pivot = partitionner(tab, debut, fin, f);
      quicksortrec (tab, debut, pivot - 1);
      quicksortrec (tab, pivot + 1, fin);
    }
}

/**
 * Fonction de tri rapide d'un tableau d'entiers
 * @param int tab[] le tableau dans lequel on souhaite faire une partition
 * @param unsigned int nelem le nombre d'elements du tableau
 */
void 
quicksort 
(int tab[], unsigned int nelem)
{
  quicksortrec (tab, tab, tab + nelem - 1);
}

