#define NMAXLINES 100


/* fonction de comparaison de 2 entiers references par leurs pointeurs */
/* retourne -1 si x>y, 1 si x>y, 0 si x=y */
int cmp (const void *x, const void *y);

/* fonction d'echange de 2 elements de meme type */
void permut (void *x, void *y, int size);

/* fonction de partitionnement d'un tableau entre les elements pointes par debut et fin */
/* dont les elements sont de taille size */
/* en utilisant la fonction de comparaison compare */
void* partitionner (void *debut, void *fin, int size, int(*compare)(const void *, const void *));

/* fonction recursive de tri rapide sur un tableau entre les elements pointes par debut et fin */
/* dont les elements sont de taille size */
/* en utilisant la fonction de comparaison compare */
void quicksortrec (void *debut, void *fin, int size, int(*compare)(const void*, const void*));

/* fonction de tri rapide d'un tableau de nelem elements de taille size */
/* dont le premier est pointe par base */
/* en utilisant la fonction de comparaison compare  */
void quicksort (void *base, unsigned int nelem, int size, int(*compare)(const void*, const void*));

