/* Lemaire H�l�ne
   TP4
   commande qsint
 */

#include<stdlib.h>
#include<stdio.h>
#define TABSIZE 1000


void quicksort_int(int tab[], unsigned int size)
{
  int pivot, montant, descendant, tmp;
  if(size > 1)
    {
      pivot = tab[0] ;
      montant = 1 ;
      descendant = size-1 ;
      while(montant <= descendant) //tant que les deux ne se sont pas crois�es
	{
	  while(tab[montant] < pivot){ //on fait monter le curseur si le montant et inf�rieur au pivot
	    montant++ ;
	  }
	  while(tab[descendant] >= pivot){ //on fait descendre le curseur si le descendant et sup�rieur ou �gal au pivot 
	    if(descendant == 0) break;
	    descendant-- ;
	  }
	  if(montant>descendant)
	    { //l'ordre est bon donc on ne change pas
	    break ;
	    }
	  tmp = tab[montant] ;                  // 
	  tab[montant] = tab[descendant] ;      // on inverse les nombre point�s par les curseurs montant et descendant
	  tab[descendant] = tmp ;               //
	  
	}
      tmp = tab[0];
      tab[0] = tab[descendant]; 
      tab[descendant] = tmp;
      quicksort_int(tab,descendant);                      // rappelle quicksort sur deux tableaux
      quicksort_int(tab+descendant+1,size-descendant-1);  // 
    } 
}

int main(void)
{
  int tab[TABSIZE];
  int i;
  srand(time(NULL));  
  printf("tri d'entiers\n");
  for(i = 0; i < TABSIZE; i++)
    {
      tab[i]=rand()%99;
      printf("%d ",tab[i]);
    }
  putchar('\n');
  i=0;
  quicksort_int(tab,TABSIZE);
  for(i = 0; i < TABSIZE; i++)
    {
      printf("%d ",tab[i]);
    }
  putchar('\n');   
  return 0;
}
