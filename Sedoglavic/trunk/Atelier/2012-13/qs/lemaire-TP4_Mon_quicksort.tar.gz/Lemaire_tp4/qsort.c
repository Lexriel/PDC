/* Lemaire Hélène
   TP4
   commande qsort
 */
#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#define TABSIZE 1000

int cmptInt(const void *a, const void *b)
{ 
  int *aa=(int *) a; 
  int *bb=(int *) b;
  if(*aa>*bb) return 1 ;
  else if (*aa<*bb) return (-1);
  else return 0;
}

int cmptChar(const void *a, const void *b)
{
  char *aa = (char*) a;
  char *bb = (char*) b;
  if(*aa>*bb) return 1;
  else if(*aa<*bb) return (-1);
  else return 0;
}

int cmptDouble(const void *a, const void *b)
{
  double *aa = (double*) a;
  double *bb = (double*) b;
  if(*aa>*bb) return 1;
  else if(*aa<*bb) return (-1);
  else return 0;
}

void echanger(void *a, void *b, int size)
{
  void *tmp = malloc(size);
  memcpy(tmp,a,size);
  memcpy(a,b,size);
  memcpy(b,tmp,size);
  free(tmp);
}

void quicksort(void *base, int nb, int size, int (*compar)(const void *, const void *))
{
  void *pivot;
  int m, d;
  if(nb > 1)
    {
      pivot = base ;
      m = 1 ;
      d = nb-1 ;
      while(m <= d)
	{
	  while(compar(( base)+size*m , pivot) < 0)
	    {
	      m ++ ;
	    }
	  while(compar((base)+size*d , pivot) >= 0)
	    {
	      if(d==0) break;
	      d-- ;
	    }
	  if(m<=d)
	    {
	      echanger(base+size*m,base+size*d,size);

	    }	 
	}

      echanger(base,base+size*d,size);

      quicksort(base,d,size,compar);
      quicksort(base+d*size+size,nb-d-1,size,compar);
    } 
}

  int main(void)
  {
    int tab[TABSIZE];
    int i;
    srand(time(NULL));  
    printf("tri d'entiers\n");
    for(i = 0; i < TABSIZE; i++)
    {
      tab[i]=rand()%99;
      printf("%d ",tab[i]);
    }
    putchar('\n');
    i=0;
    quicksort(tab,TABSIZE,sizeof(int),cmptInt);
     for(i = 0; i < TABSIZE; i++)
    {
      printf("%d ",tab[i]);
    }
     putchar('\n');



    char tabChar[TABSIZE];
    int j;
    int randNum;
    char randChar =' ';
    randNum=0;
    srand(time(NULL));
    printf("\ntri de caractères\n");
    for(j = 0; j < TABSIZE; j++)
    {    
      randNum = rand()%26; // nombre compris entre 0 et 26
      randNum = randNum + 97;//ajoute 97 pour obtenir un caractère dans la table ascii
      randChar = (char) randNum;// on le cast pour modifier le nombre de la table ascii en caractère
      tabChar[j]=randChar;
      printf("%c ",tabChar[j]);
    }
    putchar('\n');
    j=0;
    quicksort(tabChar,TABSIZE,sizeof(char),cmptChar);
     for(j = 0; j < TABSIZE; j++)
    {
      printf("%c ",tabChar[j]);
    }
     putchar('\n');


    double tabDouble[TABSIZE];
    double randDouble;
    printf("\ntri de decimaux \n");
    for(j = 0; j < TABSIZE; j++)
    {    
      randDouble = (rand()/(double)RAND_MAX ) * (99-0) + 0;
      tabDouble[j]=randDouble;
      printf("%f ",tabDouble[j]);
    }
    putchar('\n');
    j=0;
    quicksort(tabDouble,TABSIZE,sizeof(double),cmptDouble);
     for(j = 0; j < TABSIZE; j++)
    {
      printf("%f ",tabDouble[j]);
    }
     putchar('\n');

     return 0;
  }
