Lemaire Hélène
Groupe 5 

Commandes qsint et qsort

Pour le qsint va générer un tableau. J'ai fixé le nombre d'élément à 1000 comme dans l'énoncé. La fonction le réécrit ensuite la suite de chiffre triée.

Même chose pour le qsort sauf que j'ai utilisé 3 sortes de tableaux différents
- Un tableau d'entier
- Un tableau de caractère
- Un tableau de décimal

Pour que ma fonction soit générique, j'utilise des fonctions de comparaisons différents selon le type.
Egalement, comme la taille d'un élément différe selon le type, il faut que la fonction prenne en compte la taille du type.
ex: sizeof(int)

Ma fonction echange ne fonctionnait pas au départ car je faisais les échanges avec des pointeurs. J'ai donc effectué des recherches sur internet. Apparemment, l'échange de deux éléments en utilisant des pointeurs n'est pas judicieux. Ne trouvant d'autres solutions, j'ai donc repris une fonction déjà existante sur le site pour avancer dans le tp. Entre temps je n'ai pas réussi a trouvé une meilleure solution c'est pourquoi j'ai laisser la fonction telle quelle.
 
Je n'ai pas eu le temps de réaliser la commande msort qui ordonnée des lignes.
