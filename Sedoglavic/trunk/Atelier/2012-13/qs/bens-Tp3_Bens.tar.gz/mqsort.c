#include <stdio.h>
#include <stdlib.h>
#define TABSIZE 5

void echanger(int tab[], int indDeb,int indF)
{
  printf("\nechange de %i et %i", tab[indDeb], tab[indF]); 
  int temp = tab[indDeb];
  tab[indDeb] = tab[indF];
  tab[indF] = temp;
}

void qs (int tab[], int deb, int fin)
{
  unsigned int indM, indD; 
  const int pivot = deb;
  indM = deb;
  indD = fin;
  if(deb >= fin)
    return;
  while (1)
  {
    while (tab[indM] <= tab [pivot] && indM < (TABSIZE - 1))
    {
      indM++;
    }
    
    while (tab[indD] > tab[pivot] && indD > 0)
    {
      indD--;
    }
    
    if (indM < indD)
      echanger(tab, indM, indD);
    else
      break;
  }
  //echanger(tab, indD, pivot);
  qs(tab, deb, indD);
  qs(tab, (indD+1), fin); 
}

void quicksort_int(int tab[], unsigned int nelem)
{
  qs(tab, 0, nelem-1);
}

int main(int argc, char* argv[])
{
  int tab[TABSIZE];
  int i;
  for (i=0; i<TABSIZE ; i++)
  {
    tab[i] = rand()%10; 
  }
  printf("Tableau Initial :\n");
  for (i=0; i<TABSIZE ; i++)
  {
    printf("%i ", tab[i]);
  }
  quicksort_int(tab, TABSIZE);
  printf("\n");
  printf("Tableau final :\n");
  for (i=0; i<TABSIZE ; i++)
  {
    printf("%i ", tab[i]);
  }
  printf("\n");
  return 0;
}