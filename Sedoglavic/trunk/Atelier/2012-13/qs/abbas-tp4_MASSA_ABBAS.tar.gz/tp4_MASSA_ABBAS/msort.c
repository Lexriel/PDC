#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include"qs.h"
#include"readl.h"
#include"variables.h"


int my_strcmp(const void *a, const void *b){
  char *aa = (char*) a;
  char *bb = (char*) b;
  return strcmp(aa,bb);
}
  

int main(){
  char line[NMAXCHAR+2], lesLignes[NMAXLINE][NMAXCHAR+2];
  int nbDeLignes=0,i,nbChar;
  
  while((nbChar=readl(line)) != EOF || line[0] != EOF)
    {
      if(nbDeLignes >= NMAXLINE) 
	{
	  fprintf(stderr, "Erreur : Nombre maximal de lignes atteint\n");
	  exit(EXIT_FAILURE);
	}
      if(nbChar > NMAXCHAR)
	{
	  fprintf(stderr, "Erreur : Nombre maximal de caracteres sur une ligne atteint\n");
	  exit(EXIT_FAILURE);
	}
      
   
      strcpy(lesLignes[nbDeLignes] , line) ;
      
      nbDeLignes++;
    }

  
  quicksort(*lesLignes,nbDeLignes,NMAXCHAR+2,my_strcmp);

  for(i=0;i<nbDeLignes;i++){
    printf("%s",lesLignes[i]);
  }

  exit(EXIT_SUCCESS);
  return 0;
}
 
