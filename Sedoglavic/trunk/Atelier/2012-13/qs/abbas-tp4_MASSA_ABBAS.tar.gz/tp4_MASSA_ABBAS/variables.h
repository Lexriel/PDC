#define NMAXCHAR 80
#define NMAXLINE 50
