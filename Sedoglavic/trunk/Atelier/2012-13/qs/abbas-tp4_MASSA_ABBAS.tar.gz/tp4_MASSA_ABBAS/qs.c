#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#define TABSIZE 200




int comparInt(const void *a, const void *b)
{
  int *aa = (int*) a;
  int *bb = (int*) b;
  if(*aa>*bb) return 1 ;
  else if (*aa<*bb) return (-1);
  else return 0;
}

int comparChar(const void *a, const void *b){
  char *aa = (char*) a;
  char *bb = (char*) b;
  if(*aa>*bb) return 1;
  else if(*aa<*bb) return (-1);
  else return 0;
}



void echanger(void *a, void *b, int size)
{
  void *tmp = malloc(size);
  memcpy(tmp,a,size);
  memcpy(a,b,size);
  memcpy(b,tmp,size);
  free(tmp);
}

void quicksort(void *base, int nmemb, int size, int (*compar)(const void *, const void *))
{
  void *pivot;
  int m, d;
  if(nmemb > 1)
    {
      pivot = base ;
      m = 1 ;
      d = nmemb-1 ;
      while(m <= d)
	{
	  while(compar(((char*) base)+size*m , pivot) < 0)
	    {
	      m ++ ;
	    }
	  while(compar(((char*)base)+size*d , pivot) >= 0 && d!=0)
	    {
	      d-- ;
	    }
	  if(m<=d)
	    {
	      echanger((char*)base+size*m,(char*)base+size*d,size);
	    }	 
	}

      echanger((char*)base,(char*)base+size*d,size);

      quicksort(base,d,size,compar);
      quicksort(((char*)base)+d*size+size,nmemb-d-1,size,compar);
    } 
}
