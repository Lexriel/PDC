#include<stdlib.h>
#include<stdio.h>
#include"qsint.h"

int main(){
  int i, tab[TABSIZE];
  for(i=0;i<TABSIZE;i++) 
    {
      tab[i] = rand() % 10000;
    }
  for(i=0;i<TABSIZE;i++)
    {
      printf("%d\n",tab[i]);
    }
  printf("\nLets sort the tab\n\n");
  quicksort_int(tab,TABSIZE);
  for(i=0;i<TABSIZE;i++)
    {
      printf("%d\n",tab[i]);
    }
  return (0);
}
