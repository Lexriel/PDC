#include<stdio.h>
#include<stdlib.h>
#include"variables.h"



/* Lit une ligne sur l'entree standart.
   Cette ligne doit comporter moins de MAXLINE caracteres.

   Le resultat est retourne dans line.
   Un \0 est ecrit en fin de la chaine

   Le tableau line doit etre de taille au moins MAXLINE+2

   Retourne le nombre de caracteres lu, non compris le \0 final.
   Retourn EOF si al fin de fichier est atteinte

   Termine l'execution sur une erreur si rencontre une ligne de plus de MAXLINE caractere
*/

int
readl
(char line[])
{
  int i,j;
  /* on initialise le tableau line avec que des \0 */
  for(j=0;j<NMAXCHAR+2;j++) 
    line[j] = '\0';
  i = 0;

  /* on met dans le tableau tous les caractere lu */
  while(i < NMAXCHAR +1 && (line[i] = getchar()) != '\0' && line[i] != '\n')
    {
      /* on renvoie EOF si on est en fin de fichier */
      if(line[i] == EOF){
	return EOF;
	exit(EXIT_SUCCESS);
      }
      i++ ;
    }

  return i;
  exit(EXIT_SUCCESS);

}
