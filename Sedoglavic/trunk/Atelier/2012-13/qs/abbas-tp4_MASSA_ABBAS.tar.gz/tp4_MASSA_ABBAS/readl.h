#define MAXLINE 82

extern int readl(char line[]);

