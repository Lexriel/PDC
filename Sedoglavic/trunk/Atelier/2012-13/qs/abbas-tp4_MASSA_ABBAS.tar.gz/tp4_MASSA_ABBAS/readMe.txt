MASSA Alexis - ABBAS Hussein
TP4 Groupe 5



Pour le fichier qsint_tst.c on crée un tableau de 200 int aleatoires, on le tri.

Compilation : make qsint_tst

Le fichier msort.c contient une fonction de comparaison de chaine de caractere, et un main permettant de trié les lignes luent sur l'entrée standart

On a defini dans le fichier variables.h les variables NMAXLINE pour le nombre maximum de ligne que peut contenie le fichier a trier et NMAXCHAR pour le nombre maximum de caractere dans ses lignes

Compilation : make msort
Test : ./msort < "fichier"
