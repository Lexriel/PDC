/* Renaud Alexandre Groupe 5 "Le tri quicksort" */

#include <stdio.h>
#include <string.h>
#include "qsint.h"

int
main
(void)
{

  int nelem;
  nelem = 7;
  int tab[] = {5, 8, 11, 2, 3, 22, 14};
  int i;
  printf("Tableau avant tri : \n");
  for(i=0; i<nelem;i++)
    {
	  
      printf("%i ", tab[i]);
    }

 printf("\n");
  
  quicksort_int(tab,nelem);
  
  printf("Tableau apres tri : \n");
  for(i=0; i<nelem;i++)
    {
      printf("%i ", tab[i]);
    }
  printf("\n");
  return 0;
}
