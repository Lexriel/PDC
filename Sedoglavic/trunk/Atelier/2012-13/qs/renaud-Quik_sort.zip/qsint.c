/* Renaud Alexandre Groupe 5 "Le tri quicksort" */

#include <stdio.h>
#include <string.h>
#include "qsint.h"

void 
quicksort_int
(int tab[], unsigned int nelem)
{
  int pivot, montant, descendant, tmp, tmpMontant, tmpDescendant;
  

  pivot = tab[0];

  if(nelem == 2 && tab[0]>tab[1])
    {
      tmp = tab[1];
      tab[1]=tab[0];
      tab[0]=tmp;
    }
    
  if(nelem > 2)
    {
      
      pivot = 0;
      descendant = nelem-1;
      montant = 1;
      while(descendant > montant)
	{
	 
	  //Cherche un montant plus grand que le pivot
	  while(montant<nelem-1 && tab[montant]<tab[pivot])
	    {
	      montant++;
	    }

	  //et un descendant plus petit que le pivot
	  while(descendant>0 && tab[descendant]>tab[pivot])
	    {
	      descendant--;
	    }
	  //Si montant est arrivé à la fin du tableau alors on échange le pivot et descendant
	  //si descendant < montant alors on échange le pivot et descendant
	  // 
	  
	  if(montant == nelem || descendant < montant)
	    {
	      tmp = tab[pivot];
	      tab[pivot] = tab[descendant];
	      tab[descendant] = tmp;
      
      
	      int nelemdes, nelemmont;
	      nelemmont = nelem-1-descendant;
	      quicksort_int(&tab[0],descendant);
	      quicksort_int(&tab[descendant+1],nelemmont);
	      return ;
	    }

	  tmpDescendant = descendant-1;
	  tmpMontant=montant+1;

	  //Chercher un tmpMontant plus petit que montant
	  while(tmpMontant<nelem-1 &&  tab[tmpMontant]>tab[montant])
	    {
	      tmpMontant++;
	    }
	  
	  //et un tmpDescendant plus grand que descendant
	  while (tmpDescendant>1 && tab[tmpDescendant]>tab[descendant])
	    {
	      tmpDescendant--;
	    }
	  
	  //Si le tmpDescendant est plus grand que descendant alors on les échanges
	  if(tab[descendant] < tab[tmpDescendant])
	    {
	      tmp = tab[descendant];
	      tab[descendant] = tab[tmpDescendant];
	      tab[tmpDescendant] = tmp;
	    }

	  //Si le tmpMontant est plus petit que montant alors on les échanges
	  if(tab[montant] > tab[tmpMontant])
	    {
	      tmp = tab[montant];
	      tab[montant] = tab[tmpMontant];
	      tab[tmpMontant] = tmp;
	    }
	}
    }

 
  return ;
}
