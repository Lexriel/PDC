/* Renaud Alexandre Groupe 5 "Le tri quicksort" */

#ifndef __QSINT_H__
#define __QSINT_H__

void quicksort_int(int tab[], unsigned int nelem);

#endif

