#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "msort.h"
#include "readl.h"


int main (int argc, char *argv[])
{
	char mat[MAXLINE][MAXLINE];
 	char line[MAXLINE];
  	int i;
 	int ligne=0,colonne=0;
  
  fprintf(stderr,"debut du traitement de MSORT\n");
 
	int fin_lecture=0;
		while (fin_lecture==0){
			printf("ENTREZ UNE LIGNE SVP   :");
	char c, temp[MAXLINE];
	int s=0,colonne=0;
  		scanf ("%s",temp);
   		while(s<MAXLINE)
    {
    mat[ligne][colonne]=temp[colonne];colonne++;s++;
    }	
     
   	ligne++;
   	printf ("VOULEZ VOUS ENTREZ UNE NOUVELLE LIGNE :  [entrer  0 pour NON  ou 1 pour OUI]  : ");
   	int reponse; scanf("%d",&reponse);
  		if (reponse==0) fin_lecture=1;
  	}

	int  k=0;
	while(k<ligne){
	int kk=0;
	while( mat[k][kk]!='\0'){
		printf("[%c] ",mat[k][kk]);kk++;
	}
	k++;
		printf ("\n");
	}


	quick(mat,ligne-1,comp_str);


		printf ("***************************\n");
 	k=0;
 	while(k<ligne){
	int kk=0;
	while( mat[k][kk]!='\0'){
		printf("[%c] ",mat[k][kk]);kk++;
	}
	k++;
	  printf ("\n");
	}
  exit(EXIT_SUCCESS);
}
 
