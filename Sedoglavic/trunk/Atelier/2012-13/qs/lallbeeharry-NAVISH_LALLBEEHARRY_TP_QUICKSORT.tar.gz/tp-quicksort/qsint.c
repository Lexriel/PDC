#include <stdio.h>
#include "qsint.h"


void quicksort_int(int tab[], unsigned int size)
{
 int ascendent =0, descendent =size;
  quickSort( tab,ascendent ,descendent);
}

void quickSort( int a[], int ascendent, int descendent)
{
   int j;

   if( ascendent < descendent ) 
   {
   	
        j = partition( a, ascendent, descendent);
       quickSort( a, ascendent, j-1);
       quickSort( a, j+1, descendent);
   }
	
}



int partition( int a[], int ascendent, int descendent) {
   int pivot, i, j, t;
   pivot = a[ascendent];
   i = ascendent; j = descendent+1;
		
   while( 1)
   {
   	do ++i; while( a[i] <= pivot && i <= descendent );
   	do --j; while( a[j] > pivot );
   	if( i >= j ) break;
   	t = a[i]; a[i] = a[j]; a[j] = t;
   }
   t = a[ascendent]; a[ascendent] = a[j]; a[j] = t;
   return j;
}


 
