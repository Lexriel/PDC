#include <stdio.h>
#include "qs.h"


int main() 
{
	char a[TABSIZE]={'j','w','r','q','l','b','o','c','a','s'} ;	

	int i;


	printf("\n\nLE TABLEAU NON TRIE EST : \n\n");
	
             for(i = 0; i < TABSIZE; ++i)
		printf(" [%c] ", a[i]);

	
	quick(a,TABSIZE,comp_char);


	printf("\n\nLE TABLEAU TRIE EST : \n\n");
		for(i = 0; i < TABSIZE; ++i)
			if (a[i]!='\n') printf("[%c] ", a[i]);
       		printf ("\n END \n");

return 0;
} 
