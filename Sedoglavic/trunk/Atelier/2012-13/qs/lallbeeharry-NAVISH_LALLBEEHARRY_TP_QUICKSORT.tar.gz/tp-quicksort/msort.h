#define MAXLINE  81


int comp_str(char x[MAXLINE], char y[MAXLINE]);
void quick(char base[MAXLINE][MAXLINE], int nmemb, int(*compar)(const void *, const void *));
void quickSort( char a[MAXLINE][MAXLINE], int ascendent, int descendent, int(*compar)(const void *, const void *));
int partition( char a[MAXLINE][MAXLINE], int ascendent, int descendent, int(*compar)(const void *, const void *)) ;
