#include <stdlib.h>
#include <stdio.h>
#define TABSIZE 10


void 
quicksort_int
(int tab[], unsigned int nelem){
  if(nelem < 2)
  {
    return ;
  }

  int pivot, montant, descendant;
  pivot = 0;
  montant = 0;
  descendant = nelem-1 ;

  while(tab[montant] < tab[descendant])
  {
    while(compEnt(tab[montant],tab[pivot]) < 0)
	{
	  montant++;
	}
	while(compEnt(tab[pivot],tab[descendant]) <= 0)
	{
	  descendant--;
	}
	if(montant == descendant)
	{
	  return;
	}
	tab[montant] =+ tab[descendant];
	tab[descendant] =- tab[montant];
	tab[montant] =- tab[descendant];
  }
  
  
  tab[pivot] =+ tab[descendant];
  tab[descendant] =- tab[pivot];
  tab[pivot] =- tab[descendant];
  
  //quicksort_int(tab,pivot);
  //quicksort_int(tab+pivot,nelem-pivot);

}

int
compEnt
(ent1, ent2)
{
  return ent1 - ent2;
}


int 
main()
{
  int monTab[TABSIZE];
  int i ;

  for(i=0;i < TABSIZE;i++)
  {
    monTab[i] = rand()%10;
  }
  for(i=0;i < TABSIZE;i++)
  {
    printf("%i\t", monTab[i]);
  }  
  printf("\n");

  quicksort_int(monTab, TABSIZE);

  for(i=0;i < TABSIZE;i++)
  {
    printf("%i\t", monTab[i]);
  }
  printf("\n");
  return 0;
}
