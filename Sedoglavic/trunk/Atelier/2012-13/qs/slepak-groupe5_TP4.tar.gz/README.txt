SLEPAK Jérémy
GROUPE 5

qsint.c :
Ce quickSort trie correctement un tableau d'entiers.
Le tableau est initialiser grâce à la fonction rand. Pour simplifier l'affichage, les entiers sont choisis aléatoirement dans l'intervalle [0-100].
Une fonction echanger est définie pour echanger les valeurs d'un tableau.

qs.c :
Ce quickSort trie correctement les tabeaux de tout type. Un tableau d'entier, un tableau de caractére et un tableau de float ont été définis.
Les entiers et les caractères sont générés aléatoirement.
3 fonctions de comparaison ont été définis pour chaques type.
Je n'ai pas su créer ma fonction echanger sans utiliser des fonctions déjà existante (pas bien !).

Par manque de temps, je n'ai pas pu écrire la fonction msort.
