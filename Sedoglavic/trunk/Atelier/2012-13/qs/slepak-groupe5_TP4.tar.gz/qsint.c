/*
SLEPAK Jérémy
GROUPE 5
*/

#include <stdio.h>
#include <stdlib.h>

#define TABSIZE 10

void 
echanger
(int tab[], int a, int b)
{
    int tmp = tab[a];
    tab[a] = tab[b];
    tab[b] = tmp;
}

void 
quickSort_int
(int tab[], unsigned int nelem)
{ 
  int pivot, montant, descendant;
  pivot = tab[0] ;
  montant = 1 ;
  descendant = nelem-1 ;

  if(nelem > 1)
  {
    while(montant <= descendant) //Tant que le montant ne dépasse pas le descendant
    {
     while(tab[montant] < pivot) //On incrémente le montant tant qu'il est inférieur au pivot
     {
     montant ++ ;
     }
 
     while(tab[descendant] >= pivot) //On décrémente le descendant tant qu'il est supérieur au pivot
     {
       if(descendant == 0) break;
       descendant-- ;
     }

     if(montant>descendant) // Si le montant rencontre le descendant on sort
     {
       break ;
     }
     echanger(tab,montant,descendant); // Sinon on echange le montant et le descendant
    }
      echanger(tab,0,descendant); // On echange ensuite le pivot et le descendant

      quickSort_int(tab,descendant); // Et on rappelle la fonction
      quickSort_int(tab+descendant+1,nelem-descendant-1);
   } 
}


int main(void)
{   
    int tab[TABSIZE];
    int i,nb;
    srand(time(NULL));
    for(i = 0; i < TABSIZE; i++)
    {
	tab[i]=rand()%100;printf("%d ", tab[i]);
    }
    printf("\n");

    quickSort_int(tab,TABSIZE);
    
    for(i = 0; i < TABSIZE; i++)
    {
	printf("%d ", tab[i]);
    }
    putchar('\n');
    
    return 0;
}







