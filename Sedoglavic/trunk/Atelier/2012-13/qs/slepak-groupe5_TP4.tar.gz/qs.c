/*
SLEPAK Jérémy
GROUPE 5
*/

#include<stdlib.h>
#include<stdio.h>
#include<string.h>

#define TABSIZE 1000

void 
echanger
(void *a, void *b, int size)
{
  void *tmp = malloc(size);
  memcpy(tmp,a,size);
  memcpy(a,b,size);
  memcpy(b,tmp,size);
  free(tmp);
}

int 
cmpInt
(const void *a, const void *b)
{ 
  const int *ai=(const int *) a; /*const int *ai : ai est un pointeur sur une constante entier --- (const char *) a : a est un pointeur constant sur un caractère*/ 
  const int *bi=(const int *) b;
  if(*ai>*bi) return 1 ;
  else if (*ai<*bi) return (-1);
  else return 0;
}

int 
cmpFloat
(const void *a, const void *b)
{ 
  const float *ad=(const float *) a;
  const float *bd=(const float *) b;
  if(*ad>*bd) return 1 ;
  else if (*ad<*bd) return (-1);
  else return 0;
}

int 
cmpChar
(const void *a, const void *b)
{ 
  const char *ac=(const char *) a; 
  const char *bc=(const char *) b;
  if(*ac>*bc) return 1 ;
  else if (*ac<*bc) return (-1);
  else return 0;
}



void 
quickSort_Gen
(void *base, int nelem, int size, int (*compar)(const void *, const void *))
{ 
  int montant, descendant;
  void *pivot;
  
  pivot=base;
  montant = 1 ;
  descendant = nelem-1 ;

  if(nelem > 1)
  {
    while(montant <= descendant) //Tant que le montant ne dépasse pas le descendant
    {

     while(compar(base+size*montant,pivot)<=0) //On incrémente le montant tant qu'il est inférieur au pivot
     {
      montant ++;
     }
 
     while(compar(base+size*descendant,pivot)>0) //On décrémente le descendant tant qu'il est supérieur au pivot
     {
       if(descendant == 0) break;
       descendant--;
     }

     if(montant<=descendant) // Si le montant n'a pas rencontré le descendant on echange les valeurs
     {
       echanger(base+(size*montant),base+(size*descendant),size);
     }
    }
     echanger(base,base+size*descendant,size); // On echange le pivot et le descendant

     quickSort_Gen(base,descendant,size,compar); // Et on rappelle la fonction
     quickSort_Gen(base+descendant*size+size,nelem-descendant-1,size,compar);
   } 
}



int main(void)
{   
    int tab[TABSIZE];
    float tabf[5] = {2.34,1.23,4.56,3.45,5.67};
    char tabc[TABSIZE];
    int i,j;

    putchar('\n');printf("##### TRI DE INT #####");putchar('\n');
    srand(time(NULL));
    for(i = 0; i < TABSIZE; i++)
    {
	tab[i]=rand()%100;printf("%d ", tab[i]);
    }
    printf("\n");printf("\n");
    quickSort_Gen(tab,TABSIZE,sizeof(int),cmpInt);
     
    for(i = 0; i < TABSIZE; i++)
    {
	printf("%d ", tab[i]);
    }
    putchar('\n');putchar('\n');printf("##### TRI DE DOUBLE #####");putchar('\n');
   


   for(j = 0; j < 5; j++)
   {
	printf("%f ", tabf[j]);
   }
   printf("\n");
   quickSort_Gen(tabf,5,sizeof(float),cmpFloat);
   for(j = 0; j < 5; j++)
    {
	printf("%f ", tabf[j]);
    }

    putchar('\n');putchar('\n');printf("##### TRI DE CHAR #####");putchar('\n');


   int randNum;
   char randc =' ';
   randNum=0;
   srand(time(NULL));
   for(j = 0; j < TABSIZE; j++)
   {
      randNum = rand()%26;
      randNum = randNum + 97;
      randc = (char) randNum;
      tabc[j]=randc;
      printf("%c ",tabc[j]);
   }
   printf("\n");printf("\n");
   quickSort_Gen(tabc,TABSIZE,sizeof(char),cmpChar);
   for(j = 0; j < TABSIZE; j++)
    {
	printf("%c ", tabc[j]);
    }
    putchar('\n');putchar('\n');

    return 0;
}
