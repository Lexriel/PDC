#include <stdlib.h>
#include <stdio.h>
#include "qsint.h"


void swap(int *a, int *b)
{
   int temp;
 
   temp = *b;
   *b = *a;
   *a = temp;   
}


void quicksort_int(int tab[], unsigned int nelem)
{
    if(nelem > 1)
    {
        int pivot, montant, descendant;
    
        pivot = tab[0];           /* premier element */
        montant = 0;              /* scanner de gauche (montant) */
        descendant = nelem - 1;   /* scanner de droite (descendant) */
        


        /* Echange tant que montant a pas croisé descendant */
        while(montant <= descendant)
        {
            while(tab[montant] <= pivot)
                montant++;
            while(pivot < tab[descendant])
                descendant--;

            if(montant <= descendant)
                swap(&tab[montant], &tab[descendant]);
        }

        swap(&tab[0], &tab[descendant]);
    
        
        quicksort_int(tab, descendant);
        quicksort_int(tab + descendant + 1, nelem - descendant - 1);
    }
}




int main(int argc, char *argv[])
{
    int i;
    int tab[TABSIZE];


    for(i=0; i<TABSIZE; i++)
        tab[i] = rand();
        
        
    for(i=0; i<TABSIZE; i++)
        printf("%d\n", tab[i]);

    quicksort_int(tab, TABSIZE);    
    
    printf("-----------\n");
    for(i=0; i<TABSIZE; i++)
        printf("%d\n", tab[i]);
    
    



    exit(EXIT_SUCCESS);
}



