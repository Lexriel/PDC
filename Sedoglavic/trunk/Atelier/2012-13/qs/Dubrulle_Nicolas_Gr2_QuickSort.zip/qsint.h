#define TABSIZE 10


void swap(int*, int*);

void quicksort_int(int tab[], unsigned int nelem);


