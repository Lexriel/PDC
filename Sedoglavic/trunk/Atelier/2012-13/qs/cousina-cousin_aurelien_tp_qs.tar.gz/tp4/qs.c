int compareInt(const void * a, const void * b) {
  return *(int *)a - *(int *)b;
}

int comparestr(const void * a, const void * b) {
  return strcmp((char *)a,(char *)b);
}

void bubblesort(void * tab, unsigned int nelem,int size,int(*compar)(const void *, const void *)) {
  int i,j,tmp;
  for(i=1;i<nelem;i++) {
    j=i;
    while(j>0 && compar(tab+j*size,tab+(j-1)*size)<0) {     
      pointer_swap(tab+j*size,tab+(j-1)*size,size);
      j--;
    }
  }
}

void pointer_swap(void * a, void * b , int size) {
  char * ca;
  char * cb;
  char tmp; 
  ca = a;
  cb = b;
  while(size--) {
    tmp = *ca;
    *ca=*cb;
    *cb=tmp;
    ca++;
    cb++;
  }
 
}


void quicksort(void *base, int nelem, int size, int(*compar)(const void *, const void *)) {
  int pivot=0;
  int montant=1;
  int descendant=nelem-1;
  int tmp;
  if(nelem<5) {
    bubblesort(base,nelem,size,compar);
  }
  else {
    while(montant<descendant) {
      while(compar(base+montant*size,base+pivot*size)<0 && montant<nelem) {
	montant++;
      }
      while(compar(base+pivot*size,base+descendant*size)<=0 && descendant>0) {
	descendant--;
      }
      if(montant>=descendant){break;}
      pointer_swap(base+montant*size,base+descendant*size,size);
    }
    pointer_swap(base+pivot*size,base+descendant*size,size);

    quicksort(base,descendant,size,compar);
    quicksort(base+size*(descendant+1),nelem-descendant-1,size,compar);
  }
}
