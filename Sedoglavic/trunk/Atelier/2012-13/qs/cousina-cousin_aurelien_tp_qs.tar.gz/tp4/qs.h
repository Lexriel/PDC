#include <string.h>

#define NMAXLINE 200
#define NMAXCHAR 300

typedef struct lines Lines;

struct lines {
  char tab[NMAXLINE][NMAXCHAR];
  int nlines;
};

int comparestr(const void * a, const void * b);

int compareInt(const void * a, const void * b);

void bubblesort(void * tab, unsigned int nelem,int size,int(*compar)(const void *, const void *));

void quicksort(void *base, int nelem, int size, int(*compar)(const void *, const void *));

void pointer_swap(void * a, void * b , int size);
