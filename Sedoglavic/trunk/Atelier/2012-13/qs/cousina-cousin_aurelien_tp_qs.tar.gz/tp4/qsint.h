int compareInt(int a,int b);

void bubblesortInt(int tab[], unsigned int nelem);

void quicksortInt(int tab[], unsigned int nelem);
