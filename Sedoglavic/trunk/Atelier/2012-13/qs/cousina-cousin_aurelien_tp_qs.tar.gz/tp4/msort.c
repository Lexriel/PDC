#include <stdio.h>
#include <stdlib.h>
#include "qs.h"
#include "qs.c"
#include "readl.h"


int main(void) {
  int i;  
  Lines leslignes;
  leslignes.nlines=0;
  while(readl(leslignes.tab[leslignes.nlines]) != EOF) {
    leslignes.nlines++;
  }

  for(i=0;i<leslignes.nlines;i++) {
    printf("%s\n",leslignes.tab[i]);
  }
  printf("------------SORTING...------------\n");
  quicksort((void *)leslignes.tab, leslignes.nlines, NMAXCHAR,comparestr);
  for(i=0;i<leslignes.nlines;i++) {
    printf("%s\n",leslignes.tab[i]);
  }
  exit(EXIT_SUCCESS);
}

