int compareInt(int a,int b) {
  return a-b;
}

void bubblesortInt(int tab[], unsigned int nelem) {
  int i,j,tmp;
  for(i=1;i<nelem;i++) {
    j=i;
    while(j>0 && tab[j]<tab[j-1]) {     
	tmp=tab[j];
	tab[j]=tab[j-1];
	tab[j-1]=tmp;
	j--;
    }
  }
}

void quicksortInt(int tab[], unsigned int nelem) {
  int pivot=0;
  int montant=1;
  int descendant=nelem-1;
  int tmp;
  if(nelem<5) {
    bubblesortInt(tab,nelem);
  }
  else {
    while(montant<descendant) {
      while(compareInt(tab[montant],tab[pivot])<0 && montant<nelem) {
	montant++;
      }
      while(compareInt(tab[pivot],tab[descendant])<=0 && descendant>0) {
	descendant--;
      }
      if(montant>=descendant){break;}
      tmp=tab[montant];
      tab[montant]=tab[descendant];
      tab[descendant]=tmp;
    }
    tmp =tab[pivot];
    tab[pivot]=tab[descendant];
    tab[descendant]=tmp;
    quicksortInt(tab,descendant);
    quicksortInt(&tab[descendant+1],nelem-descendant-1);
  }
  
}
