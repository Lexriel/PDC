#include <stdio.h>
#include <stdlib.h>
#include "qsint.h"
#include "qsint.c"

#define TABSIZE 150


int main() {
  int tab[TABSIZE];
  int i;
  srand(time(NULL));
  for(i=0;i<TABSIZE;i++) {
    tab[i]=rand()%100;
    printf("%d\t",tab[i]);
  }
  printf("---------SORT------\n");
  quicksortInt(tab, TABSIZE);
  for(i=0;i<TABSIZE;i++) {
    printf("%d\t",tab[i]);
  }
}
