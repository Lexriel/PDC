#include <stdio.h>
#include <stdlib.h>
#include "readl.h"
#include <string.h>

#define TABSIZE 100 /* pour la main 1 */

int compareInt(const void * a, const void * b) {
  return *(int *)a - *(int *)b;
}

int comparestr(const void * a, const void * b) {
  return strcmp((char *)a,(char *)b);
}

int main1(int argc, char ** argv) {
  int tab[TABSIZE];
  int i;
  srand(time(NULL));
  for(i=0;i<TABSIZE;i++) {
 
    tab[i]=rand()%1000;
    printf("%d\t",tab[i]);
  }
  printf("---------SORT------\n");
  quicksort((void *)tab, TABSIZE, sizeof(int),&compareInt);
  for(i=0;i<TABSIZE;i++) {
    printf("%d\t",tab[i]);
  }
}

int main(void) {
  int i;  
  Lines leslignes;
  leslignes.nlines=0;
  while(readl(leslignes.tab[leslignes.nlines]) != EOF) {
    leslignes.nlines++;
  }

  for(i=0;i<leslignes.nlines;i++) {
    printf("%s\n",leslignes.tab[i]);
  }
  printf("------------SORTING...-------\n");
  quicksort((void *)leslignes.tab, leslignes.nlines, NMAXCHAR,comparestr);
  for(i=0;i<leslignes.nlines;i++) {
    printf("%s\n",leslignes.tab[i]);
  }
  exit(EXIT_SUCCESS);
}

