/* 
 * Théo CALIBRE
 * Clément Hochedez
 * G5
 *
 *
*/

#define NMAXCHAR 20
#define NMAXLINE 3

extern int readl(char line[]);

