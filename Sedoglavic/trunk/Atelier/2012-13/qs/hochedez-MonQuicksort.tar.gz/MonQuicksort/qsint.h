/* 
 * Théo CALIBRE
 * Clément HOCHEDEZ
 * G5
 *
 *
*/

#define TABSIZE 1000

/* permet d'echanger la valeur du montant et du descendant */ 
void echanger(int tab[], int a, int b)
{
    int tmp = tab[a];
    tab[a] = tab[b];
    tab[b] = tmp;
}

//  
int rand_ab(int a, int b){
    return rand()%(b-a) +a;
}
