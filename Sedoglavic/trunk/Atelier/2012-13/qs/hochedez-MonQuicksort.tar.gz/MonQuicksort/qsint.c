/* 
 * Théo CALIBRE
 * Clément Hochedez
 * G5
 * quicksort 1-- 
 *
*/

#include <stdlib.h>
#include <stdio.h>
#include "qsint.h"


/*la methode quicksort_int permet de trier les éléments du tableau dans un ordre croissant */ 
void quicksort_int(int tab[], unsigned int nelem)
{
  /*on crée un pivot qui aura comme valeur le premier élément du tableau, un montant qui va s'incrémenter et un descendant qui va décrémenter */ 
  int pivot;
  int montant; 
  int descendant; 
  int tmp;
  if(nelem > 1)
  {
    /* le montant sera fixé sur l'indice 2 du tableau */ 
    montant=1 ;
    /* le descendant sera fixé sur le dernier indice du tableau */ 
    descendant=nelem-1;
    /* le pivot sera la valeur du premier element du tableau */ 
    pivot=tab[0] ;
    /* tant que le montant sera inférieur au descendant, le montant va prendre l'indice n+1 et le descendant n-1 ssi le montant 
     * est inférieur au pivot et le descendant supérieur à celui-ci
     */ 
    while(descendant >= montant)
    {
	while(tab[montant] < pivot)
	{
	    montant++;
	}
	while(tab[descendant] >= pivot)
	{
	    if(descendant==0) 
		break;
	    descendant--;
	}
	if(montant > descendant)
	{
	    break ;
	}
	echanger(tab,montant,descendant);
    }
    tmp = tab[0];
    tab[0] = tab[descendant];
    tab[descendant] = tmp; 
    quicksort_int(tab,descendant);
    quicksort_int(tab+descendant+1,nelem-descendant-1);
  } 
  return;
}


/* test de la méthode quicksort_int */ 
void main (void)
{
    int i;
    int nb_aleatoire = 0;
    int taille = 0;
    do 
    {
       printf("Entrer la taille du tableau entre 0 et 1001 non compris : ");
       scanf("%d",&taille);
       if(taille<=0)
       {
          printf("il y a pas d'élement dans le tableau \n");
       }
       if(taille>TABSIZE)
       {
          printf("il y a trop d'element dans le tableau \n");
       }
    }
    while(taille<=0 || taille>TABSIZE);
    int tab[taille];
    for(i=0;i<taille;i++) 
    {
	nb_aleatoire = rand_ab(0,100);
	tab[i]=nb_aleatoire;
    }
    printf("tableau non trié : \n");
    for(i=0;i<taille-1;i++)
      printf("%d-" ,tab[i]);
    printf("%d" ,tab[taille-1]);
    printf("\n");
    quicksort_int(tab,taille);
    printf("resultat du qsort : \n");
    for(i=0;i<taille-1;i++)
      printf("%d-" ,tab[i]);
    printf("%d" ,tab[taille-1]); 
    printf("\n");

}




