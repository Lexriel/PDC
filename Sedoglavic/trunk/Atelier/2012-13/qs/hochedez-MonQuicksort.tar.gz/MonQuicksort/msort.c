/* 
 * Théo CALIBRE
 * Clément Hochedez
 * G5
 *
 *
*/

#include "readl.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int readl(char line[])
{
    if (fgets(line, NMAXCHAR, stdin) == NULL)
    {
        if(feof(stdin))
            return EOF;
        else
            return 0;
    }
    else
        return strlen(line);
}



int main(void) 
{

   /* les caracteres rentrés par l'utilisateur */ 
   char tab[NMAXCHAR];   
   /* lignes stockés dans le tableau */
   /* la ligne est la ligne retourne*/
   int ligne;
   ligne = readl(tab);
   while(ligne!=EOF)
   {
      

   }
   
   

}
