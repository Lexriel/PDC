Théo Calibre 
Clément Hochedez

I] Travail à réaliser 

-Créer une bibliotèque de tri de tableau d’entiers (fichiers qsint.c et qsint.h).
-Ecrire un programme de test de cette bibliothèque (qsint_tst).
-Ecrire une bibliotheque de tri quicksort générique (fichiers qs.c et qs.h).
-Implanter la commande msort.

II] Fichiers rendus 

-qsint.c : fonction qui tri le tableau d'entiers avec le main dans le même fichier 
-qsint.h : contient la methode rand et la procédure echange. fichier associé à qsint.c 
-qs.c : fonction qui tri le tableau de maniere generique 
-qs.h : contient des fonctions de comparaison et d'echange. 
-msort.c : fichier incomplet 
-readl.h : lit la ligne rentré par l'utlisateur 


III] Avancement du travail

Partie 1 : La bibliotheque de tri de tableau d'entiers 

Le tri de tableau d'entier fonctionne. 
Lors du lancement du test, l'utilisateur renseigne la table du tableau. Ce tableau est généré aléatoirement avec la commande rand().
Nous avons modifié le rand pour que les nombres soit bornés entre 0 et 100 pour éviter d'avoir de gros chiffres. 
Le test affiche le tableau initaliser avec le rand() et affiche le tableau trié. 

Partie 2 : La bibliotheque de tri quicksort générique

Le tri quicksort générique fonctionne. On peut trier des entiers mais aussi des caractères. 
Un main a été crée montrant les deux exemples. 

Partie 3 : le msort 

Le msort ne fonctionne pas.    

IV] Difficultés rencontrées 

On a pas très bien compris l'utilité du msort
On ne sait pas si il faut trier tous les caracteres de chaques lignes ou alors triés les lignes par ordre du dictionnaire. 
Nous n'avons pas reussi à manipuler les structures de données. 
L'avancement à été supprimé car notre msort ne compilait pas. 
Impossible de séparer le main du qsint.c , l'erreur est la suivante lorsque je compile :

----------------------------------------------------------------------------------------------------
/usr/bin/ld: /usr/lib/debug/usr/lib/crt1.o(.debug_info): relocation 0 has invalid symbol index 12
/usr/bin/ld: /usr/lib/debug/usr/lib/crt1.o(.debug_info): relocation 1 has invalid symbol index 13
[...] 
/usr/lib/gcc/i486-linux-gnu/4.4.3/../../../../lib/crt1.o: In function `_start':
(.text+0x18): undefined reference to `main'
collect2: ld returned 1 exit status
----------------------------------------------------------------------------------------------------


 
