/* 
 * Théo CALIBRE
 * Clément Hochedez
 * G5
 * quicksort générique 
 *
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "qs.h"

/* quicksort generique 
*  la base represente le tableau
*  nmemb : le nombre d'elements
*  size : la taille du tableau
*/

void quicksort(void *base, int nmemb, int size, int (*compar)(const void *, const void *))
{
  void *pivot;
  int montant;
  int descendant;
  if(nmemb > 1)
    {
      montant=1;
      descendant=nmemb-1;	
      pivot=base ;
      /* on boucle tant que le montant n'est pas égal ou supérieur au descendant */ 
      while(montant <= descendant)
	{
	  while(compar(((char*) base)+size*montant , pivot) < 0)
	    {
	      montant ++ ;
	    }
	  while(compar(((char*)base)+size*descendant,pivot) >= 0 && descendant!=0)
	    {
	      descendant-- ;
	    }
	  /* meme cas que pour le premier quicksort, si le montant est inférieur ou égal on descendant, on echange les 2 valeurs. */ 
	  if(montant<=descendant)
	    {
	      echanger((char*)base+size*montant,(char*)base+size*descendant,size);
	    }	 
      }
      echanger((char*)base,(char*)base+size*descendant,size);
      quicksort(base,descendant,size,compar);
      quicksort(((char*)base)+descendant*size+size,nmemb-descendant-1,size,compar);
    } 
}


void main (void)
{
    int i;
    int j;
    int nmemb=5; 
    /* creation d'un tableau de caractere */ 
    char tab[10] = {'z','w','r','t','a','c','f','g','m','x'};
    /* creation d'un tableau d'entier */ 
    int tab2[5] = {84,14,88,47,1};
    /* quicksort effectue sur le tableau de caractere */ 
    quicksort(tab,nmemb,sizeof(char),comparChar);
    for(i=0;i<4;i++)
      printf("%c-" ,tab[i]); 
    printf("%c" ,tab[4]); 
    printf("\n"); 
    /* quicksort effectue sur le tableau d'entier */ 
    quicksort(tab2,nmemb,sizeof(int),comparChar);
    for(j=0;j<4;j++)
      printf("%d-" ,tab2[j]);
    printf("%d" ,tab[5]);
    printf("\n");
    

}



