#include "qsint.h"
#include <stdlib.h>
#include <stdio.h>


int
main
(void)
{
	const int SIZE =20;
	int tab_ex[SIZE];
	unsigned int i;
	for(i=0;i<SIZE;i++){
		tab_ex[i]=rand()/10000000;
	}

	printf("--Avant le tri--\n");
	for(i=0;i<20;i++){
		printf("%d ",tab_ex[i]);
	}

	quicksort_int(tab_ex,SIZE);

	printf("\n--Après le tri--\n");

	for(i=0;i<20;i++){
		printf("%d ",tab_ex[i]);
	}
	printf("\n");

	return 0;
}
