extern void qs (void *, int , int ,int(*)(const void *, const void *));
