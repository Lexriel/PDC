#include "qsint.h"
#include <stdlib.h>
#include <stdio.h>

//Fonction de comparaison de deux entiers
int
compare
(int n1,int n2)
{
	return n1-n2;
}

//Fonction permettant de trier un tableau d'entiers
void
quicksort_int
(int tab[], unsigned int nelem)
{
	if(nelem>1){
		int montant;
		int descendant;
		int x;
		int tmp;
		x=0;
		montant=1;
		descendant=nelem-1;

		
		while(montant<descendant){
			while(compare(tab[montant],tab[x])<0 && montant<nelem)
				montant++;
			while(compare(tab[x],tab[descendant])<=0 && descendant>0)
				descendant--;
			if(montant<descendant){
				tmp= tab[descendant];
				tab[descendant] = tab[montant];
				tab[montant] = tmp;
			}
		}

		if(compare(tab[x],tab[descendant])>0){
			tmp = tab[x];
			tab [x]=tab[descendant];
			tab[descendant] = tmp;
		}

		quicksort_int(tab,descendant);
		quicksort_int(tab+descendant+1,nelem-descendant-1); 
	}	
}

