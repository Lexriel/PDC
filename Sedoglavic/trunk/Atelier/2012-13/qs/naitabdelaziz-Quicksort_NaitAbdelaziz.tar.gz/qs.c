#include <stdlib.h>
#include <stdio.h>
#include "qs.h" 

/**Fonction de comparaison de deux entiers**/
int int_comparer(const void* a,const void* b)
{
	int _a = *((int*) a);
	int _b = *((int*) b);
	return (_a - _b);
}

/**QuickSort Générique**/
void 
qs
(void *base, int nelem, int size,int(*compar)(const void *, const void *))
{
	/**Un tableau à un élement est déja trié**/
	if(nelem>1){
		int montant;
		int descendant;
		int x=0;
		unsigned i;
		montant=1;
		descendant=nelem-1;

		while(montant<descendant)
		{
			while(compar(((char*)base)+montant*size,((char*)base)+x*size)<0 && montant<nelem)
				montant++;
			while(compar(((char*)base)+x*size,((char*)base)+descendant*size)<=0 && descendant>0)
				descendant--;
			if(montant<descendant)
			{
				/**On cast base en char* pour pouvoir lire et ecrire dedans octet par octet**/
				char * tmp	= (char*) malloc(size);
				char * dsc = (((char*)base)+descendant*size);
				char* mnt = (((char*)base)+montant*size);
				for(i = 0;i<size;i++)
				{
					tmp[i] = dsc[i];
					dsc[i] = mnt[i];
					mnt[i] = tmp[i];
				}
				free(tmp);
			}
		}
		if(compar(((char*)base)+x*size,((char*)base)+descendant*size)>0)
		{
			char* tmp = (char*)malloc(size);
			char* dsc = (((char*)base)+descendant*size);
			char* pivot = (((char*)base)+x*size);
			for(i = 0;i<size;i++)
			{
				tmp[i] = pivot[i];
				pivot[i] = dsc[i];
				dsc[i] = tmp[i];
			}
			free(tmp);
		}
		qs(base,descendant,size,compar);
		qs(((char*)base)+(descendant+1)*size,nelem-descendant-1,size,compar); 
	}
}

