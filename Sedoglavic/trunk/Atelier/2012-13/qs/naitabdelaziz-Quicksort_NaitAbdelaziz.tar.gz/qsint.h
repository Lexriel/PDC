extern int compare (int ,int);
extern void quicksort_int (int[], unsigned int);
