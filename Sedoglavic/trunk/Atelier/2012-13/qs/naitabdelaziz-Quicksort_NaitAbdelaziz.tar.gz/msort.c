#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "qs.h"
#define NMAXLIGNES 100
#define NMAXCHAR 81

int 
readl 
(char *line) 
{
	unsigned int i;
	i=0;
	if(fgets(line,NMAXCHAR,stdin)==NULL)
		return EOF;
	while(i<NMAXCHAR && line[i]!=EOF && line[i]!='\0'){
		i++;
	}
	
	return i-1;
}



/**type ligne_t : structure représentant une ligne**/
typedef struct {
	char buffer[NMAXCHAR+1];
} ligne_t;


/**Fonction de comparaison de deux entiers**/
int mstrcmp(const void* a,const void* b)
{
	return strcmp((char*)a,(char*)b);
}

/**Fonction de comparaison de deux structures représentant deux lignes**/
int cmp(const void * a,const void * b){
	return strcmp(((ligne_t*)a)->buffer,((ligne_t*)b)->buffer);
}


/**Fonction d'affichage d'un tableau de ligne_t**/
void 
afficher
(ligne_t tab[], unsigned int nbLignes)
{
	unsigned int i;	
	for(i=0;i<nbLignes;i++){
		printf("%s",tab[i].buffer);
	}
	return;
} 




int
main
(void){
	unsigned int cpt,nbChar;
	cpt=0;
	ligne_t ligne[NMAXLIGNES];
	while((nbChar=readl(ligne[cpt].buffer))!=EOF){
		/*printf("\nNombre de caracteres pour la ligne %d : %d",cpt+1,nbChar);*/
		if(nbChar>79){
			printf("Le nombre de caractères de la ligne %d est trop grand",cpt);
			exit(1);
		}
		cpt++;
	}
	printf("\n");
	qs((void*)ligne,cpt,(NMAXCHAR+1)*sizeof(char),cmp);
	afficher(ligne,cpt);
	return 0;
}
