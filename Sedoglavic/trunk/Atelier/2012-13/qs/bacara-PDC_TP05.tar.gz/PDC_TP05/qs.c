#include "qs.h"

void combsort(void *base, int nelem, size_t size, int(*compar)(const void *, const void*));
void memorySwap(void *pva, void *pvb, size_t n);
int getNewGap(int gap);

void
quicksort(void *base, int nelem, size_t size, int(*compar)(const void *, const void *)) {
  char *base_first; /* Pointe le premier element de "base" */
  char *base_last; /* Pointe le dernier element de "base" */
  char *pivot;
  char *montant;
  char *descendant;
  int tmp;  
  /*
  if (nelem <= 35) {
    insertionsort(base, nelem, size, compar);
    return;
  }  
  */
  /* Initialisation des pointeurs */
  base_first = base;
  base_last = base_first + ((nelem - 1) * size);
  pivot = base_first;
  montant = base_first + size;
  descendant = base_last;

  /* Tant que les pointeurs montant et descendant ne se sont pas croises ... */
  while (montant < descendant) {
    /* Incrementation du pointeur montant tant qu'il ne depasse pas le tableau
     * et que la valeur reference est inferieure ou egale a la valeur pivot */
    while (montant < base_last && compar(montant, pivot) < 0)
      montant = montant + size;
    /* Decrementation du pointeur descendant tant qu'il ne depasse pas le tableau
     * et que la valeur reference est superieure a la valeur pivot */
    while (descendant > base_first && compar(pivot, descendant) <= 0)
      descendant = descendant - size;
    
    /* Si les pointeurs se sont croises, arret de la boucle */
    if (montant >= descendant)
      break;
    
    /* Echange des donnees contenues dans les zones memoires pointees par montant et descendant */
    memorySwap(montant, descendant, size);

    /* Cas particulier : si le pivot et le montant pointaient la meme adresse, mise a jour du pivot */
    if (montant == pivot)
      pivot = descendant;     
  }
  
  /* Echange des donnes contenues dans les zones memoires pointees par pivot et descendant */
  memorySwap(pivot, descendant, size);
  
  /* Si le premier sous-tableau contient plus d'un element, appel recursif */
  if ((tmp = (descendant - base_first) / size) > 1)
    quicksort(base_first, tmp, size, compar); 
  
  /* Si le deuxieme sous-tableau contient plus d'un element, appel recursif */    
  if ((tmp = (base_last - descendant) / size) > 1)
    quicksort(descendant + size, tmp, size, compar);  
}

void
combsort(void * base, int nelem, size_t size, int (*compar)(const void *, const void *)) {
  char * base_first;
  char * base_last;
  char * current;
  char * next;

  char * gap_limit;
  int gap;
  char swap;

  base_first = base;
  base_last = base_first + ((nelem - 1) * size);
  gap = nelem;

  do {
    swap = 0;
    gap = getNewGap(gap);

    gap_limit = base_last - (gap * size);
    for (current = base_first; current <= gap_limit; current += size) {
      next = current + (gap * size);
      if (compar(current, next) > 0) {
	memorySwap(current, next, size);
	swap = 1;
      }
    } 
    
  } while (swap);
}

void
memorySwap(void *pva, void *pvb, size_t n) {
  char *pa;
  char *pb;
  char tmp;

  pa = pva;
  pb = pvb;

  while (n--) {
    tmp = *pa;
    *pa = *pb;
    *pb = tmp;
    pa++;
    pb++;
  }
}

int getNewGap(int gap) {
  gap = (gap * 10) / 13;
  if (gap == 9 || gap == 10)
    return 11;
  if (gap < 1)
    return 1;
  return gap;
}
