#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "qs.h"
#include "readl.h"

#define NMAXLINE 200
#define NMAXCHAR 81

typedef struct InputData InputData;
struct InputData {
  int data_c;
  char data_v[NMAXLINE][NMAXCHAR];
};

InputData
readStdIn() {
  InputData data; /* Structure de retour */
  char buffer[NMAXCHAR]; /* Tampon de lecture */
  int flag; /* Flag de lecture */
  
  int char_c; /* Compteur de caracteres */
  
  data.data_c = 0;
  flag = 0;

  /* Faire ... */
  do {
    /* Lecture de la ligne */
    flag = readl(buffer);    
    /* Gestion cas particulier */
    if (flag == EOF && !buffer[0]) 
      break;
    /* Copie du tampon vers la structure de donnees */
    char_c = 0;
    while ((data.data_v[data.data_c][char_c++] = buffer[char_c]));

  } while (++data.data_c < NMAXLINE && flag != EOF); 
  /* .. tant que le maximum de lignes n'est pas atteint, et que le flux n'est pas fini. */
  
  if (data.data_c == NMAXLINE) {
    fprintf(stderr, "Le fichier contient trop de lignes !\n");
    exit(EXIT_FAILURE);
  }

  return data;
}

int
compareTo(const void * pva, const void * pvb) {
  return strcmp((char *)pva, (char *)pvb);
}

int
main(int argc, char * argv[]) {
  InputData data;
  int i;
  
  data = readStdIn();
  quicksort(data.data_v, data.data_c, NMAXCHAR, &compareTo);
  
  for (i = 0; i < data.data_c; i++)
    printf("%s\n", data.data_v[i]);

  return 0;
}
