#include <stdio.h>
#include <stdlib.h>

#include "qsint.h"

#define TABSIZE 1000
#define RAND_RANGE 10000

int
main(int argc, char * argv[]) {  
  int tab[TABSIZE];
  int i;
  
  srand(time(NULL));
  printf("\n##### CREATION ET AFFECTATION DE VALEURS ALEATOIRES AU TABLEAU #####\n\n");
  for (i = 0; i < TABSIZE; i++) {
    tab[i] = rand() % RAND_RANGE;
    printf("%i\t", tab[i]);
  }
  printf("\n\n####################################################################\n");
  
  quicksort_int(tab, TABSIZE);

  printf("\n##### TABLEAU POST-QUICKSORT #####\n\n");
  for (i = 0; i < TABSIZE; i++) 
    printf("%i\t", tab[i]);
  printf("\n\n##################################\n");

  printf("\n##### VERIFICATION DES VALEURS DU TABLEAU #####\n\n");
  for (i = 0; i < TABSIZE - 1; i++) {
    if (tab[i] > tab[i + 1])
      printf("ERR: Element %i (%i) -- superieur a l'element %i (%i).\n", i, tab[i], i + 1, tab[i + 1]);
  }

  printf("Fin de la verification\n");
  printf("\n###############################################\n\n");
  
  return 0;
}
