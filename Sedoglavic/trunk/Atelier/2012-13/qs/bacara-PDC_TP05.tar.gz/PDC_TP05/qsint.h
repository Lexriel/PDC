#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define PTR_LAST tab+(nelem-1)
extern void quicksort_int(int tab[], unsigned int nelem);
extern int f(int x, int y);

