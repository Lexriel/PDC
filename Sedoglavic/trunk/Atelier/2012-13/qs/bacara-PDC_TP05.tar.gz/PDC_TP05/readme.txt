Commandes makefile:

- make all: Compile qsint_tst et msort
- make qsint_tst: Compile le programme de test de la bibliothèque qsint.c
- make msort: Compile le programme msort avec la bibliothèque qs.c
- make msort-test: Compile msort et appelle le script de test

L'ensemble des fonctionnalités demandées sont implémentées. Le tri msort n'accepte que NMAXLINE de NMAXCHAR au maximum (par défaut, 200 et 81).
