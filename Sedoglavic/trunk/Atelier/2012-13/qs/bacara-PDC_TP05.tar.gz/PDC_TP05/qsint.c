#include "qsint.h"

void
quicksort_int(int tab[], unsigned int nelem) {
  int * pivot; /* Pointeur sur le pivot */
  int * montant; /* Pointeur montant */
  int * descendant; /* Pointeur descendant */
  int tmp; /* Tampon pour les echanges de valeurs */

  /* Choix du pivot et initialisation des pointeurs montant et descendant */
  pivot = tab;
  montant = tab;
  descendant = PTR_LAST;

  /* Tant que montant est inferieur a descendant ... */
  while (montant < descendant) {
    /* Incrementation de montant tant que l'element mont reference est tel que f(mont,pivot) <= 0 */
    while (montant < PTR_LAST && f(*montant, *pivot) <= 0) 
      montant++;
    /* Decrementation de descendant tant que l'element desc reference est tel que f(pivot,desc) < 0 */
    while (descendant > tab && f(*pivot, *descendant) < 0)      
      descendant--;
    
    /* Arret de la boucle si les pointeurs se sont croises */
    if (montant >= descendant)
      break;

    /* Echange des valeurs referencees par montant et descendant */
    tmp = *montant;
    tab[montant - tab] = *descendant;
    tab[descendant - tab] = tmp;

    /* Cas particulier: si le pivot a ete echange, il faut mettre a jour le pointeur vers la bonne adresse */
    if(montant == pivot)
      pivot = descendant;    
  }

  /* Echange du descendant et du pivot */
  tmp = *pivot;
  tab[pivot - tab] = *descendant;
  tab[descendant - tab] = tmp;  
  
  /* Si le premier sous-tableau contient plus d'un element, appel recursif */
  tmp = descendant - tab;
  if (tmp > 1)
    quicksort_int(tab, tmp);
  /* Si le deuxieme sous-tableau contient plus d'un element, appel recursif */
  tmp = PTR_LAST - descendant;
  if (tmp > 1)
    quicksort_int(descendant + 1, tmp);  
}

int
f(int x, int y) {
  if (x == y)
    return 0;
  if (x > y)
    return 1;
  return -1;
}
