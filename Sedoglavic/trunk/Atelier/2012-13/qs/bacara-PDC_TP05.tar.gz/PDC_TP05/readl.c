#include "readl.h"

int
readl(char line[]) {
  int i;
  char c;

  for (i = 0, c = EOF; i < NMAXCHAR; i++) {
    c = getchar();
    
    if (c == EOF) {
      line[i] = '\0';
      return EOF;
    }
    else if (c == '\n') {
      line[i] = '\0';
      return i;
    }
    else {
      line[i] = c;
    }
    
  }
  
  if (i >= NMAXCHAR) {
    fprintf(stderr, "One line contains more than %i characters !\n", NMAXCHAR);
    exit(EXIT_FAILURE);
  }

  return -1;
}
