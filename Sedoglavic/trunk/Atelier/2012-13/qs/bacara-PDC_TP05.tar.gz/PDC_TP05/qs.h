#include <stdlib.h>

extern void quicksort(void * base, int nelem, size_t size, int(*compar)(const void *, const void *));
