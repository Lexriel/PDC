#include <stdio.h>
#include <stdlib.h>

#define NMAXCHAR 81

extern int readl(char line[]);
