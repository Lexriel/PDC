#!/bin/sh
SEPARATOR=--------------------------------------------------------------------------------

echo $SEPARATOR
echo "TEST #1: Fichier valide"
echo $SEPARATOR
./msort < msort-test_noerr.txt

echo $SEPARATOR
echo "TEST #2: Fichier invalide -- Ligne de plus de 80 caracteres"
echo $SEPARATOR
./msort < msort-test_tooMuchChar.txt

echo $SEPARATOR
echo "TEST #3: Fichier invalide -- Trop de lignes"
echo $SEPARATOR
./msort < msort-test_tooMuchLine.txt

echo $SEPARATOR
exit 0;
