/*nom : Grahek*/
/*prenom : Kevin*/

#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>

#define TABSIZE 1000


/*echange deux element dans le tableau tab au indices i et j*/
void
echanger
(int tab[], int i, int j)
{
  int memoire;
  memoire=tab[i];
  tab[i]=tab[j];
  tab[j]=memoire;
}
/*choisit comme pivot le premier element en indice debut*/
/*deplace a la bonne postion le pivot et renvoi l indice de ce pivot*/
/*parametre tab le tableau , debut indice ou commence la fonction , fin indice ou finit la fonction*/
int
partionner
(int tab[],int debut,int fin) {
  int i;
  int pivot=tab[debut];
  for (i = 1; i < fin; i++)
    {
      if (pivot>tab[i]) {
	echanger(tab,debut,i);
	debut++;
	echanger(tab,i,debut);
      }
    }
  return debut;
}


/*tri du tableau tab qui est composé de nelem element*/
void
quicksort_int
(int tab[], unsigned int nelem)
{
  int pivot;
  if (nelem>1)
    { 
      pivot=partionner(tab,0,nelem);
      quicksort_int(tab,pivot);
      quicksort_int(tab+(pivot+1),nelem-(pivot+1));
    }
  
}


int
main
(void)
{
  int i;
  int tableau[]={3,4,1,5,2,0};
  printf("tableau avant premutation \n");
  for(i=0;i<5;i++)
    {
      printf("%i,",*(tableau+i));
    }
  quicksort_int(tableau,5);
  /*i=partionner(tableau,0,5);*/
  /* printf("\n %i tableau apres permutation \n",i); */
  for(i=0;i<5;i++)
    {
      printf("%i,",tableau[i]);
    }
  printf("\n appuyez sur une touche pour terminer le programme");
  return 0;
}
