Nom : Grahek
Prenom : Kevin
quicksort_int terminé
quicksort general non fonctionnelle.
pour compiler :make
