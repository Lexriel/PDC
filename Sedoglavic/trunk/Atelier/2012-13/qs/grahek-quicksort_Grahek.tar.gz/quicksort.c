#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TABSIZE 1000

/* echange deux element  */
/* a pointeur sur le premier element */
/* b pointeur sur le deuxieme element */
/* n la taille d un element */
void
echanger
(void *a,void *b,int n)
{ 
  int i;
  char tmp;
  for (i=0;i < n;i++)
  {
    tmp=*(((char *) a)+i);
    *(((char *) a)+ i)=*(((char *)b)+i);
    *(((char *) b)+ i)=tmp;
  }
}

/* partitionne un tableau en choississant comme pivot le premier element */
int 
partionner
(void *tab,int debut,int fin,int size,int(*compar)(const void *, const void *)) {
  int i;
  char *pivot=(((char *)tab)+debut);
  for (i = 1; i < fin; i++)
    {
      if (compar(pivot,(((char *)tab)+(i)))>0) {
	echanger(((char *)(tab)+debut),((char *)(tab)+(i)),size);
	debut++;
	echanger(((char *)(tab)+i),((char *)(tab)+debut),size);
      }
    }
  return debut;
}

/*tri rapide */
/*parametre*/
/*base :pointeur sur la structure a trie*/
/*nelem :nombre d element de la structure*/
/*size : taille d un element de la structure*/
/*compar : lafonction de comparaison*/
void
quicksort
(void *base, int nelem, int size,int(*compar)(const void *, const void *))
{
  int pivot;
  if (nelem>1)
    { 
      pivot=partionner(base,0,nelem,size,compar);
      quicksort(base,pivot,size,compar);
      quicksort(((int *) base)+(pivot+1),(nelem-(pivot+1)),size,compar);
    }  
}



/*compare deux element par leur pointeur*/
int compare (const void *a, const void *b) {
  const char *str1 = *((const char **)(a));
  const char *str2 = *((const char **)(b));
  return strcmp (str1, str2);
}


int
main
(void)
{
  int i;
  char *tableau[]={"zzz","fff","bbb","bbh","ggg","ooo"};
  printf("tableau avant premutation \n");
  for(i=0;i<6;i++)
    {
      printf("%s,",*(tableau+i));
    }


  quicksort(tableau,6,sizeof(char),compare);
  for(i=0;i<6;i++)
    {
      printf("%s,",tableau[i]);
    }
  printf("\n appuyez sur une touche pour terminer le programme\n");
  return 0;
}
