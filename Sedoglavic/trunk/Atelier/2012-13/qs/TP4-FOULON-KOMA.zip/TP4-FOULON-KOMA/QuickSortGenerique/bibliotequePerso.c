#include <stdio.h>
#include "bibliotequePerso.h"

int fonctionCompart (const void * element1, const void * element2){
	
	
	int membre1 = *((int *) element1);
	int membre2 = *((int *) element2);

		if(membre1 > membre2){
				
				return 1;
			}
		else if(membre1 == membre2){
				
				return 0;
			}
		else{
				return -1;
		}
	
		
	
	}