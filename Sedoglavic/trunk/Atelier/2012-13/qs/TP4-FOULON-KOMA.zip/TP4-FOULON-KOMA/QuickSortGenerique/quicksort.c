#include <stdio.h>
#include <stdlib.h>
#include "bibliotequePerso.h"

void quicksort(void *base, int nelem, int size,int(*compar)(const void *, const void *)){
               	
              int montant = 1;
			  int descendant = nelem - 1;
			  char tmp;
			  char * tab ;
			  
			  tab = (char *) base ;

if(nelem > 1){


	while(1){
		/* tans que tab+descendant*size est plus grand que tab, soit dit autrement, tans que tab+descendant*size n est pas plus petit ou egale a tab */
			
			while(((*compar)((tab+descendant*size),(tab)) == 1) && (descendant > 0)){
					descendant --;
				}
			
		/* tans que tab+montant*size est plus petit que tab, soit dit autrement, tans que tab+montant*size n est pas plus grand ou egale a tab */
						
			while(((*compar)((tab+montant*size),(tab)) == -1) && (montant < nelem)){
					montant++;
				}
			
		/* Si descendant est superieur a montant, c est que il ne se sont pas encore croiser */
		/* On invese alors les deux , mais uniquement si tab[descendant] est plus grand que tab[montant]*/
		if( descendant > montant ){
			
				tmp = *(tab+descendant*size);
				*(tab+descendant*size) = *(tab+montant*size);
				*(tab+montant*size) = tmp;
		
		}
			
		/* Si descendant est inferieur a montant, c est que il se sont croiser */
		/* On invese alors descendant et pivot */
		if( descendant <= montant ){
				
				tmp = *(tab+descendant*size);
				*(tab+descendant*size) = *tab;
				*tab = tmp;
				break;
			}	
		}
		
		
		/* on envoie le coter gauche du pivot, c est a dire tab , avec le nombre d element contenu par descendant car c est la fin du prochain tableau */
		quicksort( tab , descendant , size , compar);
		/* on envoie le coter droit du tableau , c est a dire tab plus le nombre d element qui sont a gauche de descendant + descendant lui meme */
		quicksort( tab + (( descendant + 1 )*size) , ( nelem - ( descendant + 1 ) ) , size ,compar);

	}	
}
	
int main(){
	
	int taille = 11;
	int boucle = taille;
	int i;
	int tab[] = {11 , 21 , 15 , 19 , 16 , 2 , 10 , 28 , 2 , 4 , 21};
	int (*pointeurSurFonction)(const void * element1, const void *element2); 
	
	pointeurSurFonction = fonctionCompart;         
	
	for(i=0 ; i < boucle ; i++){
		printf(" %d ",tab[i]);
		}
	printf("\n");
	
	
	quicksort(tab,taille,sizeof(int),pointeurSurFonction);
	
	
	for(i=0 ; i < boucle ; i++){
		printf(" %d ",tab[i]);
		}
	printf("\n");
	
	return 0;
	}	