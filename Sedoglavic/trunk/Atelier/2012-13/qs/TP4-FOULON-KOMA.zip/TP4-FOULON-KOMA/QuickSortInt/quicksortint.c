#include <stdio.h>
#include <stdlib.h>

void quicksort_int(int tab[], unsigned int nelem){
	
	
	int montant = 1;
	int descendant = nelem - 1;
	int tmp;
if(nelem > 1){


	while(1){
		/* on descend jusqu'a ce que tab[descendant] soit plus petit que tab[0] */
			while((tab[descendant] >= tab[0]) && (descendant > 0)){
					descendant --;
				}
			
		/* on monte jusqu'a ce que tab[montant] soit plus grand que tab[0] */
			while( (tab[montant] <= tab[0]) && (montant < nelem)){
					montant++;
				}
			
		/* Si descendant est superieur a montant, c est que il ne se sont pas encore croiser */
		/* On invese alors les deux , mais uniquement si tab[descendant] est plus grand que tab[montant]*/
		if( descendant > montant ){
				tmp = tab[descendant];
				tab[descendant] = tab[montant];
				tab[montant] = tmp;
			}
			
		/* Si descendant est inferieur a montant, c est que il se sont croiser */
		/* On invese alors descendant et pivot */
		if( descendant < montant ){
				tmp = tab[descendant];
				tab[descendant] = tab[0];
				tab[0] = tmp;
				break;
			}	
		}
		
		
		/* on envoie le coter gauche du pivot, c est a dire tab , avec le nombre d element contenu par descendant car c est la fin du prochain tableau */
		quicksort_int( tab , descendant);
		/* on envoie le coter droit du tableau , c est a dire tab plus le nombre d element qui sont a gauche de descendant + descendant lui meme */
		quicksort_int( tab + ( descendant + 1 ) , ( nelem - ( descendant + 1 ) ));

}	
}
	
int main(){
	
	int taille = 11;
	int boucle = taille;
	int i;
	int tab[] = {11 , 21 , 15 , 19 , 16 , 2 , 10 , 28 , 2 , 4 , 21};
	
	for(i=0 ; i < boucle ; i++){
		printf(" %d ",tab[i]);
		}
	printf("\n");
	
	quicksort_int(tab,taille);
	
	
	for(i=0 ; i < boucle ; i++){
		printf(" %d ",tab[i]);
		}
	printf("\n");
	
	return 0;
	}	
