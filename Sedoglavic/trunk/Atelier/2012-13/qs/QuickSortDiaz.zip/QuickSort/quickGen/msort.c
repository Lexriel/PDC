#include "readl.h"
#include "qs.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define MAXLINE 10
#define MAXCHAR 81
/*
	Ajoute la ligne lue au tableau a trié.
*/
void affichage(char * tab,int size)
{
	int i=0,ligne=0;
	for(i=0;i<size;i++)
	{
		ligne++;
		printf ("%c",tab[i]);
	}
}
void ajoutligne(char * tab,const char * ligne)
{
	int i=0;
	for(i=0;i<MAXCHAR;i++)
		*(tab+i)=*(ligne+i);
}
int main(int argc, char *argv[])
{
	int size=MAXLINE*MAXCHAR;
	int ligne=1;
	char *tab=malloc(MAXLINE*MAXCHAR);
	char *lignelue=malloc(MAXCHAR);
	while(1)
	{
		if(readl(lignelue)>0)
			ajoutligne(tab+((ligne-1)*MAXCHAR),lignelue);
		/*
			sil'on as lue MAXLINE ligne alors c'est la dernier ligne àlire dans se cas on  sort de la boucle
		*/
		if(ligne == MAXLINE)
		{
			break;
		}
		ligne++;
	}
	free(lignelue);
	quicksort(tab,MAXLINE,MAXCHAR,&comparstring);
	printf("%s\n\n","range");
	affichage(tab,size); 
	free(tab);
	return 1;
}


