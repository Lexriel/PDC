#include <stdlib.h>
#include <stdio.h>
#include <string.h>
/*
	Fonction permettant l'echange des donnees
*/
/*
	Comparaison de string.
*/
int comparstring(const void * a,const void * b)
{
	return strcmp((char *)a,(char *)b);
}
/*
	Comparaison d'entier.
*/
int comparint(const void * a,const void * b)
{
	return *(const int *)a-*(const int *)b;
}
/*
	Comparaison de char.
*/
int comparchar(const void * a,const void * b)
{
	return *(const char *)a-*(const char *)b;
}
void mmemcpy(void * a, void *b, int size)
{
  	char tmp,*aa,*bb ;
  	aa = (char *) a ;
  	bb = (char *) b ;
  	for(; size>0 ;size--) 
  	{
      	tmp = *aa;
      	*aa = *bb ;
      	*bb = tmp ;
		aa++;
		bb++ ;
	}
}
void quicksort(void* base, int nmemb, int size, int(*compar)(const void*, const void*))
{ 
	char* montant;
	char* descendant;
	char* pivot;
	pivot = (char *)base;
	montant = (char *)base+size;
	descendant = (char *)base+((nmemb-1)*size);
	
	/*
		Si il y as moins de deux elements alors on as rien a faire.
	*/
	if( nmemb < 2)
        return;
     /*
     	Si l'on as deux elements l'on vérifie que les deux sont bien ordonné sinon on les echanges de places et on quitte.
	*/
	if(nmemb==2)
	{
		if(compar(pivot,pivot+size)>0)
			mmemcpy(pivot, pivot+size, size);
		return ;
	}
	while(1)
	{
    	/*
    		tant que montant est inferieur au pivot l'on passe au suivant, tous en fessant attention de ne pas sortir du tableau.
    	*/
		while ((compar(montant,pivot)<=0) && (montant < pivot + nmemb*size))
	 		montant=montant+size;
		/*
			tant que descendant est superieur au pivot on passe a l'element du tableau le precedent, tous en fessant attention 
			de ne pas sortir du tableau.
		*/	  
		while (compar(descendant,pivot)>0 && (descendant >= (char *)base ))
			descendant=descendant-size; 
		/*
			Si montant est inferieur au pivot descendant alors on echange leur valeur.
		*/	
      	if (compar(montant,descendant)<0) 
	 	mmemcpy(montant,descendant,size);
		/*
			Dans le cas ou le pivot montant est superieur a celui qui descend on les echanges et on sort de la boucle.
		*/	
      	if (compar(montant,descendant)>=0)
		{
			mmemcpy(pivot,descendant,size);
	 		break; 
		}
			return; 
	}
	quicksort(base, ((char*)descendant - (char*)base)/size,size, compar);
	quicksort(descendant+size,((nmemb*size)-((char *)descendant-(char *)base))-1,size, compar);
}
