#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tools.h"
#define MAXCHAR 81

int readl(char line[])
{
	
     int compt = strlen(line);
	if(compt < MAXCHAR)
	{
	/*
		si fgets renvoie null alors on as rien lue donc on return 0 pour signalé qu'on as un eof
	*/
	  if(fgets(line,MAXCHAR,stdin)!=NULL)
	       return compt;
	  else
	 	 return 0;
	}
	else
	{
	/*
		si la chaine est trop grande on retourne -1 pour signalé une erreur.
	*/
		return -1;
	}
     

}
