int readl(char line[]);
