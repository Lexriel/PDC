#include "qsint.h"
int main(void)
{
    int tab[TABSIZE];
    int i; 
	srand(time(NULL));
    for(i = 0; i < TABSIZE; i++)
    {
		tab[i]=rand()%(199);
    }
    quicksort_int(tab,TABSIZE);
    affichage(tab,TABSIZE);
    return 0;
}

