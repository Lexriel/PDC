#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define TABSIZE 30
void swap(int *a, int *b);
void quicksort_int(int tableau[],unsigned int taille);
void  affichage(int *t, int taille);

