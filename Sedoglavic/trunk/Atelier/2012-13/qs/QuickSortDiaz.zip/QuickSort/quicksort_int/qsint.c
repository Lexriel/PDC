#include "qsint.h"
#define TABtaille 30
/*
	Fonction permettant d'échangé les données du tableaux
*/

void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}
/*
	Affichage du tableau.
*/
void  affichage(int *t, int taille)
{
  int i=0;
  for (i=0;i<taille;i++)
    printf("%d\t",t[i]);
  printf("\n");
}
void quicksort_int(int tab[], unsigned int taille)
{
    int *montant; 
    int *descendant;
    int *pivot;
	pivot = tab;
	montant = tab+1;
	descendant = tab+(taille-1);
    /* Si le tableau est de longueur nulle, il n'y a rien à faire. */
    if( taille < 2)
        return;
     /*
     	Si l'on as deux elements l'on vérifie que les deux sont bien ordonné sinon on les echanges de places et on quitte.
     */
	if(taille==2)
	{
		if(tab[0]> tab[1])
			swap(tab,tab+1);
		return;
	}
	while(1)
    {
    	/*
    		tant que montant est inferieur au pivot l'on passe au suivant, tous en fessant attention de ne pas sortir du tableau.
    	*/
		while ((*montant<=*pivot) && (montant < tab+taille) )
	  		montant ++;
		/*
			tant que descendant est superieur au pivot on passe a l'element du tableau le precedent, tous en fessant attention 
			de ne pas sortir du tableau.
		*/	  
		while ((*descendant >*pivot) && (descendant >= tab ))
			descendant --; 
		/*
			Si montant est inferieur au pivot descendant alors on echange leur valeur.
		*/	
      	if (montant < descendant) 
	 		swap(montant,descendant);
		/*
			Dans le cas ou le pivot montant est superieur a celui qui descend on les echanges et on sort de la boucle.
		*/	
      	if (montant >= descendant)
		{
	  		swap(pivot,descendant);
	 		break; 
		} 
    } 
	quicksort_int(tab,descendant-tab);
	quicksort_int(descendant+1,taille-(descendant-tab)-1) ;
}

