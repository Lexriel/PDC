Archive cree par DIAZ Jeremy.
Dans le dossier quicksort_int vous pourrez trouvé le quicksort d'entier avec son makefile.
Dans le dossier quickGen vous pourrez trouvé l'indentation de la fonction msort avec sont makefile.
Malheuresement je n'arrive pas à reglé l'erreur de segmentation
