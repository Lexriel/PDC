#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <limits.h>

#include "qsint.h"
#include "qs.h"

#define TABSIZE 20

int f2(int *a, int *b)
{
    return *a - *b;
}

int main(void)
{
    int i = 0;
    int *tab = NULL;
    srand((unsigned int)time(NULL));
    tab = (int*)malloc(TABSIZE * sizeof(int));
    if (!tab)
    {
        perror("malloc");
        return 1;
    }
    puts("Int sort:");
    for (i = 0; i < TABSIZE; ++i)
    {
        tab[i] = rand()%TABSIZE;
        printf(" %d ", tab[i]);
    }
    puts("");
    quicksort_int(tab, TABSIZE);
    for (i = 0; i < TABSIZE; ++i)
    {
        printf(" %d ", tab[i]);
    }
    puts("");
    puts("Generic sort:");
    for (i = 0; i < TABSIZE; ++i)
    {
        tab[i] = rand() % TABSIZE;
        printf(" %d ", tab[i]);
    }
    puts("");
    quicksort(tab, TABSIZE, sizeof(int), (int(*)(const void*, const void*))(f2));
    for (i = 0; i < TABSIZE; ++i)
    {
        printf(" %d ", tab[i]);
    }
    puts("");
    return 0;
}
