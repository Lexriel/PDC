#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int f(int a, int b)
{
    if (a == b)
        return 0;
    if (a > b)
        return 1;
    else
        return -1;
}

void quicksort_int(int tab[], unsigned int nelemen)
{
    int *x = &tab[0];
    int *montant, *descendant;
    int t =0;
    montant = &tab[0];
    descendant = &tab[nelemen-1];
    //printf("#%p %p %p %d\n", montant, descendant, x, nelemen);
    if (nelemen > 1)
    {
        while (montant < descendant)
        {
            while (montant<descendant && f(*montant, *x) < 0)
            {
                ++montant;
            }
            while (montant<descendant && f(*x, *descendant) <= 0)
            {
                --descendant;
            }
            //printf("%p %p\n", montant, descendant);
            if(montant< descendant){
                if(x==tab){
                    x=descendant;
                }
                t = *montant;
                *montant = *descendant;
                *descendant = t;
            }
        }
        t = *x;
        *x = *descendant;
        *descendant = t;
        //printf("==%p %p %d %d\n", montant, descendant, descendant - tab, &tab[nelemen-1]-descendant);
        //puts("1");
        quicksort_int(tab, descendant - tab);
        //puts("2");
        quicksort_int(descendant+1, &tab[nelemen-1]-descendant);
    }
}

