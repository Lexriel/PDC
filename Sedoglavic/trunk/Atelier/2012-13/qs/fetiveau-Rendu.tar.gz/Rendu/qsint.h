#ifndef QSINT_H
#define QSINT_H

void quicksort_int(int tab[], unsigned int nelemen);
#endif
