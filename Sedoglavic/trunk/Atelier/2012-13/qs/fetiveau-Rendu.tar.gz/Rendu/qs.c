#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void swap(void *a, void *b, int size)
{
    char *tmp = (char*)malloc(size);
    memcpy(tmp, a, size);
    memcpy(a, b, size);
    memcpy(b, tmp, size);
}

void quicksort(void *tab, int nelemen, int size, int(*compar)(const void *, const void*))
{
    char *x = (char*)tab;
    char *t = (char*)malloc(size);
    char *montant, *descendant;
    montant = (char*)tab;
    descendant = ((char*)tab)+nelemen*size-1*size;
    //printf("#%p %p %p %d\n", montant, descendant, x, nelemen);
    if ((int)nelemen <= 1)
        return;
    while (montant < descendant)
    {
        while (montant < descendant && compar(montant, x) < 0)
            montant+=size;
        while (montant < descendant && compar(x, descendant) <= 0)
            descendant-=size;
        //printf("%p %p\n", montant, descendant);
        if (montant < descendant)
        {
            if (x == tab)
                x = descendant;
            swap(descendant, montant, size);
        }
    }
    *t = *x;
    *x = *descendant;
    *descendant = *t;

    //printf("==%p %p %d %d\n", montant, descendant, ((char*)descendant - (char*)tab)/size, (((char*)tab+nelemen*size-size)-descendant));
    //puts("1");
    quicksort((void*)tab, (descendant - (char*)tab)/size, size, compar);
    //puts("2");
    quicksort((void*)(descendant + size), (((char*)tab + nelemen*size - 1*size) - descendant)/size, size, compar); 
}

