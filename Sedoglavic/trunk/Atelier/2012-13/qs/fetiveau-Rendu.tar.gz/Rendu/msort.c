#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "qs.h"

#define NMAXLINE 4
#define NMAXCHAR 10
#define TABSIZE NMAXLINE

int main(int argc, char **argv)
{
    char *line = NULL;
    char **file = (char**)malloc(NMAXLINE*sizeof(void*));
    int i = 0;
    unsigned lineno = 0;
    if (!file)
    {
        perror("malloc");
        return 1;
    }
    for (i = 0; i < NMAXLINE; ++i)
    {
        file[i] = (char*)calloc(NMAXCHAR, sizeof(char));
        if (!file[i])
        {
            perror("malloc");
            return 1;
        }
    }
    line = (char*)calloc(NMAXCHAR, sizeof(char));
    while (lineno < NMAXLINE && fgets(line, NMAXCHAR, stdin))
    {
        if (line[strlen(line) - 1] != '\n')
        {
            fprintf(stderr, "Line too long\n");
            return 1;
        }
        strncpy(file[lineno], line, NMAXCHAR);
        ++lineno;
    }
    qsort(file, TABSIZE, NMAXCHAR, (int(*)(const void*, const void*))(strcmp));
    for (i= 0; i < NMAXLINE; ++i)
    {
        printf("%c", *file[i]);
    }
    return 0;
}
