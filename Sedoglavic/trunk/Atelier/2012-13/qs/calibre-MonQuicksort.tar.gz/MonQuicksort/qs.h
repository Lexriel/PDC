/* 
 * Théo CALIBRE
 * Clément Hochedez
 * G5
 *
 *
 */


/* la fonction echange les deux valeurs a et b  */ 
void echanger(void *a, void *b, int size)
{
  void *tmp = malloc(size);
  memcpy(tmp,a,size);
  memcpy(a,b,size);
  memcpy(b,tmp,size);
}

/* fonction qui permet de comparer deux adresses d'entier 
 * la fonction retourne 1 si x>y
 * la fonction retourne -1 si x<y
 * retourne 0 si x==y
 */

int comparInt(const void *a, const void *b)
{
  int *aa = (int*) a;
  int *bb = (int*) b;
  if(*aa>*bb) return 1 ;
  else if (*aa<*bb) return (-1);
  else return 0;
}

/* fonction qui permet de comparer deux adresses de caracteres 
 * la fonction retourne 1 si x>y
 * la fonction retourne -1 si x<y
 * retourne 0 si x==y
 */
int comparChar(const void *a, const void *b){
  char *aa = (char*) a;
  char *bb = (char*) b;
  if(*aa>*bb) return 1;
  else if(*aa<*bb) return (-1);
  else return 0;
}


