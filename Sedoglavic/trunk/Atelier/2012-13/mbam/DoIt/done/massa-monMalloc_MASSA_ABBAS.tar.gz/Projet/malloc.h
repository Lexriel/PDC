#define _XOPEN_SOURCE 500
#include <unistd.h>
#include "struct.h"

bloc_t * firstfit (size_t size, bloc_t * liste);
void * malloc (size_t size);
