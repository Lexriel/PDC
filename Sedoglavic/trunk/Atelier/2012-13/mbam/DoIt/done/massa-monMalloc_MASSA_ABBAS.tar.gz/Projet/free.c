#include "free.h"

void insertBloc (bloc_t *ptr,bloc_t *list){
    // S'il y a pas de bloc libre dans list alors list pointe sur ptr
    if (list == NULL){
        list = ptr;
    }else{
        //S'il y a on cherche la meilleur placement pour le bloc à liberer, Le blocs sont triés par ordre croissant des adresses mémoire
        bloc_t *tmp = NULL;
        while (list && (&list) < (&ptr)){
            tmp = list;
            list = (list->suivant);
        }
        //Si on trouve pas un bloc dont l'adresse est plus petit que le notre on l'ajoute au début de la liste
        if (tmp == NULL){
            ptr->suivant = list;
		list = ptr;
        }else{
            //Sinon on l'ajoute à son emplacement
            ptr->suivant = tmp->suivant;
            tmp->suivant = ptr;
        }
        //Si le bloc libéré est adjacent à son prédécesseur alors on fusionne les deux blocs
        if (&tmp == (&ptr - 1)){
            tmp->taille +=  ptr->taille;
            tmp->suivant = ptr->suivant;
            tmp->espaceDispo = (void *) (tmp+2);

        }
        //Si le bloc libére est adjacent avec sont successeur alors on fusionne les deux blocs
        else if (&ptr == (&(ptr->suivant) + 1)){
            ptr->taille +=  (ptr->suivant)->taille;
            ptr->suivant = (ptr->suivant)->suivant;
            ptr->espaceDispo = (void *) (ptr+2);
        }

    }

}


void
free (void *ptr){
    insertBloc(ptr,ListeDesBlocsLibres);

}

