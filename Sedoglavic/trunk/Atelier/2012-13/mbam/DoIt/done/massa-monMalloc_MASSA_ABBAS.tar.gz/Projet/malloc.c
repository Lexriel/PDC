#include "malloc.h"


bloc_t * firstfit (size_t size, bloc_t * liste) {

	bloc_t * tmp = NULL, *ptr ;
	ptr = liste;

	while (ptr && (ptr-> taille) < size) {
		tmp = ptr ;
   		ptr = (ptr->suivant);
   	}

	if(ptr==NULL)
		return NULL ;

	/*Si la taille du bloc est celle recherchee */
	if (ptr->taille == size){
		/* suppression du bloc de la liste , en fesant pointer le bloc precedant sur le suivant*/
		tmp->suivant = ptr->suivant;
		/* on retourne le bloc*/
		return ptr;
	}

	/*Sinon on divive le bloc */
	if(ptr-> taille > size) {

		/* on ajoute lespace libre restant du bloc dans la liste */
		ptr->taille -= size+sizeof(bloc_t);

		/* on retourne le bloc*/
		bloc_t * bloc = (bloc_t *)((char *) ptr->espaceDispo + ptr->taille) ;
   		bloc->taille= size;
   		bloc->suivant = NULL;
   		bloc ->espaceDispo = (void *) (bloc+1) ;
   		return bloc;
   	}

   	return NULL;
}


void *malloc (size_t size)
{

   bloc_t * blocklibre ;
   /* Si on appel malloc pour la premiere fois */
   if (ListeDesBlocsLibres== NULL) {

   	/*on demande à sbrk un gros bloc de memoire*/
   	unsigned int taille = 1<<12;
	bloc_t * debut;
	debut = (bloc_t *) sbrk (taille);
	debut->taille = taille - sizeof(bloc_t) ;
	debut->espaceDispo = (void *)((char*)debut + sizeof(bloc_t)) ;

   	/*on ajoute le bloc de memoire libre à la bam */
   	ListeDesBlocsLibres = debut ;
   }

   blocklibre = firstfit(size, ListeDesBlocsLibres);
   if(blocklibre == NULL)
	   return NULL ;
   return blocklibre->espaceDispo ;
}





