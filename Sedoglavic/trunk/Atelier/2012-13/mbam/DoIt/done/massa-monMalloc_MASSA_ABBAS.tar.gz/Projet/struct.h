#ifndef _STRUCT_H_
#define _STRUCT_H_
struct bloc_s
{
	size_t taille;
	struct bloc_s * suivant;
	void * espaceDispo ;
} ;

typedef struct bloc_s bloc_t;
static bloc_t * ListeDesBlocsLibres ;
#endif
