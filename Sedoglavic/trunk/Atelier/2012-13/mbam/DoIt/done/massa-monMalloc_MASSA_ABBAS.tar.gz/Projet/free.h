#define _XOPEN_SOURCE 500
#include <unistd.h>
#include "struct.h"
void insertBloc (bloc_t *ptr,bloc_t *list);
void free (void *ptr);
