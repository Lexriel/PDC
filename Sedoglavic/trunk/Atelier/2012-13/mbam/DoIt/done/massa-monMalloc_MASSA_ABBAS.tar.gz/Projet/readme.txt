ABBAS Hussein
MASSA Alexis
L3S5 Groupe 5

Nous avons fait malloc et free. 

A la différence de l'énoncé, notre liste chainée est implantée de sorte que le dernier élement pointe sur null.

On a fait ce que l'on a pu, le mecanisme de fonctionnement de la mémoire et les pointeurs nous ont posé pas mal de problèmes.


