#define _XOPEN_SOURCE 500
#include <unistd.h>
#include "struct.h"
#include "malloc.h"
#include "free.h"

int
main
(void)
{
    int *p = malloc(10);
    int *q = malloc(3);
    free(p);
    free(q);
}
