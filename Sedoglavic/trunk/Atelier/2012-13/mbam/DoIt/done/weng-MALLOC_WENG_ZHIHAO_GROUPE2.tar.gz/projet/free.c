void free(void *ptr_bloc){
	struct chaine_s* bloc_free = listeBlocLibre;
	if(!first_call){
		while(bloc_free->suivant->espace != ptr_bloc){
			bloc_free->precedent = bloc_free;
			bloc_free = bloc_free->suivant;
			bloc_free->suivant = bloc_free->suivant->suivant;
		
		}
	}
	/* on va liberer et fusionner les blocs de mémoire de façon recursif */
		
	/*si le bloc precedent n'est pas free*/
	if(bloc_free->precedent->bloc_libre == FALSE){
	
		/*si le bloc suivant n'est pas null et n'est pas free*/
		if(bloc_free->suivant != NULL ){
			if(bloc_free->suivant->bloc_libre == FALSE){
				/* c'est la condition d'arret */
				bloc_free->bloc_libre = TRUE;
				return;
			}
		}
	}	
	/* on fusionne les blocs suivants qui ont ete free */
	if(bloc_free->suivant != NULL && bloc_free->suivant->bloc_libre == TRUE){
		/* si le bloc suivant est free on fusionne les deux blocs */
		bloc_free->suivant = bloc_free->suivant->suivant;
		bloc_free->suivant->precedent = bloc_free;
		free(bloc_free->suivant);	
	}
	/* on fusionne les blocs precedents qui ont ete free */
	if(bloc_free->precedent->bloc_libre == TRUE){
		bloc_free->precedent->suivant = bloc_free->suivant;
		bloc_free->precedent = bloc_free->precedent->precedent;
		free(bloc_free->precedent);
	}
}







