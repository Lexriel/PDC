#include "malloc.h"
#include "tools.h"
#include <string.h>
#define TEXTE "anticonstitutionnellement"
#define SAC "sac little marcel"
#define TEST "test"
int main(void){
	char *test, *strcp, *texte, *sac;
	int taille;

	printf("\n premier appel malloc \n");
	test = malloc(strlen(TEST)+10);
	strcpy(test,TEST);
	strcp = strdup(test);
	taille = strlen(test);
	printf("main -> taille : %d \n", taille);	
	printf("%s \n %s \n",test,strcp);

	printf("\n deuxieme appel malloc \n");
	texte = malloc(strlen(TEXTE));
	strcpy(texte,TEXTE);
	strcp = strdup(texte);
	printf("%s \n %s \n",texte,strcp);

	printf("\n troisieme appel malloc \n");
	sac = malloc(strlen(SAC));
	strcpy(sac,SAC);
	strcp = strdup(sac);
	printf("%s \n %s \n",sac,strcp);

	printf("\n appel a free \n");
	free(test);
	free(sac);
	free(strcp);
	return 1;

}
