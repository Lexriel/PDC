La fonction malloc marche correctement (plusieurs malloc à la suite)

mais je n'arrive pas à implémenter la fonction free 
Pour moi l'implementation de free consiste juste à mettre le booleen "bloc_libre", qui est dans la structure, à TRUE lorsqu'on free
Le problème c'est que la fonction free prend en parametre un pointeur vers l'espace alloué, et non vers la structure. Je ne peux donc pas acceder a la structure pour mettre le booleen à TRUE 
