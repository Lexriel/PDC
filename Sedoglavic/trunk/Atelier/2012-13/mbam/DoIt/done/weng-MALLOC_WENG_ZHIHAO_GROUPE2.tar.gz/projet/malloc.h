#include <stdio.h>

struct chaine_s
{
	unsigned int taille;
	struct chaine_s * suivant;
	struct chaine_s * precedent;
	void* espace;
	/* booleen qui vaut true si l'espace alloue est disponible, false sinon  */
	int bloc_libre;
};

void* malloc_recursif(struct chaine_s * bloc_precedent,struct chaine_s * BlocLibre,size_t size);

void* malloc(size_t size);

void free(void* ptr_bloc);

