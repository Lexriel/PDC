#define _XOPEN_SOURCE 500
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stddef.h>
#include "tools.h"
#include "malloc.h"

/* defini le malloc de la librairie par notre malloc */
#ifdef malloc
#undef malloc
#undef free
#endif


static struct chaine_s * listeBlocLibre;
static int first_call = TRUE;
static unsigned int count_size = 0;
static unsigned int max_size = 1<<10;

/*
 * memory = sbrk(1<<10);
 * listeBlocLibre->suivant = NULL;
 * listeBlocLibre->taille = 1<<10 - sizeof(struct chaine_s);
 * listeBlocLibre->espace = (char* memory) + sizeof(struct chaine_s); 
 */

static char* memory = NULL;

void* malloc(size_t size){
	if(first_call){
		memory = sbrk(max_size);
		first_call = FALSE;
		listeBlocLibre = (struct chaine_s*) memory;
		listeBlocLibre->precedent = NULL;
		listeBlocLibre->suivant = NULL;
		listeBlocLibre->taille = size;
		count_size += size + sizeof(struct chaine_s);
		listeBlocLibre->espace = (char*)memory + sizeof(struct chaine_s);
		/*memory += sizeof(struct chaine_s) + size;*/
		listeBlocLibre->bloc_libre = FALSE;
		return listeBlocLibre->espace;
	}	
	else{
		malloc_recursif(listeBlocLibre, listeBlocLibre->suivant, size);
	}
	return listeBlocLibre->espace;
}


void* malloc_recursif(struct chaine_s* bloc_precedent, struct chaine_s * BlocLibre, size_t size){
	/* condition d'arret */
	/* test si il reste assez de memoire, sinon rappel de la methode sbrk */
	if((max_size - count_size ) < size){
		memory = sbrk(max_size*2);
		max_size *= 2;
	}
	if(BlocLibre == NULL){
		BlocLibre = (struct chaine_s*) memory;
		BlocLibre->precedent = bloc_precedent;
		BlocLibre->suivant = NULL;
		BlocLibre->taille = size;
		count_size += size + sizeof(struct chaine_s);
		BlocLibre->espace = (char*)bloc_precedent->espace + bloc_precedent->taille + sizeof(struct chaine_s);
	    /*memory += sizeof(struct chaine_s) + size;*/
		BlocLibre->bloc_libre = FALSE;
		return BlocLibre->espace;
	}
	if(BlocLibre->bloc_libre == TRUE){
		/* si le bloc libre a la taille exacte qu'il faut */
		if(size == BlocLibre->taille){
			BlocLibre->bloc_libre = FALSE;
			return BlocLibre->espace;
		}

		/* si le bloc trouve est de taille plus grande que size */
		else if(BlocLibre->taille > size){
			struct chaine_s* chaineTmp = (struct chaine_s*) BlocLibre->espace + size;
			chaineTmp->precedent = BlocLibre;
			chaineTmp->suivant = BlocLibre->suivant;
			chaineTmp->taille = BlocLibre->taille - size ;
			chaineTmp->espace = (char*)BlocLibre->espace + size + sizeof(struct chaine_s);
			chaineTmp->bloc_libre = TRUE;

			BlocLibre->suivant = chaineTmp;
			BlocLibre->taille = size;
			BlocLibre->bloc_libre = FALSE;

			return BlocLibre->espace;
		}
	}
	
	return malloc_recursif(BlocLibre, BlocLibre->suivant, size);
}


void free(void *ptr_bloc){
	struct chaine_s* bloc_free = listeBlocLibre;
	if(bloc_free->suivant != NULL){
		while(bloc_free->suivant->espace != ptr_bloc){
	
			bloc_free->precedent = bloc_free;
			bloc_free = bloc_free->suivant;
			bloc_free->suivant = bloc_free->suivant->suivant;
		
		}
	}
	/* on va liberer et fusionner les blocs de mémoire de façon recursif */
		
	/*si le bloc precedent n'est pas free*/
	if(bloc_free->precedent->bloc_libre == FALSE){
	
		/*si le bloc suivant n'est pas null et n'est pas free*/
		if(bloc_free->suivant != NULL ){
			if(bloc_free->suivant->bloc_libre == FALSE){
				/* c'est la condition d'arret */
				bloc_free->bloc_libre = TRUE;
				return;
			}
		}
	}	
	/* on fusionne les blocs suivants qui ont ete free */
	if(bloc_free->suivant != NULL && bloc_free->suivant->bloc_libre == TRUE){
		/* si le bloc suivant est free on fusionne les deux blocs */
		bloc_free->suivant = bloc_free->suivant->suivant;
		bloc_free->suivant->precedent = bloc_free;
		free(bloc_free->suivant);	
	}
	/* on fusionne les blocs precedents qui ont ete free */
	if(bloc_free->precedent->bloc_libre == TRUE){
		bloc_free->precedent->suivant = bloc_free->suivant;
		bloc_free->precedent = bloc_free->precedent->precedent;
		free(bloc_free->precedent);
	}
}


