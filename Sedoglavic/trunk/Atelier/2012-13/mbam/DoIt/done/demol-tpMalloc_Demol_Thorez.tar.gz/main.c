#include "malloc.h"
#include <stdio.h>

int main(int argc, char *argv[])
{

  int *p = malloc_f(10);
  char *s = malloc_f(sizeof(char*));   

 s= "blabla\0";

 printf("%s\n",s);

  free(s);


  return 0;
}
