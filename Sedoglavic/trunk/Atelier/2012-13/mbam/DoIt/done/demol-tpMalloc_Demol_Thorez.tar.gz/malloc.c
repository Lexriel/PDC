#define _XOPEN_SOURCE 500
#define MINLLOC 1<<10
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <malloc.h>

typedef enum {DISPO, OCCUPE} bool ;
typedef struct cellule_s *malloc_t;

struct cellule_s
{
  void *ptr;
  malloc_t suivant;
  int taille;
  bool statut;
};
 
static int premierAppel = 1;
static malloc_t all;


void init(int size)
{
  if(size < MINLLOC)
  {
  all = (malloc_t) sbrk(MINLLOC);
  all->ptr = (void *)((char *)all + sizeof(struct cellule_s));
  all->taille  = MINLLOC;
  }
  else
  {
  all = (malloc_t) sbrk(size*2);
  all->ptr = (void *) ((char *) all + sizeof(struct cellule_s));
  all->taille = size*2;
  }
  all->statut  = DISPO;
  all->suivant = NULL; 
  premierAppel = 0;
}

void * malloc_f (int size)
{
  malloc_t tmp ;
  malloc_t suiv;
  if(premierAppel)
    {	
	init(size);
    }
  tmp = all;

  while(tmp->suivant)
    {
      if((tmp->statut == DISPO) && (tmp->taille  >= size))
	{
	  tmp->statut = OCCUPE;
	  return tmp->ptr; 
	}
      
      tmp = tmp->suivant;      
    }

  if(tmp->taille > (size + sizeof(struct cellule_s)))
    { 
      suiv = (malloc_t) ((char *)tmp->ptr+tmp->taille-size-sizeof(struct cellule_s)) ;

      suiv->suivant = NULL; 
      suiv->statut = OCCUPE ;
      suiv->ptr = (void *) ((char *)suiv + sizeof(struct cellule_s));
      suiv->taille = size ;
    }
   return suiv->ptr ;
}

void free(void *p)
{
/*  int i = 0;	
  malloc_t tmp  = all; 

  char *stmp;
  strncat(stmp,tmp->ptr,strlen(p));

  printf("%s",p);
  printf("%s",stmp);

  while(memcmp((*(char *)tmp->ptr),(*(char *)p), strlen(p)) != 0);
  tmp->statut = OCCUPE;
  for(i;i<(tmp->taille);i++)
  {
    ((tmp->ptr)) = NULL; 
  }*/
}
