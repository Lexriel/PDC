#ifndef H_MALLOC
#define H_MALLOC

void init(int size);

void * malloc_f (int size);

void free(void *p);
#endif 
