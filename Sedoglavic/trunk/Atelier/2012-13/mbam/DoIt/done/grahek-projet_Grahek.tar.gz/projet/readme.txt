Nom:Grahek
Prénom:Kevin
malloc et free terminé en version non optimisé.
il reste cependant un problème :les appels successifs de sbrk ne relie pas l' ancien bloc avec le nouvellement crée ce qui est problématique lors d un free()
