/* nom :Grahek */
/* prenon : Kevin */
#define _XOPEN_SOURCE 500
#define __USE_XOPEN_EXTENDED 1
#define RESERVATION_OCTET 100

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


typedef enum {
            TRUE  = (1==1),
            FALSE = (1==0)
    } bool;


void *montas;
typedef struct chainon_m *chai;

/*structure d une liste de bloc appellé avec un seul sbrk*/
struct chainon_m {
  int taille;
  chai suivant; /*pointeur sur le bloc suivant*/
  void *espace; /* pointeur sur l espace libre */
  bool used; /* TRUE si l'espace est utilisee , FALSE sinon */
};


static chai listeBloc;



/*diviser le bloc c en deux en ayant le nouveau bloc de la taille de memory
retourne l adresse du nouveau bloc*/
chai
split(int memory,chai c)
{
  chai new;
  int i;

  i=c->taille-(memory + sizeof(struct chainon_m));
  new=c;
  new->taille=memory;
  c=(chai) (((char *)c) + c->taille +sizeof(struct chainon_m));
  c->espace=(char *) c + sizeof(struct chainon_m);
  c->taille=i;
  new->suivant=c;
  new->used=TRUE;
  new->espace=(char *) new + sizeof(struct chainon_m);
  c->suivant=NULL;
 printf ("taille du bloc cree :%d\n",new->taille + sizeof(struct chainon_m) );
  return new;
}



/*initialise un bloc avec un nombre d octet contenu dans memory 
  renvoi le bloc*/
chai
init(int memory)
{
  chai listebloclibre;
  montas= sbrk(memory);
  listebloclibre=(chai) montas;
  listebloclibre->suivant=NULL;
  listebloclibre->taille =(memory) - sizeof(struct chainon_m);
  listebloclibre->espace=(char *) montas +sizeof(struct chainon_m);
  return listebloclibre;
}

chai
rechercheBloc(int memory,chai bloc)
{
  while (bloc) 
    {
      if ((bloc->used == FALSE ) & (bloc->taille > memory))
	return bloc;
      bloc=bloc->suivant;
    }
  return NULL;
}


void*
mymalloc(int memory)
{

  chai new,listeNewbloc;
  if (!(listeNewbloc=(rechercheBloc(memory,(chai) montas)))) {
    listeBloc=init(RESERVATION_OCTET);
    printf("sbrk    || ");
    new=split(memory,listeBloc);
    return new->espace;
  }
  else {
    printf("no sbrk || ");
    new=split(memory,listeNewbloc);
    return new->espace;
  }
}

void
myfree(void *adresse)
{
  chai freebloc;
  freebloc=(chai) ((char *) adresse - sizeof(struct chainon_m));
  freebloc->used=FALSE;
  if(freebloc->suivant != NULL) {
    /* printf ("taille : %d\n",freebloc->taille); */
    if ((freebloc->suivant->used)==FALSE) {
      /* printf("taille du bloc suivant %d\n",freebloc->suivant->taille); */
      freebloc->taille= (freebloc->taille)+(freebloc->suivant->taille)+ sizeof(struct chainon_m);
      freebloc->suivant=freebloc->suivant->suivant;
      myfree(adresse);
      /* printf ("taille ++ : %d\n",freebloc->taille); */
    }
  }
}


int main(int argc, char *argv[])
{
  chai ff,dd;
  ff=mymalloc(50);
  dd=mymalloc(50);
  myfree(dd);
  myfree(ff);
  mymalloc(80);
  return 0;
}
 

