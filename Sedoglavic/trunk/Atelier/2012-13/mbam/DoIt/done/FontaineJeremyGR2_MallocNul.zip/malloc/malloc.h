void* base=NULL;
typedef struct s_bloc *t_bloc;


struct s_bloc
{ 
    int libre;
    size_t taille;
    t_bloc suivant;
    /* rajouté pour la decoupe de bloc */
    char donnee[1];
};

t_bloc trouve_bloc
(t_bloc *dernier,size_t taille);

t_bloc augmente_bloc
(t_bloc dernier, size_t taille);

void decoupe_bloc
(t_bloc b,size_t taille);

void * malloc 
(size_t taille);
