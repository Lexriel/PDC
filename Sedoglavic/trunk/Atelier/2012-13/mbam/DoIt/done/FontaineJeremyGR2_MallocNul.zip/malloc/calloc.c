#include <unistd.h>
#include "malloc.h"


void *calloc(int nbElt, int taille)
{
  void	*addr;
  char	*str;
  int	i;

  i = 0;
  addr = malloc(nbElt * taille);
  if (addr == NULL)
    return (addr);
  str = addr;
  while (i < nbElt * taille)
    {
      str[i] = 0;
      i++;
    }
  return (addr);
}

