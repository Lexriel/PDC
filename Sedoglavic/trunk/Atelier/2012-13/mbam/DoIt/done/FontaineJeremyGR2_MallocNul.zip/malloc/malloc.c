#include <stdio.h>
#include <unistd.h>
#include "malloc.h"
#define TAILLE_BLOC (sizeof(struct s_bloc))



/* first-fit */
t_bloc trouve_bloc
(t_bloc *dernier,size_t taille)
{
    t_bloc b=base;

    /* Parcours tant que ce n'est pas libre et que la taille */
    /* ne correspond pas ET b non null */
    while(!(b->libre && b->taille >= taille) && b) 
    {
        *dernier = b;
        b = b->suivant;
    }
    return b;
}

/* Augmente le tas */
t_bloc augmente_bloc
(t_bloc dernier, size_t taille)
{
    t_bloc b;
    void *ps;
    b=sbrk(0);
    ps=sbrk(TAILLE_BLOC + taille);

    /* pas d'espace du tout */
    if (ps == (void *)-1) 
        return (1==0);
    b->taille = taille;
    b->suivant = NULL;
    /* Mise a jour du dernier bloc */
    if (dernier)
        dernier->suivant = b;
    b->libre=0;

    return b;
}


void decoupe_bloc
(t_bloc b,size_t taille)
{
    t_bloc nouveau_bloc;
    nouveau_bloc = b->donnee + taille;
    nouveau_bloc->taille = b->taille - taille - TAILLE_BLOC ;
    nouveau_bloc->suivant = b->suivant;
    nouveau_bloc->libre = 1;
    b->taille = taille;
    b->suivant = nouveau_bloc;

}

void * malloc 
(size_t taille)
{
    t_bloc b,dernier;
    size_t l;
    if (base) 
    {
        /* trouve_bloc*/
        dernier = base;
        b = trouve_bloc (&dernier,l);
        if (b) 
        {
            /* On regarde si on peut decouper */
            if ((b->taille - l) >= ( TAILLE_BLOC + 4))
                decoupe_bloc(b,l);
            /* b occupee */
            b->libre =0;
        } 
        else 
        {
            /* On demande plus de place */
            b = augmente_bloc(dernier ,l);
            /* Peut-on faire mieux ?...*/
            if (!b)
                return (1==0);
        }
    } 
    else 
    {
        /* premiere allocation */
        b = augmente_bloc(NULL,l);
        if (!b)
            return (1==0);
        base = b;
    }
    return (b->donnee );
}




