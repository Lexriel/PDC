/********************************************************
 *    redefinition des fonctions de la lib malloc       *
 *          Aurelien COUSIN - Valentin LEFILS           *
 *                L3S5 Info - Dec.2012                  *
 *******************************************************/


#include "monmalloc.h"        /* definitions des fonctions, structures et macros dans ce fichier */


/*** alloue size octets, et renvoie  un  pointeur  sur  la  memoire allouee ***/
void *malloc(size_t size) {
	return monmalloc(size);
}


/*** libere  l'espace  memoire pointe par ptr ***/
void free(void *ptr) {
	monfree(ptr);
}


/*** modifie la taille du bloc de mémoire pointe  par
   ptr  pour l'amener à une taille de size octets ***/
void *realloc(void *ptr, size_t size){
	return monrealloc(ptr,size);
}


/*** alloue la  memoire  necessaire  pour  un  tableau nmemb  elements representant chacun size octets, et renvoie un pointeur vers la memoire allouee. Remplit la zone avec des zeros ***/
void *calloc(size_t nmemb, size_t size){
	return moncalloc(nmemb,size);
}
