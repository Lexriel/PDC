/********************************************************
 *     header de la lib d'allocation memoire malloc.c   *
 *          Aurelien COUSIN - Valentin LEFILS           *
 *                L3S5 Info - Dec.2012                  *
 *******************************************************/

#include <stddef.h>

#define TAILLE 4096        /* taille utilisee pour deplacer le segment break */
#define M_MXFAST 1         /* macro de la commande pour set maxfast */
#define M_NLBLOCKS 2       /* macro de la commande pour seter numblks */

typedef struct memblock Memblock;
typedef struct optblock Optblock;


/* permet de representer un bloc memoire libre à partir de sa taille et d'un pointeur vers le bloc suivant */
struct memblock {
  int size;
  Memblock * next;
};


/* permet de representer la liste chainee de blocs pour la gestion des blocs optimises */
struct optblock {
  Optblock * next;
};


/* affiche la liste des blocs libres geres par la librairie */
void afficheMemoire();


/* affiche la liste des blocs optimises libres geres par la librairie */
void afficheMemoireMallopt();


/* fusionne les blocs de memoire libres adjacents */
void memCollapse(Memblock *block);


/* separe un bloc memoire en deux: un alloue de taille size et un libre */
void memSplit(Memblock *curblock, unsigned int size);


/* copie n octets depuis la zone mémoire src vers la zone mémoire dest */
void *monmemcpy(void * dest, const void * src,size_t n);


/* mallopt() ajuste les parametres qui controlent le comportement des fonctions liees à l'allocation de memoire */
int monmallopt(int cmd,int val);


/* augmente la taille du tableau de blocs optimises de numblks elements et retourne un pointeur vers le debut du nouveau tableau */
void * mallopt_createtab();


/* retourne un pointeur vers un bloc memoire alloue grace a mallopt */
void *mallopt_call();

/* alloue size octets, et renvoie  un  pointeur  sur  la  memoire allouee */
void *monmalloc(size_t size);


/* modifie la taille du bloc de mémoire pointe  par
   ptr  pour l'amener à une taille de size octets */
void * monrealloc(void *ptr, size_t size);


/* alloue la  memoire  necessaire  pour  un  tableau nmemb  elements representant chacun size octets, et renvoie un pointeur vers la memoire allouee. Remplit la zone avec des zeros */
void *moncalloc(size_t nmemb, size_t size);


/* libere  l'espace  memoire pointe par ptr */
void monfree(void *ptr);
