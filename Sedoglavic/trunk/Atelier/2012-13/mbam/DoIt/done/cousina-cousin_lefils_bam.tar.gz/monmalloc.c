/********************************************************
 *     librairie d'allocation memoire monmalloc.c       *
 *          Aurelien COUSIN - Valentin LEFILS           *
 *                L3S5 Info - Dec.2012                  *
 *******************************************************/


#include "monmalloc.h"             /* definitions des fonctions structures et macros dans ce fichier */

#define _XOPEN_SOURCE 500

#include <unistd.h>
#include <stdio.h>
#include <strings.h>


static Memblock *firstblock = NULL;        /* pointeur vers le premier element de la liste chainee de blocs libres */
static Optblock * malloptab;               /* pointeur vers le debut du tableau de blocs optimises */
static int mallopt_initialized = 0; /* permet de savoir si un emplacement a deja ete alloue avec mallopt */
static int maxfast = 0;             /* taille a partir de laquelle mallopt doit etre appele */
static int numblks = 100;           /* nombre d'elements dans chaque tableau alloué par mallopt */



/*** affiche la liste des blocs libres geres par la librairie ***/
void afficheMemoire(){
  Memblock *curblock = firstblock;
  int i=0;
  printf( "***********Etat blocs libre malloc************\n");
  do{
    ++i;
    printf("bloc %d:%p - Taille:%d - Adresse du suivant:%p\n",i,curblock,curblock->size,curblock->next);
    curblock = curblock->next;
  } while (curblock != firstblock);
  printf("***********************************\n"); 
}


/*** affiche la liste des blocs optimises libres geres par la librairie ***/
void afficheMemoireMallopt(){
  Optblock *curblock = malloptab;
  int i=0;
  printf("***********Etat blocs libre mallopt************\n");
  do{
    ++i;
    printf("bloc %d:%p - Adresse du suivant:%p\n",i,curblock,curblock->next);
    curblock = curblock->next;
  } while (curblock != malloptab);
  printf("***********************************\n");

} 


/*** fusionne les blocs de memoire libres adjacents ***/
void memCollapse(Memblock *block){
  if (block->next != firstblock){
    /* si les deux blocs adjacents sont libres*/
    if ((block != firstblock) && ((char *)block->next == (char *)block + block->size + sizeof(Memblock))){
      /* on les fusionne en un seul bloc */
      block->size += block->next->size + sizeof(Memblock);
      block->next = block->next->next;
      memCollapse(block);
    }
    else memCollapse(block->next);
  }
} 


/*** separe un bloc memoire en deux: un alloue de taille size et un libre ***/
void memSplit(Memblock *curblock, unsigned int size) {
  Memblock *tmp;
  if (size < (curblock->size - sizeof(Memblock))){
    tmp = curblock->next;
    curblock->next = (void *)((char *)curblock + sizeof(Memblock) + size);
    curblock->next->next = tmp;
    curblock->next->size = curblock->size - size - sizeof(Memblock);
    curblock->size = size;
  }
}


/*** copie n octets depuis la zone mémoire src vers la zone mémoire dest ***/
void *monmemcpy(void * dest, const void * src,size_t n) {
  char * source,cible;

  source=(char *) src;
  cible=(char *) dest;
  while(n--) {
    /*copie de l'octet du pointeur source vers la cible */
    cible = source;
    source++;
    cible++;
  }

  return dest;
}


/*** mallopt() ajuste les parametres qui controlent le comportement des fonctions liees à l'allocation de memoire ***/
int monmallopt(int cmd, int val) {
  if(mallopt_initialized || val < 0) {
    return 0;
  }
  switch(cmd) {

  case M_MXFAST:
    maxfast=val;
    break;

  case M_NLBLOCKS:
    numblks=val;
    break;
  }
  return 1;
}


/*** augmente la taille du tableau de blocs optimises de numblks elements et retourne un pointeur vers le debut du nouveau tableau ***/
void * mallopt_createtab() {
  int i;
  Optblock * curblock;
  if (!mallopt_initialized){
    mallopt_initialized = 1;
    malloptab = monmalloc(numblks * (sizeof(Optblock*) + maxfast));
    curblock = malloptab;
  }
  else {
    curblock = monmalloc(numblks * (sizeof(Optblock*) + maxfast));
  }

  curblock->next = (char *)curblock + sizeof(Optblock *) + maxfast;
  malloptab->next = curblock->next;
  for(i=0;i<numblks-1;i++) {
    curblock = curblock->next;
    curblock->next = (char *)curblock + sizeof(Optblock *) + maxfast;
 
  }
  curblock->next = malloptab;
  return malloptab->next;
}


/*** retourne un pointeur vers un bloc memoire alloue grace a mallopt ***/
void *mallopt_call() {
  Optblock *tmp;
  tmp = malloptab->next;
  if(malloptab->next == malloptab) {
    tmp = mallopt_createtab();
  }
  malloptab->next = tmp->next;
  tmp->next = malloptab;
  return (char *)tmp + sizeof(Optblock *);

}


/*** alloue size octets, et renvoie  un  pointeur  sur  la  memoire allouee ***/
void *monmalloc(size_t size) {
  Memblock *curblock,*prevblock;
  if(size <= maxfast) {
    if(!mallopt_initialized) {
      malloptab = mallopt_createtab();
    }
    return mallopt_call();
  }
  else {
    /* initialiation de firstblock */
    if(!firstblock) {
      firstblock = sbrk(sizeof(Memblock)); 
      firstblock->size = 0;
      firstblock->next = firstblock;
    }
    curblock = firstblock;
    /* parcours de la liste de blocs libres */ 
    do {
      curblock = curblock->next;
      if(curblock->size >= size){  
	prevblock = curblock;
	while (prevblock->next != curblock){
	  prevblock = prevblock->next; 
	}
	if(curblock->size >= (size + sizeof(Memblock))){
	  memSplit(curblock,size);
	}
	prevblock->next = curblock->next;
	curblock->next = NULL;

	return (char * )curblock + sizeof(Memblock);
      }
    } while (curblock->next != firstblock);
    /*Si blocs libres trop petits, Agrandissement de la zone mémoire et rappel de malloc*/
    curblock->next = sbrk(TAILLE);
    curblock->next->size = TAILLE - sizeof(Memblock);
    curblock->next->next = firstblock;
    memCollapse(firstblock);

    return monmalloc(size);
  }
}

/*** modifie la taille du bloc de mémoire pointe  par
   ptr  pour l'amener à une taille de size octets ***/
void * monrealloc(void *ptr, size_t size) {
  char *new;
  size_t minsize;
  Memblock *tmp;

  if(ptr == NULL) {
    return monmalloc(size);
  }
  if(size == 0) {
    monfree(ptr);
  }
  /* recuperation de la taille la plus petite entre celle demandee et celle du pointeur d'origine */
  tmp = (Memblock *)((char *)(ptr - sizeof(Memblock)));
  if (size>tmp->size) minsize = tmp->size;
  else minsize = size;
  new = monmalloc(size);
  monmemcpy(new,ptr,minsize);
  monfree(ptr); 

  return new;
}


/*** alloue la  memoire  necessaire  pour  un  tableau nmemb  elements representant chacun size octets, et renvoie un pointeur vers la memoire allouee. Remplit la zone avec des zeros ***/ 
void *moncalloc(size_t nmemb, size_t size){
  char *tmp = monmalloc(nmemb*size);
  bzero(tmp,size*nmemb);

  return tmp;    
}


/*** libere  l'espace  memoire pointe par ptr ***/
void monfree(void *ptr) {  
  Memblock * curblock, *tofree;
  Optblock *tmp;
  if(ptr==NULL) {
    return;
  }
  tmp = ptr-sizeof(Optblock);
  if(malloptab != NULL && tmp->next == malloptab){
    tmp->next = malloptab->next;
    malloptab->next = tmp;
    return;
  }
  tofree = (Optblock *)(ptr - sizeof(Memblock));
  if(!firstblock) {
    firstblock = sbrk(sizeof(Memblock));
    firstblock->size = 0;
    firstblock->next = firstblock;
    return;
  }
  if(ptr == firstblock){
    return;
  }
  curblock = firstblock;

  while( (curblock->next < tofree) && (curblock->next != firstblock) ) {
    curblock = curblock->next;
  }
  tofree->next = curblock->next;
  curblock->next = tofree;

  memCollapse(firstblock);
}
