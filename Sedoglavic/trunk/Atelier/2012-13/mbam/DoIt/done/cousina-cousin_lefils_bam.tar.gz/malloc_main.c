#include <unistd.h>
#include <stdio.h>
#include "monmalloc.h"

int main(){
  int i;
  char *test1,*test2,*test3;

  test1=monmalloc(20);
  printf("test1=malloc(20) effectue\n");
  test1=monrealloc(test1,50);
  printf("test1=realloc(test1,50) effectue\n");
  monmallopt(M_MXFAST,8);
  monmallopt(M_NLBLOCKS,10);
  printf("set maxfast=8 , numblks=10\n");
  monfree(test1);
  printf("free(test1) effectue \n");
  for(i=0;i<21;i++) {
    test3 = monmalloc(6);
    printf("#%d: mallopt appele pour malloc(6)\n",i);
    afficheMemoireMallopt();
  }
  
  return 0;
}
