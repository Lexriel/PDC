#define _XOPEN_SOURCE 500
#define __USE_XOPEN_EXTENDED 1
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int 
main
(void)
{
  struct chainon_m * chainonVide;
  chainonVide = premierChainon((1<<12),NULL);
  /*chainonVide = newChainon((1<<10),NULL, NULL);*/

  /*malloc(1<<12, chainonVide);*/
  return 0;

}

