#define _XOPEN_SOURCE 500
#define __USE_XOPEN_EXTENDED 1
#define tailleChainon (1 << 24)
#include <unistd.h>
#include <stdio.h>
#include <stddef.h>		/* for size_t */



/*  creation d un bloc de taille 1<<24 (2^24 bits) diviser en 3 parties : taille du bloc | adresse du maillon suivant | l'adresse de l'espace libre /
*--* void *montas;
*|* montas = sbrk(tailleChainon);

*/
/*|* struct chainon_m * listeBlocLibre;
*|* listeBlocLibre = ( struct chainon_m *) montas;
*|* listeBlocLibre -> suivant = NULL;
*|* listeBlocLibre -> taille = tailleChainon - sizeof(struct chaine_m);
*--* listeBlocLibre -> espace = (char *)montas + sizeof(struct chaine_m);
* listeBlocLibre est un enorme chainon du quel seront creer les autres dans son espace libre */
typedef struct chainon_m chainon_t;
 struct chainon_m
 {
   /* il faudra sans doute rajouter un "magic number" pour definir le début et la fin du chainon, pour eviter les depassements */
   int taille;
   chainon_t *suivant;
   void *espace;
 };

static chainon_t* ChainonMere;

void *
monmalloc (size_t size)
{
   printf("\n*********** malloc ********* \n");
  if(ChainonMere->taille >= size)
    {
      printf("espace suffisant trouvé \n");
      printf("taille, suivant, adresse de l'espace du ChainonMere : %d, %d, %d \n", ChainonMere->taille,ChainonMere->suivant,ChainonMere->espace);
     
      void* espaceNecessaire = ChainonMere->espace + ChainonMere->taille;
      espaceNecessaire = espaceNecessaire-size;
      espaceNecessaire = espaceNecessaire-sizeof(struct chainon_m);

      chainon_t* chainon;
      chainon = espaceNecessaire;
      chainon->taille = size;
      chainon->espace = espaceNecessaire+sizeof(struct chainon_m);
      chainon->suivant = espaceNecessaire;

      ChainonMere->taille = ChainonMere->taille - (size +sizeof(struct chainon_m));
      printf("taille, suivant, adresse de l'espace du nouveau chainon : %d, %d, %d \n", chainon->taille,chainon->suivant,chainon->espace);
      printf("taille, suivant, adresse de l'espace du ChainonMere : %d, %d, %d \n", ChainonMere->taille,ChainonMere->suivant,ChainonMere->espace);
    }
  else{
     printf("espace insuffisant !!! \n");
  }
    return 0; 
 }

chainon_t *
newChainon (int taille,chainon_t *suivant,void *espace)
{
  printf("\n*********** newChainon ********* \n");
  printf("taille demandée : %d \n", taille);
  printf("taille disponible du chainonMere : %d \n", ChainonMere->taille);
  monmalloc(taille);
  chainon_t* chainon;
  /* chainon = {taille, suivant, espace};
  printf("taille récupérée : %d \n", chainon->taille);*/
  return  chainon;
}

chainon_t *
premierChainon (int tailleC,chainon_t *suivantC)
{ 
  printf("\n*********** premierChainon ********* \n");
  ChainonMere = sbrk(tailleC) ;
  printf("taille demandée pour ChainonMere : %d \n", tailleC);
  ChainonMere->taille = tailleC ;
  printf("taille allouée pour ChainonMere : %d \n", ChainonMere->taille);

  printf("adresse du suivant de ChainonMere : %d \n", suivantC);
  ChainonMere->suivant = suivantC ;
  printf("suivant allouée pour ChainonMere : %d \n", ChainonMere->suivant);

  ChainonMere->espace = &ChainonMere->taille ;
  printf("adresse de l'espace allouée pour ChainonMere : %d \n", ChainonMere->espace);

  chainon_t * chainonVide1;
  chainonVide1 = newChainon((1<<10),NULL,ChainonMere->espace);

chainon_t * chainonVide2;
 chainonVide2 = newChainon((1<<7),NULL,ChainonMere->espace);

chainon_t * chainonVide3;
 chainonVide3 = newChainon((1<<11),NULL,ChainonMere->espace);

chainon_t * chainonVide4;
  chainonVide4 = newChainon((1<<10),NULL,ChainonMere->espace);

  return ChainonMere;
}






