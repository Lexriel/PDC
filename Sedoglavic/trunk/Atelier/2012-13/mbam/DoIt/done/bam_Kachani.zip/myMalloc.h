#ifndef MYMALLOC_H_
#define MYMALLOC_H_

#include <unistd.h>

const int M_MXFAST = 1;
const int M_NLBLOCKS = 2;

typedef struct _cellule
{
	void* plage;
	int blocksPleins;
	struct _cellule* next;
} cellule;

void mallopt(int, int);
void* malloc(size_t);
void free(void*);
void* realloc(void*, size_t);
void* calloc(size_t,size_t);

#endif 
