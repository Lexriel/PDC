#include "myMalloc.h"

int maxFast = 0;
int numBlks = 100;

void** hdle;
cellule* hdle_cell;

//Fonction qui retourne la puissance de 2 la plus grande que n
int prochP2(int n)
{
	int x = 1;
	while (n > 0)
	{
		n /= 2;
		x *= 2;
		
	}
	return x;
}
//Inititialisation des paramètres de la résérvation des petits blocs
void mallopt(int cmd, int val)
{
	if (hdle_cell == NULL )
	{
		if (cmd == M_MXFAST)
			maxFast = val;
		else if (cmd == M_NLBLOCKS)
			numBlks = val;
	}
}

void* malloc(size_t size)
{
	//Retourne 0 si la taille passée en paramètre est nulle
	if (size == 0)
		return NULL ;
		
	//Gestion des demandes d'allocation de taille reduite
	if (size <= maxFast)
	{
		size_t cell_size = (maxFast + 1) * numBlks;
		cellule* iter_cell = hdle_cell;
		cellule* prev_cell = hdle_cell;
		
		//On parcours la liste chainée des tableaux afin de trouver un tableau vide ou partiellement vide
		while (iter_cell != NULL && iter_cell->blocksPleins == numBlks)
		{
			prev_cell = iter_cell;
			iter_cell = iter_cell->next;
		}
		//Si le tableaux trouvé est vide  on resérve l'espace pour l'ensemble des blocs  avec sbrk()
		if (iter_cell == NULL )
		{
			iter_cell = sbrk(sizeof(cellule*));
			if (iter_cell == NULL )
				return NULL ;
			if (prev_cell != NULL )
				prev_cell->next = iter_cell;
			else
				hdle_cell = iter_cell;
			iter_cell->plage = sbrk(cell_size);
			if (iter_cell->plage == NULL )
				return NULL ;
		}
		char* iter_plage = (char*) iter_cell->plage;
		
		//On parcours le tableau courant jusqu'a trouver un bloc vide =>un bloc est vide si le premier octet vaut 0
		while (iter_plage < (char*) iter_cell->plage + cell_size
				&& *iter_plage != 0)
			iter_plage = iter_plage + maxFast + 1;
			
		
		*iter_plage = 1;   // le bloc est reservé maintenant ==> le flag vaut 1 
		iter_cell->blocksPleins++;
		
		// pointeur vers le premier octet après le flag
		
		return (void*) (iter_plage + 1);
	}
	
	//Gestion des demandes ordinaires
	
	if (hdle == NULL )
		hdle = sbrk(sizeof(void**));
	if (hdle == NULL )
		return NULL ;
	void** prev = hdle;
	size_t p_size = sizeof(void**) + 2 * sizeof(size_t);
	void** runner = *hdle;
	// Parcours de  la mémoire déjà résérvée pour une plage avec un espace libre suffisant
	while (runner != NULL )
	{
		prev = runner;
		size_t* t_size = (size_t*) (runner + 1);
		size_t* r_size = t_size + 1;
		
		
		if (*t_size - *r_size >= size + p_size * (*r_size != 0))
		{
			//Si la taille utilisée est nulle ==> pas besoin de créer un nouveau pointeur
			if (*r_size == 0)
				*r_size = size;
			//Si non, on résérve un nouveau pointeur
			else
			{
				size_t tmp_r_size = *r_size;
				size_t tmp_t_size = *t_size;
				*t_size = *r_size;
				runner = (char*) runner + *t_size + p_size;
				t_size = (size_t*) (runner + 1);
				r_size = t_size + 1;
				*t_size = tmp_t_size - tmp_r_size - size;
				*r_size = size;
				*prev = runner;
			}
			return (void*) ((char*) runner + p_size);
		}
		runner = *runner;
	}
	// Pas d'espace suffiant déja résérvé ==> réserver de nouveau
	size_t alloc_size = prochP2(size + p_size);
	runner = sbrk(alloc_size);
	if (runner == NULL )
		return NULL ;
	*prev = runner;
	size_t* t_size = (size_t*) (runner + 1);
	size_t* r_size = t_size + 1;
	*t_size = alloc_size - p_size;
	*r_size = size;
	return (void*) ((char*) runner + p_size);
}

void free(void* ptr)
{
	if (hdle != NULL )
	{
		size_t p_size = sizeof(void**) + 2 * sizeof(size_t);
		void** runner = hdle;
		void** prev;
		//On parcours l'ensemble des pointeurs résérvé pour verifié la présence du pointeur à libérer
		while (runner != NULL )
		{
			prev = runner;
			runner = *runner;
			//Si le pointeur existe on procède à la liberation
			if (ptr == (char*) runner + p_size)
			{
				size_t* t_size = (size_t*) (prev + 1);
				size_t* free_t_size = (size_t*) (runner + 1);
				//On verifie si l'espace libéré est adjacent à un autre espace libre pour les fusioner
				if ((char*) prev + p_size + *t_size == (char*) runner)
				{
					*t_size += *free_t_size + p_size;
					*prev = *runner;
				}
				else
				{
					size_t* r_size = free_t_size + 1;
					*r_size = 0;
				}
				return;
			}
		}
	}
}
void* realloc(void* ptr, size_t size)
{
	if (hdle != NULL )
	{
		size_t p_size = sizeof(void**) + 2 * sizeof(size_t);
		void** runner = hdle;
		void** prev;
		while (runner != NULL )
		{
			prev = runner;
			runner = *runner;
			//Si le pointeur à realouer existe, on essaye de modifier espace réservé s'il est suffisant,
			//sinn on libère l'espace courant et on alloue un nouveau
			if (ptr == (char*) runner + p_size)
			{
				size_t* t_size = (size_t*) (runner + 1);
				size_t* r_size = t_size + 1;
				if (*t_size >= size)
				{
					*r_size = size;
					return ptr;
				}
				else
				{
					free(ptr);
					return malloc(size);
				}
			}
			return NULL ;
		}
	}
	return NULL ;
}

void* calloc(size_t count, size_t eltsize)
{
	//On résérve l'espace des nouveaux pointeurs
	size_t it = count * eltsize;
	char* init = malloc(it);
	if (init ==NULL)
		return NULL;
	//On initialize le tout à 0
	while (init <= init + it)
	{
		*init = 0;
		init++;
	}
	return init;

}

int main(int argc, char **argv)
{
	
	mallopt(M_MXFAST, 100);
	mallopt(M_NLBLOCKS, 5);
	int* x;
	int i;
	for (i = 1; i <= 20; i++)
	{
		x = malloc(10);
		printf("\n%d ---> %d", i, x);
		//free(x);
	}
	//	int* x = malloc(100);
	//	malloc(100);
	//	printf("%d\n", x);
	//	x = realloc(x, 105);
	//	printf("%d", x);

}

