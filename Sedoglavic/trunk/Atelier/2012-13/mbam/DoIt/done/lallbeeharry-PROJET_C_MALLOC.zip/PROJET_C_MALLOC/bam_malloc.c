
/*

AMAL ZERIOUH 
Navish Lallbeeharry
EL MOUTAOUKIL MEHDI

*/








#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>		
#include "bam_malloc.h"

#define BLOCK_SIZE 100

#define align4(x) ((((( x ) -1)>>2)<<2) + 4 )

#ifdef malloc
#undef malloc
#undef free
#endif

void *base=NULL;




struct s_block {
	size_t size,s;
	struct s_block *next;
	struct s_block *prev;
	struct s_block *last;
	int free;
	int nb_block;
	void *ptr;
	/* A pointer to the allocated block */
	char data [1];
};

typedef struct s_block * t_block ;

/* Get the block from and addr*/
t_block get_block (void *p)
{
	char *tmp;
	tmp = p;
	return (p = tmp -= BLOCK_SIZE );
}


/* Valid addr for free*/
int valid_addr (void *p)
{
	if (base)
	{
		if ( p>base && p < sbrk(0))
		{
			return (p == ( get_block (p))->ptr );
		}
	}
	return (0);
}

/* fusion*/
t_block fusion ( t_block b){
	if (b->next && b->next ->free )
	{
		b->size += BLOCK_SIZE + b->next ->size;
		b->next = b->next ->next;
		if (b->next)
		b->next ->prev = b;
	}
	return (b);
}

/* calloc*/
void * calloc ( size_t number , size_t size )
{
	size_t *new;
	size_t s4 ,i;
	new = malloc ( number * size );
	if (new)
	{ 
		s4 = align4 ( number * size) << 2;
		for (i=0; i<s4 ; i++)
			new[i] = 0;
	}
	return (new );
}


/* The free*/

void bam_free(void *p ,char *filename, unsigned line )
{
	t_block b;
	if ( valid_addr (p))
	{
		b = get_block (p);
		b->free = 1;
		/* fusion with previous if possible */
		if(b->prev && b->prev ->free)
			b = fusion (b->prev );
		/* then fusion with next */
		if (b->next) 
			fusion (b);
		else
		{
			/* free the end of the heap */
			if (b->prev)
				b->prev ->next = NULL;
			else
				/* No more block !*/
				base = NULL;
				brk(b);
		}
	}
}



/* Copy data from block to block */
void copy_block ( t_block src , t_block dst)
{
	int 	*sdata ,* ddata ;
	size_t 	i;
	sdata = src ->ptr;
	ddata = dst ->ptr;
	for (i=0; i*4<src ->size && i*4<dst ->size; i++)
		ddata [i] = sdata [i];
}

/* Add a new block at the of heap  */
/* return NULL if things go wrong  */
t_block extend_heap ( t_block last , size_t s)
{ 
	
	t_block b; 
	b = sbrk (0); 
	sbrk ( BLOCK_SIZE + s); 
	b->size = s; 
	b->next = NULL; 
	b->prev = last; 
	b->ptr = b->data; 
	if (last) 
		last->next = b; 
	b->free = 0; 
	return (b); 
} 





/* decoupage du bloc selon la taille */
/* The b block must exist . */
void split_block ( t_block b, size_t s) 
{ 
	t_block new; 
	new = ( t_block )(b->data + s); 
	new->size = b->size - s - BLOCK_SIZE ; 
	new->next = b->next; 
	new->prev = b; 
	new->free = 1; 
	new->ptr = new ->data; 
	b->size = s; 
	b->next = new; 
	if (new->next) 
		new ->next ->prev = new; 
} 



/* The realloc */

void * realloc (void *p, size_t size)
{
	size_t 	s;
	t_block 	b, new;
	void 	*newp;
	if (!p)
	 return ( malloc (size ));
	if ( valid_addr (p))
	{
		s = align4 (size );
		b = get_block (p);
		if (b->size >= s)
		{
			if (b->size - s >= ( BLOCK_SIZE + 4))
			split_block (b,s);
		}
		else
		{
		/* Try fusion with next if possible */
			if (b->next && b->next ->free && (b->size + BLOCK_SIZE + b->next ->size) >= s)
			{
				fusion (b);
				if (b->size - s >= ( BLOCK_SIZE + 4))
				split_block (b,s);
			}
			else
			{
			/* good old realloc with a new block */
			newp = malloc (s);
			if (! newp)
				/* we ’re doomed ! */
				return (NULL );
				/* I assume this work ! */
				new = get_block (newp );
				/* Copy data */
				copy_block (b,new );
				/* free the old one */
				free(p);
				return (newp );
			}
		}
	return (p);
	}
	return (NULL );
}



t_block find_block( t_block *last , size_t size )
{
	t_block b=base;
	while (b && !(b->free && b->size >= size )) 
	{
		*last = b;
		b = b->next;
	}
	return (b);
}



void * bam_malloc ( size_t size ,char *filename, unsigned line)
{
	t_block b,last;
	size_t 	s;
	s = align4 (size );
	if (base) 
	{
		/* First find a block */
		last = base;
		b = find_block (&last ,s);
		if (b) 
		{
			/* on decoupe le bloc trouvé si taille est tres grande (la difference avec la taille memoire demandée est supérieure 				ou egale a block_size + 4: taille minimale pour créer un bloc)   */
			if ((b->size - s) >= ( BLOCK_SIZE + 4))
			split_block (b,s);
			b->free =0;
		} 
		else
		{
			/* No fitting block , extend the heap */
			b = extend_heap (last ,s);
			if (!b) return (NULL );
		}
	}
	else 
	{
		/* first time */
		b = extend_heap (NULL ,s);
		if (!b)  return (NULL );
		base = b;
	}
	return (b->data );
}


