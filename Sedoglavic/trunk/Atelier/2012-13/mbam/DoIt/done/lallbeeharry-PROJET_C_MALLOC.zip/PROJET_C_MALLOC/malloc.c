/*

AMAL ZERIOUH 
Navish Lallbeeharry
EL MOUTAOUKIL MEHDI

*/

#include <stddef.h>		/* for size_t */
#include "bam_malloc.h"

/* Forget definition of malloc wrappers */
#ifdef malloc
#undef malloc
#undef free
#endif

/* Redefinition of malloc () */
void *
malloc (size_t size)
{
    /* unknown source filename and line */
    return bam_malloc(size, (char *)0, 0); 
}

/* Redefinition of free () */
void
free (void *ptr) 
{
    /* unknown source filename and line */
    bam_free(ptr, (char*) 0, 0); 
}

