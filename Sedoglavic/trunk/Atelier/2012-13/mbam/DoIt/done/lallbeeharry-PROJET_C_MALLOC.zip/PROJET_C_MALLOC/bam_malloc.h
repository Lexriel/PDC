/*

AMAL ZERIOUH 
Navish Lallbeeharry
EL MOUTAOUKIL MEHDI

*/

#ifndef _PHM_MALLOC_H_
#define _PHM_MALLOC_H_

/* malloc() and free() replacement */
void *
bam_malloc (size_t size,	/* as in malloc() */
	    char *filename,	/* source filename of the function call */
	    unsigned line); 	/* source line number of the f. call */

void
bam_free (void *ptr,		/* as in free() */
	  char *filename,	/* filename and line of the call */
	  unsigned line);

/* malloc and free as wrappers */
#define malloc(sz)      bam_malloc(sz, __FILE__, __LINE__)
#define free(ptr)       bam_free(ptr, __FILE__, __LINE__)

#endif
