/********PROJET MON ESPACE ALLOCATION MEMOIRE********************/
ZERIOUH AMAL
LALLBEEHARRY NAVISH
EL MOUTAOUKIL MEHDI
GROUPE 5
PDC

********************************************/

on a travailler sur les fonctions suivant :
malloc
free
realloc et calloc


on a fait notre mieux pour implementer les different fonctions.
on a aussi travailler avec les fichier d'exemple donner sur le portail mais il nous manque quelque test et des trace de malloc.

