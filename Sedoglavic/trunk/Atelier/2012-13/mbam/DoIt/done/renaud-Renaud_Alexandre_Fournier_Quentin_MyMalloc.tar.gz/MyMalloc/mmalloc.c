//Renaud Alexandre && Fournier Quentin
#define _XOPEN_SOURCE 500
#include <unistd.h>
#include "mmalloc.h"
#include <stdio.h>
#include <string.h>


static malloc_t espace;
static const dispo oui = OUI; 
static const dispo non = NON; 


 
void *
mmalloc
(unsigned int size)
{
  int TAILLE_BLOC;
  TAILLE_BLOC = sizeof(struct espace_s);
  int taille;
  taille = (1 << size) + TAILLE_BLOC;
  malloc_t res, espace_tmp;
  int MARGE;
  MARGE = (1<<6);
 
  //Si l'espace mémoire n'existe pas on le crée
  if(!espace)
    {
      espace = (malloc_t) sbrk(taille+MARGE);
      espace->courant = espace + TAILLE_BLOC;
      espace->taille  = taille+MARGE;
      espace->suivant = NULL;
      espace->disponible = oui;
    }
  espace_tmp = espace;

  //Tant que l'espace courant n'est pas disponible 
  //et que sa taille n'est pas suffisante
  //si il existe un espace qui le suit alors on passe
  while((espace_tmp->disponible == non 
	 || espace_tmp->taille < taille)
	&& espace_tmp->suivant)
    {
      espace_tmp = espace_tmp->suivant;
    }
  //Si l'espace courant n'est pas disponible
  //ou que sa taille n'est pas suffisante
  //si il n'existe pas de suivant alors on réalloue un nouvel espace
  if((espace_tmp->disponible == non
      || espace_tmp->taille < taille)
     && !espace_tmp->suivant)
    {
      //initialisation du nouveau bloc mémoire
      malloc_t espace_suiv;
      espace_suiv = sbrk(taille+MARGE);
      espace_suiv->courant = espace_suiv + TAILLE_BLOC;
      espace_suiv->suivant =NULL;
      espace_suiv->taille = taille+MARGE;
      espace_suiv->disponible = oui;


      espace_tmp->suivant = espace_suiv;
      espace_tmp = espace_tmp->suivant;
     
   
      espace->taille += taille+MARGE;
    }
  espace_tmp->courant = espace_tmp + TAILLE_BLOC;

  res = espace_tmp;
  res->courant = espace_tmp->courant;
  res->taille = taille;
  res->disponible = non;

  //Définition du bloc restant disponible en mémoire.
  malloc_t suiv;
  suiv = res+taille;
  suiv->courant = suiv + TAILLE_BLOC;
  suiv->suivant = NULL;
  suiv->taille = espace_tmp->taille - res->taille;
  suiv->disponible = oui;


  res->suivant = suiv;

  return res->courant;
}


void
mfree
(void *ptr)
{
  malloc_t espace_tmp;
  espace_tmp = espace;
  while(espace_tmp->courant != ptr && espace_tmp->suivant != NULL)
    {
      espace_tmp = espace_tmp->suivant;
    }
  
  espace_tmp->disponible = oui;
  
  return;
}

