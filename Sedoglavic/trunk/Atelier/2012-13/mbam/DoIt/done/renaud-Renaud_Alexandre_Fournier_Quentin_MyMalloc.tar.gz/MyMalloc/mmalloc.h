//Renaud Alexandre && Fournier Quentin
#ifndef __MMALLOC__
#define __MMALLOC__

typedef enum {OUI, NON} dispo;
typedef struct espace_s *malloc_t;

struct espace_s
{
  void *courant;
  malloc_t suivant;
  int taille;
  dispo disponible;
};

void * mmalloc (unsigned int);
#endif
