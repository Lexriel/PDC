//Renaud Alexandre && Fournier Quentin
#include "mmalloc.c"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int
main
(void)
{
  printf("test malloc\n");

  int * debut;
  printf("test 1\n");
  debut = mmalloc(sizeof(int));
  printf("%p\n", debut);

  *debut = 1;
  printf("%i\n",*debut);
  char * debut2;
  printf("test 2\n");
  debut2 = mmalloc(sizeof(char)*5);
  printf("%p\n", debut2);

  debut2 = "abcde";
  printf("%s\n",debut2);

  printf("test 12\n");
  printf("%i\n",*debut);
  printf("test 3\n");
  int * debut3;
  debut3 = mmalloc(sizeof(int));
  printf("%p\n", debut3);

  *debut3 = 3;
  printf("%i\n",*debut3);

  printf("test 1 2\n");
  printf("%i\n",*debut);

  printf("test 2\n");
  int * debut4;
  debut4 = mmalloc(sizeof(int));
  printf("%p\n", debut4);

  *debut4 = 4;
  printf("%i\n",*debut4);

  printf("test free \n");

  mfree(debut2);
	  
  return 0;
  
}
