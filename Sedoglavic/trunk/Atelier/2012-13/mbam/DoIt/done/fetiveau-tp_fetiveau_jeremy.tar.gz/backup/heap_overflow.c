#include <string.h>
#include "malloc.h"

int main(int argc, char **argv)
{
    char *str = (char*)malloc(10);
    char *str2 = (char*)malloc(10);
    strcpy(str, "0123456789ABCD");
    free(str2);
    return 0;
}

