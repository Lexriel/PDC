#include <stdio.h>
#include "malloc.h"

#define NB_EL 5000
#define TAILLE_EL 30

int main(void)
{
    char **tab = NULL;
    int i = 0;
    puts("Here");
    tab = (char**)malloc(NB_EL * sizeof(char*));
    printf("%x\n", tab);
    if (!tab)
    {
        puts("malloc");
        return 1;
    }
    puts("Loop:");
    for (i = 0; i < NB_EL; ++i)
    {
        tab[i] = (int*)malloc(sizeof(char) * TAILLE_EL);
        if (!tab[i])
        {
            puts("malloc");
            return 1;
        }
        strcpy(tab[i], "yo");
    }
    for (i = 0; i < NB_EL; ++i)
    {
        printf("%s\n", tab[i]);
    }
    for (i = 0; i < NB_EL; ++i)
    {
        free(tab[i]);
    }
    return 0;
}
