#include <stdio.h>
#include "malloc.h"

int main(void)
{
    char *str = (char*)malloc(40);
    printf("=================>%p\n", str);
    strcpy(str, "hello");
    printf("%s\n", str);

    free(str);

    str = (char*)malloc(40);
    printf("=================>%p\n", str);
    strcpy(str, "world");
    printf("%s\n", str);
    return 0;
}
