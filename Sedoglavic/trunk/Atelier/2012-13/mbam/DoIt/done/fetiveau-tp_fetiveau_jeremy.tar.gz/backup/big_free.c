#include <stdio.h>
#include "malloc.h"

int main(void)
{
    char *str = (char*)malloc(10000);
    free(str);
}
