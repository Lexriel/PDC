#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    char *a = (char*)malloc(0);
    char *b = (char*)malloc(10);
    char *c = (char*)malloc(100);
    char *d = (char*)malloc(1000);
    char *e = (char*)malloc(10000);
    free(d);
    free(e);
    free(c);
    free(b);
    free(a);
    a = (char*)malloc(100);
    b = (char*)malloc(100);
    c = (char*)malloc(100);
    d = (char*)malloc(10000);
    e = (char*)malloc(10);
    free(d);
    free(a);
    free(e);
    free(b);
    free(c);
}
