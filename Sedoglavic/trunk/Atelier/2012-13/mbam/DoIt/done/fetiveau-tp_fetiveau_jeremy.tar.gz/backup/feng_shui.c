#include <stdio.h>
#include "malloc.h"

int main(void)
{
    int **tab = (int**)malloc(10 * sizeof(int*));
    int i = 0;
    for (i = 0; i < 10; ++i)
    {
        tab[i] = (int*)malloc(sizeof(int));
        *tab[i] = i;
    }
    free(tab[8]);
    free(tab[2]);
    free(tab[3]);
    free(tab[6]);
    free(tab[4]);
    free(tab[5]);
    free(tab[0]);
    free(tab[1]);
    free(tab[7]);
    free(tab[9]);
    for (i = 0; i < 10; ++i)
    {
        tab[i] = (int*)malloc(sizeof(int));
        printf("%d ", *tab[i]);
    }
    puts("");
    return 0;
}
