#include <stdio.h>
#include "malloc.h"

int main(void)
{
    char *str = malloc(7);
    char *str2 = malloc(7);
    printf("str allocated at %p and %p\n", str, str2);
    free(str2);
    printf("%s %s\n", str, str2);
    strncpy(str, "hello", 6);
    strncpy(str2, "world", 6);
    printf("%s %s\n", str, str2);
    asm("int $3");
}
