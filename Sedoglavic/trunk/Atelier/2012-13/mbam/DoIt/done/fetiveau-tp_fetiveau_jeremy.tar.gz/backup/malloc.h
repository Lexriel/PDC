#ifndef MALLOC_H
#define MALLOC_H

#define FIRST_ALLOC (N_LIST_ENTRY*sizeof(_LIST_ENTRY) + 10000)
#define N_LIST_ENTRY 128

void *malloc(unsigned size);
void free(void* ptr);
int mallopt(int cmd, int val);

int maxfast;
int numblks;
char* topchunk;
int avl_from_top;

char can_mallopt;
enum mallopt_cmd{M_MXFAST, M_NLBLOCKS};

typedef struct _list_entry
{
    unsigned int cookie;
    struct _list_entry* flink;
    struct _list_entry* blink;
} _LIST_ENTRY;

typedef struct chunk_header
{
    unsigned int cookie;
    unsigned int size;
    unsigned int is_free;
}_CHUNK_HEADER;

_LIST_ENTRY *ListHints;


#endif
