#include <stdio.h>
#include "malloc.h"

int main()
{
    char *a = (char*)malloc(10);
    free(a);
    free(a);
    return 0;
}
