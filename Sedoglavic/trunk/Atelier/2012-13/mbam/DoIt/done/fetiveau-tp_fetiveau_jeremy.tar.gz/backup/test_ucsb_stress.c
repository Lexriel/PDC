#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include "malloc.h"

#ifdef HAVE_DRAND48
#define RAND() (drand48())
#define SEED(x) (srand48((x)))
#else
/* not my fault it's not there... */
#define RAND() ((double)random()/RAND_MAX)
#define SEED(x) (srandom((x)))
#endif

#define BUFS (1000)


int main(int argc, char *argv[])
{
	int size;
	int where;
	void *ptr[BUFS];
	int i;

	for(i=0; i < BUFS; i++)
	{
		ptr[i] = NULL;
	}


	for(i=0; i < 50000; i++)
	{
		printf("iter: %d\n",i);
		where = (int)(RAND() * BUFS);

		if(ptr[where] == NULL)
		{
			size = (int)(RAND() * 25000);
			ptr[where] = malloc(size);
			if(ptr[where] == NULL)
			{
				fprintf(stderr,
				"malloc at iteration %d failed for size %d\n",
				i,size);
				fflush(stderr);
			}
		}
		else
		{
			free(ptr[where]);
			ptr[where] = NULL;
		}
	}

	/*
	 * now -- free them
	 */
	for(i=0; i < BUFS; i++)
	{
		if(ptr[i] != NULL)
		{
			free(ptr[i]);
			ptr[i] = NULL;
		}
	}

	printf("\n");

	printf("made it -- passed test\n");
	exit(0);
}



