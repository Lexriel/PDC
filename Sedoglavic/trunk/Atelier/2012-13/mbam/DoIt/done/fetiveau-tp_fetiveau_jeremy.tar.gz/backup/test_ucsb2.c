#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include "malloc.h"

int main(int argc, char *argv[])
{
	char *a1;
	char *a2;
	char *a3;
	char *a4;

	a1 = (char *)malloc(60);
	if(a1 == NULL)
	{
		fprintf(stderr,"call to malloc(60) failed\n");
		fflush(stderr);
		exit(1);
	}

	a2 = (char *)malloc(32);
	if(a2 == NULL)
	{
		fprintf(stderr,"first call to malloc(32) failed\n");
		fflush(stderr);
		exit(1);
	}

	free(a1);

	a3 = (char *)malloc(92);
	if(a3 == NULL)
	{
		fprintf(stderr,"call to malloc(92) failed\n");
		fflush(stderr);
		exit(1);
	}

	a4 = (char *)malloc(32);
	if(a4 == NULL)
	{
		fprintf(stderr,"second call to malloc(92) failed\n");
		fflush(stderr);
		exit(1);
	}

	/*
	 * free it all -- notice that a1 is already free
	 */
	free(a2);
	free(a3);
	free(a4);

    puts("No crash");
	return(0);
}

	

