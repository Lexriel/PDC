#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include "malloc.h"

void* getFromTop(unsigned size);
void _init_malloc();
void* big_alloc(unsigned size);
void expand_heap();

void validate_free_list()
{
    if (!ListHints)
    {
        fprintf(stderr, "No listhints. Aborting.");
        abort();
    }
}

void* malloc(unsigned size)
{
    int i = 0;
    unsigned entry = size;
    char *ret = NULL;
    if (!ListHints)
    {
        _init_malloc();
    }
    while (!entry % 8)
        ++entry;
    entry /= 8;
    //printf("[malloc]entry for size %d is %d\n", size, entry);
    if (entry >= N_LIST_ENTRY) 
    {
        ret = big_alloc(size + sizeof(_CHUNK_HEADER));
        if (!ret)
        {
            puts("Out of memory");

            return NULL;
        }
        ((_CHUNK_HEADER*)ret)->cookie = 0xDEADBEEF;
        ((_CHUNK_HEADER*)ret)->size = size;
        return ret + sizeof(_CHUNK_HEADER);
    }
    for (i = entry; i < N_LIST_ENTRY; ++i)
    {
        if ((ListHints[i].flink) != NULL)
        {
            ret = (char*)ListHints[i].flink;
            if ((ListHints[i].flink)->flink != NULL)
            {
                ListHints[i].flink = (ListHints[i].flink)->flink;
            }
            else
            {
                ListHints[i].flink = NULL;
            }

            ((_CHUNK_HEADER*)ret)->cookie = 0xDEADBEEF;
            ((_CHUNK_HEADER*)ret)->size = size;
            ((_CHUNK_HEADER*)ret)->is_free = 0;
            return ret + sizeof(_CHUNK_HEADER);
        }
    }
    //printf("Getting from top (%d)\n", avl_from_top);
    ret = getFromTop(size + sizeof(_CHUNK_HEADER));
    //printf("%p\n", ret);
    if (!ret)
    {
        puts("Out of memory");
        exit(1);
    }
    ((_CHUNK_HEADER*)ret)->cookie = 0xDEADBEEF;
    ((_CHUNK_HEADER*)ret)->size = size;
    ((_CHUNK_HEADER*)ret)->is_free = 0;
    return ret + sizeof(_CHUNK_HEADER);
}

void* getFromTop(unsigned size)
{
    char *ret;
    ret = topchunk;
    if (avl_from_top < size)
    {
        expand_heap();
    }
    topchunk += size;
    avl_from_top -= size;
    return ret;
}

void expand_heap()
{
    topchunk = sbrk(50000);
    avl_from_top = 50000;
}

void* big_alloc(unsigned size)
{
    int* ret;
    ret = sbrk(size);
    return ret;
}

void free(void* ptr)
{
    if (!ptr)
        return;
    char *ret = ptr;
    ret -= sizeof(_CHUNK_HEADER);
    unsigned entry = ((_CHUNK_HEADER*)ret)->size;
    if (((_CHUNK_HEADER*)ret)->cookie != 0xDEADBEEF)
    {
        fprintf(stderr, "Corrupted chunk. Aborting\n");
        abort();
    }
    if (((_CHUNK_HEADER*)ret)->is_free)
    {
        fprintf(stderr, "Double free detected. Aborting\n");
        abort();
    }
    ((_CHUNK_HEADER*)ret)->is_free = 1;
    while (!entry % 8)
        ++entry;
    entry /= 8;
    if (entry >= N_LIST_ENTRY)
    {
        puts("big free");
        return;
    }
    //printf("[free]entry for %p is %d\n", ptr, entry);
    ((_LIST_ENTRY*)ret)->flink = ListHints[entry].flink;
    ListHints[entry].flink = (_LIST_ENTRY*)ret;
}

int mallopt(int cmd, int val)
{
}

void* getProgramBreak()
{
    return sbrk(0);
}

/*__attribute__((constructor))*/
void _init_malloc()
{
    int i = 0;
    //printf("%d\n", FIRST_ALLOC);
    topchunk = sbrk(FIRST_ALLOC);
    //*((char*)topchunk+FIRST_ALLOC) = 0;
    if (topchunk < 0)
    {
        perror("Unable to init topchunk");
        exit(1);
    }
    avl_from_top = FIRST_ALLOC;
    ListHints = (_LIST_ENTRY*)topchunk;
    topchunk += N_LIST_ENTRY * sizeof(_LIST_ENTRY);
    avl_from_top -= N_LIST_ENTRY * sizeof(_LIST_ENTRY);
    //printf("%d\n", avl_from_top);
    //*((char*)topchunk+avl_from_top) = 0;
}
