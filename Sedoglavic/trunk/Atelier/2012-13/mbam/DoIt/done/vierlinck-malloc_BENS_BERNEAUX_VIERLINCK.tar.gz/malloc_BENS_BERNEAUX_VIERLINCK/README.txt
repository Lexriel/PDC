BENS Joffrey
BERNEAUX Denis
VIERLINCK Florian

GROUPE 5 - L3S5

/////////////////////////////////////
//////TP MALLOC//////////////////////
/////////////////////////////////////

	- Algorithme du malloc et de free = AlgoMalloc
	- Codage du malloc et de free = malloc.c
	- Dossier avec exemple = FichMalloc


REMARQUE :

Le malloc fonctionne avec une structure de donnée qui est stocké dans un tableau de taille prédéfini par un define.
malloc.c compile.




PS : explication du trinome.


			Le mariage d'un binome avec un monome (en toute légalité)

				Le binome VIERLINCK BERNEAUX apercut
				le binome BENS qui fut un monome,
				par grande bonté, ce dernier bonhomme,
				fut recueilli par les premiers hurluberlus.



				
				 


