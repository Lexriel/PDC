#define XOPEN_SOURCE 500
#define DEM_MEMOIRE 32768
#define NB_APPEL  100 
#include <unistd.h>
#include <stdio.h>


/*enumeration sur l'état d'une case du tableau*/
typedef enum {LIBRE, VERROU} cell_occup; 

/*structure permettant de gérer l'espace mémoire demandé par sbrk() = annuaire*/
struct cellule{
  char *debEspace;
  unsigned taille;
  cell_occup occupation;
};

/*création du tableau permettant de stocker les informations de chaque appel à malloc*/
static struct cellule tabAnnuaire[NB_APPEL];
/*stocke le nombre d'appel à malloc utilisant une nouvelle cellule du tableau*/
static int nb_malloc = 0;
/*stocke le nombre d'espece pris au pour le total des appels à malloc*/
static int taille_vide_mem = 0;
static char *debMem = NULL;

void
*db_malloc
(unsigned size)
{
  void *ptr;
  int indiceTab = 0;
  
  /*boucle de recherche : verifiant si un espace est libre et espace superieur ou egal à la taille demandé*/
  while((indiceTab < nb_malloc) && (tabAnnuaire[indiceTab].occupation != LIBRE) && (tabAnnuaire[indiceTab].taille <= size))
  {
     indiceTab++;
  }

  /*si OUI aucune case déjà crée est libre et permet de stocker la taille demandé*/
  if(indiceTab >= nb_malloc)
  {
     printf("Création d'une nouvelle case\n");
    /*SI le tableau possede encore des cases libres*/
    if(nb_malloc <= NB_APPEL)
    {
      /*Remplissage d'une nouvelle case du tableau*/
      tabAnnuaire[nb_malloc].debEspace = debMem;
      tabAnnuaire[nb_malloc].taille = size;
      tabAnnuaire[nb_malloc].occupation = VERROU;
      nb_malloc++;
    }
    /*test si la taille demandé est supérieur à l'espace mémoire qu'on possede du sbrk précédent*/
    if(taille_vide_mem < size)
    {
	debMem = sbrk(DEM_MEMOIRE); 
	taille_vide_mem = DEM_MEMOIRE;
    }
    ptr = debMem;
    debMem += size;

  }else{
      printf("Utilisation d'une case déjà existante\n");
    tabAnnuaire[indiceTab].occupation = VERROU;
    ptr = tabAnnuaire[nb_malloc].debEspace;
  }

  return ptr;
}




void
db_free
(void *ptr)
{
  int indiceTab = 0;
  /*boucle parcourant tout les cases du tableau*/
  while(indiceTab < nb_malloc)
  {
    /*test si la cellule correspond à l'adresse du parametre*/
    if(tabAnnuaire[indiceTab].debEspace == ptr)
    {
      tabAnnuaire[nb_malloc].occupation = LIBRE;
      printf("Libération d'un espace mémoire\n");
      return (void)1;
    }
    indiceTab++;
  }
  return (void)0;
}


int 
main(char * args[])
{
  void* valret;

  printf("DEBUT\n"); 
  printf("malloc de 30\n");
  db_malloc(30);
  printf("malloc de 50\n");
  valret = db_malloc(50);
  printf("malloc de 70\n");
  db_malloc(70);
  printf("free de 50\n");
  db_free(valret);
  printf("malloc de 50\n");
  db_malloc(90);
  printf("malloc de 10\n");
  db_malloc(10);

  printf("FIN\n");

  return 0;
}



