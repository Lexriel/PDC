/* ------------------------------
   $Id: tools.h,v 1.1 2005/11/24 14:28:58 marquet Exp $
   ------------------------------------------------------------

   MIsc utilities
   Philippe Marquet, Nov 2005
   
*/

#ifndef _TOOLS_H_
#define _TOOLS_H_

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif


#endif
