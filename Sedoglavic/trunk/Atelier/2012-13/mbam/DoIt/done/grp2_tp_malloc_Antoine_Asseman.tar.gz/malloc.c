/* groupe 2
 * Antoine Asseman
*/

#define _XOPEN_SOURCE 500	/* nécessaire pour utiliser sbrk mais placé dans les options de compilation */

#include<stdio.h>
#include<errno.h>
#include<unistd.h>		/* for sbrk */
#include<string.h>
#include<stdlib.h>

/* liste doublement chainée et non circulaire. sauvegarde les blocs mémoire déjà aloués (nécessaire pour libérer un bloc mémoire via free) */
struct memoryList{
	/* taille du bloc */
	int size;

	/* pointeur vers la zone mémoire */
	char* ptr;

	/* pointeur vers le bloc suivant */
	struct memoryList *next;

	/* bloc utilisé = 1
	 * bloc libre = 0
	 */
	unsigned short int used;
};


/*taille initiale du segment de données: 2^10
 * freeSize représente la quantité de mémoire du tas qui n'a pas encore été alouée (donc à la fin du tas)
 */
static long int freeSize = 1<<10;


/* segment de données utilisateur
 * le type char* est préféré à void* car il est impossible de faire de l'arithmétique de pointeurs de type void */
static char* tas = NULL;
static struct memoryList* tasBlocs = NULL;

/* contient l'ensemble des blocs mémoires aloués par l'utilisateur */
static struct memoryList* head;

void creerTas(int size)
{
	tasBlocs = (struct memoryList*)sbrk(size*sizeof(struct memoryList)); /* la structure de données a pour taille maximale celle d'un bloc multiplié par le nombre maximum de blocs (autant de blocs que d'unités de mémoire) */
	tas = (char*)sbrk(size);

	/* initialisation du premier bloc */
	head = tasBlocs;
	tasBlocs++;
	head->size = 0;
	head->next = NULL;
	head->used = 0;
}

void* creerBloc(size_t size)
{
	struct memoryList* blocIterator;
	struct memoryList* newBloc;

	blocIterator = head;
	while(blocIterator->next!=NULL) /* parcours de la liste */
	{
		if(!(blocIterator->used) && blocIterator->size >= size) /* un bloc libre et d'une taille suffisante est disponible */
		{
			if(blocIterator->size == size) /* un bloc de la taille exacte a été trouvé, parfait! */
			{
				blocIterator->used = 1;
				return blocIterator->ptr;
			}
			/* un bloc libre de taille supplémentaire a été trouvé
			 * il faut donc le diviser en deux: un nouveau bloc est ajouté juste après correspondant à la partie non utilisée */
			newBloc = tasBlocs; /* newBloc n'est pas aloué dans la mémoire locale mais dans celle réservée pour le stockage de la structure */
			tasBlocs++;
			newBloc->used = 0;
			newBloc->size = blocIterator->size - size;
			newBloc->next = blocIterator->next;
			newBloc->ptr = blocIterator->ptr+size;
			blocIterator->size = size;
			blocIterator->used = 1;
			blocIterator->next = newBloc;

			return blocIterator->ptr;
		}
		blocIterator = blocIterator->next;
	}

	/* aucun bloc libéré avec une taille suffisante n'est disponible, un nouveau bloc est créer à partir de la mémoire restante du tas */
	if(freeSize < size) /* la partie restante du tas est insuffisante */
	{
		printf("Error: not enough memory!\n(only %ld left...)", freeSize);
		return NULL;
	}

	if(head->used == 0 && head->next == NULL) /* la t?te n'est pas utilis?e */
	{
		head->ptr = tas;
		head->used = 1;
		head->size = size;
		head->next = NULL; /* pas n?cessaire mais au cas o?... */
		tas += size;
		freeSize-= size;

		return head->ptr;
	}
	/* sinon on ajoute un nouveau bloc dans la structure de données */
	newBloc = tasBlocs;
	tasBlocs++;
	newBloc->used = 1;
	newBloc->size = size;
	newBloc->ptr = tas;
	newBloc->next = NULL;
	blocIterator->next = newBloc;
	freeSize -= size;
	tas += size;

	return newBloc->ptr;
}

/* Redefinition of malloc () */
void * myMalloc (size_t size)
{
	if(tas==NULL) creerTas(freeSize); 

	return creerBloc(size);
}

/* Redefinition of free () */
void myFree (void *ptr) 
{
	struct memoryList* bloc;
	struct memoryList* blocPrecedent;

	bloc = head;
	blocPrecedent = bloc;
	while(bloc->ptr!=ptr && bloc->ptr-tas<0)
	{
		blocPrecedent = bloc;
		bloc = bloc->next;
	}

	if(bloc->ptr!=ptr)
	{
		printf("espace mémoire introuvable...\n");
		return;
	}
	/* désallocation de la mémoire */
	bloc->used = 0;
	if(!bloc->next) /* ce bloc est le dernier de la liste, on peut d?salouer le bloc ainsi que le tas */
	{
		blocPrecedent->next = NULL;
		bloc->size = 0; /* au cas o? le bloc pr?c?dent serait libre lui aussi */
		tasBlocs--;
		tas-=bloc->size;
	}
	else if(!bloc->next->used) /* le bloc suivant est libre, on peut le recoller avec le notre */
	{
		bloc->size += bloc->next->size;
		bloc->next = bloc->next->next;
	}
	/* le bloc pr?c?dent est libre, on peut le recoller avec le notre */
	if(!blocPrecedent->used)
	{
		blocPrecedent->size+=bloc->size;
		blocPrecedent->next = bloc->next;
		/* on remarque que si le bloc pr?c?dent est libre et que le bloc courrant est ? la fin de la liste, il reste un bloc vide ? la fin de la liste. Il pourra ?tre supprim? lorsque le bloc plac? avant lui sera d?salou?, sinon il sera utilis? et d?coup? lors du prochain appel ? malloc */
	}
}

void printDataStructure()
{
	struct memoryList *bloc;
	int i;

	bloc = head;
	i = 0;
	while(bloc!=NULL)
	{
		printf("bloc num?ro: %d\ntaille: %d\ndonn?es: %s\nused? %d\n\n",i,bloc->size,bloc->ptr,bloc->used);
		i++;
		bloc=bloc->next;
	}
}

int main(void)
{

	char *str, *str1, *str2, *str3;

	/* Un appel direct à malloc */
	str = myMalloc(strlen("contenu de str"));
	str = strcpy(str, "contenu de str"); 

	str1 = myMalloc(strlen("texte de str1")+10);
	str1 = strcpy(str1, "texte de str1"); 

	str2 = myMalloc(strlen("dans str2"));
	str2 = strcpy(str2, "dans str2"); 
	printf("il y a 3 blocs pour l'instant:\n");
	printDataStructure();

	myFree(str1);
	str3 = myMalloc(strlen("str3"));
	str3 = strcpy(str3, "str3"); 

	printf("on supprime le bloc 1 et on ins?re un autre bloc de taille inf?rieure. on constate qu'il se stocke dans le bloc 1 et qu'un bloc vide contenant le volume restant est ins?r? juste apr?s:\n");
	printDataStructure();

	myFree(str3);
	printf("on supprime ? nouveau le bloc 1 (il n'est pas plac? ? la fin):\n");
	printDataStructure();

	myFree(str2);
	printf("dernier bloc supprim?: les deux derniers blocs sont supprim?s\n");
	printDataStructure();
	exit(EXIT_SUCCESS);
}

