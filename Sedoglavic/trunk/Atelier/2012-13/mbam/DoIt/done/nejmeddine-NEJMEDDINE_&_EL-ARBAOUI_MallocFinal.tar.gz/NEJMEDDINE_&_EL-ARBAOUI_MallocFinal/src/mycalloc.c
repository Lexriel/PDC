#include <stdio.h>
#include <unistd.h>
#include <stdarg.h>
#include <stdlib.h>
#include "mymalloc.h"



/* Alloue l'espace nécessaire pour un tableau de  nb éléments chacun de taille size */
void * mycalloc (unsigned int nb, unsigned int size){
	return mymalloc((nb*size));
}
