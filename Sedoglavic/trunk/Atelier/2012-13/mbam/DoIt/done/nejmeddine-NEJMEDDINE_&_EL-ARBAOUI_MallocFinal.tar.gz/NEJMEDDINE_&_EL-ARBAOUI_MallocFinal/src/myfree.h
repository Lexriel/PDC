#ifndef MYFREE
    #define MYFREE 1

    /* Macros de remplacements */
    #define free(x)       myfree(x)

    /* Désalloue le pointeur passé en paramètre */
    /* Retourn RETURN_FAILURE en cas d'echec (ea: ce pointeur n'a jamais été alloué) */
    extern int myfree (void *pointeur);

#endif
