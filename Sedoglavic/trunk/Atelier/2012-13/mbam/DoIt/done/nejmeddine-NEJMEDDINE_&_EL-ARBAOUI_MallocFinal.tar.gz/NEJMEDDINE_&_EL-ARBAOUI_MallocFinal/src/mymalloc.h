#ifndef MYMALLOC
    #define MYMALLOC 1

    /* Macros de remplacements */
    #define malloc(a)     mymalloc(a)


    /* Retourne un pointeur de bloc d'au moins size octets.*/
    extern void *mymalloc (unsigned int size);

#endif
