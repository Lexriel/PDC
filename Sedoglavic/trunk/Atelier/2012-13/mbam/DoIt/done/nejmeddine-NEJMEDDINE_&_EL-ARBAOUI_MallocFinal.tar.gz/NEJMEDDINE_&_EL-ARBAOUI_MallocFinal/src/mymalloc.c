#include <stdio.h>
#include <unistd.h>
#include <stdarg.h>
#include <stdlib.h>
#include "memoryblock.h"


/* Alloue un pointeur de taille size et le renvoie */
void *mymalloc (unsigned int size){   
    block_t *blocdispo;
    unsigned int demandes_sup;
    void *newzone;
    void *res;

    int octet_en_plus;	/*octets libre allouer par sbrk en cas de non disponibilite de memoire*/
    if (size == 0) {
        return NULL;
    }
    
/*chercher le premier block libre de taille size*/
    blocdispo = freem_first_fit(size);

/*    si on trouve pas , on cherche*/  
    if (!blocdispo) {
        /* Le nombre de demandes qu'il faudra effectuer pour satisfaire size */
        demandes_sup = (size / BYTES_USER_MAX) +2  ;/* on a choisi +2, afin d eviter l appel du cout systeme!*/
	octet_en_plus =BYTES_USER_MAX * demandes_sup;
        /* on demande au systeme de nous donner plus de memoire grace au sbrk*/
        newzone = sbrk(octet_en_plus);
        freem_add(newzone, octet_en_plus);
        freem_clean();
        blocdispo = freem_first_fit(size);
    }

    busym_add(res = block_get_pointer(blocdispo), size);
    freem_reduce(blocdispo, size);

    return res;

}


