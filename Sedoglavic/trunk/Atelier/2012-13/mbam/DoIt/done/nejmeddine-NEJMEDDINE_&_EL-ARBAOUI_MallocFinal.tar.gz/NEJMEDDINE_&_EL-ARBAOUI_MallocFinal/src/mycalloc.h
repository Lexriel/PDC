#ifndef MYCALLOC
    #define MYCALLOC 1

    /* Macros de remplacements */
    #define calloc(x,y)   mycalloc(x,y)


    /* Alloue l'espace nécessaire pour un tableau de nmemb éléments de taille size */
    extern void *mycalloc (unsigned int nmemb, unsigned int size);

#endif
