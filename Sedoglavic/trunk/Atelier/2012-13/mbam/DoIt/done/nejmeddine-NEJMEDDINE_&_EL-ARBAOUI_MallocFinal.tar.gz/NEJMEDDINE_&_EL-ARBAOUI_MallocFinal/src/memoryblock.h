
#ifndef MEMORYBLOCK
    #define MEMORYBLOCK 1
    #define BYTES_USER_MAX 10000 /* (10ko avec ko -> 1000o) nombres d octets max que l utilisateur epeut demander*/

    #define ECHEC 0
    #define SUCCES 1
    
    /* definition De la structure  BLOC */
    struct block_m
    {
        unsigned int size;       /* Taille du bloc */   
        void * content;          /* Pointeur vers la zone mémoire  */ 
        struct block_m * prev;   /* Pointeur vers le bloc précédent */
        struct block_m * next;   /* Pointeur vers le bloc suivant */
    };

    typedef struct block_m block_t;

    /*defintion de la structure d'une liste des blocs */
    struct block_list_m {
        block_t *first;
        block_t *last;
    };

    typedef struct block_list_m   block_list_t;
  
    
                         /* SPECIFICATION DES FONCTIONS */

/*---------------------------------------------------------------------------------------------------------------*/
                  /* Fonctions primitives et auxiliares pour gerer un block*/
/*---------------------------------------------------------------------------------------------------------------*/


/* Crée une nouvelle cellule, avec le contenu passé en paramètre. */
    extern block_t *newblock(void *, unsigned int );

/* Détermine si "" est dans "" */
    extern int block_list_is_exist(block_list_t *, block_t *);
    
/* Détermine si la liste est vide ou non */
    extern int block_list_is_free(block_list_t *);

/* Ajoute un bloc en tête de liste */
    extern void block_list_fist_add(block_list_t *, block_t *);

/* Ajoute un bloc en fin de liste */
    extern void block_list_last_add(block_list_t *, block_t *);


/* Insère "" après "" dans "". 
 * Retourne ECHEC si "" n'est pas présent dans "".
 */
    extern int block_list_block_insert_after (block_list_t *, block_t *, block_t *);

/* Insère "" avant "" dans ""
 * Retourne ECHEC si "" n'est pas présent dans "".
 */
    extern int block_list_block_insert_before (block_list_t *, block_t *, block_t *);
    
/* Supprime "" de "".
   Retourne ECHEC si "" n'appartient pas à "".
*/
    extern int block_list_block_del(block_list_t *, block_t *);
    
/* 
    Affiche l'état de la liste 
*/
    extern void list_block_print (block_list_t *);

/*
    Renvoie le pointeur associé à ce bloc
*/
    extern void *block_get_pointer (block_t *); 

/*
    Renvoie la taille associée à ce bloc
*/
    extern unsigned int get_size (block_t *);

    /* Affiche sur la sortie standard l'état de la memoire (le parametre de cette fonction definnit le type de la memoire a fficher */
    extern void memory_print(int);
/*---------------------------------------------------------------------------------------------------------------*/
                                       /*gestions des blocks libres*/
/*---------------------------------------------------------------------------------------------------------------*/

/* Ajoute un nouveau bloc de mémoire libre, pointant vers pointeur et de taille size. */
/* Retourne le dit bloc */
extern block_t *freem_add(void *pointeur, unsigned int size);

/* Ajoute le bloc à la liste de blocs de mémoire libre. */
extern void freem_block_add(block_t *);

/* Supprime le bloc passé en paramètre. Retourne ECHEC si  n'existe pas */
extern int freem_block_del(block_t *);

/* Trouve et renvoie la première cellule libre dont le bloc a une taille suffisante pour contenir size */
extern block_t *freem_first_fit(unsigned int size);

/* diminuer l'espace disponible de ce bloc de *size* octets. Cette opération peut donc supprimer le bloc.
Peut retourner ECHEC en cas d'erreur. (size trop grand, par ex)*/
extern int freem_reduce(block_t *, unsigned int size);

/* Effectue la fusion entre les blocs de mémoires contigus */
extern void freem_clean();




/*---------------------------------------------------------------------------------------------------------------*/
				  /* gestions des blocks occupés*/
/*---------------------------------------------------------------------------------------------------------------*/

/* Ajoute un nouveau bloc de mémoire allouée, pointant vers pointeur et de taille size. */
extern block_t *busym_add(void *pointeur, unsigned int size);

/* Ajoute le bloc à la liste de blocs de mémoire allouée. */
extern void busym_block_add(block_t *);

/* Supprime le bloc passé en paramètre. Retourne ECHEC si  n'existe pas */
extern int busym_block_del(block_t *);

/* Renvoie le block_t dont le pointeur est égal à celui passé en paramètre. Renvoie NULL si une telle block_t n'existe pas */
extern block_t *busym_search(void * pointeur);


#endif
