/* 
	Schepens Mathieu -- Souiki Adam -- L3 Groupe 5
	Projet malloc 
*/

#ifndef MS_AS_MALLOC_H_
#define MS_AS_MALLOC_H_

/* malloc() and free() replacement */
void *
notreMalloc (size_t size);

void
notreFree (void *ptr);

void *
notreCAlloc(size_t nmemb, size_t size);

void *
notreRealloc(void *ptr, size_t size);

/* malloc and free as wrappers */
#define malloc(sz)      		notreMalloc(sz)
#define free(ptr)      			notreFree(ptr)
#define calloc(nmemb,size)		notreCAlloc(nmemb,size)
#define realloc(ptr,size)		notreRealloc(ptr,size)
#define mallopt(param,value)	notreMallopt(param, value)

#endif
