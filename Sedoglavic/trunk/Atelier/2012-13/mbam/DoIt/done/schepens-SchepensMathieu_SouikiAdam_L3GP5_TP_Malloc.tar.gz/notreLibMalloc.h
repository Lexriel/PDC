/* 
	Schepens Mathieu -- Souiki Adam -- L3 Groupe 5
	Projet malloc 
*/

#ifndef MS_AS_MALLOC_H_
#define MS_AS_MALLOC_H_

/* malloc() and free() replacement */
void *
notreMalloc (size_t size,	/* as in malloc() */
	    char *filename,	/* source filename of the function call */
	    unsigned line); 	/* source line number of the f. call */

void
notreFree (void *ptr,		/* as in free() */
	  char *filename,	/* filename and line of the call */
	  unsigned line);

/* malloc and free as wrappers */
#define malloc(sz)      notreMalloc(sz, __FILE__, __LINE__)
#define free(ptr)       notreFree(ptr, __FILE__, __LINE__)

#endif
