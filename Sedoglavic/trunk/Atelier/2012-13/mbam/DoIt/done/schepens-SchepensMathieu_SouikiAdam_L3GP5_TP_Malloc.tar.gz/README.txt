/* 
	Schepens Mathieu -- Souiki Adam -- L3 Groupe 5
	Projet malloc 
*/

Malloc, free, realloc, calloc, mallopt sont fonctionnels (même si mallopt est fait tres brievement en raison de la facon dont nous avons code le reste.
Malloc est fonctionnel, divers tests ont ete effectues et cela semble fonctionner.

Exemples de commandes reussissant parfaitement :
ls, firefox, firefox &, clear, cd, mkdir, rmdir, rm, ...

Exemple de commandes reussissant mais avec affichage de message d'erreur (printf de notre malloc) :
cp blabla blabla2
xeyes & 

Exemples de commande ne reussissant pas, mais ne generant pas de message d'erreur :
man ls
grep include malloc.c
gedit, gedit &

Exemples de commandes echouant :
Auto-completion quand on rentre une commande, emacs &, et probablement d'autres.

