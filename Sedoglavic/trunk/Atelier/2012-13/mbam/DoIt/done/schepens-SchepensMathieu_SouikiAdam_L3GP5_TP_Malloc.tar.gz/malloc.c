/* 
	Schepens Mathieu -- Souiki Adam -- L3 Groupe 5
	Projet malloc 
*/

#include <stddef.h>		/* for size_t */
#include "notreMalloc.h"

/* Forget definition of malloc wrappers */
#ifdef malloc
#undef malloc
#undef free
#undef calloc
#undef realloc
#undef mallopt
#endif

/* Redefinition of malloc () */
void *
malloc (size_t size)
{
    return notreMalloc(size); 
}

/* Redefinition of free () */
void
free (void *ptr) 
{
    notreFree(ptr); 
}

/* Redefinition of calloc () */
void *
calloc(size_t nmemb, size_t size)
{
	notreCAlloc(nmemb,size);
}

/* Redefinition of realloc */
void *
realloc(void *ptr, size_t size)
{
	notreRealloc(ptr,size);
}

/*Redefinition of mallopt */
int mallopt (int param, int value)
{
	notreMallopt(param,value);
}
