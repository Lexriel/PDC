/* 
	Schepens Mathieu -- Souiki Adam -- L3 Groupe 5
	Projet malloc 
*/

/*
 * Nombre d'octets a reserver en memoire pour l'utilisateur
*/
#define NB_OCTETS_A_RESERVER 1048576

/*
 * Taille de l'espace mémoire mis dans une cellule
*/
#define TAILLE_PTR_CELLULE 8

/*
 * Pour que sbrk ne pose pas probleme
*/
#define _XOPEN_SOURCE 500

#include <unistd.h>


/*
 * Notre type cellule
*/
typedef struct cellule *cellule;

/*
 * Notre structure cellule, on fonctionne avec le systeme de listes :
 * *pointeur : le pointeur vers le bloc d'espace memoire allouable a l'utilisateur
 * next : la cellule suivante dans la liste
 * etat : l'etat de la cellule
 * nbOctetsDemandes : le nombre d'octets demandes par l'utilisateur lors de l'appel a malloc
*/
struct cellule
{
	void *pointeur;
	cellule next;
	int nbOctetsDemandes;
};

/* 
 * Notre liste de cellules
*/
static cellule liste = NULL;

/* 
 * Fonction qui prend en parametre un entier, et retourne la cellule d'indice i dans la liste
 * L'indice commence a 0 
*/
cellule getCellule(int i)
{
	cellule c=liste;
	int cpt=0;

	while(c)
	{
		if(cpt==i)
			return c;
		c=c->next;
		cpt++;
	}
	return NULL;
}

/* 
 * Fonction qui prend en parametre un pointeur, et retourne la cellule qui a ce pointeur en attribut
*/
cellule getCelluleAvecPointeur(void * pointeurATrouver)
{
	cellule c=liste;

	while(c)
	{
		if(c->pointeur==pointeurATrouver)
			return c;
		c=c->next;
	}
	return NULL;
}

/*
 * Methode qui prend en parametre une cellule, retourne l'attribut pointeur de cette cellule
*/
void* getPointeur(cellule c)
{
	return c->pointeur;
}

/*
 * Methode qui prend en parametre une cellule, retourne l'attribut nbOctetsDemandes de cette cellule
*/
int getNbOctetsDemandes(cellule c)
{
	return c->nbOctetsDemandes;
}

/*
 * Methode qui prend en parametre une cellule, un nouveau nombre, 
 * et modifie l'attribut nbOctetsDemandes de cette cellule en fonction du nouveau nombre
*/
void setNbOctetsDemandes(cellule c, int nouvNb)
{
	c->nbOctetsDemandes=nouvNb;
}

/*
 * Fonction qui retourne la taille de notre liste
*/
int size()
{
	int cpt=0;
	cellule c = liste;
	while(c)
	{
		cpt++;
		c=c->next;
	}
	return cpt;
}

/* 
 * Fonction qui prend en parametre le nombre d'octets demandes par l'utilisateur lors de l'appel a malloc
 * Retourne la premiere cellule qui dispose d'un espace libre suffisant
*/
cellule recupererPremiereCelluleDEspaceLibreSuffisant(size_t nbOctetsDemandes)
{
	int cpt=0;
	cellule c = liste;
	cellule ret=NULL;
	int espaceRestantAVerifier=nbOctetsDemandes;
	while(c)
	{
		if(espaceRestantAVerifier<=0)
		{
			return ret;
		}
		if(isFree(c))
		{
			if(ret==NULL)
			{
				ret=c;
				espaceRestantAVerifier-=TAILLE_PTR_CELLULE;
			}
			else
			{
				espaceRestantAVerifier-=TAILLE_PTR_CELLULE;
			}
		}
		else
		{
			ret=NULL;
		}
		c=c->next;
		cpt++;
	}
		if(espaceRestantAVerifier<=0)
		{
			return ret;
		}
		return NULL;
}

/* 
 * Fonction qui prend en parametre le nombre d'octets demandes par l'utilisateur lors de l'appel a malloc
 * Retourne le nombre de cellule(s) requis pour avoir suffisamment d'espace
*/
int nbCellulesRequises(int nbOct)
{
	if(nbOct%TAILLE_PTR_CELLULE==0)
		return nbOct/TAILLE_PTR_CELLULE;
	return nbOct/TAILLE_PTR_CELLULE +1;
}

/*
 * Fonction qui prend en parametre une cellule c
 * Retourne 0 si getNbOctetsDemandes(c) est negatif (donc cellule libre), une autre valeur sinon
 */
int isFree(cellule c)
{
	return getNbOctetsDemandes(c)<0;
}

/* 
 * Methode qui initialise la liste de cellules
*/
void initListe()
{
	int nbOctetsAReserverPourUneCellule = sizeof(void *)+sizeof(cellule*)+sizeof(int);
	int nbCellulesACreer = (NB_OCTETS_A_RESERVER/TAILLE_PTR_CELLULE)+1;
	void * pointeurEspaceMemoireListe = sbrk(nbOctetsAReserverPourUneCellule*nbCellulesACreer);
	void * pointeurEspaceMemoireUtilisateur = sbrk(NB_OCTETS_A_RESERVER);
	
	liste = pointeurEspaceMemoireListe;
	cellule celluleALaquelleRajouterUneCelluleSuivante = liste;
	
	int i;
	for(i=0;i<nbCellulesACreer;i++)
	{
		celluleALaquelleRajouterUneCelluleSuivante->pointeur=pointeurEspaceMemoireUtilisateur+i*TAILLE_PTR_CELLULE;
		celluleALaquelleRajouterUneCelluleSuivante->nbOctetsDemandes=-1;
		if(i==nbCellulesACreer-1)
		{
			celluleALaquelleRajouterUneCelluleSuivante->next=NULL;
		}
		else
		{
			celluleALaquelleRajouterUneCelluleSuivante->next=pointeurEspaceMemoireListe+nbOctetsAReserverPourUneCellule*i;
		}
		celluleALaquelleRajouterUneCelluleSuivante=celluleALaquelleRajouterUneCelluleSuivante->next;
	}
}

/* 
 * Notre malloc :
 * Prend en parametre le nombre d'octets demandes par l'utilisateur
 * Renvoie un pointeur vers le debut de l'espace memoire attribue a l'utilisateur
 * Renvoie NULL s'il ne peut pas allouer d'espace a l'utilisateur
*/
void *notreMalloc(size_t nbOct)
{
	if(nbOct==0)
	{
		return;
	}
	
	/* Si la liste n'est pas deja cree, on la cree */
	if(liste==NULL)
		initListe();
		
	/* On stocke le nombre de cellules requises, et on recupere la premiere cellule */
	
	int nbCellules = nbCellulesRequises(nbOct);
	cellule c =  recupererPremiereCelluleDEspaceLibreSuffisant(nbOct);
	
	/* Si cette cellule vaut NULL, pas assez d'espace pour attribuer a l'utilisateur le nombre d'octets souhaites */
	if(c==NULL)
	{
		printf("ERREUR : Pas d'espace suffisamment grand pour stocker %d octets \n", nbOct);
		return NULL;
	}
	size_t i;
	
	/* Cellule qui va parcourir les cellules a attribuer et remplacer les nbOctetsDemandes */
	cellule parcourir=c;
	
	/* On va parcourir les cellules afin de changer l'etat en utilise */
	for(i=0;i<nbCellules;i++)
	{
		setNbOctetsDemandes(parcourir,nbOct-i*TAILLE_PTR_CELLULE);
		parcourir=parcourir->next;
	}
	
	/* On retourne le pointeur de la premier cellule d'espace disponible suffisant */
	return c->pointeur;
}

/* 
 * Notre free :
 * Prend en parametre un pointeur
 * Affiche une erreur si le pointeur donne n'est pas attribue
*/
void notreFree(void * ptr)
{
	if(!ptr)
	{
		return;
	}
	/* Si la liste vaut NULL, elle n'a pas ete cree -> pas d'appel a malloc auparavant */
	if(liste==NULL)
	{
		printf("ERREUR : PAS DE MALLOC FAIT AUPARAVANT !!! \n");
		return;
	}
	
	/* On recupere la cellule qui a en attribut ce pointeur */
	cellule c =  getCelluleAvecPointeur(ptr);
	
	/* Si cette cellule vaut NULL -> Ce pointeur n'a pas ete delivre a l'utilisateur */
	if(c==NULL)
	{
		printf("ERREUR : Vous essayez de liberer un pointeur non delivre par une fonction d'allocation memoire, pointeur problematique : %p \n",ptr);
		return;
	}
	if(isFree(c))
	{
		printf("ERREUR : Cellule deja liberee ... \n");
		return;
	}
	/* On recupere le nombre de cellules requises pour l'espace qui avait ete demande lors de la "reservation" de cette cellule */
	int nbCellulesReservees = nbCellulesRequises(getNbOctetsDemandes(c));
	int i;
	
	/* Pour chaque cellule dans celles qui etaient reservees pour l'appel a malloc correspondant
	 * On met l'etat de la cellule a libre, et on reinitialise l'attribut nbOctetsDemandes */
	for(i=0;i<nbCellulesReservees;i++)
	{
		setNbOctetsDemandes(c,-1);
		c=c->next;
	}
	
	return;
}

/*
 * Notre calloc, prend en parametre le nombre de membres pour lesquels il faut reserver une memoire de size octets
 * Renvoie un pointeur sur le premier octet de la zone attribuee a l'utilisateur
 */
void *notreCAlloc(size_t nmemb, size_t size)
{
	size_t produit = nmemb*size;
	void *ptr = notreMalloc(produit);
		
	int i,j;
	
	for(i=0;i<produit;i++)
	{
		char *ecr=ptr;
		
		for(j=0;j<8;j++)
		{
			ecr[j]=0;
		}
	}
	return ptr;
}

/*
 * Notre realloc, prend en parametre le pointeur ptr pour lequel on veut reallouer la memoire, et la nouvelle size voulue
 * Renvoie un pointeur vers la zone memoire attribuee a l'utilisateur
 * On conserve ce qui etait ecrit sur un certain nombre d'octets, ce nombre etant min(ancienneSize,nouvelleSize)
 */
void *notreRealloc(void *ptr, size_t size)
{
	if(ptr==NULL)
	{
		return notreMalloc(size);
	}
	
	if(size==0)
	{
		notreFree(ptr);
		return;
	}
	
	int valeurMini = getNbOctetsDemandes(getCelluleAvecPointeur(ptr));
	
	if(valeurMini>size)
	{
		valeurMini=size;
	}
	notreFree(ptr);
	void * nouvPointeur=notreCAlloc(1,size);
	
	char *tab=nouvPointeur;
	char *tab2=ptr;
	
	
	int i,j;
	for(i=0;i<valeurMini;i++)
	{
		char *ecr=ptr;
		
		for(j=0;j<8;j++)
		{
			ecr[j]=0;
		}
	}
	
	return nouvPointeur;
}

/*
 * Notre mallopt, vu la conception de notre malloc, nous avons decide de retourner 1 par defaut
 */
int notreMallopt (int param, int value)
{
	return 1;
}

/*
 * Optimisations possible :
 * Supprimer l'etat, dire que ca depend de nbOctDemandes (si negatif alors libre, sinon utilisee)
 */
