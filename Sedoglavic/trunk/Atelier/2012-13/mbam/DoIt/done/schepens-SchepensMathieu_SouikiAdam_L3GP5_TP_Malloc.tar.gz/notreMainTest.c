/* 
	Schepens Mathieu -- Souiki Adam -- L3 Groupe 5
	Projet malloc 
*/

#define _XOPEN_SOURCE 500

#include <unistd.h>
#include "notreMalloc.h"

/* 
 * Notre main, fait divers tests
*/
int main(void)
{		
int cpt=1;
	
	notreFree(0);
	
	void * alloc1 = notreMalloc(8);
	void * alloc2 = notreMalloc(12);
	/*cellule c=liste;
	TESTS MALLOC ET FREE
	void * alloc2 = notreMalloc(32);
	void * alloc3 = notreMalloc(4);
	void * alloc4 = notreMalloc(12);
	void * alloc5 = notreMalloc(10);
	void * alloc6 = notreMalloc(20);
	void * alloc7 = notreMalloc(60);
	
	cellule c=liste;
	printf("AVANT FREE : \n");	
	while(c)
	{
		printf("Cellule %d : pointeur %p, adresseSuivant %p, etat ", cpt, c->pointeur, c->next);
		if(c->etat==CELL_FREE)
			printf("FREE ");
		else
			printf("USED ");
		printf(", nbOctDmdes : %d \n",c->nbOctetsDemandes);
		c=c->next;
		cpt++;
	}


	
	c=liste;
	cpt=1;
	notreFree(alloc2);
	notreFree(alloc4);

	printf("APRES FREE : \n");
	while(c)
	{
		printf("Cellule %d : pointeur %p, adresseSuivant %p, etat ", cpt, c->pointeur, c->next);
		if(c->etat==CELL_FREE)
			printf("FREE ");
		else
			printf("USED ");
		printf(", nbOctDmdes : %d \n",c->nbOctetsDemandes);
		c=c->next;
		cpt++;
	}



	void * alloc8 = notreMalloc(24);
	c=liste;
	cpt=1;
	printf("APRES DEUXIEME MALLOC : \n");

	while(c)
	{
		printf("Cellule %d : pointeur %p, adresseSuivant %p, etat ", cpt, c->pointeur, c->next);
		if(c->etat==CELL_FREE)
			printf("FREE ");
		else
			printf("USED ");
		printf(", nbOctDmdes : %d \n",c->nbOctetsDemandes); 
		c=c->next;
		cpt++;
	}
	
	notreFree((alloc8)+1);*/
	
	/* TEST CALLOC
	void * alloc9 = notreCAlloc(5,sizeof(int));
	int *tab=alloc9;
	printf("test 1 : %d %d %d %d %d \n", tab[0], tab[1], tab[2], tab[3], tab[4]);
	*/
	
	int *tabRealloc1=alloc1;
	tabRealloc1[0]=5;
	tabRealloc1[1]=7;
	
	/*c=liste;
	cpt=1;
	printf("APRES FREE PUIS CALLOC : \n");
	
	
	while(c)
	{
		printf("Cellule %d : pointeur %p, adresseSuivant %p, etat ", cpt, c->pointeur, c->next);
		if(c->etat==CELL_FREE)
			printf("FREE ");
		else
			printf("USED "); 
		printf(", nbOctDmdes : %d \n",c->nbOctetsDemandes);
		c=c->next;
		cpt++;
	}
	
	
	alloc1=notreRealloc(alloc1,24);
	int *tabRealloc2=alloc1;
	tabRealloc2[0]=5;
	printf("test 2 %p : %d\n", alloc1, tabRealloc2[0]);
	
	c=liste;
	cpt=1;
	printf("APRES REALLOC : \n");

	while(c)
	{
		printf("Cellule %d : pointeur %p, adresseSuivant %p, etat ", cpt, c->pointeur, c->next);
		if(c->etat==CELL_FREE)
			printf("FREE ");
		else
			printf("USED "); 
		printf(", nbOctDmdes : %d \n",c->nbOctetsDemandes);
		c=c->next;
		cpt++;
	}*/
		
	return 0;
}
