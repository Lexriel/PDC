#define _XOPEN_SOURCE 500
#define __USE_XOPEN_EXTENDED 1 

#include <unistd.h>
#include <stdio.h>
#include "alloc.h"

int main (void)
{
    display_memory_state () ; 

    int* ptr = my_malloc (10 * sizeof(int) ) ;

    display_memory_state () ;  

    int * blooo = my_malloc (20 * sizeof (int) ) ;

    display_memory_state () ;  

    int * bloo = my_malloc (20 * sizeof (int) ) ;

    display_memory_state () ;  

    int * blo = my_malloc (20 * sizeof (int) ) ;

    display_memory_state () ; 

    int * bl = my_malloc (20 * sizeof (int) ) ;

    display_memory_state () ; 

    my_free (blo) ;

    display_memory_state () ;   

    my_free (blooo) ;

    display_memory_state () ; 
  
    my_free (bloo) ;

    display_memory_state () ;  

    my_free (ptr) ;

    display_memory_state () ; 

    my_free (bl) ;

    display_memory_state () ; 

	return 0 ;
}

