#define _XOPEN_SOURCE 500
#define __USE_XOPEN_EXTENDED 1 

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stddef.h>
#include <stdbool.h>

#include "alloc.h"

typedef struct mem_bloc
{
	struct mem_bloc* next ;
    struct mem_bloc* prev ;
	size_t size ;
    bool free ;
    bool allocated_by_malloc ;
} mem_bloc ;

static mem_bloc* list_bloc = NULL ;
static bool first_malloc = true ;

void* my_malloc (unsigned int size)
{
    mem_bloc* prev = NULL ;
    mem_bloc* bloc = list_bloc ;
    while (bloc != NULL && (bloc->free == false || bloc->size < size) )
    {
        prev = bloc ;
        bloc = bloc->next ;
    } 

    if (bloc == NULL)
    {
        bloc = sbrk ( size + sizeof(mem_bloc) ) ; 
        if (bloc == NULL)
        {
            return NULL ; 
        }  

        if (first_malloc)
        {
            list_bloc = bloc ;
            first_malloc = false ;
        }      

        bloc->free = false ;
        bloc->size = size ;
        bloc->next = NULL ;
        bloc->prev = prev ;
        bloc->allocated_by_malloc = true ;

        if (bloc->prev != NULL)
        {
            bloc->prev->next = bloc ;
        }
    } 
    if (bloc->size == size)
    {
        bloc->free = false ;
        bloc->allocated_by_malloc = 1 ;
    }
    else
    {
        size_t old_size = bloc->size ;   
        mem_bloc* old_next = bloc->next ;     

        bloc->free = false ; 
        bloc->size = size ;
        bloc->next += sizeof(mem_bloc) + size ;
        bloc->allocated_by_malloc = true ;

        bloc->next->size = old_size - size ;
        bloc->next->free = true ;
        bloc->next->next = old_next ;
        bloc->prev->next = bloc ;
    }

    ++bloc ;

    /* amélioration n°2 : remplissage du segment retourné par malloc par des valeurs arbitraires */
    char* returned_mem = (char*) bloc ; 
    for (size_t i = 0 ; i < size ; ++i)
    {
        returned_mem[i] = (char) ((i>>1) * (i<<5) + i%5) ;
    }

    return (void*) bloc ;
}

void my_free (void* ptr)
{
    mem_bloc* bloc_ptr = (mem_bloc*) ptr ;
    mem_bloc* bloc = --bloc_ptr ;

    /* amelioration 1 : on vérifie que le bloc de mémoire rendu a bien étè alloué par malloc */
    if (bloc_ptr->allocated_by_malloc == false)
    {
        exit (EXIT_FAILURE);
    }

    bloc->free = true ;

    /* fusion des blocs pour réduire la fragmentation */
    if (bloc->prev != NULL && bloc->prev->free)
    {
        bloc->prev->size += bloc->size + sizeof(mem_bloc) ;
        bloc->prev->next = bloc->next ;
        if (bloc->next != NULL)
        {
            bloc->next->prev = bloc->prev ;
        }
        bloc = bloc->prev ;
    }
    if (bloc->next != NULL && bloc->next->free)
    {
        bloc->size += bloc->next->size + sizeof(mem_bloc) ;
        if (bloc->next != NULL)
        {
            bloc->next = bloc->next->next ;
            if (bloc->next != NULL)
            {
                bloc->next->prev = bloc ;
            }
        }
    }

    /* amélioration 4 : récriture du segment rendu pour éviter que le programmeur ne réutilise un segment déjà free */
    size_t size = bloc->size ;
    char* cptr = (char*) ++bloc ;   
 
    for (size_t i = 0 ; i < size ; ++i)
    {
        cptr[i] = (char) ((i>>1) * (i<<5) + i%5) ;
    }
}

void* my_calloc (unsigned int size)
{
    char* new = my_malloc (size) ;
    for (size_t i = 0 ; i < size ; ++i)
    {
        new[i] = 0 ;
    }    
    return (new);
}

void* my_realloc (void* source , unsigned int size)
{
    void* dest = my_malloc (size) ;
    mem_bloc* bloc_begin = (mem_bloc*) source ;
    memcpy (dest , source , (--bloc_begin)->size ) ;
    my_free (source) ;
    return dest ; 
}

/*

void* mallopt (int cmd, int val)
{
    if (cmd == M_MXFAST)
    {

    }
    else
    {
        malloc(M_NLBLOCKS) ;
    }

}

*/

void display_memory_state (void)
{
    mem_bloc* bloc = list_bloc ;
    while (bloc != NULL)
    {
        printf ("adresse du bloc : %p - libre : %d - taille : %d - next : %p - prev : %p - alloue par malloc : %d\n", (void*) bloc , bloc->free , bloc->size, (void*) bloc->next , (void*) bloc->prev , bloc->allocated_by_malloc) ;

        bloc = bloc->next ;
    }
    printf ("%s\n\n" , "NULL") ;
}

