#include <stdbool.h>

void* my_malloc (unsigned int size) ;

void* my_calloc (unsigned int size) ;

void* my_realloc (void* source , unsigned int size) ;

void my_free (void* ptr) ;

void* mallopt (unsigned int size) ;

void display_memory_state (void) ;

