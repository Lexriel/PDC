Le fichier nv_malloc.c contient les fonctions malloc et free qui marche et contient aussi un main qui permet de les tester
