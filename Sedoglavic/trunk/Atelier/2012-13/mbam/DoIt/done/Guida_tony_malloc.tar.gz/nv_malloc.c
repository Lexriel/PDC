#define _XOPEN_SOURCE 500
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#ifdef malloc
#undef malloc
#undef free
#endif

static void *memory=NULL;
static int full_size=0;
static int first_call=0;

/*la structure d'un block videc boolean 0 reserve 1 vide*/
struct chaine_de_block {
  int taille;
  struct chaine_de_block *suivant;
  int *debut;
  int vide;
};

/*le premier block de la chaine*/
struct chaine_de_block firstblock;
/*initialise la memoire*/
void initialisation_memoire(){
  memory=sbrk(1<<10);
}


/* si c'est le premier appelle on modifie first block et on incremente full_size verifier si full_size n'est pas dépasser*/
void *malloc(size_t size){
  if (first_call==0){
    printf("premier appel\n");
    firstblock.taille=size;
    firstblock.debut=memory;
    firstblock.suivant=NULL;
    firstblock.vide=0;
    full_size+=size;
    first_call=1;
printf("memory %p\n",memory);
    return firstblock.debut;
  }
else {
  int i=0;
  int taille_tmp;
  struct chaine_de_block *block_precedent=&firstblock;
  struct chaine_de_block nv_block;

  /*on cherche le dernier block ajoute ou un block vide avec la taille correspondante a size ou plus grand que size (partition des bloc vide)*/

  while (i==0){
    printf("recherche et de taille %i\n",block_precedent->taille);
    if (block_precedent->suivant!=NULL && block_precedent->vide==0){
      printf("pas encore trouver et ce block  \n ");
     block_precedent=block_precedent->suivant;
    }

    /*cas ou on a un block vide et que la taille est = a la taille du block*/
    else if(block_precedent->vide==1 && size== block_precedent->taille){
	printf("block vide et bonne taille\n");
      block_precedent->vide=0;
      full_size+=size;
      return block_precedent->debut;
    }

    /*cas ou un block vide et que la taille est < a la taille du block*/
    else if (block_precedent->vide==1 && size< block_precedent->taille){
      /*modification de la taille du block precedent, reserve et creation d'un nouveau block avec taille t_preced-size*/
printf("block vide et taille <\n");
      taille_tmp=block_precedent->taille;
      block_precedent->taille=size;
      block_precedent->vide=0;
      /*creation du nv_block avec la memoire vide restante*/
      nv_block.taille=taille_tmp-size;
      nv_block.debut=block_precedent->debut+block_precedent->taille;

      /*si le block precedent vide avait un suivant alors il faut le changer*/
      if (block_precedent->suivant!=NULL){
	nv_block.suivant=block_precedent->suivant;
	block_precedent->suivant=&nv_block;
      }
      else {
	block_precedent->suivant=&nv_block;
      }
      nv_block.vide=1;
      full_size+=size;
      return block_precedent->debut;
    }
    else if (block_precedent->vide==1 && size>block_precedent->taille){
      printf("pas encore trouver 2 dont la taille est %i et demande %i\n ",block_precedent->taille,size);
      block_precedent=block_precedent->suivant;
      }
    else {
      printf("trouver \n");
      i=1;
    }
  }
  nv_block.taille=size;
  nv_block.debut=block_precedent->debut+block_precedent->taille;
  block_precedent->suivant=&nv_block;
  nv_block.suivant=NULL;
  nv_block.vide=0;
  full_size+=size;
  printf("fin ini \n");
  printf("taille total est de %i \n",full_size);
  return nv_block.debut;
  }
}

/*my free*/
void free(void *ptr){
  /*chercher le block  avec le pointeur correspondant 
prendre sa taille
 */
  int i=0;
  struct chaine_de_block *block_precedent=&firstblock;
printf("le pointeur a chercher %p\n",ptr);
  while (i==0){
    printf("recherche free pour le pointeur  \n");
	
    if (block_precedent->debut!=ptr && block_precedent->suivant!=NULL){
	printf("block suivant\n");
     block_precedent=block_precedent->suivant;
    }
    else if (block_precedent->suivant==NULL){
      printf("Error unknow pointer\n");
      i=1;
    }
    else {
      printf("trouver et on nettoie\n");
      i=1;
      block_precedent->vide=1;
      full_size-=block_precedent->taille;
    }
  }
  printf("Free complete\n");
}

int main (void)
{
  char *truc;
  char *bidul;
  char *machin;
char *hahah;
  initialisation_memoire();
  truc= malloc(5);
  bidul=malloc(4);
  machin=malloc(10);
free(truc);
hahah=malloc(5);
  printf("%p et %p et %p\n",truc,bidul,machin);
printf("%p %p \n",truc,bidul);

/*
 freet(bidul);
 hahah=malloc(7);
printf("%p %p \n",truc,bidul);*/
  return 0;
}

/*a faire 
1 reussir a comprendre le *debut
2 tout reverfifier
*/
