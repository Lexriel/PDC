#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include "malloc.h"


#define MSIZE	100000
#define tBloc	sizeof(bloc_s)

typedef struct bloc_s bloc_s;
struct bloc_s{
	unsigned int size;
	struct bloc_s * next;
	unsigned int free;
};
	
static int first_call = TRUE;
/*premier élément de la liste chainée*/
static bloc_s * first;

static int nb_blocs = 1;

void * my_malloc(unsigned int size){

	unsigned int i;
	int trouve = FALSE;
	void * ptr;
	struct bloc_s * courant;

	/*premier appel à malloc*/
	if (first_call) {
		printf("Premier appel de malloc\n");
		first_call = FALSE;
		first = sbrk(MSIZE);

		printf("%p\n",(void*)first);
		printf("%p\n",(void*)(first+MSIZE));

		first->size=MSIZE - tBloc;
		first->next = first;
		first->free = TRUE;
	}
	courant = first;
	i=0;
	
	if(first_call)
		printf("first->size :%d\n",courant->size);
	printf("size : %d\n",size);
	
	/*On va parcourir tous les blocs et voir s'il y en a un libre de taille suffisante*/
	trouve=FALSE;
	while(!trouve){
		if(courant->size==size && courant->free==TRUE && i<nb_blocs){
			/*Si le bloc courant est de taille égale à la taille demandée*/
			trouve=TRUE;
		}
		else if(courant->size > (size + tBloc) && courant->free==TRUE && i<nb_blocs){
			/*Si la taille du bloc courant est supérieure à la taille demandée*/
			trouve=TRUE;
		}
		else if(i>=nb_blocs){
			/*Si aucun bloc ne satisfait la demande  */
			trouve=TRUE;
		}
		if(!trouve){
			i++;
			courant = courant->next;
		}
	}
	
	/*Si le bloc courant est de taille égale à la taille demandée*/
	if(courant->size==size && courant->free==TRUE && i<nb_blocs){
		courant->free = FALSE;
		ptr = (void*)(courant+tBloc);
	}
	/*Si la taille du bloc courant est supérieure à la taille demandée*/
	else if(courant->size > (size + tBloc) && courant->free==TRUE && i<nb_blocs){
		bloc_s* nouveau = (bloc_s*)(courant+tBloc+size) ;
		printf("%p\n",(void*)courant);
		printf("%p\n",(void*)nouveau);
		nouveau->size = courant->size - tBloc - size;
		courant->size = size;
		nouveau->next=courant->next;
		courant->next=nouveau;
		nouveau->free=TRUE;
		courant->free=FALSE;
		nb_blocs++;
		ptr = (void*)(courant+tBloc);
	}
	/*Si aucun bloc ne satisfait la demande */
	else if(i>=nb_blocs){
		bloc_s* nouveau = sbrk(MSIZE);
		printf("courant : %p\n",(void*)courant);
		printf("first : %p\n",(void*)first);
		printf("courant->next : %p\n",(void*)courant->next);
		printf("i : %d nbBlocs %d\n",i,nb_blocs);
		nouveau->size = MSIZE - tBloc;
		nouveau->free=TRUE;
		nouveau->next = first;
		courant->next = nouveau;
		nb_blocs++;

		printf("Nouveau : %p ; compare avec : %p\n",(void*)nouveau,(void*)(courant+tBloc+courant->size));
		if(courant->free==TRUE && nouveau == (bloc_s*)(courant+tBloc+courant->size)){
			courant->next=first;
			courant->size= courant->size+tBloc+nouveau->size;
		}
		return my_malloc(size);
	}
	else { printf("Ne rentre nulpart\n"); }
	return ptr;
}

void my_free(void* ptr){
	struct bloc_s * courant = first;
	struct bloc_s * precedent;
	unsigned int i = 0;
	while(ptr != (void*)(courant+tBloc) && i<nb_blocs){
		i++;
		precedent = courant ;
		courant = courant->next;
	}
	if(i>=nb_blocs)printf("Erreur free : bloc non trouvé\n");
	else {
		courant->free=TRUE;
		/*Fusionne precedent et courant*/
		if(precedent->free==TRUE && courant==(bloc_s*)(precedent+tBloc+precedent->size)){
			if(courant==first)first=precedent;
			precedent->next=courant->next;
			precedent->size= precedent->size+tBloc+courant->size;
			courant=precedent;
		}
		/*Fusionne next et courant*/
		if((courant->next)->free==TRUE && (courant->next)==(bloc_s*)(courant+tBloc+courant->size)){
			if((courant->next)==first)first=courant;
			courant->next=(courant->next)->next;
			courant->size= courant->size+tBloc+(courant->next)->size;
		}
		printf("Free OK\n");
	}
}

int main(void){
	int *a;
	int *b;
	
	a = my_malloc(sizeof(int));
	b = my_malloc(20*sizeof(int));    

	*a = 100;
	b[1]= 7;
	
	printf("%d\n",*a);
	printf("%d\n",b[1]);

	printf("Début free\n");
	my_free(a);
	my_free(b);
	return 0;
}
