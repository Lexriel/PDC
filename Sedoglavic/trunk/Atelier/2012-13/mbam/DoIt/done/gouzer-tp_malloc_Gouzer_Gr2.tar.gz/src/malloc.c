/***************************
 *                         *
 * Author : William GOUZER *
 * Date : 08/12/12         *
 * Groupe : 2              *
 * Project : Malloc        *
 *                         *
 ***************************/

#define _XOPEN_SOURCE 500
#define __USE_XOPEN_EXTENDED 1
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

/******************************
*******************************
**                           **
** IMPLEMENTATION OF MALLOC  **
**                           **
**                           **
*******************************
*******************************/

/* Structure representing a list of blocks for malloc */
typedef struct Block Block;
struct Block {
  size_t size;
  struct Block *next;
  struct Block *prev;
};

/* Structure which is used for memorising the blocks allocated by malloc */
typedef struct ListeOfMallocs ListeOfMallocs;
struct ListeOfMallocs {
  struct ListeOfMallocs *next;
  void *ptr;
};


/* Pointer to my structure of blocks */
Block *firstBlock;
/* Pointer to my structure which represents what malloc already gave to the user */
ListeOfMallocs *firstMalloc;
/* Pointer to my structure which represents what free keeps */
ListeOfMallocs *firstFree;

/* Default size of my blocks */
#define BIGBLOCK 1<<10


/* Prototypes of malloc */
void *my_malloc (unsigned);
Block *splitBlock(Block *, unsigned);
Block *increaseMemory(unsigned);
Block *searchBlock(unsigned);

/* Prototypes of free */
void my_free (void *ptr);
ListeOfMallocs* isPreviouslyAllocatedByMalloc (void *);
void addPreviouslyAllocatedByMalloc (void *);
ListeOfMallocs* createBlockAllocated (void);
void removePreviouslyAllocatedByMalloc (ListeOfMallocs *);
void addFreeBlock (ListeOfMallocs *);
int isThereABlockNearBy (void *);
void fusion (void *);
ListeOfMallocs *lastBlock (ListeOfMallocs *);


int main (void) {
  void *m10;
  void *m20;
  void *m30;
  void *m150;
  void *m500;
  void *m112;
  void *m11;

  puts("##### ALLOCATION OF 10");
  m10 = my_malloc(10);
  printf ("returnMalloc : %p\n\n",m10);

  puts("##### ALLOCATION OF 20");
  m20 = my_malloc(20);
  printf ("returnMalloc : %p\n\n",m20);

  puts("##### ALLOCATION OF 30");
  m30 = my_malloc(30);
  printf ("returnMalloc : %p\n\n",m30);

  puts("##### ALLOCATION OF 150");
  m150 = my_malloc(150);
  printf ("returnMalloc : %p\n\n",m150);

  puts("##### ALLOCATION OF 500");
  m500 = my_malloc(500);
  printf ("returnMalloc : %p\n\n",m500);

  puts("##### ALLOCATION OF 1<<12");
  m112 = my_malloc(1<<12);
  printf ("returnMalloc : %p\n\n",m112);

  puts("##### ALLOCATION OF 11");
  m11 = my_malloc(11);
  printf ("returnMalloc : %p\n\n",m11);

  return 0;
}

/**
 *
 **/
void *my_malloc (unsigned size) {
  Block *whatToSplit;

  /* search through my structure to find a block that can satisfy the size */
  /* will return null on echec */
  whatToSplit = searchBlock(size);

  if (whatToSplit==NULL) {
    /* Echec of the research or just empty list, so we'll increase the memory */
    puts("no need to search, it's null");
    whatToSplit = (void *) ((char *)increaseMemory(size) + sizeof(size_t)) ;

    addPreviouslyAllocatedByMalloc((void *)whatToSplit);
    return whatToSplit;
  }
  whatToSplit = (void *) ((char *)splitBlock(whatToSplit, size) + sizeof(size_t));

  addPreviouslyAllocatedByMalloc((void *)whatToSplit);
  return whatToSplit;
}

/**
 * This function will simply search through the list of blocks and try to find
 * a suitable block for the requested size.
 * - return NULL if the list is empty or none of the blocks are suitable
 * - return the first block it can find that fits the size + sizeof(size_t) constraint
 **/
Block *searchBlock(unsigned size) {
  Block* blockFound = firstBlock;

  puts("-- SEARCHBLOCK --");
  if (firstBlock==NULL)
    return NULL;

  do {
    blockFound = blockFound->next;
    if (blockFound->size >= (size + sizeof(size_t)) )
      return blockFound;
  } while (firstBlock!=blockFound);

  puts("search unsuccessful");
  return NULL;
}

/**
 * This function will try to increase the memory (the list of blocks)
 * and will let splitBlock operate the cutting of an oversize block.
 *
 * - return a new block of the desired size, either from a default allocation of BIGBLOCK
 * or a direct allocation by size
 **/
Block *increaseMemory(unsigned size) {
  Block *newBlock;
  puts("-- INCREASEMEMORY --");

  /* If the size ask by the user + the size of a size_t is */
  /* less than equal of the default block size, i'll do a classic malloc */
  if ( (size + sizeof(size_t) ) <= BIGBLOCK) {
    /* If the list is empty, we initialize it, set its prev/next and split the necessary size */
    if (firstBlock==NULL) {
      firstBlock = sbrk(BIGBLOCK);
      firstBlock->size = BIGBLOCK;
      firstBlock->next = firstBlock;
      firstBlock->prev = firstBlock;
      return splitBlock(firstBlock, size);
    }
    /* Almost the same situation except you also change its neighbors */
    else {
      newBlock = sbrk(BIGBLOCK);
      newBlock->size = BIGBLOCK;
      newBlock->next = firstBlock;
      newBlock->prev = firstBlock->prev;

      firstBlock->prev->next = newBlock;
      firstBlock->prev = newBlock;
      return splitBlock(newBlock, size);
    }
  }
  /* Equivalent to the else, the user asks too much, we'll do a specific allocation */
  puts("Big alloc");
  newBlock = sbrk(size + sizeof(size_t));
  newBlock->size = size + sizeof(size_t);
  return newBlock;
}

/**
 * This function will try various scenarios for cutting a block
 *
 * + There is enough space for a block left + its new structure :
 * that's the "default" case, we create a standard blockleft and a new block
 *
 * + There is just enough space for a block but not anything else :
 * we give all the block to the user anyway, the bytes left are not worth keeping and we'll
 * gain them back when the pointer will be freed, no need to sbrk in that case
 *
 * + Last case, we cut and just bypass the block from the list
 *
 *
 * - finaly, return a new block that fitted the above scenarios
 * Additionnal remark : there are of course little changes made when the block to split is the first
 * of the list
 **/
Block *splitBlock(Block *whatToSplit, unsigned size) {
  Block *blockLeft;
  int sizeBlockLeft, sizeBlockLeft_giveItAllAnyway;
  puts("-- SPLITBLOCK --");

  /* Space needed to create a block left + the full "cost" of another structure */
  sizeBlockLeft = whatToSplit->size - size - sizeof(Block);
  /* Space needed by the user and just size_t */
  sizeBlockLeft_giveItAllAnyway = whatToSplit->size - size - sizeof(size_t);


  /* If there is enough space to create a block left, we'll split and return what the user wants */
  if (sizeBlockLeft > 0) {
    blockLeft = (Block *) ((char *)whatToSplit + size + sizeof(size_t));
    blockLeft->size = whatToSplit->size - size - sizeof(size_t);

    if (whatToSplit==firstBlock && whatToSplit->next==firstBlock) {
      /* if it's the first block and is alone, we shrink it and redefine its next/previous */

      blockLeft->next = blockLeft;
      blockLeft->prev = blockLeft;
      firstBlock = blockLeft;
    }
    else if (whatToSplit==firstBlock && firstBlock->next!=firstBlock) {
      /* if it's the first block and is NOT alone, we shrink it, redefine its next/previous */
      /* and change where to neighbors link so they match up */
      firstBlock->next->prev = blockLeft;
      firstBlock->prev->next = blockLeft;

      blockLeft->next = firstBlock->next;
      blockLeft->prev = firstBlock->prev;
      firstBlock = blockLeft;
    }
    else {
      /* otherwise it's a classic swap, we redefine its next/previous and change the neighbors */
      blockLeft->next = whatToSplit->next;
      blockLeft->prev = whatToSplit->prev;

      whatToSplit->next->prev = blockLeft;
      whatToSplit->prev->next = blockLeft;
    }
  }
  /* If there is enough space for the user but not for storing the cost of another stucture, */
  /* we'll give it to the user anyway and it'll be re-gain when freed */
  else if ( (sizeBlockLeft<=0) && (sizeBlockLeft_giveItAllAnyway>=0) ) {

    if (whatToSplit==firstBlock && firstBlock->next==firstBlock) {
      /* There is only one block and we'll give it all, so we must set it to NULL */
      firstBlock->next = NULL;
      firstBlock->prev = NULL;
      firstBlock = NULL;
    }
    else if (whatToSplit==firstBlock && firstBlock->next!=firstBlock) {
      /* This is the first block but it's not alone, so we need to move the head */
      /* of the list and rebind the neighbors */
      firstBlock->next->prev = firstBlock->prev;
      firstBlock->prev->next = firstBlock->next;
      firstBlock = firstBlock->next;
    }
    else {
      /* simple case where you just bypass the block */
      whatToSplit->next->prev = firstBlock->prev;
      whatToSplit->prev->next = firstBlock->next;
    }
  }
  else {
    /* temporary else, we mustn't be in this function if we cannot split the block */
    /* but shit happens, so we should catch this potential error */
    exit(EXIT_FAILURE);
  }

  /* set the size and return it */
  whatToSplit->size = size + sizeof(size_t);
  return whatToSplit;
}


/**********************************************************************
***********************************************************************
**                                                                   **
** IMPLEMENTATION OF FREE                                            **
** this is NOT *producton ready*                                     **
**      ----------------------------------------                     **
* + Some functions are maybe redondant and not yet finished           * 
* but everything compiles and doesn't cause segmentation fault etc... *
* + This part is not well documented, but again it is not finished    *
*  and not yet completely understood;                                 *
*                                                                     *
**                                                                   **
***********************************************************************
*************************************/

/**
*
**/
void my_free (void *ptr) {
  return;
}

/**
 * This function test whether the block is part of a previously call to malloc or not.
 * - return the block previously allocated (if exists)
 * - otherwise, it will return null
 **/
ListeOfMallocs* isPreviouslyAllocatedByMalloc (void *bk) {
  ListeOfMallocs *it = firstMalloc;

  while (it != NULL) {
    if (it->ptr == bk)
      return it;
    it = it->next;
  }
  return NULL;
}

/**
 * Function that will add a block to the list of blocks allocated by malloc.
 *
 **/
void addPreviouslyAllocatedByMalloc (void *bk) {
  ListeOfMallocs *newBlock = createBlockAllocated();

  if (isPreviouslyAllocatedByMalloc(bk) == NULL) {
    newBlock->next = firstMalloc;
    newBlock->ptr = bk;
    firstMalloc = newBlock;
  }

  return;
}

/**
 * Function that will create a block of type ListeOfMallocs
 **/
ListeOfMallocs* createBlockAllocated(void) {
  ListeOfMallocs *newBlock;

  if (firstFree == NULL) {
    newBlock = (ListeOfMallocs *) sbrk(sizeof(ListeOfMallocs));
    return newBlock;
  }
  newBlock = firstFree;
  firstFree = firstFree->next;
  return newBlock;
}


/**
 * Function that will remove a block from the ListeOfMallocs
 **/
void removePreviouslyAllocatedByMalloc (ListeOfMallocs *bk) {
  ListeOfMallocs *it = firstMalloc;

  if (firstFree == NULL)
    return;

  if (firstMalloc == bk) {
    firstMalloc = firstMalloc->next;
    addFreeBlock(bk);
  }

  while (it->next != NULL) {
    if (it->next == bk) {
      it->next = bk->next;
      addFreeBlock(bk);
      return;
    }
    it = it->next;
  }
  return;
}

/**
 * Function that add the ListeOfMallocs bk to the list of free blocks
 *
 *
 **/
void addFreeBlock(ListeOfMallocs *bk) {

  if (firstFree != NULL) {
    bk->next = firstFree;
    firstFree = bk;
  }
  else {
    bk->next = NULL;
    firstFree = bk;
  }
}

/**
 * Function that will test if a block possesses another companion that it can fusion with
 **/
int isThereABlockNearBy (void *bk) {


  return 0;
}

/**
 * Function that will try to glue back together two adjacents blocks
 **/
void fusion (void *bk) {


  return;
}

/**
 * Function that will test if there is a last block and try to return it.
 * - return NULL if there is no block at all in the list
 * - otherwise return a pointer to the last block
 **/
ListeOfMallocs *lastBlock (ListeOfMallocs *liste) {
  ListeOfMallocs *nb = liste;

  if (firstMalloc==NULL)
    return NULL;
  while (nb != NULL)
    nb = nb->next;

  return nb;
}
