#ifndef MYMALLOC_H
#define MYMALLOC_H

#define _XOPEN_SOURCE 500
#define M_MXFAST 0
#define M_NLBLOCKS 100
void print_malloc_calls(void);
void myfree(void*, char*, unsigned);
void *mymalloc(size_t , char*, unsigned);
void * mycalloc (size_t, size_t, char*, unsigned );
void * myrealloc (void*, size_t, char*, unsigned);
int mallopt(int, int);

#define malloc(sz)      mymalloc(sz, __FILE__, __LINE__)
#define free(sz)      myfree(sz, __FILE__, __LINE__)
#define calloc(nb,sz)      mycalloc(nb,sz, __FILE__, __LINE__)
#define realloc(ptr,val)      myrealloc(ptr,val, __FILE__, __LINE__)

#endif
