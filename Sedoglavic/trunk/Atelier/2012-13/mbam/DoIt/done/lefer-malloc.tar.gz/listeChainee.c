/**
 * #=====================================
 * AUTHOR : LEFER Gregory
 * Bibliotheque d'allocation dynamique de memoire
 * #=====================================
 */
#define _XOPEN_SOURCE 500
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#include "listeChainee.h"

/* size to increment user memory space used by sbrk */
#define SIZEINCREASE 1024
/* permet de connaitre la taille de la liste s */
#define sizeOfList(l) sizeRec(l,l)
/* permet d'afficher la liste l*/
#define print_list(l) printList(l,l)
/* permet de savoir si  */
#define can_up(s) can_up_bloc(s,state.malloc_ptr)
/* taille maximal de l'historique des appels de malloc,free,calloc,realloc */
#define MAXCALL 100000


/* structure representing a cell of the list */
typedef struct bloc *bloc_t; 
struct bloc{
  size_t size;
  struct bloc *next;
  struct bloc *previous;
};

/* malloc_state va contenir le sdi */
typedef struct malloc_struct malloc_state;
struct malloc_struct
{
  /* gestion malloc */
  bloc_t malloc_ptr;
  
  /* gestion mallopt */
  bloc_t mallopt_ptr;
  size_t mxfast;
  size_t numblks;
  size_t locked;
  
};

enum  call_e {FREE_CALL, MALLOC_CALL,REALLOC_CALL,CALLOC_CALL}; 
struct call_s{
  char cl_file[100]; 
  unsigned int cl_line; 
  unsigned cl_size; 
  enum call_e cl_type;   
};

typedef struct bloc_renvoye *bloc_malloc;
struct bloc_renvoye{
  struct bloc_renvoye *next;
  void *ptr;
};

bloc_malloc malloced ;
bloc_malloc malloced_free;

malloc_state state; /* first free bloc */
static struct call_s malloc_calls[MAXCALL];
/* static bloc_t malloc_adresses = sbrk(MAXCALL * ); */
static int next_call = 0;
static int BREAK = 1;

/**
 * #=====================================
 * Permet d'afficher la liste de bloc à partir du bloc b
 * et s'arrete a la fin de la liste.
 * 
 * printList(b) :
 *   b : bloc a partir duquel on commence l'affichage
 * #=====================================
 */
void printList(bloc_t first, bloc_t list){
  if (list != NULL){
    /* fprintf (stdout,"\n>>bloc %p:\n", (void *) list); */
    fprintf (stdout,"  _size : %d\n",(int) list->size);

    /* fprintf (stdout,"  prev : %p\n", (void *) list->previous); */
    /* fprintf (stdout,"  next : %p\n\n", (void *) list->next); */
    if(list->next != first)
      printList(first,list->next);
    else{
      getchar();
    }
  }
}
/**
 * #=====================================
 * Fonction permettant de savoir si la liste envoye en parametre est correctement
 *  chainee
 *
 * chainage_ok(l) :
 *  l : liste dont on souhaite tester si le chainage est correct
 * #=====================================
 */
char chainage_ok(bloc_t liste){
  bloc_t tmp,first;

  if (liste == NULL)
    return 1;

  first = liste;
  tmp = liste;
  while(tmp->next != first){
    tmp = tmp->next;    
  }
  return 1;  
}



/**
 * #=====================================
 * Fonction permettant de savoir si le pointeur envoyé en paramétre est bien un pointeur
 *  qui a été envoyé par un appel de malloc
 *
 * is_malloced(ptr) :
 *  ptr : pointeur dont on souhaite savoir si il a été renvoyé par un appel de malloc 
 * #=====================================
 */
bloc_malloc is_malloced(void *ptr){
  bloc_malloc tmp;
  tmp = malloced;

  while ( tmp != NULL){
    if (ptr == tmp->ptr){
      return tmp;
    }
    tmp = tmp->next;
  }
  return NULL;
}

/**
 * #=====================================
 * Fonction permettant d'ajouter à la liste des blocs libérés
 *  le bloc b afin de conserver des blocs sans avoir besoin de
 *  refaire un sbrk
 *
 * first_malloced() :
 *  return : le premier bloc libre de la liste contenant les blocs libérés
 *            se trouvant dans malloced_free;
 * #=====================================
 */
bloc_malloc first_malloced(){
  bloc_malloc out;
  if ( malloced_free == NULL){
    out = (bloc_malloc)sbrk(sizeof(struct bloc_renvoye));
  }else{
    out = malloced_free;
    malloced_free = malloced_free->next;
  }
  return out;
    
}

/**
 * #=====================================
 * Fonction permettant d'ajouter à la liste des blocs libérés
 *  le bloc b afin de conserver des blocs sans avoir besoin de
 *  refaire un sbrk
 *
 * free_malloced(b) :
 *  b : bloc que l'on souhaite rajouter à la liste des blocs pouvant
 *       contenir les pointeurs renvoyés par malloc
 * #=====================================
 */
void free_malloced(bloc_malloc b){
  if (malloced_free == NULL){
    b->next = NULL;
    malloced_free = b;
  }else{
    b->next = malloced_free;
    malloced_free = b;
  }
}

/**
 * #=====================================
 * Fonction permettant d'insérer dans la liste des pointeurs renvoyés par
 *  malloc un nouveau bloc contenant le pointeur ptr
 *
 * insert_malloced(ptr) :
 *  ptr : pointeur renvoyé par malloc que l'on souhaite ajouter à la liste
 *         des pointeurs renvoyés par malloc
 * #=====================================
 */
void insert_malloced(void *ptr){
  bloc_malloc tmp;    
  tmp = first_malloced();

  if (is_malloced(ptr) == NULL){
    tmp->next = malloced;
    tmp->ptr = ptr;
    malloced = tmp;
  }
}

/**
 * #=====================================
 * Fonction permettant de retirer de la liste des pointeurs renvoyés par
 *  malloc le bloc envoyé en paramétre
 *
 * delete_malloced(b) :
 *   b : bloc de la liste que l'on souhaite supprimer
 * #=====================================
 */
void delete_malloced(bloc_malloc b){
  bloc_malloc tmp;
   
  if (malloced == NULL)
    return;
  
  if ( malloced == b){
    malloced = malloced->next;
    free_malloced(b);
    return;
  }
    /* tmp = b->next; */
  tmp = malloced;

  while (tmp->next != NULL){
    if (tmp->next == b){
      tmp->next = b->next;
      free_malloced(b);
      return;
    }
    tmp = tmp->next;
  }
  return;
}

/**
 * #=====================================
 * Fonction permettant de fusionner le bloc envoyé en parametre
 *  avec les blocs l'entourant si jamais ceci est necessaire.
 *
 * fusionner(b) :
 *   b : bloc de la liste que l'on souhaite fusionner avec ses voisins
 * #=====================================
 */
void fusionner(bloc_t b){
  bloc_t prev, next;
  prev = b->previous;
  next = b->next;

  /* fusion du bloc avec le suivant */
  if ( ( (char *) b + sizeof(size_t) + b->size ) == (char *)next &&  (b->size + sizeof(size_t) + next->size < 130000)){
    if (b->size + sizeof(size_t) + next->size > 130000)
      write(1,"over!\n",6);
    b->size = b->size + sizeof(size_t) + next->size ;
    (next->next)->previous = b;
    b->next = next->next;
  }

  /* fusion du bloc avec le precedent */
  if (((char *)prev + sizeof(size_t) + prev->size ) == (char *) b && (b->size + sizeof(size_t) + prev->size < 130000)){
    if (b->size + sizeof(size_t) + prev->size > 130000)
      write(1,"over!\n",6);
    prev->size = prev->size + sizeof(size_t) + b->size;
    prev->next = b->next;
    (b->next)->previous = prev;
  }
}

/**
 * #=====================================
 * Fonction renvoyant la taille d'une liste, cette fonction est appele
 *  par la fonction sizeOfList(bloc_t) se trouvant dans les defines
 *
 * sizeRec(f,l) :
 *   f : point de depart du parcours de la liste
 *   l : element courant lors du parcours de la liste
 * #=====================================
 */

int sizeRec(bloc_t first, bloc_t list){
  if (list == NULL)
    return 0;
  if ( list->next == first)
    return 1;
  return 1 + sizeRec(first,list->next); 
      
}


/**
 * #=====================================
 * Permet de récupérer le premier bloc assez grand
 * pour stocker size octets.
 *
 * first_free(size,chaine) :
 *   size   : taille du bloc que l'on souhaite
 *   chaine : premier bloc de la liste dans lequel on souhaite
 *            rechercher un bloc assez grand
 * #=====================================
 */
bloc_t first_free(int size, bloc_t chaine){
  if (chaine == NULL )
    return NULL;
  if ( chaine->size  >= size)
    return chaine;
  else if (chaine->next != state.malloc_ptr)     
    return first_free(size,chaine->next);
  else 
    return NULL;
}

/**
 * #=====================================
 * Methode pour supprimer le bloc envoye en parametre 
 * de la liste des blocs libres.
 *
 * remove_free(b) :
 *  b : bloc que l'on souhaite supprimer de la liste
 *      des blocs libres
 * #=====================================
 */
void remove_free(bloc_t b){
  bloc_t prev,next;
  if (state.malloc_ptr == NULL){
    return ;
  }

  if ( b == state.malloc_ptr && (state.malloc_ptr)->next == state.malloc_ptr){ 
    state.malloc_ptr = NULL;
  }
  else{
    prev = b->previous;
    next = b->next;
    prev->next = b->next;
    next->previous = b->previous;

    if (b == state.malloc_ptr)
      state.malloc_ptr = b->next;
  }  
}

/**
 * #=====================================
 * Permet d'inserer un bloc entre 2 autres blocs
 * 
 * inserer_between(b,p,n) :
 *   b : bloc que l'on souhaite inserer
 *   p : bloc se trouvant avant le bloc a inserer
 *   n : bloc se trouvant apres le bloc a inserer
 * #=====================================
 */
void inserer_between(bloc_t new_bloc, bloc_t prev, bloc_t next){
  
  if(new_bloc < state.malloc_ptr)
    state.malloc_ptr = new_bloc;
  new_bloc->next = next;
  new_bloc->previous = prev;
  prev->next = new_bloc;
  next->previous = new_bloc;
  fusionner(new_bloc);  
}

/**
 * #=====================================
 * Methode pour inserer un bloc dans la liste envoyee
 * en second parametre en respectant l'ordre des adresses memoires.
 *
 * inserer(b, lst) :
 *   b   : bloc a inserer dans la liste lst
 *   lst : premier element de la liste où inserer le bloc b 
 * #=====================================
 */
void inserer(bloc_t new_bloc , bloc_t list){
  if (list !=NULL){
   
    if (new_bloc < list){
      new_bloc->next = list;
      new_bloc->previous = list->previous;
 
      (list->previous)->next = new_bloc;
      list->previous = new_bloc;

      /* write(1,"w",1); */
      if (list == state.malloc_ptr)
	state.malloc_ptr = new_bloc;
      /* write(1,"x",1); */
      fusionner(new_bloc);
      return;
    }

    if (list->next == state.malloc_ptr){
      inserer_between(new_bloc,list, list->next);
    }
    else{
      
      inserer(new_bloc,list->next);
    }      
  }  
}

/**
 * #=====================================
 * Permet de decouper le bloc b en 2 blocs, le premier
 * bloc fera la taille donnee en second parametre si
 * il reste assez de place pour faire un deuxieme bloc
 * sinon on renvoi le bloc complet.
 *
 * cut_bloc(b,s) :
 *   b : bloc que l'on souhaite decouper
 *   s : taille du bloc que l'on souhaite recuperer
 * #=====================================
 */
void cut_bloc(bloc_t b, size_t s){
  bloc_t new;

  if ((b->size - s) > sizeof(struct bloc)){
    remove_free(b);
    new = (bloc_t)((char *)b + sizeof(size_t) + s);
    new->size = b->size - sizeof(size_t) - s;
    b->size = s;
    if (state.malloc_ptr == NULL){
      new->next = new;
      new->previous = new;
      state.malloc_ptr = new;
    }
    else{
      if (b == state.malloc_ptr){
  	new->next = b->next;
  	(new->next)->previous = new;
  	new->previous = b->previous;
  	(new->previous)->next = new;
  	state.malloc_ptr = new;
      }
      else
  	inserer(new,state.malloc_ptr);
    }
  }
  else{
    remove_free(b);
  }
  
}

/**
 * #=====================================
 * Permet d'augmenter le segment de memoire disponible pour
 * le programme et place le pointeur first a la position au debut
 * de la zone memoire libre.
 * #=====================================
 */
void increaseFreeMemory(size_t s){
  bloc_t last, new;

  if (s > SIZEINCREASE){
    new = sbrk(s + sizeof(size_t));
    new->size = s;
  }
  else{
    new = sbrk(SIZEINCREASE);
    new->size = SIZEINCREASE - sizeof(size_t);
  }

  if (state.malloc_ptr == NULL){
    state.malloc_ptr = new;
    (state.malloc_ptr)->next = state.malloc_ptr;
    (state.malloc_ptr)->previous = state.malloc_ptr;
  }
  else{
    last =  (state.malloc_ptr)->previous; /* on récupére le dernier bloc libre */
    if ( ((char *)last + sizeof(size_t) + last->size) == (char *)new)
      last->size = last->size + new->size + sizeof(size_t);
    else {
      inserer_between(new, last, last->next);
    }
  }

  /* print_list(state.malloc_ptr); */

}

/**
 * #=====================================
 * Fonction permettant d'initialiser un tableau de bloc
 *  avec state.numblks blocs de taille identique correspondant à 
 *  state.mxfast
 * #=====================================
 */
void init_mallopt(){
  size_t i, cellsize = 0;
  bloc_t tmp/* , old_malloc */;
  
  /* Si il reste des blocs libres dans le tableau associé à
     mallopt alors on ne fait rien */
  if (state.mallopt_ptr!=NULL)
    return ;

  /* Si jamais on n'a pas precise le nombre de blocs du tableau
     alors on utilise la taille par defaut */
  if (state.numblks == 0)
    state.numblks = M_NLBLOCKS;

  /* On calcul la taille des blocs du tableau*/
  /* Si la taille definit par l'utilisateur est inferieur à la taille
     necessaire pour stocker les pointeurs suivant et precedent alors
     on redefinit state.mxfast pour pouvoir les stocker */
  if (state.mxfast <= sizeof(struct bloc) - sizeof(size_t)){
    cellsize = sizeof(struct bloc) - sizeof(size_t);
    state.mxfast = sizeof(struct bloc) - sizeof(size_t);
  }
  else
    cellsize = state.mxfast;

  /* allocation de l'espace mémoire necessaire */
  /* old_malloc = state.malloc_ptr; */
  state.mallopt_ptr = sbrk((sizeof(size_t) + cellsize) * state.numblks);
  /* state.malloc_ptr = old_malloc; */

  /* chainage de la liste */
  /* creation des suivants */
  for (i=0;i < state.numblks-1; i++) {
    tmp = &state.mallopt_ptr[i];
    tmp->next = &state.mallopt_ptr[i+1];
    tmp->size = cellsize;
  }
  tmp = &state.mallopt_ptr[state.numblks-1];
  tmp->next = state.mallopt_ptr;
  tmp->size = cellsize;
  
  /* creation des precedents */
  for (i=1;i < state.numblks; i++) {
    tmp = &state.mallopt_ptr[i];
    tmp->previous = &state.mallopt_ptr[i-1];
  }
  tmp = state.mallopt_ptr;
  tmp->previous = &state.mallopt_ptr[state.numblks-1];

}

/**
 * #=====================================
 * Methode permettant de recuperer le premier bloc libre
 *  dans le tableau de blocs alloues pour malloc
 *
 * first_free_mallopt(void) :
 *   return le pointeur void correspondant au premier bloc libre
 * #=====================================
 */
void *first_free_mallopt(){
  bloc_t out;
  
  /* Si il n'y a pas de blocs disponible alors on cree un nouveau
     tableau de blocs et on verouille le mallopt */
  if (state.mallopt_ptr == NULL){
    init_mallopt();  
    /* On verouille mallopt pour ne plus pouvoir l'utiliser */  
    state.locked = 1;
  }
  
  /* on recupere le nouveau bloc libre */
  out = state.mallopt_ptr;

  /* Si le bloc retourne est le dernier alors on met le pointeur 
     du tableau a NULL sinon on reforme le maillage */
  if (out->next == out)
    state.mallopt_ptr = NULL;
  else{
    (out->next)->previous = out->previous;
    (out->previous)->next = out->next;
    state.mallopt_ptr = out->next;
  }

  return (void *) ((char *)out + sizeof(size_t));
}


/**
 * #=====================================
 * Methode pour renvoyer un pointeur void vers l'adresse
 * d'un segment memoire correspondant a la taille demande
 * par l'utilisateur
 *
 * malloc(size) :
 *   size : nombre d'octets que l'on souhaite utiliser
 * #=====================================
 */
void *mymalloc(size_t size, char *filename, unsigned line ){
  bloc_t out;
  void *out_mallopt;


  if (next_call < MAXCALL) {
    strncpy(malloc_calls[next_call].cl_file,
	    filename ? filename : "??",
	    100); 
    malloc_calls[next_call].cl_line = line; 
    malloc_calls[next_call].cl_size = size; 
    malloc_calls[next_call].cl_type = MALLOC_CALL;   
    next_call++;
  }


  /* Si la taille est inferieur à celle fixee pour le mallopt
     alors on retourne le premier bloc libre trouve */
  if ( size <= state.mxfast){

    out_mallopt = first_free_mallopt(size);
    insert_malloced(out_mallopt);

    return out_mallopt;
  }

  /* Si la taille ne permet pas de stocker les pointeurs suivant et
     precedent alors on donne un bloc d'une taille le permettant  */
  if (size < (sizeof(struct bloc) - sizeof(size_t)))
    size = (sizeof(struct bloc) - sizeof(size_t));

  /* Tant que l'on a pas trouve un bloc de la taille suffisante alors
     on augmente la memoire */
  while((out = first_free(size, state.malloc_ptr)) == NULL)
    increaseFreeMemory(size); 

  /* Decoupage si le bloc est trop grand sinon on supprimer le bloc
     de la liste des blocs libre */
  if (out->size != size){
    cut_bloc(out,size);
  }
  else{
    remove_free(out);
  }

  insert_malloced((void *) ((char *) out + sizeof(size_t)));

  /*******************************************************************************************************************************************/
  /* On renvoie l'adresse memoire se trouvant apres les octets où sont */
  /*    stockes la taille du bloc afin de pouvoir le recuperer lors de la */
  /*    liberation du bloc */
  return (void *) ((char *) out + sizeof(size_t));    
}

/**
 * #=====================================
 * Fonction permettant de remettre l'adresse envoye
 * en parametre dans les adresses disponibles pour
 * un futur malloc
 *
 * myfree(a) :
 *  a : pointeur correspondant au bloc que l'on souhaite
 *      remettre dans les blocs libres
 * #=====================================
 */
void myfree(void *adresse, char *filename, unsigned line){
  bloc_t new;
  bloc_malloc control;
  control = NULL;

  if (adresse == NULL || (control = is_malloced(adresse)) == NULL){
    return;
  }
  
  /* Liberation du bloc de control permettant de savoir si le pointeur appartient aux adresses
     renvoyée par malloc  */
  if(control != NULL){
    delete_malloced(control); /********************************************/
    /* print_list(state.malloc_ptr); */ 
  } 
   
  /* fprintf (stdout,"Dans %-20sligne %-10dappel de free sur %p\n",filename,line,adresse); */
  /* keep trace of the call */
  if (next_call < MAXCALL) {
    strncpy(malloc_calls[next_call].cl_file,
	    filename ? filename : "??",
	    100); 
    malloc_calls[next_call].cl_line = line; 
    malloc_calls[next_call].cl_type = FREE_CALL;   
    next_call++;
  }
  
  /* on recupere le bloc associe a l'adresse memoire du parametre */
  new = (bloc_t)((char *)adresse - sizeof(size_t));

  /* printf("myfree de %d\n",(int)new->size); */

  /* Si la taille est inferieure à celle fixee par mallopt alors on remet
     le bloc dans la liste des blocs allouees par mallopt */
  if (new->size <= state.mxfast){
    /* Si la liste des blocs sont vide alors on precise qu'il est le point
       de depart */
    if (state.mallopt_ptr == NULL){
      state.mallopt_ptr = new;
      new->next = state.mallopt_ptr;
      new->previous = state.mallopt_ptr;
    }
    /* Si il y a encore des blocs libres alors on ajoute le bloc libere au
       debut de la liste des blocs libres car comme tous les blocs sont de 
       meme taille, il n'est pas necessaire de garder l'ordre memoire */
    else{
      new->next = state.mallopt_ptr;
      new->previous = state.mallopt_ptr->previous;
      (state.mallopt_ptr->previous)->next = new;
      state.mallopt_ptr->previous = new;
      state.mallopt_ptr = new;
    }
    return;
  }
  /* Si la liste des blocs libres pour le malloc est vide alors
     on met le bloc rendu en premiere position sinon on l'insere
     dans la liste en respectant l'ordre des adresses memoire */
  if (state.malloc_ptr == NULL){
    new->next = new;
    new->previous = new;
    state.malloc_ptr = new;
  }
  else{	
    inserer(new,state.malloc_ptr);
  }
}


/**
 * #=====================================
 * Fonction permettant de modifier les caracteristiques des petits
 *  blocs que l'on va renvoyer
 *
 * mallopt(c,v) :
 *   c : commande de la caracteristique que l'on souhaite modifier
 *        -M_MXFAST  : modifie la taille des petits blocs
 *        -M_NLBLOCS : modifie le nombre de blocs alloues
 *   v : valeur que l'on souhaite attribuer a la commande
 *  return 0 en cas de probleme et 1 sinon
 * #=====================================
 */
int mallopt(int cmd, int val){
  /* Si jamais on a deja alloue un petit bloc alors on ne peut plus modifier */
  if (state.locked)
    return 0;

  switch(cmd){
  case M_MXFAST:
    state.mxfast = val;
    return 1;
  case M_NLBLOCKS:
    state.numblks = val;
    return 1;
  default:
    return 0;
  }
}

/**
 * #=====================================
 * Methode pour allouer l'espace necessaire pour
 * stocker nmemb elements de taille size. De plus
 * tout les octets sont initialisés a zero.
 *
 * calloc(nb,size) :
 *   nb   : nombre d'elements que l'on souhaite stocker
 *   size : taille de chaque element
 * return pointeur void sur l'espace memoire alloue
 * #=====================================
 */
void * mycalloc (size_t nmemb, size_t size, char *filename, unsigned line){
  void *out;
  int i, taille_malloc;
  
  /* if (chainage_ok(state.malloc_ptr)) */
  /*   write(1,"o",1); */

  if (next_call < MAXCALL) {
    strncpy(malloc_calls[next_call].cl_file,
	    filename ? filename : "??",
	    100); 
    malloc_calls[next_call].cl_line = line; 
    malloc_calls[next_call].cl_size = size; 
    malloc_calls[next_call].cl_type = CALLOC_CALL;   
    next_call++;
  }

  taille_malloc = size*nmemb;


  if (taille_malloc < sizeof(struct bloc) - sizeof(size_t))
    taille_malloc = sizeof(struct bloc) - sizeof(size_t);

  out = malloc(taille_malloc);
  

  for (i = 0; i < taille_malloc ; i++){
    *((char *)out + i) = 0;
  }
  
  return (void *) out;
}

/**
 * #=====================================
 * Permet de savoir si le bloc suivant celui en parametre
 *  est libre, si c'est le cas alors on le renvoie sinon
 *  on renvoie NULL.
 *
 * can_up_bloc(bloc,lst) :
 * bloc : bloc que l'on souhaite augmenter
 * lst : liste dans lequel chercher le suivant
 * #=====================================
 */
bloc_t can_up_bloc(bloc_t bloc, bloc_t liste){

  if (liste == NULL || liste < bloc )
    return NULL;

  if ((char *) bloc + sizeof(size_t) + bloc->size == (char *)liste ){
    return liste;
  }
  
  if (liste->next != state.malloc_ptr)
    return can_up_bloc(bloc, liste->next);
  
  return NULL;
}

/**
 * #=====================================
 * Methode pour augmenter ou diminuer la taille alloue
 *  a un pointeur. Si le bloc suivant est libre et que
 *  l'espace est suffisant pour la demande alors on 
 *  envoi le meme pointeur, sinon on alloue un nouveau
 *  pointeur avec malloc en copiant les donnees du pointeur
 *  d'origine envoye en parametre.
 *
 *  realloc (ptr, size) :
 *    ptr  : pointeur que l'on souhaite modifier
 *    size : nouvelle taille voulue
 * #=====================================
 */
void * myrealloc (void * ptr, size_t size, char *filename, unsigned line){
  bloc_t new, next, b/*,w ,a_delete */;
  void *tmp;
  int i;
  
  /* fprintf(stderr,"============> MYREALLOC %p %d\n", ptr,(int)size); */

  if ( next_call < MAXCALL) {
    strncpy(malloc_calls[next_call].cl_file,
	    filename ? filename : "??",
	    100); 
    malloc_calls[next_call].cl_line = line; 
    malloc_calls[next_call].cl_size = size; 
    malloc_calls[next_call].cl_type = REALLOC_CALL;   
    next_call++;
  }

  if(ptr == NULL || is_malloced(ptr)== NULL){
    return malloc(size);
  }
  

  /* on recupere le bloc associe a l'adresse memoire du parametre */
  new = (bloc_t)((char *)ptr - sizeof(size_t));

  /* on recupere le bloc suivant le bloc new à condition qu'ils sont collés */
  next = can_up_bloc(new,state.malloc_ptr);
  /* Si on veut reallouer un bloc de mallopt,
   * ou si le bloc suivant n'est pas disponible
   * ou si la taille du bloc suivant ne permet pas d'obtenir une
   * taille suffisante */
  if (new->size <= state.mxfast || next == NULL  || (next != NULL && new->size + sizeof(size_t) + next->size < size)){

    tmp = malloc(size);
    
    if (new->size < size ){
      for (i = 0; i < new->size ; i++){
	*((char *)tmp + i) = *((char *)ptr + i) ;
      }
    }
    else{
      for (i = 0; i < size ; i++)
	*((char *)tmp + i) = *((char *)ptr + i) ;
    }

    free(ptr);

    return tmp;
  }

  if (size <= new->size && new->size > state.mxfast){

    if (new->size - size < sizeof(struct bloc))
      return ptr;

    /* write(1,"i",1); */
    /* printf("size demande :%d",(int)size); */
    b = (bloc_t)((char *)new + sizeof(size_t) + size);
    b->size = new->size - sizeof(size_t) - size;
    new->size = size;
    if (state.malloc_ptr == NULL){
      b->next = b;
      b->previous = b;
      state.malloc_ptr = b;
    }
    else{
      inserer(b,state.malloc_ptr);
    }

    /* if (chainage_ok(state.malloc_ptr)) */
    /*   write(1,"ok",2); */
    return ptr;
  }


  remove_free(next);
  /* On recupere le bloc se trouvant apres la nouvelle taille necessaire */

  /*******************************/
  /* A CORRIGER !!!! */

  

  /* write(1,"s",1); */
  /* w = (bloc_t)((char *)next + (size- new->size)); */
  /* w->size = next->size - (size- new->size); */
  new->size = size ;

  /* if (w->size <= sizeof(struct bloc) - sizeof(size_t) || w->size <= state.mxfast){ */
  /*   new->size = new->size + w->size + sizeof(size_t) ; */
  /*   return ptr; */
  /* } */
  
  /* if (state.malloc_ptr != NULL) */
  /*   inserer(w,state.malloc_ptr); */
  /* else { */
  /*   state.malloc_ptr = w; */
  /*   w->next = w; */
  /*   w->previous = w; */
  /* } */
  /* write(1,"ok",2); */

  /* if (chainage_ok(state.malloc_ptr)) */
  /*   write(1,"t",1); */

  return ptr;
  
}

void
print_malloc_calls(void) 
{
  int i ;
  /* bloc_malloc tmp; */

  BREAK = 0;
  fprintf(stderr, "------------------------------\n"
	  " Trace des appels a malloc()\n"
	  "------------------------------\n"
	  "------------------------------\n");
  fprintf(stderr, "%d appel(s) a malloc()\n", next_call) ; 
  for (i=0; i<next_call; i++) {
    switch (malloc_calls[i].cl_type) {
    case MALLOC_CALL: 
      fprintf(stderr, 
	      "Dans %18s, ligne %5d, %5d octets demandes\n", 
	      malloc_calls[i].cl_file, 
	      malloc_calls[i].cl_line, 
	      malloc_calls[i].cl_size); 
      break; 
    case FREE_CALL: 
      fprintf(stderr, 
	      "Dans %18s, ligne %5d, appel de free()\n", 
	      malloc_calls[i].cl_file, 
	      malloc_calls[i].cl_line);  
      break;
    case CALLOC_CALL: 
      fprintf(stderr, 
	      "Dans %18s, ligne %5d, appel de calloc %d()\n", 
	      malloc_calls[i].cl_file, 
	      malloc_calls[i].cl_line,
	      malloc_calls[i].cl_size);  
      break;
    case REALLOC_CALL: 
      fprintf(stderr, 
	      "Dans %18s, ligne %5d, appel de realloc()\n", 
	      malloc_calls[i].cl_file, 
	      malloc_calls[i].cl_line);  
      break;
    default:
      fprintf(stderr,"ciyciy");
    }
  }
  fprintf(stderr, "------------------------------\n");

  /* fprintf(stderr, "------------------------------\n" */
  /* 	  " Trace des bloc malloced()\n" */
  /* 	  "------------------------------\n" */
  /* 	  "------------------------------\n"); */
  /* tmp = malloced; */

  /* while (tmp != NULL){ */
  /*   fprintf(stderr, "current : %p\n", (void *)tmp ); */
  /*   fprintf(stderr, "next : %p\n", (void *)tmp->next ); */
  /*   tmp = tmp->next; */
  /* } */
  /* fprintf(stderr, "------------------------------\n"); */
    
}

