#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "listeChainee.h"

/**
 * #=====================================
 * AUTHOR : LEFER Gregory
 * Exemple d'utilisation de la bibliotheque
 * #=====================================
 */


int main(void)
{
  int *p1, *p2;

  p1 = malloc(30);

  p2 = malloc(5000);


  for (*p2 =0; *p2 < 30; *p2 = *p2 + 1){
    *((char *)p1 + *p2) = 1;
  }

  printf("%d\n",*p1);
  
  realloc(p1,50);

  printf("%d\n",*p1);

  free(p1);

  p1 = malloc(5000);
  
  free(p2);
  free(p1);

  exit(EXIT_SUCCESS);
}
