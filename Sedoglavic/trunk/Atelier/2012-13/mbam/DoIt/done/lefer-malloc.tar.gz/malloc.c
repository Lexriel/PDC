#include <unistd.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include "listeChainee.h"

#ifdef malloc
#undef malloc
#undef calloc
#undef realloc
#undef free
#endif

void *malloc(size_t size)
{
  return  mymalloc(size, (char *)0, 0); 
}

void free(void *ptr){
  myfree(ptr,(char *)0, 0);
  return;
}

void *realloc(void *ptr, size_t sz){
  return myrealloc(ptr,sz,(char *)0, 0);
}

void *calloc(size_t nb, size_t sz){
  return mycalloc(nb,sz,(char *)0, 0);
}
