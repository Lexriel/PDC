/**
	@author KOMA Xavier - FOULON Nicolas ©
	@since 21/11/2012
	@version 1.0

	Header my_malloc.h

**/ 



/**
*
* Structure chainon_m
* comportant:
* une taille en integer non signé,
* une struct chainon_m référancant le chainon_m suivant,
* et l'espace libre pour savoir où on recommancera pour la création du prochaine bloc
*
*/
struct chainon_m
{
	int taille;
	struct chainon_m * suivant;
	void * espace_libre;
};

/**
*
* Création d'un premier maillon dont la taille est libre, le suivant maillon n'existe pas encore, et possédant l'espace libre
* de TAILLE_INITIAL, ici 1 puissance 10.
* @param void
* @return une struct chainon_m 
* 
*/
struct chainon_m * 
creerPremierMaillonLibre
(void);

/**
*
* Permet de creer un nouveau maillon_m suite à la division d'un bloc trop grand
*
*/
struct chainon_m * 
creerNouveauMaillon
(int nouvelleTaille, struct chainon_m * ancien_bloc_libre);

/**
*
* Création d'un premier maillon dont la taille est libre, le suivant maillon n'existe pas encore, et possédant l'espace libre
* de TAILLE_INITIAL, ici 1 puissance 10.
* @param struct chainon_m * liste_bloc_libre, unsigned int taille_memoire_demandee
* @return struct chainon_m 
* 
*/
struct chainon_m *  
parcoursListeChaineeBlocLibre
(struct chainon_m * liste_bloc_libre, int taille_memoire_demandee);

