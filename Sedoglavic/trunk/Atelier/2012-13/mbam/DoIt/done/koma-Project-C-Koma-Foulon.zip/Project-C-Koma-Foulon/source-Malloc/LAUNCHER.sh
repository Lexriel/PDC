# !/bin/bash
# Script de lancement pour le projet en C

clear

make
./exe_my_malloc