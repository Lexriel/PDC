/**
	@author KOMA Xavier - FOULON Nicolas ©
	@since 21/11/2012
	@version 1.0

	my_malloc.c
**/

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>	
#include "my_malloc.h"

#define TAILLE_INITIAL (1<<10)



struct chainon_m * creerPremierMaillonLibre(void)
{
	struct chainon_m * liste_bloc_libre_creation;
	void * mon_tas ;
	mon_tas = sbrk(TAILLE_INITIAL);

	
	liste_bloc_libre_creation = (struct chainon_m *) mon_tas;
	
	liste_bloc_libre_creation->suivant = NULL;
	liste_bloc_libre_creation->taille = TAILLE_INITIAL - sizeof(struct chainon_m); /* car il faut conserver une petite place mémoire pour notre struct*/
	liste_bloc_libre_creation->espace_libre = (char *) mon_tas + sizeof(struct chainon_m);

	return liste_bloc_libre_creation;
}


struct chainon_m * creerNouveauMaillon(int nouvelleTaille, struct chainon_m * ancien_bloc_libre){
	
	struct chainon_m * nouveau_bloc_libre = ((struct chainon_m *) ((char *) ancien_bloc_libre + ancien_bloc_libre->taille - nouvelleTaille));
	nouveau_bloc_libre->taille = nouvelleTaille - sizeof(struct chainon_m);
	nouveau_bloc_libre->suivant = NULL;
	nouveau_bloc_libre->espace_libre = (char *) ancien_bloc_libre + sizeof(struct chainon_m);
	
	printf("Creation nouveau maillon_m. taille : %d \n", nouveau_bloc_libre->taille);
	return nouveau_bloc_libre;
}


struct chainon_m *  parcoursListeChaineeBlocLibre(struct chainon_m * liste_bloc_libre, int taille_memoire_demandee ){
	
	int nouvelleTaille;
	nouvelleTaille = 0;

	if(liste_bloc_libre->taille == taille_memoire_demandee){
		printf("La taille de mon bloc memoire est egale a la taille demandee. Je vous retourne le bloc.\n");
		fflush(stdout);
		return liste_bloc_libre; /* extraire de la liste */
	}
	else if(liste_bloc_libre->taille > taille_memoire_demandee){
		printf("La taille de mon bloc memoire est plus grande que la taille demandee. Je vais donc creer un nouveau maillon.\n");
		fflush(stdout);
		nouvelleTaille = liste_bloc_libre->taille - taille_memoire_demandee;
		return creerNouveauMaillon(nouvelleTaille, liste_bloc_libre);
	}
	else if(liste_bloc_libre->taille < taille_memoire_demandee){
		printf("Fichtre! La taille de mon bloc memoire est trop petite pour la taille que vous souhaitez.\n N\'abusez pas non plus, nous sommes en 2012, les machines actuelles ont assez de memoire.\n Vous allez tomber sur un Segmentation Fault et voila, que dis-je un :");
		fflush(stdout);
		parcoursListeChaineeBlocLibre(liste_bloc_libre->suivant, taille_memoire_demandee); /* Utilisation récursivité */
		return NULL;	
	}
	else{ /* Utilisation récursivité */
		printf("Je n\'ai pas trouvé de bloc du premier coup, je réitére l\'operation.\n"); 
		fflush(stdout);
		parcoursListeChaineeBlocLibre(liste_bloc_libre->suivant, taille_memoire_demandee);
		return NULL;	
	}
			
}

/**
*
* fonction main
*
*/
int main(){
	struct chainon_m * liste_bloc_libre;
	struct chainon_m * bloc_Parcours;
	liste_bloc_libre = creerPremierMaillonLibre();

	printf("\n*** _BIENVENUE DANS MON MALLOC_ ***\n\a");

	printf("\n-La taille disponible pour le premier bloc creer: %d (4*octect).\n", liste_bloc_libre->taille);

	bloc_Parcours = parcoursListeChaineeBlocLibre(liste_bloc_libre, 10);
	printf("\n-La taille disponible suite a un parcouru de la liste de bloc est de  : %d (4*octect).\n\n", bloc_Parcours->taille);


	return 0;
}