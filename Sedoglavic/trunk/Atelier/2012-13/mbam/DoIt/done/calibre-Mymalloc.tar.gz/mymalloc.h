/*
 * Th�o CALIBRE
 * Cl�ment HOCHEDEZ
 */

#ifndef _mymalloc_h
#define _mymalloc_h
/* taille de cellule fix� � 50 */ 
#define TAILLE_CELLULE 50


#define align4(x) (((((x)-1)>>2)<<2)+4)

/* Structure de la cellule */ 
struct cellule_s {
    struct cellule_s *precedent;
    struct cellule_s *suivant;
    unsigned taille;
    char donnees[1];
    int free;
    void *ptr;
};

typedef struct cellule_s *cellule_t;

/* Permet de fusionner une cellule */
cellule_t fusion(cellule_t b);
/* Permet d'atteindre une cellule */
cellule_t getCellule(void *p);
/* Verifie si une adresse est valide, si elle peut �tre atteinte */
int estvalide(void *boolenne);
/* segmente une cellule */ 
void decoupe_cellule(cellule_t b, unsigned s);
/* Permet de rechercher une cellule */
cellule_t search_cellule(cellule_t *last, unsigned s);
/* ajoute une cellule  */
cellule_t add(cellule_t last, unsigned s);
/* appel du free */
void pfree(void *p);
/* Appel de la fonction malloc */
void *pmalloc(unsigned taille);

#endif
