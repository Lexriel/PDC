Hochedez Clement
Calibre Théo
G5


I] TRAVAIL REALISE


-> Le malloc et free ont été réalisés
-> Nous avons fait une bibliotheque mymalloc.h, nous avons défini la structure de la cellule et les fonctions externes 
présentées en partie II
-> le malloc et le free se trouvent dans le mymalloc.c


Difficultés

-> Ne sachant pas trop comment démarrer, nous avons fait un tour sur les forum et nous nous sommes aidés du topic suivant : 
http://www.siteduzero.com/forum-83-609799-p1-recode-malloc-free.html

-> On a eu pas mal de problèmes avec les pointeurs ce qui engendré pas mal d'erreur dans la console. 

-> Nous avons perdu trop de temps à essayer de faire le malloc et free, nous n'avons pas eu le temps d'implémenter les fonctions suivantes:
-mallopt
-realloc
-calloc


II] Fonctions explications 


La fonction permet de fusionner une cellule avec une autre passé en paramètre.
cellule_t fusion(cellule_t b);

La fonction suivante permet de recuperer une cellule
cellule_t getCellule(void *p);

On vérifie que l'adresse d'une cellule est correcte avec une fonction booléenne.
int estvalide(void *p);

Permet de segmenter une cellule passé en paramètre 
void decoupe_cellule(cellule_t b, size_t s);

recherhe une cellule 
cellule_t search_cellule(cellule_t *last, size_t s);

ajoute une cellule avec une nouvelle cellule et une taille passé en paramètre
cellule_t add(cellule_t last, size_t s);

fonction d'appel du free 
void pfree(void *p);

fonction d'appel du malloc
void *pmalloc(size_t taille);
