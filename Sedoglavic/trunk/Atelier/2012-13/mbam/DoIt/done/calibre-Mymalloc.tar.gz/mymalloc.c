/*
 * Th�o CALIBRE
 * Cl�ment HOCHEDEZ 
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include "mymalloc.h"

/* debut de la liste chain�e  */ 
void *debut=NULL;

/* permet d'ajouter une cellule */ 
cellule_t add(cellule_t fin, unsigned t){
  cellule_t cellule;
  cellule = sbrk(0); 
  int sbr;
  sbr = (int) sbrk(TAILLE_CELLULE + t);
  if (sbr < 0) {
    return (NULL);
  }
  cellule->precedent = fin;
  cellule->suivant = NULL;
  cellule->taille = t;
  cellule->ptr = cellule->donnees;
  if (fin) {
    fin->suivant = cellule;
  }
  cellule->free = 0;
  return (cellule);
}

/* recherche une cellule pass� en param�tre avec la taille */ 
cellule_t search_cellule(cellule_t *tmp, unsigned taille){
  cellule_t cellule=debut;
  while (cellule && !(cellule->free && cellule->taille >= taille)) {
    *tmp = cellule;
    cellule = cellule->suivant;
  }
  return (cellule);
}

/* permet de segmenter la cellule */ 
void decoupe_cellule(cellule_t cellule, unsigned t){
  cellule_t new;
  new = (cellule_t)(cellule->donnees + t);
  new->free = 1;
  new->taille = cellule->taille-t-TAILLE_CELLULE;
  new->suivant = cellule->suivant;
  new->ptr = new->donnees;
  cellule->taille = t;
  cellule->suivant = new;
  if(new->suivant) {
    new->suivant->precedent = new;
  }
}

/* permet de fusionner une cellule pass� en param�tre */
cellule_t fusion(cellule_t cellule){
  if (cellule->suivant && cellule->suivant->free){
    cellule->taille += TAILLE_CELLULE + cellule->suivant->taille;
    cellule->suivant = cellule->suivant->suivant;
    if (cellule->suivant) {
      cellule->suivant->precedent = cellule;
    }
  }
  return (cellule);
}

/* permet d'obtenir la cellule */ 
cellule_t getCellule(void *p) {
  char *tmp;
  tmp = p;
  tmp = tmp - TAILLE_CELLULE;
  p = tmp;
  return (p);
}

/* return 1 si l'adresse est valide, 0 sinon */ 
int estvalide(void *boolenne) {
  if (debut) {
    if (boolenne < sbrk(0) && boolenne > debut) {
      return (boolenne == (getCellule(boolenne))->ptr);
    }
  }
  return (0);
}


/*
 * APPEL DES 2 FONCTIONS
 * MALLOC ET FREE 
 *
 */


/* appel de malloc */ 

void *pmalloc(unsigned taille){
  cellule_t cellule,last;
  unsigned t;
  t = align4(taille);
  if (debut) {
    last = debut;
    cellule = search_cellule(&last,t);
    if (cellule) {
      if ((cellule->taille - t) >= (TAILLE_CELLULE + 4)) {
	decoupe_cellule(cellule,t);
      }
      cellule->free=0;
    }
    else {
      cellule = add(last,t);
      if (!cellule) {
	return(NULL);
      }
    }
  } 
  else {
    cellule = add(NULL,t); 
    if (!cellule) {
      return(NULL); debut = cellule;
    }
  }
  return(cellule->donnees); 
}

/* appel de free */ 

void pfree(void *p) {
  cellule_t cellule;
  if(estvalide(p)) {
    cellule = getCellule(p);
    cellule->free = 1;
    if(cellule->precedent && cellule->precedent->free) 
    {
      cellule = fusion(cellule->precedent);
    }
    if (cellule->suivant) {
      fusion(cellule);
    }
    else {
      if (cellule->precedent) {
	cellule->precedent->suivant = NULL;
      }
      else {
	debut = NULL;
      }
      brk(cellule);
    }
  }
}

/* Test du malloc et du free */ 

int main() {

   int *aa;
   /* on reserve de l'espace memoire pour la variable aa */ 
   aa = (int *) pmalloc(20 * sizeof(int));
   /* on libere l'espace memoire */ 
   pfree(aa);

}



