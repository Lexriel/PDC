#include "malloc_free.h"
#include "mfree.h"




void
mfree
(void * ptr)
{
	free(ptr);
}
