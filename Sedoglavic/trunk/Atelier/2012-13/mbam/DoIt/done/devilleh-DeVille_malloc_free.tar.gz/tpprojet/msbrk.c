#define _XOPEN_SOURCE 500
#define __USE_XOPEN_EXTENDED 1
#include <unistd.h>
/*
int
main
(void)
{ 
	void *toto;
	toto = sbrk (1<<12);
	return 0;
}
*/
