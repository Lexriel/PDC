

void *mmalloc(size_t size);
