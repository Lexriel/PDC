#include "malloc_free.h"
#include "mmalloc.h"



void *
mmalloc
(size_t size)
{
  return malloc(size);
}


