#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "msbrk.c"
#include "malloc_free.h"

#define TEST 12

#define MSIZE 100000

static char *memory = NULL;

typedef struct freeptr_s * freeptr_t;
struct freeptr_s {
  void * ptr_free;
  freeptr_t ptr_next;
};

static freeptr_t freeptr = NULL;

freeptr_t
new_freeptr
()
{
  freeptr_t freeptr = sbrk(sizeof(freeptr_t));
  freeptr->ptr_free = NULL;
  freeptr->ptr_next = NULL;
  return freeptr;

}





void * 
malloc
(size_t size)
{
  void *ptr = NULL;
  freeptr_t test_freeptr = freeptr;
  
  while((test_freeptr != NULL) && !ptr) {
    if ((sizeof test_freeptr->ptr_free) >= size) {
      ptr = test_freeptr->ptr_free;
    }
    test_freeptr = test_freeptr->ptr_next;
  }

  if (!ptr) {
    if (!memory) {
      memory = sbrk(MSIZE);
      ptr = memory;
      memory += size;
    }
    else if( (sizeof memory) < size) {
      memory = sbrk(MSIZE);
      ptr = memory;
      memory += size;
  }
    else {
      ptr = memory;
      memory += size;
    }
  }
  return ptr;
}



void 
free
(void *ptr)
{
  
  freeptr_t n_freeptr = new_freeptr();
  if (!freeptr || !(freeptr->ptr_free)) {
    freeptr = new_freeptr();
    freeptr->ptr_free = ptr;
    freeptr->ptr_next = NULL;
  }
  else {
    n_freeptr->ptr_free = ptr;
    n_freeptr->ptr_next = freeptr;
    freeptr = n_freeptr;
  }
  

}


