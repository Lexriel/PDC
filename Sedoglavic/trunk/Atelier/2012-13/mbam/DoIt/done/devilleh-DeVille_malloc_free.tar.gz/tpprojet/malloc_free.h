#include <stdio.h>


/* La fonction d'allocation mémoire

 */

extern void * malloc(size_t size);


/* La fonction de libération de la mémoire 
 */

extern void free(void * ptr);
