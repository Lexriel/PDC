#include <string.h>
#include "malloc_free.h"
#include "mmalloc.h"
#include "mfree.h"



int
main
(void)
{
  char *ptr =  mmalloc(sizeof("Test"));
  ptr = "Test";
  printf("%s\n%d\n",ptr, sizeof(ptr));
  mfree(ptr);
  return 0;
}
