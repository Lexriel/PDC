#define _XOPEN_SOURCE 500
/* #define __USE_XOPEN_EXTENDED 1 */
#include <unistd.h>
#include <stdio.h>


struct mbloc_s{
  struct mbloc_s *next;
  struct mbloc_s *prev;
  void *espace;
  size_t size;};
typedef struct mbloc_s mbloc;

static mbloc *freemem ;


void
init_freemem
(unsigned size)
{
  printf("*** Initialisation memoire libre ***\n\tTaille demandee : %d\n\n", size);

  if ((size + sizeof(mbloc)) < (1<<12))
    freemem = (mbloc *)sbrk(1<<12);
  else
    freemem = (mbloc *)sbrk(size + sizeof(mbloc) + (1<<12));
  freemem->next = freemem;
  freemem->prev = freemem;
  freemem->size = (1<<12) - sizeof(mbloc);
  freemem->espace = (char *)freemem + sizeof(mbloc);
}


void
extend_freemem
(unsigned size)
{
  mbloc * bloc;

  printf("*** Extension memoire libre ***\n\tTaille demandee : %d\n\n", size);

  bloc = freemem;
  while (bloc->next != freemem)
    bloc = bloc->next;
  if ((size + sizeof(mbloc)) < (1<<12))
    bloc->next = (mbloc *)sbrk(1<<12);
  else
    bloc->next = (mbloc *)sbrk(size + sizeof(mbloc) + (1<<12));
  (bloc->next)->next = freemem;
  (bloc->next)->prev = bloc;
  (bloc->next)->size = ((size + sizeof(mbloc)) < (1<<12)) ? (1<<12) - sizeof(mbloc) : size + (1<<12);
  (bloc->next)->espace = (char *)(bloc->next) + sizeof(mbloc);

  printf("Adresse extension bloc %p, adresse bloc->next %p, adresse bloc->prev %p, taille %d\n\n",(void*) bloc->next,(void*) (bloc->next)->next,(void*) (bloc->next)->prev, (int)(bloc->next)->size);

}


mbloc*
find_first_free_mbloc
(mbloc *bloc, unsigned size)
{
  
  if (bloc->size >= size)
    {
      printf("Adresse 1er bloc free %p, adresse bloc->next %p, adresse bloc->prev %p, taille %d\n\n",(void*) bloc,(void*) bloc->next,(void*) bloc->prev, (int)bloc->size);
      return bloc;
    }
  if (bloc->next != freemem)
    return find_first_free_mbloc(bloc->next, size);
  extend_freemem(size);
  return bloc->next;
}

void
orderfreemem
()
{
  while (freemem > freemem->prev)
    freemem = freemem->prev;
  return;
}


void
printbloclist
()
{
  mbloc *bloc;

  printf("*** printbloclist ***\n\n");
  bloc = freemem;
  do
    {
      printf("\tAdresse bloc %p, adresse bloc->next %p, adresse bloc->prev %p, taille %d\n",(void*) bloc,(void*) bloc->next,(void*) bloc->prev, (int)bloc->size);
    }
  while ((bloc = bloc->next) != freemem);
  printf("\n");
}


void *
mymalloc
(unsigned size)
{
  mbloc *freembloc, *newmbloc;

  printf("*** MALLOC ***\n");
  printf("\tTaille demandée : %d\n", size);
  printf("\tTaille structure : %d\n", (int)sizeof(mbloc));
  printf("\tTaille totale : %d\n", size+(int)sizeof(mbloc));


  if (freemem == NULL)
    init_freemem(size);

  newmbloc = find_first_free_mbloc(freemem,size);

  /* L'adresse du prochain bloc memoire est celle du pointeur de l'espace que l'on renvoie a laquelle on ajoute la taille de l'espace alloue */
  printf("Taille du bloc memoire libre recupere : %d\n", (int)newmbloc->size);

  /* decoupage d'un nouveau bloc et insertion dans la chaine */
  freembloc = (mbloc*)((char*)newmbloc->espace + size);
  freembloc->next = newmbloc->next;
  freembloc->prev = newmbloc;
  freembloc->size = newmbloc->size - ( size + sizeof(mbloc) );
  freembloc->espace = (char *)freembloc + sizeof(mbloc);

  (newmbloc->next)->prev = freembloc;
  newmbloc->next = freembloc;
  newmbloc->size = size;

  /* extraction du bloc a renvoyer */
  (newmbloc->prev)->next = freembloc;
  (newmbloc->next)->prev = newmbloc->prev;

  newmbloc->next = NULL;
  newmbloc->prev = NULL;

  freemem = freembloc;
  orderfreemem();

  printf("\tL'adresse de la structure est %p\n", (void*)newmbloc);
  printf("\tL'adresse du pointeur retourné est %p\n", newmbloc->espace);
  printf("\tLa taille allouée est %d octets\n\n", (int)newmbloc->size);

  printbloclist();

  return newmbloc->espace;
}


void
insertfreebloc
(mbloc *bloc)
{
  mbloc *freebloc;

  /* insertion du bloc dans la chaine de blocs libres */
  freebloc = freemem;
  while ((freebloc < bloc)&&(freebloc->next != freemem))
    freebloc = freebloc->next;
  bloc->next = freebloc;
  bloc->prev = freebloc->prev;
  (bloc->next)->prev = bloc;
  (bloc->prev)->next = bloc;

  /* recollage bloc precedent */
  if ((char*)(bloc->prev)->espace + (bloc->prev)->size == (char*)bloc)
    {
      printf("\tBloc recolle au precedent\n\n");
      (bloc->prev)->next = bloc->next;
      (bloc->next)->prev = bloc->prev;
      (bloc->prev)->size = (bloc->prev)->size + sizeof(mbloc) + bloc->size;
      bloc = bloc->prev;
    }
  
  /* recollage bloc suivant */
  if ((char*)bloc->espace + bloc->size == (char*)bloc->next)
    {
      printf("\tBloc recolle au suivant\n\n");
      bloc->size = bloc->size + sizeof(mbloc) + (bloc->next)->size;
      bloc->next = (bloc->next)->next;
      (bloc->next)->prev = bloc;
    }
  return;
}


void
myfree
(void *ptr)
{
  mbloc *bloc;

  printf("*** FREE ***\n");
  bloc = (mbloc*) ((char*)ptr - sizeof(mbloc));
  printf("\tsize : %d octets\n\n", (int)bloc->size);
  insertfreebloc(bloc);
  orderfreemem();
  printbloclist();
  ptr = NULL;
  return;
}


int
main
()
{
  void *ptr1, *ptr2, *ptr3, *ptr4, *ptr5;

  ptr1 = mymalloc (2000);
  ptr2 = mymalloc (1600);
  ptr3 = mymalloc (sizeof(int));
  myfree(ptr1);
  myfree(ptr2);
  
  ptr4 = mymalloc (5600);
  ptr1 = mymalloc (5600);
  ptr2 = mymalloc (8600);
  ptr5 = mymalloc (17);

  myfree(ptr3);
  myfree(ptr1);
  myfree(ptr4);
  myfree(ptr2);
  myfree(ptr5);
 
  printf("Adresse du prochain bloc memoire libre : %p\n",(void*)freemem);
  return 0;
}
