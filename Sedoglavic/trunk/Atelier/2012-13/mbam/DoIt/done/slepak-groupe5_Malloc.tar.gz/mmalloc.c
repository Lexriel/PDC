/*
  LEMAIRE Helene
  SLEPAK Jeremy

  GROUPE 5
*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#define TAILLE 20
#define align4(x) (((((x)-1)>>2)<<2)+4)

struct bloc_s {
    unsigned size;
    struct bloc_s *suivant;
    struct bloc_s *prec;
    int vide;
    void *ptr;
    char data[1];
};

typedef struct bloc_s *bloc_t;
void *base=NULL;

/*
 *##############################################"
 *##########       Le malloc     ###############
 *##############################################
*/

bloc_t 
ajoute
(bloc_t last, unsigned s)
{
  int taille;
  bloc_t b;
  b = sbrk(0);
  taille = (int) sbrk(TAILLE + s);

  if (taille < 0) {
    return (NULL);
  }

  b->size = s;
  b->suivant = NULL;
  b->prec = last;
  b->ptr = b->data;

  if (last) {
    last->suivant = b;
  }

  b->vide = 0;
  return (b);
}


void 
fractionne
(bloc_t b, unsigned s)
{
  bloc_t tmp;
  tmp = (bloc_t)(b->data + s);
  tmp->size = b->size - s - TAILLE;
  tmp->suivant = b->suivant;
  tmp->vide = 1;
  tmp->ptr = tmp->data;
  b->size = s;
  b->suivant = tmp;

  if(tmp->suivant) {
    tmp->suivant->prec = tmp;
  }
}


bloc_t 
find
(bloc_t *last, unsigned size)
{
  bloc_t b=base;

  while (b && !(b->vide && b->size >= size)) {
    *last = b;
    b = b->suivant;
  }

  return (b);
}



void 
*malloc
(unsigned size)
{
  bloc_t b,last;
  unsigned s;
  s = align4(size);

  if (base) {
    last = base;
    b = find(&last,s);

    if (b) {

      if ((b->size - s) >= (TAILLE + 4)) {
	fractionne(b,s);
      }

      b->vide=0;
    }

    else {

      b = ajoute(last,s);

      if (!b) {
	return(NULL);
      }
    }
  } 

  else {
    b = ajoute(NULL,s); 
    if (!b) {
      return(NULL); base = b;
    }
  }

  return(b->data); 
}


/*
 *##############################################"
 *##########       Le free       ###############
 *##############################################
*/

bloc_t 
fusion(bloc_t b)
{
  if (b->suivant && b->suivant->vide){

    b->size += TAILLE + b->suivant->size;
    b->suivant = b->suivant->suivant;

    if (b->suivant) {
      b->suivant->prec = b;
    }
  }

  return (b);
}

bloc_t 
get_bloc(void *p) 
{
  char *tmp;
  tmp = p;
  tmp = tmp - TAILLE;
  p = tmp;

  return (p);
}



int 
estBloc(void *p) 
{
  if (base) {

    if (p > base && p < sbrk(0)) {

      return (p == (get_bloc(p))->ptr);
    }
  }

  return (0);
}



void 
free(void *p) 
{
  bloc_t b;

  if(estBloc(p)) {
    b = get_bloc(p);
    b->vide = 1;

    if(b->prec && b->prec->vide) {
      b = fusion(b->prec);
    }

    if (b->suivant) {
      fusion(b);
    }

    else {
      if (b->prec) {
	b->prec->suivant = NULL;
      }

      else {
	base = NULL;
      }

      brk(b);
    }
  }
}


/*
 *##############################################"
 *##########         Test        ###############
 *##############################################
*/

int 
main()
{
	int *e;
	
	printf("Appel de MALLOC :\n");
        printf("Taille demandee %d octets \n",12*sizeof(int) );
	e=(int *)malloc(12*sizeof(int));
	
        printf("%p \n", e);
        printf("Appel de FREE \n");
	free(e);
	printf("%p \n", e);

	return 0;
}
