LEMAIRE H�l�ne
SLEPAK J�r�my

GROUPE 5

Nous avons r�alis� les fonctions free et malloc. 

Pour se faire nous avons du cr�er une liste de bloc qui ont une taille, un suivant
un precedent et une disponibilit� (vide ou plein) ainsi que plusieurs fonctions :

Pour le malloc :

bloc_t ajoute(bloc_t last, unsigned s); 
 -> ajoute a la liste de blocs un nouveau bloc pass� en param�tre avec une taille �galment pass�e en param�tre

bloc_t find(bloc_t *last, unsigned s);
 -> trouve le bloc pass� en param�tre avec la taille pass�e en param�tre

void fractionne(bloc_t bloc, unsigned s);
 -> fractionne le bloc � la taille pass�e en param�tre

void *malloc(unsigned size);
 -> alloue un bloc m�moire de taille pass�e en param�tre



Pour le free :

bloc_t get_bloc(void *p); 
 -> qui retourne le bloc trouv� au niveau du pointeur pass� en param�tre 

bloc_t fusion(bloc_t b);
 -> qui fusionne le bloc pass� en param�tre et le retourne

int estBloc(void *p);
 -> qui retourne vrai si le pointeur pass� en param�tre pointe sur un bloc

void free(void *p);
 -> qui lib�re le bloc pass� en param�tre


Nous n'avons pas eu le temps de commencer le mallopt, calloc et realloc car la r�alisation du malloc et du free nous ont pos� pas mal de probl�mes :
- d�marrage du projet
- defaut dans notre structure de d�part
- erreur de segmentation du aux pointeurs

Nous nous sommes aid�s du site "lesiteduzero" pour le projet.
