#include <stdio.h>
#include <stdlib.h>

#define _DEBUG_MODE
#include "dpr_malloc.h"

#define N_SIZE             200
#define NB_STR             15
#define NB_CHAR            50
#define NB_INT             30
#define LARGE_AMOUNT       12000
#define SMALL_AMOUNT       4000

int main(void) {
  register unsigned i;
  
  char* *unCertainNombreDeChaines;
  char *containeurDeBeaucoupDOctets;
  int *premiersEntiersNaturels[N_SIZE * 2];
  int *tableauDEntiers;

  /* Reglage des parametres de l'optimisation */ 
  fprintf(stdout, "Reglage des parametres de l'otimisation: maxfast=%i\tnumblocks=%i\n", 5, 100);
  mallopt(M_MXFAST, 5);
  mallopt(M_NLBLOCKS, 100);
  
  /* Allocation de l'espace necessaire et stockage des N_SIZE premiers entiers naturels */
  fprintf(stdout, "Allocation de l'espace necessaire et stockage des %i premiers entiers naturels\n", N_SIZE);
  for (i = 0; i < N_SIZE; i++) {
    premiersEntiersNaturels[i] = malloc(sizeof(int));
    *premiersEntiersNaturels[i] = i;
  }
  
  printmanagedmemory();

  /* Allocation de NB_STR chaine de NB_CHAR caracteres maximum  */
  fprintf(stdout, "Allocation de %i chaine de %i caracteres maximum\n", NB_STR, NB_CHAR);
  unCertainNombreDeChaines = malloc(NB_STR * sizeof(char*));
  for (i = 0; i < NB_STR; i++)
    unCertainNombreDeChaines[i] = malloc(NB_CHAR * sizeof(char));
  
  printmanagedmemory();

  /* Besoin de LARGE_AMOUNT octets ? Aucun probleme. */
  fprintf(stdout, "Allocation de %i octets\n", LARGE_AMOUNT);
  containeurDeBeaucoupDOctets = malloc(LARGE_AMOUNT * sizeof(char));

  printmanagedmemory();

  /* Liberation des chaines */
  fprintf(stdout, "Liberation des chaines\n");
  for (i = 0; i < NB_STR; i++)
    free(unCertainNombreDeChaines[i]);

  printmanagedmemory();

  /* Reallocation du gros bloc */
  fprintf(stdout, "Reallocation du bloc de %i octets en %i octets\n", LARGE_AMOUNT, SMALL_AMOUNT);
  containeurDeBeaucoupDOctets = realloc(containeurDeBeaucoupDOctets, SMALL_AMOUNT);

  printmanagedmemory();

  /* Allocation de l'espace necessaire et stockage des N_SIZE à N_SIZE*2 premiers entiers naturels */
  fprintf(stdout, "Allocation de l'espace necessaire et stockage des %i a %i premiers entiers naturels\n", N_SIZE, N_SIZE * 2);
  for (i = 0; i < N_SIZE; i++) {
    premiersEntiersNaturels[N_SIZE + i] = malloc(sizeof(int));
    *premiersEntiersNaturels[N_SIZE + i] = i;
  }
  
  printmanagedmemory();

  /* Allocation d'un tableau de NB_INT entiers  */
  fprintf(stdout, "Allocation d'un tableau de %i entiers\n", NB_INT);
  tableauDEntiers = calloc(NB_INT, sizeof(int));

  printmanagedmemory();

  /* Liberation du containeur des chaines */
  fprintf(stdout, "Liberation du containeur de chaines, du gros bloc, et du tableau d'entiers tout recent\n");
  free(unCertainNombreDeChaines);
  free(containeurDeBeaucoupDOctets);
  free(tableauDEntiers);

  printmanagedmemory();
  
  return 0;
}
