-- Compte-Rendu de TP --

Université Lille 1 - Licence 3 Informatique - 2012/2013 - Semestre 5
Projet: Bibliothèque d'allocation dynamique de mémoire
Auteur: BACARA Christophe
Groupe: 5


-- Présentation du makefile --

clean: Porte très bien son nom

all: Compile tout
bin: Compile les exécutables
lib: Compile la bibliothèque

> Executables:
demo:			Petite démonstration des fonctionnalités
freeinvalidpointer:	Tentative de libération d'un pointeur invalide
twofree:		Tentative de libérations successives d'un même pointeur
overwrite:		Tentative de débordement d'écriture

Les trois derniers exécutables présentent aussi une version identique, mais utilisant
l'optimisation pour les petites allocations. Ces versions ont le même nom, suffixé 
de '-opt'. (Exemple: freeinvalidpointer-opt)

> Variables notables:
DEBUG_MODE:		Permet d'activer le mode debug de la bibliothèque
	   	        (Fonction printmanagedmemory(), appel atexit supplémentaire, ...)
DISABLE_OVERFLOW:	Désactive la vérification des éventuels débordements d'écriture
			(cf. "Description des bugs connus")


-- Présentation de l'implémentation --

Les fonctions calloc(), malloc(), free(), et realloc() sont toutes implémentées,
sous forme de macro appelant les fonctions dpr*(), et sous forme de remplacement 
des fonctions standards.

La gestion de l'optimisation pour les petites allocations, aka mallopt(), est
tout aussi implémentée.

Si le mode debug est actif, il est possible d'appeler, depuis un fichier source
incluant dpr_malloc.h, les fonctions printbacktrace() et printmanagedmemory().
Pour plus d'informations concernant ces fonctions, rendez-vous à l'endroit de leurs
declarations respectives dans le fichier dpr_malloc.c et dpr_malloc.h.

J'ai mis un point d'honneur à commenter (utilement) au maximum mon code, tant pour les
"algorithmes" que pour les définitions et déclarations diverses. De
cette manière, le code s'en trouve auto-documenté, et chaque fonction dispose à la fois
d'une brève (mais utile aussi!) description, située juste avant sa déclaration, ainsi que
d'un ensemble de commentaires dans son corps, relatant ainsi les manipulations effectuées.
Chaque fonction est commentée, excepté lorsque le code est intuitif.

Remarques: la fonction printmanagedmemory() n'est déclarée que dans le .h, et uniquement
	   si le mode debug est activé. De plus, celle-ci permet de vérifier la cohérence
	   du tas.

La structure de données utilisée pour le contrôle des blocs de mémoires est celle-ci :

typedef char byte;
typedef byte memflag[4];
typedef struct s_memblock t_memblock;
struct s_memblock {
    unsigned size;
    t_memblock *nextblock;
    memflag flag;
};

size:	   Stocke la taille totale du bloc mémoire si celui-ci est libre, sinon stocke
      	   la taille de l'espace alloué.
nextblock: Pointeur vers le prochain bloc de mémoire libre. NULL si le bloc est alloué.
memflag:   Permet de marquer la mémoire afin de pouvoir déterminer si un pointeur correspond
	   effectivement à un bloc alloué par la bibliothèque.


-- Description des fonctionnalités --

Il semblerait que pour une utilisation "shell", disont, de mon niveau (relativement bas),
il est tout à fait possible de "vivre" avec cette librairie. Il semble qu'une certaine
quantité de commandes soit parfaitement fonctionnelles (celles du quotidien en tout cas).
L'autocomplétion interne au shell est fonctionnelle aussi. L'interpréteur Python, MySql,
ou encore AMPL fonctionnent, Firefox aussi, ainsi que Vi, et GCC.

Malheureusement (et même plus encore), Emacs ne fonctionnent pas, et toutes les
applications utilisant GConf ne fonctionnent qu'au coup par coup, et crashent très
facilement.


-- Description des bugs connus --

L'utilisation de l'anti-débordements d'écriture, car son implémentation actuelle
génère des erreurs avec la majorité des commandes classiques manipulant des chaînes
de caractères. Cela me semble dû aux fonctions standards string et bstring.

Les bugs concernant GConf sont connus, mais complètement mystérieux pour moi à ce jour.
Je n'ai pas le temps de les analyser, je garde ça pour le semestre prochain.

Cependant, le déboguage d'Emacs a bien avancé depuis la première fois que celui-ci
a planté. Pour le moment, mon dernier problème est celui-ci :

$ export LD_PRELOAD=chemin/d/acces/lib/malloc
$ ltrace emacs 2> ltrace.log
$ less ltrace.log

:
[...]
malloc(488)                                                                 = 0x08c7f66c
malloc(28)                                                                  = 0x08c7f864
malloc(21)                                                                  = 0x08c7f894
memmove(0xXXXXXXXX, 0x832d554, 7, 0, 7)                                     = 0xa1ac728
memmove(0xXXXXXXXX, 0xXXXXXXXX, 0, 0x8179ee4, 0x83ade61)                    = 0xbfa3f320
memmove(0xXXXXXXXX, 0xXXXXXXXX, 8, 0x8179ee4, 0x83ade61)                    = 0xbfa3f320
malloc(512)                                                                 = 0x0a1ae8bc
realloc(0x084dd030, 14
*** dlibc: detected *** realloc(): invalid pointer: 0x84dd030 ***
[...]
:

(Les champs marqués de "0xXXXXXXXX" sont variables.)

Or, le log comporte un peu plus bas le résumé de la mémoire gérée par la bibliothèque :

:
[...]
+-------------------------------------------------------------------------------------------+
| Location  | Size (By)  | Space (By) | Marks |    State    |         Internal use          |
+-----------+------------+------------+-------+-------------+-------------------------------+
| 0xYYYYYYY |         64 |         45 |   3   |  ALLOCATED  |                               |
+-----------+------------+------------+-------+-------------+-------------------------------+
[...]
+-----------+------------+------------+-------+-------------+-------------------------------+
[...]
:

0xYYYYYYYY > 0x084dd030 dans tout les cas.

Ce qui nous montre que le pointeur problèmatique est bien avant le début de la mémoire gérée.
Ce n'est donc pas la bibliothèque qui a fourni ce pointeur. De plus, après vérification
dans un ltrace avec la librairie standard, ce pointeur n'est retourné nul part ailleurs
précédemment. 

Les utilisations multiples de la fonction memmove() me laissent penser qu'il serait sûrement
bénéfique de coder l'ensemble des fonctions de manipulations de chaînes de caratères et de
manipulation de mémoire, afin que nos propres versions soient en accord avec la bibliothèque.
De plus, lors de mes analyses des bugs relatifs au débordement d'écriture, j'ai remarqué que
les blocs de mémoires problèmatiques contenaient justement des chaînes de caractères, et il 
est possible que beaucoup de bugs peuvent être réglés avec des versions spécifiques de
string.h et bstring.h.
