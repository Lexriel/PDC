/* ****************************************************************************
 * File: dpr_malloc.c      Desc: BIBLIOTHEQUE D'ALLOCATION DYNAMIQUE DE MEMOIRE
 * Author: BACARA Christophe (L3S5 Info - Groupe 5 - 2012/2013)
 * 
 *                                                       Feedback is no evil !
 * **************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "dpr_malloc.h"

/* ################################################################################################################# */
/* ############################################ DEFINITIONS DES MACROS ############################################# */
/* ################################################################################################################# */

/* Definition de la directive representant la taille a specifier lors d'un appel par la bibliotheque a la fonction sbrk()
 */
#define MSIZE                    4096

/* Definition des directives relatives a la memoire tampon des appels a la bibliotheque
 */
#define MAX_CALL                 100
#define MAX_STR                  40

/* Definition des directives pour l'acces simplifie aux variables des structures de controle de la bibliotheque
 */
#define MMEM_START               (malloc_control.managedmemstart)
#define FREEBLOCKS               (malloc_control.freememblocks)
#define CALLS                    (malloc_control.malloc_calls)
#define CALL_C                   (malloc_control.calls_count)
#define OPT_CALLED               (malloc_control.mallopt_params.mallopt_alreadycalled)
#define OPT_INITC                (malloc_control.mallopt_params.initc)
#define OPT_TABC                 (malloc_control.mallopt_params.tabc)
#define OPT_TABV                 (malloc_control.mallopt_params.tabv)
#define OPT_ELEMSIZE             (malloc_control.mallopt_params.elemsize)
#define OPT_TABSIZE              (malloc_control.mallopt_params.tabsize)
#define OPT_P_MAXFAST            (malloc_control.mallopt_params.p_maxfast)
#define OPT_P_NUMBLOCKS          (malloc_control.mallopt_params.p_numblocks)

/* Definition des directives inherentes a l'utilisation des fonctions setblockdata() et checkblockdata()
 */
#define MEMBLOCK                 0
#define OPTBLOCK                 1

/* Definition des directives relatives a la memoire tampon des appels a la bibliotheque
 */
#define MAX_CALL                 100
#define MAX_STR                  40

/* Definition des directives relatives au marquage des blocs memoires non optimises
 */
#define FLAG_BLOCKCHECK_FIRST    1
#define FLAG_BLOCKCHECK_SECOND   42

/* Definition des directives relatives a la gestion des donnees d'un bloc et des debordements d'ecriture
 */
#define FLAG_OVERFLOWCHECK       42
#define NEGATIVE_VALUE           -1
#define MEMORY_PADDING           4

/* Definition des macros qui ne servent qu'a ameliorer la lisibilite. Merci le preprocessing !
 *
 * ND: Cette lib toute entiere est d'ailleurs d'une etonnante lisibilite..
 */
#define BCAST(ptr)               ((byte*)(ptr))
#define ALLOC(ptr)               ((byte*)(ptr))+sizeof(t_memblock)
#define ALLOPT(ptr)              ((byte*)(ptr))+sizeof(t_optblock)

/* ################################################################################################################# */
/* ################################### DEFINITIONS ET DECLARATIONS GLOBALES ######################################## */
/* ################################################################################################################# */

/* Enumeration des differents appels a la bibliotheque */
enum e_call { CALLOC, MALLOC, MALLOPT, FREE, REALLOC };

/* Type representant un octet (lisibilite) */
typedef char byte;
/* Type representant un marqueur memoire*/
typedef byte memflag[4];
/* Type representant un bloc de memoire optimise */
typedef void** t_optblock;
/* Type representant un tableau de blocs de memoire optimise */
typedef t_optblock* t_optblocktab;

/* Type de structure representant un appel a la bibliotheque */
typedef struct s_call t_call;
struct s_call {
  char file[MAX_STR];                      /* Nom du fichier appelant */
  unsigned line;                           /* Ligne de l'appel */
  unsigned size;                           /* Taille demandee */
  enum e_call type;                        /* Type d'appel (malloc, calloc, realloc, free) */
};

/* Type de structure de controle d'un bloc memoire */
typedef struct s_memblock t_memblock;
struct s_memblock {
  unsigned size;                           /* Taille du bloc telle que demandee lors de l'appel a la lib si libre
					    * sinon taille physique du bloc. */
  t_memblock *nextblock;                   /* Prochain bloc de memoire libre. NULL si le bloc actuel est alloue */
  memflag flag;                            /* Marqueur memoire */
};

/* Type de structure de controle de l'optimisation d'allocations */
typedef struct s_mallopt_params t_mallopt_params;
struct s_mallopt_params {
  byte mallopt_alreadycalled;              /* Suffisamment expressif */
  
  unsigned initc;                          /* Nombre de tableaux minimums a l'initialisation */
  unsigned tabc;                           /* Nombre de tableaux actuellement utilises */
  t_optblocktab *tabv;                     /* Pointeurs vers les tableaux */

  size_t elemsize;                         /* Taille d'un element du tableau (pointeur + espace) */
  size_t tabsize;                          /* Nombre d'elements dans un tableau */

  int p_maxfast;                           /* Parametre mallopt: mxfast */
  int p_numblocks;                         /* Parametre mallopt: nlblocks */  
};

/* Type de structure de controle de la bibliotheque d'allocation memoire */
typedef struct s_malloc_control t_malloc_control;
struct s_malloc_control {
  void *managedmemstart;                   /* Sauvegarde du debut de la zone de memoire geree */
  t_memblock *freememblocks;               /* Premier maillon de la liste chainee de blocs libres */
  t_mallopt_params mallopt_params;         /* Structure de controle de l'optimisation */
  t_call malloc_calls[MAX_CALL];           /* Tampon de stockage des derniers appels a la lib */
  unsigned calls_count;                    /* Nombre d'appels effectues */
};

/* Definition des variables globales
 */
static byte malloc_initialized = 0;        /* Etat de la bibliotheque de gestion de memoire */
static byte mallopt_initialized = 0;       /* Etat de la gestion optimisee de memoire */
static t_malloc_control malloc_control;    /* Structure de controle de la bibliotheque */

/* ################################################################################################################# */
/* ##################################### DECLARATIONS DES FONCTIONS INTERNES ####################################### */
/* ################################################################################################################# */

/* > Initialise la bibliotheque d'allocation memoire.
 */
static void malloc_init();

/* > Effectue un appel sbrk(MSIZE) afin de creer un nouveau bloc de memoire, puis l'ajoute a la liste des blocs libres.
 * return: t_memblock nouvellement cree
 */
static t_memblock *sbrk_call();

/* > Initialise la structure de controle de l'allocation optimisee.
 */
static void mallopt_init();

/* > Initialise le stockage des pointeurs vers les differents tableaux de blocs optimises,
 *   et alloue le premier tableau de blocs.
 */
static void mallopt_inittabv();

/* > Effectue un appel d'allocation memoire optimise.
 * return: void* vers l'espace memoire alloue.
 */
static void *mallopt_call();

/* > Alloue un nouveau tableau de blocs de memoires optimises.
 * return: t_optblocktab nouvellement alloue
 */
static t_optblocktab mallopt_newtab();

/* > Determine si la zone memoire pointee par ptr est geree par mallopt. Renvoit le tableau contenant en cas de succes.
 * return: - t_optblocktab auquel appartient la zone memoire pointee par ptr
 *         - NULL si la zone memoire pointee par ptr n'appartient pas a l'espace memoire gere par mallopt
 */
static t_optblocktab is_optmanaged(const void *ptr);

/* > Tente de recuperer le premier bloc de memoire optimise libre dans le tableau de bloc correspondant
 *   a l'indice tab_i. Renvoit le bloc libre en cas de succes.
 * return: - t_optblock* correspondant au premier bloc libre du tableau
 *         - NULL si aucun bloc n'est libre dans ce tableau
 */
static t_optblock *mallopt_getfreeblockfromtab(const unsigned tab_i);

/* > Libere un bloc de memoire optimise.
 * return: - 1 si la libération s'est deroulee avec succes
 *         - 0 si le bloc n'est pas gere par l'optimisation
 */
static int free_optblock(const void *ptr);

/* > Insere un bloc de memoire dans la liste chainee de blocs libres. Une fois l'insertion effectuee, tente une fusion avec le bloc
 *   libre precedent dans la liste. Pour finir, tente une fusion autant de fois que possible avec le bloc libre suivant.
 */
static t_memblock *insertblockinlist(t_memblock *toinsert);

/* > Recupere le bloc precedent dans la liste celui specifie.
 * return: - t_memblock* en cas de succes
 *         - NULL en cas d'erreur
 */
static t_memblock *getpreviousblock(const t_memblock *block); 

/* > Alloue un bloc de memoire. Effectue les differentes manipulations necessaires (mise a jour de la liste,
 *   ecrasement des donnees du bloc, etc..) 
 * return: Pointeur vers la zone de memoire disponible
 *
 * ND: Si size est nulle, la fonction considerera que le bloc etait libre et que l'espace alloue sera le 
 *     plus long possible.
 */
static void *allocblock(t_memblock *block, const size_t size);

/* > Fixe les valeurs de marquage d'un bloc memoire (non-optimise)
 */
static void setblockflag(t_memblock *block);

/* > Verifie les valeurs de marquage d'un bloc memoire (non-optimise)
 */
static int checkblockflag(const t_memblock *block);

/* > Fixe des valeurs arbitraires aux octets contenu dans l'espace disponible d'un bloc memoire (optimise ou non) en alternant
 *   des valeurs positives et negatives suivant l'offset de l'octet.
 */
static void setblockdata(const void *block, const int blocktype, const int overflowonly);

#ifndef _DISABLE_OVERFLOW
/* > Verifie la presence d'un debordement d'ecriture.
 */
static int checkblockdata(const void *block, const int blocktype);
#endif

/* Calcule la taille physique d'un bloc alloue.
 */
static int getphysicalsize(const size_t size);

/* > Tente de decouper le bloc de memoire libre specifie en deux blocs dont le premier de taille newsize. Renvoit le bloc nouvellement
 *   cree. Le parametre newsize doit imperativement etre inferieur a la taille du bloc a decouper. Pour que cette operation
 *   reussisse, la taille du block doit etre au moins egal a newsize + sizeof(t_memblock) + OPT_P_MAXFAST + 1, car sinon de "petits"
 *   blocs de memoires non optimises viendront polluer la memoire en n'etant jamais alloue, les appels externes etant intercepte par
 *   mallopt.
 * return: - t_memblock* vers le bloc nouvellement cree si le decoupage a reussi
 *         - NULL si le decoupage est impossible
 *
 * ND: Le chainage est conserve.
 */
static t_memblock *splitmemoryblock(t_memblock *block, const size_t newsize);

/* > Tente de fusionner deux blocs de memoires libres. Pour que cette operation reussisse, les deux blocs
 *   passes en parametre doivent etre distincts et adjacents (au sens physique du terme).
 *   De plus, firstblock doit etre inferieur a secondblock.
 * return: - t_memblock* vers le bloc post-fusion si la fusion a reussie
 *         - NULL si la fusion est impossible
 */
static int mergememoryblocks(t_memblock *firstblock, const t_memblock *secondblock);

/* > Eleve la taille de la memoire disponible pointee par ptr jusqu'a newsize avec un appel interne a malloc(). Effectue la copie
 *   des donnees depuis l'ancienne zone memoire vers la nouvelle, puis libere l'ancienne zone memoire avec un appel interne a free().
 * return: void* vers la nouvelle zone de memoire
 */
static void *increasememory(void *ptr, const size_t newsize, const size_t maxc);

/* > Enregistre, dans le tableau dedie, la trace d'un appel a la bibliotheque d'allocation memoire. Cette fonctionnalite de la 
 *   bibliotheque garde en memoire les MAX_CALL derniers appels au maximum.
 */
static void keeptrace(const char *filename, const unsigned line, const size_t size, const enum e_call type);

/* > Provoque l'arret force de l'execution. Affiche la chaine specifie sur la sortie d'erreur.
 */
static void killme(const char *error, const void *ptr);

#ifndef _DEBUG_MODE
/* > Affiche sur la sortie standard la trace des MAX_CALL derniers appels a la bibliotheque d'allocation memoire.
 */
static void printbacktrace();
#endif

/* ################################################################################################################# */
/* ######################################## DEBUT DEFINITIONS DES FONCTIONS ######################################## */
/* ################################################################################################################# */

void malloc_init() {
  MMEM_START = NULL;
  FREEBLOCKS = NULL;
  CALL_C = 0;
  sbrk_call();
  malloc_initialized = 1;
}

void mallopt_init() {
  OPT_CALLED = 0;
  OPT_TABC = 0;
  OPT_TABV = NULL;
  OPT_ELEMSIZE = 0;
  OPT_TABSIZE = 0;
  OPT_P_MAXFAST = 0;
  OPT_P_NUMBLOCKS = 100;
  mallopt_initialized = 1;
}

void mallopt_inittabv() {
  register unsigned tab_count;
  unsigned tabv_size;

  /* Si au moins un tableau a deja ete initialise, return! */
  if (OPT_TABV)
    return;

  /* Comptage du nombre de pointeurs vers des tableaux seront necessaires pour que malloc ne renvoit pas
   * indefiniment l'appel a mallopt (qui rappellera malloc, etc..) */
  tab_count = 0;
  while ((tabv_size = tab_count * sizeof(t_optblocktab)) < OPT_P_MAXFAST) 
    tab_count++;
  
  /* Allocation du premier tableau de pointeurs */
  OPT_INITC = tab_count;
  OPT_TABV = dpr_malloc(tabv_size, "INTERNAL", __LINE__);

  /* Creation du premier tableau de blocs optimises */
  *OPT_TABV = mallopt_newtab();
  OPT_TABC++;
}

t_memblock *sbrk_call() {
  static byte called = 0;
  t_memblock *new;

  /* Appel a sbrk(), reglage de la taille du bloc nouvellement alloue. */
  new = (t_memblock*)sbrk(MSIZE);
  new->size = MSIZE - (sizeof(t_memblock) + MEMORY_PADDING);
  new->nextblock = NULL;

  /* S'il s'agit du premier appel a cette fonction, reglage de l'adresse de debut de memoire geree. */
  if (!called) {
    MMEM_START = (void*)(new);
    called = 1;
  }

  /* Insertion du bloc dans la liste des blocs libres */
  return insertblockinlist(new);
}

void *mallopt_call() {
  register unsigned tab_i;
  t_optblock *free;

  /* S'il s'agit de la premiere allocation optimisee ... */
  if (!OPT_CALLED) {
    OPT_ELEMSIZE = OPT_P_MAXFAST + sizeof(t_optblock);
    OPT_TABSIZE = (OPT_ELEMSIZE * OPT_P_NUMBLOCKS) + sizeof(t_optblocktab);
    OPT_CALLED = 1;
  }

  /* Si les pointeurs vers les tableaux de optblock n'ont pas ete initialises ... */
  if (!OPT_TABV)
    mallopt_inittabv();

  /* Parcours des tableaux de optblocks */
  for (tab_i = 0; tab_i < OPT_TABC; tab_i++) {
    free = mallopt_getfreeblockfromtab(tab_i);
    /* Si le tableau ne contient aucun bloc libre, iteration suivante */
    if (!free)
      continue;

    setblockdata(free, OPTBLOCK, 0);
    return ALLOPT(free);
  }

  /* Reallocation du tableau de *optblocktab si et seulement si le compte a l'initialisation a ete atteint */
  if (tab_i >= OPT_INITC)
    OPT_TABV = dpr_realloc(OPT_TABV, sizeof(t_optblocktab*) * (OPT_TABC + 1), "INTERNAL", __LINE__);
  
  /* Creation du nouveau tableau de blocs, et recuperation du premier libre */
  *(OPT_TABV + tab_i) = mallopt_newtab();
  OPT_TABC++;
  free = mallopt_getfreeblockfromtab(tab_i);

  setblockdata(free, OPTBLOCK, 0);
  return ALLOPT(free);
}

t_optblocktab mallopt_newtab() {
  t_optblocktab newtab;
  t_optblock current;
  t_optblock last;
  
  /* Allocation de l'espace necessaire pour un nouveau tableau */
  newtab = (t_optblocktab)(dpr_malloc(OPT_TABSIZE, "INTERNAL", __LINE__));

  /* Reglage du pointeur de tete */
  *newtab = (t_optblock)(newtab + 1);

  /* Recuperation du premier et du dernier optblock */
  current = *newtab;
  last = (t_optblock)(BCAST(current) + (OPT_ELEMSIZE * (OPT_P_NUMBLOCKS - 1)));

  /* Reglage du pointeur du dernier optblock */
  *last = 0;

  /* Creation du chainage */
  while (current != last) {
    *current = BCAST(current) + OPT_ELEMSIZE;
    current = (t_optblock)(*current);
  }

  return newtab;
}

t_optblocktab is_optmanaged(const void *ptr) {
  register unsigned tab_i;
  t_optblocktab tab;

  /* Si aucun tableau n'a ete initialise, return NULL */
  if (!OPT_TABV)
    return NULL;

  /* Pour chaque tableau de blocs .. */
  for (tab_i = 0; tab_i < OPT_TABC; tab_i++) {
    tab = *(OPT_TABV + tab_i);
    /* Si le pointeur specifie en parametre est compris entre le debut du tableau et son offset maximum
     * on retourne un pointeur vers le tableau correspondant */
    if (BCAST(tab) <= BCAST(ptr) && BCAST(ptr) < BCAST(tab) + OPT_TABSIZE)
      return tab;
  }

  /* Aucun tableau ne correspond, return NULL */
  return NULL;
}

t_optblock *mallopt_getfreeblockfromtab(const unsigned tab_i) {
  t_optblocktab tab;
  t_optblock *freeblock;

  /* Recuperation du tableau correspondant a l'indice tab_i, et recuperation du premier bloc libre */
  tab = *(OPT_TABV + tab_i);
  freeblock = (t_optblock*)(*tab);

  /* Si aucun bloc libre, return NULL */
  if (!freeblock)
    return NULL;

  /* Reglage du prochain bloc libre du tableau, et reglage du pointeur de tete du bloc alloue */
  *tab = (t_optblock)(*freeblock);
  *freeblock = (t_optblock)(-1);

  return freeblock;
}

int free_optblock(const void *ptr) {
  t_optblocktab tab;
  t_optblock *optblock;
  t_optblock *first_optblock;

  /* Si le pointeur n'est pas gere par l'optimisation, return 0 */
  if (!(tab = is_optmanaged(ptr)))
    return 0;

  /* Verification de la validite du pointeur */
  first_optblock = (t_optblock*)(BCAST(tab) + sizeof(t_optblocktab));
  optblock = (t_optblock*)(BCAST(ptr) - sizeof(t_optblock));
  if (optblock < first_optblock
      || optblock > (t_optblock*)(BCAST(tab) + OPT_TABSIZE - OPT_ELEMSIZE)
      || ((int)optblock - (int)first_optblock) % OPT_P_MAXFAST != 0)
    killme("free() [opt]: invalid pointer: ", ptr);

  /* Verification de l'indisponibilite du bloc pointe */
  if ((int)(*optblock) != -1)
    killme("free() [opt]: pointer already freed: ", ptr);

#ifndef _DISABLE_OVERFLOW
  /* Verification d'un eventuel debordement d'ecriture */
  if (!checkblockdata(optblock, OPTBLOCK))
    killme("free() [opt]: writing overflow: ", ptr);
#endif

  /* Liberation du bloc */
  *optblock = *tab;
  *tab = (t_optblock)optblock;

  setblockdata(optblock, OPTBLOCK, 0);

  return 1;
}

t_memblock *insertblockinlist(t_memblock *toinsert) {
  t_memblock *tmp;

  /* Si le bloc a inserer est deja libere, arret de la fonction */
  if (toinsert->nextblock)
    return NULL;

  setblockdata(toinsert, MEMBLOCK, 0);

  toinsert->size = getphysicalsize(toinsert->size);

  /* Si aucun bloc n'est libre, alors 'toinsert' devient le premier maillon de la liste */
  if (!FREEBLOCKS) {
    FREEBLOCKS = toinsert;
    toinsert->nextblock = toinsert;
    return toinsert;
  }

  /* Verification de la position physique du bloc memoire */
  if (toinsert < FREEBLOCKS) {
    /* Recuperation du dernier bloc de la liste, et ajout du bloc a inserer en debut de liste */
    tmp = getpreviousblock(FREEBLOCKS);
    toinsert->nextblock = FREEBLOCKS;
    tmp->nextblock = toinsert;
    FREEBLOCKS = toinsert;
  }
  else {
    /* Recuperation du bloc precedant celui a inserer selon la valeur de leurs adresses */
    tmp = FREEBLOCKS;
    while (tmp->nextblock < toinsert && tmp->nextblock != FREEBLOCKS)
      tmp = tmp->nextblock;
    /* Mise a jour des pointeurs de la liste chainee */
    toinsert->nextblock = tmp->nextblock;
    tmp->nextblock = toinsert;
    /* Tentative de fusion avec le bloc precedent */
    if (mergememoryblocks(tmp, toinsert))
      toinsert = tmp;
  }

  /* Tentative de fusion avec le bloc suivant */
  mergememoryblocks(toinsert, toinsert->nextblock);
  
  return toinsert;
}

t_memblock *getpreviousblock(const t_memblock *block) {
  t_memblock *previous;

  /* Verifications diverses et variees */
  if (!block)
    return NULL;
  if (!block->nextblock)
    return NULL;
  /* Recuperation du bloc precedent celui passe en parametre */
  previous = FREEBLOCKS;
  while (previous->nextblock != block)
    previous = previous->nextblock;

  return previous;
}

void *allocblock(t_memblock *block, const size_t size) {
  t_memblock *tmp;

  /* Si le bloc a allouer est le seul bloc libre, mise a zero de FREEBLOCKS */
  if (block->nextblock == block) {
    FREEBLOCKS = NULL;
  }
  else {
    /* Si le bloc a allouer est le premier bloc libre, mise a jour de la liste */
    if (FREEBLOCKS == block)
      FREEBLOCKS = block->nextblock;
    
    /* Reglage du bloc libre precedent */
    tmp = getpreviousblock(block);
    tmp->nextblock = block->nextblock;
  }

  /* Reglage du bloc alloue et retourne ! */
  if (size)
    block->size = size;
  else
    block->size = block->size - (sizeof(t_memblock) + (MEMORY_PADDING / 2)); /* MEM_PAD / 2 => Gagner un peu de place */
  block->nextblock = NULL;
  
  setblockflag(block);
  setblockdata(block, MEMBLOCK, 0);

  return ALLOC(block);
}

void setblockflag(t_memblock *block) {
  /* Reglage des flags */
  block->flag[0] = FLAG_BLOCKCHECK_SECOND;
  block->flag[1] = FLAG_BLOCKCHECK_FIRST;
  block->flag[2] = FLAG_BLOCKCHECK_FIRST;
  block->flag[3] = FLAG_BLOCKCHECK_SECOND;
}

int checkblockflag(const t_memblock *block) {
  /* Verification des flags */
  if (block->flag[0] == FLAG_BLOCKCHECK_SECOND
      && block->flag[1] == FLAG_BLOCKCHECK_FIRST
      && block->flag[2] == FLAG_BLOCKCHECK_FIRST
      && block->flag[3] == FLAG_BLOCKCHECK_SECOND)
    return 1;
  return 0;
}

void setblockdata(const void *block, const int blocktype, const int overflowonly) {
  register unsigned i;
  unsigned limit;
  unsigned overflow;
  t_memblock *memblock;
  byte *b;

  /* Selon le type de bloc a regler ...
   * - Recuperation du pointeur vers le debut de l'espace libre
   * - Calcul de l'offset limite pour les valeurs negatives (= espace demande lors de l'appel a la lib)
   * - Calcul de l'offset limite pour l'overflow
   */
  switch (blocktype) {
    /* Bloc de memoire classique */
  case MEMBLOCK:
    memblock = (t_memblock*)(block);
    b = ALLOC(block);
    if (!memblock->nextblock) {
      limit = memblock->size;
      overflow = getphysicalsize(limit) - (sizeof(t_memblock));
    }
    else {
      limit = memblock->size - sizeof(t_memblock);
      overflow = 0;
    }
    break;
    /* Bloc de memoire optimise */
  case OPTBLOCK:
    b = ALLOPT(block);
    limit = OPT_P_MAXFAST - 1;
    overflow = OPT_P_MAXFAST;
    break;
  }

  /* Si chaque octet doit etre initialise avec une valeur negative ... */
  if (!overflowonly) {
    for (i = 0; i < limit; i++) 
      *(b + i) = NEGATIVE_VALUE;
  }

  /* Remplissage du marquage pour l'overflow */
  for (i = limit; i < overflow; i++)
    *(b + i) = FLAG_OVERFLOWCHECK;
}

#ifndef _DISABLE_OVERFLOW
int checkblockdata(const void *block, int blocktype) {
  register unsigned i;
  unsigned offset;
  t_memblock *memblock;
  byte *b;

  /* Selon le type de bloc .. */
  switch (blocktype) {
  case MEMBLOCK:
    /* Recuperation d'un pointeur t_memblock, puis recuperation d'un pointeur vers le premier octet de marquage */
    memblock = (t_memblock*)block;
    b = ALLOC(memblock) + memblock->size;
    /* Recuperation de la longueur du marquage */
    offset = getphysicalsize(memblock->size) - (sizeof(t_memblock) + memblock->size);
    /* Verification du marquage */
    for (i = 0; i < offset; i++) {
      if (*(b + i) != FLAG_OVERFLOWCHECK)
	return 0;
    }
    break;
  case OPTBLOCK:
    /* Recuperation d'un pointeur vers l'octet de marquage */
    b = BCAST(block) + OPT_ELEMSIZE - 1;
    /* Verification du marquage */
    if (*b != FLAG_OVERFLOWCHECK)
      return 0;
    break;

  default:
    /* Si cette erreur apparait, probleme de dev interne a la lib */
    killme("checkblockdata(): unknown block type", NULL);
  }

  return 1;
}
#endif

int getphysicalsize(const size_t size) {
  size_t bsize;
  
  /* Size = taille d'une structure de controle + demandee */
  bsize = sizeof(t_memblock) + size;
  /* Si la taille est deja un multiple de MEMORY_PADDING, on incremente pour forcer le marquage */
  if (!(bsize % MEMORY_PADDING))
    bsize++;
  /* Ajout des octets de marquage */
  while (bsize % MEMORY_PADDING)
    bsize++;

  return bsize;
}

t_memblock *splitmemoryblock(t_memblock *block, const size_t newsize) {
  t_memblock *newblock;
  size_t newphysicalsize;
  size_t minimumsize;

  /* Calcul de la taille physique necessaire, et de la taille minimum pour permettre un decoupage */
  newphysicalsize = getphysicalsize(newsize);
  minimumsize = newphysicalsize + getphysicalsize(1);

  /* Verification de la taille du bloc a decouper */
  if ((!block->nextblock && getphysicalsize(block->size) < minimumsize)
      || (block->nextblock && block->size < minimumsize))
    return NULL;

  /* Creation du nouveau bloc */
  newblock = (t_memblock*)(BCAST(block) + newphysicalsize);
  
  /* Si le bloc n'est pas libre ... */
  if (!block->nextblock) {
    newblock->size = getphysicalsize(block->size) - (newphysicalsize + sizeof(t_memblock) + 1);
    newblock->nextblock = NULL;

    block->size = newsize;
  }
  else {
    newblock->size = block->size - newphysicalsize;
    newblock->nextblock = block->nextblock;

    block->size = newphysicalsize;
    block->nextblock = newblock;
  }

  /* Si le bloc decoupe est le seul bloc libre, on ajoute son pointeur */
  if (block->nextblock == block)
    block->nextblock = newblock;

  /* Reglage divers du bloc */
  setblockflag(newblock);
  setblockdata(newblock, MEMBLOCK, 0);

  return newblock;
}

int mergememoryblocks(t_memblock *firstblock, const t_memblock *secondblock) {
  /* Verification de la disponibilite des blocs a fusionner */
  if (!firstblock->nextblock || !secondblock->nextblock)
    return 0;
  /* Verification de l'adjacence des blocs */
  if (BCAST(firstblock) + firstblock->size != BCAST(secondblock))
    return 0;

  /* Fusion des blocs */
  firstblock->size += secondblock->size;
  firstblock->nextblock = secondblock->nextblock;
  
  return 1;
}

void memorycopy(void *dest, void *src, size_t size) {
  /* Beautiful is better than ugly. */
  char *target;
  char *source;

  /* Explicit is better than implicit. */
  target = (char*)(dest);
  source = (char*)(src);

  /* Simple is better than complex. */
  while (size--) {
    *target = *source;
    target++;
    source++;
    /* [...] */
  }
  /* Readability counts. */
}

void *increasememory(void *ptr, const size_t newsize, const size_t maxc) {
  void *allocated;

  /* Allocation d'un bloc memoire avec une taille suffisante */
  allocated = dpr_malloc(newsize, "INTERNAL", __LINE__);

  /* Copie des donnees */
  memorycopy(allocated, ptr, maxc);

  /* Liberation de l'ancien bloc memoire */
  dpr_free(ptr, "INTERNAL", __LINE__);

  return allocated;
}

void keeptrace(const char *filename, const unsigned line, const size_t size, const enum e_call type) {
  unsigned offset;  
  offset = CALL_C % MAX_CALL;

#ifndef _DEBUG_MODE
  /* S'il s'agit d'un appel interne, celui ci n'est pas logge */
  if (filename && !strcmp(filename, "INTERNAL"))
    return;
#endif

  strncpy(CALLS[offset].file, filename ? filename : "?\t", MAX_STR);
  CALLS[offset].line = line;
  CALLS[offset].size = size;
  CALLS[offset].type = type;
  CALL_C++;  
}

void killme(const char *error, const void *ptr) {
  fflush(stderr);

  if (!ptr)
    fprintf(stderr, "*** dlibc: detected *** %s ***\n", error);
  else
    fprintf(stderr, "*** dlibc: detected *** %s%p ***\n", error, BCAST(ptr));

#ifdef _DEBUG_MODE
  atexit(printmanagedmemory);
#endif
  atexit(printbacktrace);
  exit(EXIT_FAILURE);
}

void printbacktrace() {  
  register unsigned i;
  unsigned limit;
  /* Affichage des n derniers appels a la lib:
   * - n = CALL_C, sauf si CALL_C > 100, auquel cas, n = MAX_CALL
   */
  if (malloc_initialized && CALL_C > 0) {    
    fprintf(stderr, "====================== Backtrace: ======================\n");
    fprintf(stderr, "> Last %i calls (newest first):\n", CALL_C > MAX_CALL ? MAX_CALL : CALL_C);

    limit = CALL_C % MAX_CALL;
    for (i = (CALL_C - 1) % MAX_CALL; i != limit; i--) {
      fprintf(stderr, "File: %s\t-  Line: %i\t--    ", CALLS[i].file, CALLS[i].line);      
      switch (CALLS[i].type) {
      case CALLOC:
	fprintf(stderr, "calloc() : %i bytes(s) requested\n", CALLS[i].size);
	break;
      case MALLOC:
        fprintf(stderr, "malloc() : %i byte(s) requested\n", CALLS[i].size);
        break;
      case MALLOPT:
	fprintf(stderr, "malloc() : %i byte(s) requested [opt]\n", CALLS[i].size);
	break;
      case FREE:
	fprintf(stderr, "free()\n");
	break;
      case REALLOC:
	fprintf(stderr, "realloc(): %i byte(s) requested\n", CALLS[i].size);
	break;
      default:
	break;
      }

      if (!i) { 
	if (CALL_C > MAX_CALL)
	  i = MAX_CALL - 1;
	else
	  break;
      }
    }
    fprintf(stderr, "========================================================\n");
  }
}

#ifdef _DEBUG_MODE
void printmanagedmemory() {
  register int i;
  size_t fsize;
  size_t space;
  size_t gap;
  t_memblock *currentblock;
  void* memptr;
  void* membreak;

  membreak = sbrk(0);
  currentblock = NULL;
  /* Ecriture de l'entete du rapport */
  fprintf(stderr, "\n=== Dlibc: Managed Memory Output ============================================================\n");
  fprintf(stderr, "+-------------------------------------------------------------------------------------------+\n");
  fprintf(stderr, "| Location  | Size (By)  | Space (By) | Marks |    State    |         Internal use          |\n");

  /* Pour chaque bloc de memoire gere .. */
  memptr = MMEM_START;
  gap = 0;
  /*  while (memptr == MMEM_START || (memptr = memptr + gap) < membreak) {*/
  for (memptr = MMEM_START, gap = 0; memptr < membreak; memptr = BCAST(memptr) + gap) {
    currentblock = (t_memblock*)(memptr);
    /* Verification d'erreurs */
    if (!currentblock->size)
      killme("printmanagedmemory(): size set on 0: ", currentblock);
    if (currentblock->nextblock && currentblock->size < (sizeof(t_memblock)))
      killme("printmanagedmemory(): impossible size: ", currentblock);
    
    /* Ligne de separation superieure */
    fprintf(stderr, "+-----------+------------+------------+-------+-------------+-------------------------------+\n");
    /* Adresse du bloc */
    fprintf(stderr, "| %p |", (void*)(currentblock));

    /* Taille totale */
    if (!currentblock->nextblock)
      fsize = getphysicalsize(currentblock->size);
    else
      fsize = currentblock->size;
    fprintf(stderr, " ");
    for (i = 1000000000; i > 1; i = i / 10) {
      if (fsize < i)
	fprintf(stderr, " ");
    }
    fprintf(stderr, "%i |", fsize);

    /* Espace disponible */
    if (!currentblock->nextblock)
      space = currentblock->size;
    else
      space = currentblock->size - sizeof(t_memblock);

    fprintf(stderr, " ");
    for (i = 1000000000; i > 1; i = i / 10) {
      if (space < i)
	fprintf(stderr, " ");
    }
    fprintf(stderr, "%i |", space);

    /* Marquage */
    if (!currentblock->nextblock)
      fprintf(stderr, "   %i   |", getphysicalsize(currentblock->size) - (currentblock->size + sizeof(t_memblock)));
    else
      fprintf(stderr, "   -   |");

    /* Verification speciales */
    if (is_optmanaged(BCAST(currentblock) + sizeof(t_memblock))) {
      fprintf(stderr, "      -      |");
      fprintf(stderr, " MALLOPT MANAGED MEMORY TABLE  |\n");
      gap = getphysicalsize(currentblock->size);
      continue;
    }
    if (BCAST(currentblock) + sizeof(t_memblock) == BCAST(OPT_TABV)) {
      fprintf(stderr, "      -      |");
      fprintf(stderr, "     MALLOPT CONTROL TABLE     |\n");
      gap = getphysicalsize(currentblock->size);
      continue;
    }
    
    /* Etat du bloc */
    if (currentblock->nextblock)
      fprintf(stderr, "    FREE     |");
    else
      fprintf(stderr, "  ALLOCATED  |");
      
    fprintf(stderr, "                               |\n");
    
    if (!currentblock->nextblock)
      gap = getphysicalsize(currentblock->size);
    else
      gap = currentblock->size;
  }  

  /* Pied de rapport */
  fprintf(stderr, "+-------------------------------------------------------------------------------------------+\n");
  fprintf(stderr, "=============================================================================================\n\n");  
}
#endif

int dpr_mallopt(int param, int val) {
  if (!mallopt_initialized)
    mallopt_init();

  if (OPT_CALLED)
    return 0;

  switch (param) {
  case M_MXFAST:
    if (val < 0)
      return 0;
    OPT_P_MAXFAST = val;
    break;
  case M_NLBLOCKS:
    if (val < 0)
      return 0;
    OPT_P_NUMBLOCKS = val;
    break;
  default:
    return 0;
  }

  return 1;
}

void *dpr_calloc(size_t nmemb, size_t size, char *filename, unsigned line) {
  size_t fsize;
  void *mem;
  byte *tmp;

  if (!nmemb || !size)
    return MMEM_START;

  /* Log de l'appel */
  keeptrace(filename, line, nmemb*size, CALLOC);

  /* Calcul de la taille necessaire, et allocation */
  fsize = nmemb * size;
  mem = dpr_malloc(fsize, "INTERNAL", __LINE__);

  /* Mise a zero de l'espace memoire alloue */
  tmp = (byte*)(mem);
  while (fsize--)
    *tmp++ = 0;

  return mem;
}

void *dpr_malloc(size_t size, char *filename, unsigned line) {
  t_memblock *current;
  t_memblock *allocated;
  size_t fsize;

  /* Verification de l'initialisation de la lib */
  if (!malloc_initialized)
    malloc_init();

  /* Verification de l'optimisation eventuelle de cet appel */
  if (mallopt_initialized && size < OPT_P_MAXFAST) {
    keeptrace(filename, line, size, MALLOPT);
    return mallopt_call();
  }

  /* Log de l'appel */
  keeptrace(filename, line, size, MALLOC);
  
  /* Pointeur unique en cas de malloc(0) */
  if (!size)
    return MMEM_START;
  
  /* Calcul de la taille physique necessaire */
  fsize = getphysicalsize(size);

  /* Recherche d'un bloc libre correspondant */
  if (FREEBLOCKS) {
    current = FREEBLOCKS;  
    do {
      /* Si le bloc courant est potentiellement allouable ... */
      if (current->size >= fsize) {
	/* Si possible, on tente un decoupage du bloc */
	if (current->size > fsize) {
	  if (!splitmemoryblock(current, size))
	    return allocblock(current, 0);
	}

	return allocblock(current, size);
      }
    } while ((current = current->nextblock) != FREEBLOCKS);
  }
  
  /* Aucun bloc libre ne correspond, un appel a sbrk() est necessaire */
  allocated = NULL;
  while (!allocated) {
    current = sbrk_call();

    /* Si la taille n'est toujours pas suffisante, on passe a l'iteration suivante */
    if (current->size < fsize)
      continue;

    /* Si possible, on tente un decoupage du bloc */
    if (current->size > fsize)
      splitmemoryblock(current, size);

    allocated = current;
  }

  return allocblock(allocated, size);
}

void dpr_free(void *ptr, char* filename, unsigned line) {
  t_memblock* tofree;
  
  if (!ptr)
    return;

  /* Log de l'appel */
  keeptrace(filename, line, 0, FREE);

  /* Si ptr est le pointeur unique, arret de la fonction sans erreur */
  if (ptr == MMEM_START)
    return;

  /* S'il s'agit d'un bloc optimise, on laisse la gestion de l'optimisation s'en occuper */
  if (free_optblock(ptr))
    return;

  /* Recuperation du bloc memoire correspondant */
  tofree = (t_memblock*)(BCAST(ptr) - sizeof(t_memblock));
  
  /* Verification de la validite du pointeur */
  if (!ptr || !checkblockflag(tofree))
    killme("free(): invalid pointer: ", ptr);

  /* Verification de l'etat d'allocation du pointeur */
  if (tofree->nextblock)
    killme("free(): pointer already freed: ", ptr);

#ifndef _DISABLE_OVERFLOW
  /* Verification d'un eventuel debordement d'ecriture */
  if (!checkblockdata(tofree, MEMBLOCK))
    killme("free(): writing overflow: ", ptr);
#endif

  insertblockinlist(tofree);
}

void *dpr_realloc(void *ptr, size_t size, char *filename, unsigned line) {
  t_memblock *torealloc;
  t_memblock *tofree;
  size_t bsize;
  size_t fsize;
  size_t maxc;

  /* Log de l'appel */
  keeptrace(filename, line, size, REALLOC);

  /* Si ptr est nul, appel malloc(size) */
  if (!ptr)
    return dpr_malloc(size, "INTERNAL", __LINE__);

  /* Recuperation du bloc a reallouer */
  torealloc = (t_memblock*)(BCAST(ptr) - sizeof(t_memblock));

  if (!checkblockflag(torealloc))
    killme("realloc(): invalid pointer: ", ptr);

  /* Si size est nulle, free(ptr) */
  if (!size) {
    dpr_free(ptr, "INTERNAL", __LINE__);
    return NULL;
  }

  /* Calcul des tailles physiques */
  fsize = getphysicalsize(size);
  bsize = getphysicalsize(torealloc->size);

  if (bsize == fsize) {
    torealloc->size = size; 
    return ptr;
  }
  
  if (bsize > fsize) {
    /* Tentative de decoupage du bloc */
    if ((tofree = splitmemoryblock(torealloc, size)))
      insertblockinlist(tofree);

    if (torealloc->nextblock)
      return allocblock(torealloc, size);
    
    torealloc->size = size;
    setblockdata(torealloc, MEMBLOCK, 1);
    return ptr;
  }

  /* Determination de l'offset maximum pour la copie des donnees */
  maxc = torealloc->size > size ? size : torealloc->size;
  return increasememory(ptr, size, maxc);
}

/* ################################################################################################################# */
/* ######################################### FIN DEFINITIONS DES FONCTIONS ######################################### */
/* ################################################################################################################# */
