/* ****************************************************************************
 * File: malloc.c                       Desc: SURCHARGE DES FONCTIONS STANDARD
 * Author: BACARA Christophe (L3S5 Info - Groupe 5 - 2012/2013)
 * **************************************************************************** */

#include <stddef.h>
#include "dpr_malloc.h"

/* Si les macros de remplacement des appels standards sont definiees, celles-ci sont (undef?).
 */
#ifdef malloc
#undef mallopt
#undef calloc
#undef malloc
#undef free
#undef realloc
#endif

/* Surchage des fonctions standards
 */
int mallopt(int param, int val) {
  return dpr_mallopt(param, val);
}
void *calloc(size_t nmemb, size_t size) {
  return dpr_calloc(nmemb, size, (char*)(0), 0);
}
void *malloc(size_t size) {
  return dpr_malloc(size, (char*)(0), 0);
}
void free(void *ptr) {
  dpr_free(ptr, (char*)(0), 0);
}
void *realloc(void *ptr, size_t size) {
  return dpr_realloc(ptr, size, (char*)(0), 0);
}

