#include <stdio.h>
#include <string.h>

#include "dpr_malloc.h"

int main(void) {
  char* string;

  /* Allocation d'une chaine de caractere de longueur maximale 10 (caractere nul non-inclus) */
  string = malloc(11);
  /* Remplissage avec un message (HelloWorld) */
  strncpy(string, "HelloWorld\0", 11);
  /* Liberation de la chaine */
  free(string);

  /* Allocation a nouveau, meme taille */
  string = malloc(11);
  /* Remplissage avec un message (cettechaineestbientroplongue) */
  strncpy(string, "cettechaineestbientroplongue\0", 29);
  /* Liberation de la chaine */
  free(string);

  return 0;
}
