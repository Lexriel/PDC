#include <stdio.h>
#include <stdlib.h>

#include "dpr_malloc.h"

int main(void) {
  char* string;

  string = malloc(10);
  string++;
  free(string);

  return 0;
}
