#include <stdio.h>
#include <string.h>

#include "dpr_malloc.h"

int main(void) {
  char* string;

  mallopt(M_MXFAST, 9);

  /* Allocation d'une chaine de caractere de longueur maximale 10 (caractere nul non-inclus) */
  string = malloc(8);
  /* Remplissage avec un message (HelloWorld) */
  strncpy(string, "HelloWorld\0", 11);
  /* Liberation de la chaine */
  free(string);

  return 0;
}
