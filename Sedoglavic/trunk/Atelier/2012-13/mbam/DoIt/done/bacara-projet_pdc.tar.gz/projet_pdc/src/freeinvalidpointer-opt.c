#include <stdio.h>
#include <stdlib.h>

#include "dpr_malloc.h"

int main(void) {
  char* string;

  mallopt(M_MXFAST, 5);

  string = malloc(4);
  string += 1;
  free(string);

  return 0;
}
