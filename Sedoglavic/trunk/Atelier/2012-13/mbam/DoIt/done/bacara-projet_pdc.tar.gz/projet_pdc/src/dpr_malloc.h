/* ****************************************************************************
 * File: dpr_malloc.h      Desc: BIBLIOTHEQUE D'ALLOCATION DYNAMIQUE DE MEMOIRE
 * Author: BACARA Christophe (L3S5 Info - Groupe 5 - 2012/2013)
 * **************************************************************************** */

#ifndef _MALLOC_H
#define _MALLOC_H          1

/* Macros de remplacement des appels standards (en cas d'inclusion explicite de ce header)
 */
#define mallopt(param,val) dpr_mallopt(param,val)
#define calloc(nmemb,sz)   dpr_calloc(nmemb,sz,__FILE__,__LINE__)
#define malloc(sz)         dpr_malloc(sz,__FILE__,__LINE__)
#define free(ptr)          dpr_free(ptr,__FILE__,__LINE__)
#define realloc(ptr,sz)    dpr_realloc(ptr,sz,__FILE__,__LINE__)

/* Directives de parametrage de la fonction mallopt()
 */
#ifndef M_MXFAST
#define M_MXFAST           1
#endif
#ifndef M_NLBLOCKS
#define M_NLBLOCKS         2
#endif

/* Parametre l'optimisation de l'allocation memoire.
 */
extern int dpr_mallopt(int param, int val);

/* Alloue un tableau de nmemb elements de size octets chacun.
 */
extern void *dpr_calloc(size_t nmemb, size_t size, char *filename, unsigned line);
/* Alloue un espace memoire dynamiquement d'une taille au moins egale a size.
 */
extern void *dpr_malloc(size_t size, char *filename, unsigned line);
/* Libere un espace memoire precedemment alloue par cette bibliotheque.
 */
extern void dpr_free(void *ptr, char *filename, unsigned line);
/* Realloue un espace memoire precedemment alloue par cette bibliotheque jusqu'a au moins size octets.
 */
extern void *dpr_realloc(void *ptr, size_t size, char *filename, unsigned line);

#ifdef _DEBUG_MODE
/* > Affiche sur la sortie standard la trace des MAX_CALL derniers appels a la bibliotheque d'allocation memoire.
 */
extern void printbacktrace();
/* > Affiche sur la sortie standard les informations concernant la memoire geree par la bibliotheque
 */
extern void printmanagedmemory();
#endif

#endif

