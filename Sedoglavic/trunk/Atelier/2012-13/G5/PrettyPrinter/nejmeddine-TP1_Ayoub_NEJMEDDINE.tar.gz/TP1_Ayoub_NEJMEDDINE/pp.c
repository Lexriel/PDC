/* AYOUB NEJMEDDINE
GROUPE 5
S5 */
#include <stdio.h>
#include <stdlib.h>

int 
main()
{
    int c,i=0, as=0;  /* la variable 'as' sert a montrer le début ou la fin d'un commentaire ( back slash ) */
	int tab=0 ; /* la variable tab sert a compter le nombre de tabulation necessaire */
	char car=' ' ;
    enum {ETAT_DBT_LIGNE, ETAT_NORMAL } etat = ETAT_DBT_LIGNE;
  
    while ((c=getchar()) != EOF) {
        switch (etat) {
            case ETAT_DBT_LIGNE:
                switch (c) {
                    case ' ':
		    case '\n':
                    case '\t':
                    break;

		    case '/':

			if(as==0)		 
				as=1;		/*un commentaire a été ouvert*/ 
			putchar(c); etat=  ETAT_NORMAL;
		    break;
			


		    case '{':
 			
			for(i=0;i<tab;i++){
				putchar('\t'); 
			}	
				
			putchar(c);
			putchar('\n');
			tab++;
		  break;
		  case '}':
			
			if (car == '}') tab--;
			for(i=0;i<tab;i++){
				putchar('\t');
			} 
                        putchar(c);

                	car =' ';
		  break;
                   default:  
			if(as==1){		/* dans le cas ou on a un '\n' dans un commentaire on le ferme et on ouvre un autre et cette condition sert a verifier ce cas */
				putchar('/');putchar('*'); putchar(c); etat=  ETAT_NORMAL;
			}else{
			for(i=0;i<tab;i++){
				putchar('\t');
			} 
                        putchar(c);
			car=' ';
                        etat = ETAT_NORMAL;}
                  break;
            }
            break;
            case ETAT_NORMAL:
                switch (c) {
                    case '\n': 
 			if(as==1){
				putchar('*');putchar('/');putchar('\n');etat=ETAT_DBT_LIGNE;    
			}else{
                        putchar('\n');
                        etat=ETAT_DBT_LIGNE;
			}
                        break;
		    case '{':
 

			if(as==1){		/* dans le cas ou on a une accolade ouvrante à l'interieur d'un commentaire */
					putchar(c);
			}

			else{
			putchar('\n');
 
			for(i=0;i<tab;i++)
				putchar('\t');
	
			putchar(c);

			putchar('\n');

			tab++;
			
                        etat = ETAT_DBT_LIGNE;}
		    break;
		    case '}':	/* dans le cas ou on a une accolade fermante à l'interieur d'un commentaire */
			if(as==1){
				putchar(c);
			}
			else{
				putchar('\n');
 
				tab--;
				for(i=0;i<tab;i++)
					putchar('\t');

				putchar(c);
				car='}';
				putchar('\n');

                	        etat = ETAT_DBT_LIGNE;}
			break;

		    case '/':		/* le cas de la fin de commentaire ou la variable as = 0 */
				if(as==0){
					putchar('\n');
					as=1;}
				else	{			
					as=0;}
				
			putchar(c); 

			break;
			

                    default :  
		
                        putchar(c);

                        break;
                }
        }
    }

    exit(EXIT_SUCCESS);
}
