#include <stdio.h>
#include <stdlib.h>

void indent(unsigned int nbTab)
{
  unsigned int i;
  for(i = 0; i < nbTab; i++)
    {
      putchar('\t');
    }
}

int main()
{
  int c;
  unsigned int cpt_acco;
  cpt_acco = 0;
  enum {ETAT_DBT_LIGNE, ETAT_NORMAL, ETAT_FIN_LIGNE } etat = ETAT_DBT_LIGNE;  
  while ((c=getchar()) != EOF) {
    switch (etat) {
    case ETAT_DBT_LIGNE:
      switch (c) {
      case '{':
	indent(cpt_acco ++);
	putchar(c);
	etat = ETAT_FIN_LIGNE;
	break;
      case '}' :
	indent(--cpt_acco) ;
	putchar(c);
	etat = ETAT_FIN_LIGNE;
	break;
      case '\n':
	putchar(c);
      case ' ':
      case '\t':
	break;
      default:
	indent(cpt_acco);
 	putchar(c);
	etat = ETAT_NORMAL;
	break;
      }
      break;
    case ETAT_NORMAL:
      switch (c) {
      case '\n': 
	putchar('\n');
	etat=ETAT_DBT_LIGNE;
	break;
      case '{':
	putchar('\n');
	indent(cpt_acco ++);
	putchar(c);
	etat = ETAT_FIN_LIGNE;
	break;
      case '}':
	putchar('\n');
	indent(--cpt_acco);
	putchar(c);
	etat = ETAT_FIN_LIGNE;
	break;
      default :
	putchar(c);
	break;
      }
      break;
      case ETAT_FIN_LIGNE:
      switch (c) {
      case '{':
	putchar('\n');
	indent(cpt_acco ++);
	putchar(c);
	etat = ETAT_NORMAL;
	break;
      case '}' :
	putchar('\n');
	indent(--cpt_acco) ;
	putchar(c);
	putchar('\n');
	etat = ETAT_DBT_LIGNE;
	break;
      case '\n':
      case ' ':
      case '\t':
	break;
      default:
	putchar('\n');
	indent(cpt_acco);
 	putchar(c);
	etat = ETAT_NORMAL;
	break;
      }
      break;
    }
  }

  exit(EXIT_SUCCESS);
}
