#include <stdio.h>
#include <stdlib.h>
#define indentation 4
int 
main()
{
    int c;
    int nbInd;
    nbInd = 0;
    int i;
    enum {ETAT_DBT_LIGNE, ETAT_NORMAL } etat = ETAT_DBT_LIGNE;
  
    while ((c=getchar()) != EOF) {
     switch (etat) {
	case ETAT_DBT_LIGNE: // cas ou on est au debut d une ligne

                switch (c) {
                    case ' ':
		    case '\t':
		      break; // si l'on a un espace ou un \t on ne fait rien

		case '\n':
		  putchar(c);
		  break;
		   case '{':
		   for (i=0 ; i < (nbInd * indentation); i++)
		    {
		      putchar(' ');
		    }
		  nbInd++;
		  putchar(c);
		  putchar('\n');
		  break;

		case '}':
		  nbInd --;
		  putchar('\n');
		   for (i=0 ; i < (nbInd * indentation); i++)
		    {
		     putchar(' ');
		    }
		 
		  putchar(c);
		  putchar('\n');
 		  break;

		default: // dans le cas general on affiche le caractere lu et passe en etat normal  
		    for (i=0 ; i < (nbInd * indentation); i++)
		   {
		     putchar(' ');
		   }
                        putchar(c);
                        etat = ETAT_NORMAL;
                        break;
                }
                break;









	case ETAT_NORMAL: // cas ou l'on est pas au debut de ligne
                switch (c) {
	
	  case '\t': // si l'on un \t on n'affiche rien
	    break;

		case '\n':  // si on passe une  ligne on se retrouve dans le cas du debut de ligne
                        putchar('\n');
                        etat=ETAT_DBT_LIGNE;
                        break;
		case '}':
		  nbInd--;
		  putchar('\n');
		    for (i=0 ; i < (nbInd * indentation); i++)
		   {
		     putchar(' ');
		   }
		  putchar(c);
		  putchar('\n');
		  etat=ETAT_DBT_LIGNE;
		  break;
		case '{':
		  putchar('\n'); // cas d'une accolade ouvrante  penser a mettre en place le comtpeur d'indentation
		    for (i=0 ; i < (nbInd * indentation); i++)
		   {
		     putchar(' ');
		   }
		  putchar(c);
		  putchar('\n');
		  nbInd ++;
		  etat=ETAT_DBT_LIGNE;
		  break;


		default :  // dans le cas general on affiche   ce qu on lit
		  
                        putchar(c);
                        break;
                }
        }

    }
  
    exit(EXIT_SUCCESS);
}
