#!/bin/sh
make 
./pp < file.c
./pp <file.c> pp2.c
