#include <stdio.h>
#include <stdlib.h>

/*Cette méthode permet de gérer l'indentation*/
void incrementer(int a){
  int i;
  i=0;
 for (i;i<a;i++){
      putchar(' ');
 }
}

int 
main()
{
  int a,b,c,indent; 
  indent=0;

  /*On défini différents états : */
  /*ETAT_DBT_LIGNE : représente le premier caractère d'une ligne */
  /*ETAT_NORMAL : représente les caractères d'une ligne en dehors du premier*/
  /*ETAT_PAS_COMMENTAIRE : représente la transition entre les états ETAT_DBT_LIGNE,ETAT_NORMAL et l'état ETAT_COMMENTAIRE*/
  /*ETAT_COMMENTAIRE : représente un commentaire*/
  /*FIN_ETAT_COMMENTAIRE : représente la fin d'un commentaire*/

  enum {ETAT_DBT_LIGNE, ETAT_NORMAL, ETAT_PAS_COMMENTAIRE, ETAT_COMMENTAIRE,FIN_ETAT_COMMENTAIRE } etat = ETAT_DBT_LIGNE;
    
    /*On parcours chaques caractères du fichier jusqu'à la fin de celui ci"*/
    while ((c=getchar()) != EOF) {
        switch (etat) {

            /* Etat début de ligne*/
            case ETAT_DBT_LIGNE:
                switch (c) {
		    case ' ': 
                    case '\t': /* si le caractère est un espace, une tabulation ou un saut de ligne on ne fait rien*/
                    case '\n':
                        break;

                    /*Si le caractère est un #, on parcours chaques éléments et on l'affiche. Ainsi on est de sur d'afficher une accolade.*/
                    case '#' :
                      putchar(c);
                      while ((b=getchar()) != '\n') {
                         putchar(b);
                      }
                      etat = ETAT_NORMAL; 
		      break;

                     /*Si le caractère est un {, on incrémente (ou pas) l'indention et on affiche le caractère.*/
		    case '{' :
                      incrementer(indent);
		      putchar(c); 
		      putchar('\n');
		      incrementer(indent);
                      etat=ETAT_DBT_LIGNE;
                      indent++;
                      break;

                     /*Si le caractère est un }, on décrémente (ou pas) l'indention et on affiche le caractère.*/
	            case '}' :
                      indent--;
		      putchar(c); 
		      putchar('\n');
                      etat=ETAT_DBT_LIGNE;
                      break;

                    /*Si le caractère est un /, on passe dans l'état ETAT_PAS_COMMENTAIRE car ne certifie qu'une * suivra.*/
                    case '/' :
                      putchar(c); 
                      etat=ETAT_PAS_COMMENTAIRE;
                      break;

                    /*Sinon on affiche le caractère et on passe dans l'état normal.*/
                    default: 
                       incrementer(indent);  
		       putchar(c); 
                       etat = ETAT_NORMAL;
                       break;
                }
                break;

            /* Etat normal*/
            case ETAT_NORMAL:
                switch (c) {
                    case '\n': 
                        putchar('\n');
                        etat=ETAT_DBT_LIGNE;
                        break;

                     /*Cette condition permet d'afficher une accolade entre deux " */
                     case '"' :
                      putchar(c);
                      while ((b=getchar()) != '"') {
                         putchar(b);
                      }
                      putchar('"');
                      etat = ETAT_NORMAL; 
		      break;
                        
                         /*Si le caractère est un {,on saute une ligne et on incrémente (ou pas) l'indention et on affiche le caractère.*/
			case '{':
			 putchar('\n'); 
                         incrementer(indent);
			 putchar(c);
                         putchar('\n');
                         indent++;
			 etat=ETAT_DBT_LIGNE;
			 break;

                        /*Si le caractère est un }, on saute une ligne et on décrémente (ou pas) l'indention et on affiche le caractère.*/
                        case '}':
                         indent--;
			 putchar('\n');
                         incrementer(indent);
			 putchar(c);
                         putchar('\n');
                         etat=ETAT_DBT_LIGNE;
			 break;

                       /*Si le caractère est un /, on passe dans l'état ETAT_PAS_COMMENTAIRE car ne certifie qu'une * suivra.*/
                       case '/': 
                        putchar('\n');
                        putchar(c);
                        etat=ETAT_PAS_COMMENTAIRE;
                        break;

                        /*Sinon on affiche le caractère.*/
                        default :  
                         putchar(c);
                         break;
                }
                break;

               /* Etat ETAT_PAS_COMMENTAIRE*/  
              case ETAT_PAS_COMMENTAIRE :
              switch (c) {
                    //case ' ': 
                   // case '\t': 
                    case '\n':
                     break;

                   /*Si on rencontre une étoile, on passe dans l'état commentaire*/
                    case '*':
                    putchar(c);
                    etat=ETAT_COMMENTAIRE;
                    break;
                   
                    /* sinon on passe dans l'état normal*/
                    default :
                    etat=ETAT_NORMAL;
                    break;
               }
               break;

               /* Etat ETAT_COMMENTAIRE*/  
              case ETAT_COMMENTAIRE :
              switch (c) {
                    
                    /*Cette condition permet de limiter le nombre d'espace dans un commentaire*/
                    case ' ': 
                     switch(a=getchar()){ 
                     case ' ':
                     break;
                     
                     default :
                     putchar(' ');
                     putchar(a);
                     etat=FIN_ETAT_COMMENTAIRE;
                     break;
                     }

                    case '\t':
                    break;

                     /*Si dans un commentaire un trouve un saut de ligne, on ferme se commentaire et on en ouvre un nouveau à la ligne suivante*/
                     case '\n':
                      putchar('*');  
                      putchar('/');
                      putchar('\n');
                      putchar('/');
                      putchar('*');
                      etat=ETAT_COMMENTAIRE;
                    break;
                   
                   /* Si on rencontre une étoile, on passe dans l'état FIN_COMMENTAIRE*/
                    case '*':
                    putchar(c);
                    etat=FIN_ETAT_COMMENTAIRE;
                    break;
                    
                   default :
                    putchar(c);
                    etat=ETAT_COMMENTAIRE;
                    break;
               }
               break;
              
               /* Etat FIN_ETAT_COMMENTAIRE*/
              case FIN_ETAT_COMMENTAIRE:
                  switch (c) {
                    case ' ': 
                    case '\t': 
                    case '\n':
                        break;

                    /*Si on rencontre un / on l'affiche et on passe en début de ligne. */
                    case '/':
                    putchar(c);
                    putchar('\n');
                    etat=ETAT_DBT_LIGNE;
                    break;

                    default :
                    putchar(c);
                    etat=ETAT_COMMENTAIRE;
                    break;
               }
               break;
        }
          
    }
     /*Si le compteur représentant  l'indention est différent de 0, on affiche une erreur*/
     if(indent!=0){
      fprintf(stderr,"\n");
      fprintf(stderr,"ERROR");
      fprintf(stderr,"\n");
      exit(EXIT_FAILURE);
      }
     exit(EXIT_SUCCESS);
}
