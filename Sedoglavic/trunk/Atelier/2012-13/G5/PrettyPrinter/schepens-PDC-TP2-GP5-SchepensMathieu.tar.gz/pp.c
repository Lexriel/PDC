#include <stdio.h>
#include <stdlib.h>

int 
main()
{
  int c, cptNbAcc, i;
    enum {ETAT_DBT_LIGNE, ETAT_NORMAL } etat = ETAT_DBT_LIGNE;
/*On gere si on est en debut de ligne ou non*/
    enum {ETAT_COM, ETAT_PAS_COM, ETAT_VERS_COM, ETAT_RET_COM } com = ETAT_PAS_COM;
/*On gere comment on se situe vis a vis des commentaires*/
    enum {ETAT_CITATION, ETAT_PAS_CITATION } citation = ETAT_PAS_CITATION;
/*On gere comment on se situe vis a vis des citations*/

    cptNbAcc=0;
/*Le compteur d'accolades*/

    while ((c=getchar()) != EOF) {
        switch (etat) {
            case ETAT_DBT_LIGNE:
                switch (c) {
                    case ' ':
                    case '\n':
                    case '\t':
			if(com==ETAT_VERS_COM||com==ETAT_RET_COM)
				com=ETAT_PAS_COM;
                        break;
		    case '\'':
		    case '"':
			if(com!=ETAT_COM)
			{
				if(citation==ETAT_CITATION)
				    citation=ETAT_PAS_CITATION;
				else
				    citation=ETAT_CITATION;
				com=ETAT_PAS_COM;
			}
			putchar(c);
			break;
/*Si on voit un guillemet ou une quote, on bascule ou revient de citation*/

		    case '{' :
		      if(com==ETAT_VERS_COM||com==ETAT_RET_COM)
			com=ETAT_PAS_COM;
		      if(com==ETAT_COM||citation==ETAT_CITATION)
			putchar(c);
		      else
		      {
			  for(i=0;i<cptNbAcc;i++)
			    putchar('\t');

			  putchar(c);
			  putchar('\n');
			  cptNbAcc++;
		      }
		      break;
/*Pour les accolades, on verifie que l'on n'est pas en commentaire ou citation avant d'en tenir compte*/
       		   
		    case '}' :
		      if(com==ETAT_VERS_COM||com==ETAT_RET_COM)
			com=ETAT_PAS_COM;

		      if(com==ETAT_COM||citation==ETAT_CITATION)
			putchar(c);
		      else
		      {
			putchar('\n');
			cptNbAcc--;
			/* Erreur si negatif ? */
			for(i=0;i<cptNbAcc;i++)
			  putchar('\t');

			putchar(c);
			putchar('\n');
		      }
		      break;

		    case '/' :
		      if(com==ETAT_PAS_COM)
			com=ETAT_VERS_COM;
		      if(com==ETAT_RET_COM)
			com=ETAT_PAS_COM;
		      
		      for(i=0;i<cptNbAcc;i++)
			putchar('\t');
                      
		      putchar(c);
		      etat = ETAT_NORMAL;
		      break;

		    case '*' :
		      if(com==ETAT_COM)
			com=ETAT_RET_COM;
		      if(com==ETAT_VERS_COM)
			com=ETAT_COM;

		      for(i=0;i<cptNbAcc;i++)
			putchar('\t');

		      putchar(c);
		      etat = ETAT_NORMAL;
		      break;

/* pour les / et les *, on verifie si on etait, si l'on se dirigeait, si l'on revenait, ou si on n'etait
pas en chemin vers l'edition de commentaire */

                    default:  
		      if(com==ETAT_VERS_COM||com==ETAT_RET_COM)
				com=ETAT_PAS_COM;

		      for(i=0;i<cptNbAcc;i++)
			putchar('\t');
                      putchar(c);
                      etat = ETAT_NORMAL;
                      break;
                }
                break;

            case ETAT_NORMAL:
                switch (c) {
                    case '\n': 
                        putchar('\n');
                        etat=ETAT_DBT_LIGNE;
			if(com==ETAT_VERS_COM||com==ETAT_RET_COM)
				com=ETAT_PAS_COM;
                        break;

		    case '/' :
		      if(com==ETAT_PAS_COM)
			com=ETAT_VERS_COM;
		      if(com==ETAT_RET_COM)
			com=ETAT_PAS_COM;
                      
		      putchar(c);
		      break;

		    case '\'':
		    case '"':
			if(com!=ETAT_COM)
			{
				if(citation==ETAT_CITATION)
				    citation=ETAT_PAS_CITATION;
				else
				    citation=ETAT_CITATION;
				com=ETAT_PAS_COM;
			}
			putchar(c);
			break;
/*Si on voit un guillemet ou une quote, on bascule ou revient de citation*/

		    case '*' :
		      if(com==ETAT_COM)
			com=ETAT_RET_COM;
		      if(com==ETAT_VERS_COM)
			com=ETAT_COM;

		      putchar(c);
		      break;

		    case '{' :
		      if(com==ETAT_VERS_COM||com==ETAT_RET_COM)
			com=ETAT_PAS_COM;

		      if(com==ETAT_COM||citation==ETAT_CITATION)
			putchar(c);
		      else
		      {
			putchar('\n');
			for(i=0;i<cptNbAcc;i++)
			  putchar('\t');

			putchar(c);
			putchar('\n');
			cptNbAcc++;
			etat=ETAT_DBT_LIGNE;
		      }
		      break;

/*Pour les accolades, on verifie que l'on n'est pas en commentaire ou citation avant d'en tenir compte*/

		    case '}' :
		      if(com==ETAT_VERS_COM||com==ETAT_RET_COM)
			com=ETAT_PAS_COM;

		      if(com==ETAT_COM||citation==ETAT_CITATION)
			putchar(c);
		      else
		      {
			putchar('\n');
			cptNbAcc--;
			/* erreur si negatif ? */
			for(i=0;i<cptNbAcc;i++)
			  putchar('\t');

			putchar(c);
			putchar('\n');
			etat=ETAT_DBT_LIGNE;
		      }
		      break;

/* pour les / et les *, on verifie si on etait, si l'on se dirigeait, si l'on revenait, ou si on n'etait
pas en chemin vers l'edition de commentaire */

                    default : 
			if(com==ETAT_VERS_COM||com==ETAT_RET_COM)
				com=ETAT_PAS_COM;
                        putchar(c);
                        break;
                }
        }
    }

    exit(EXIT_SUCCESS);
}
