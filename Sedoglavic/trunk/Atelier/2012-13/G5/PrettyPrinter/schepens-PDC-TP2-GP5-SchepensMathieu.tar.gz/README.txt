TP2 de PDC de Schepens Mathieu, groupe 5 :
Fait :
Gestion de toute l'indentation en fonction des accolades
Prise en compte des commentaires de la forme /*...*/ afin de ne pas compter les accolades
Prise en compte des citations de la forme "..." afin de ne pas compter les accolades
Prise en compte des citations de la forme '...' mais problème indéfini

Améliorations possible :
Prise en compte des \ pour protéger les " fermants par exemple
Indentation en cas de if/for/while/do while avec une seule instruction et donc sans accolades
Vérifier que les citations du type '.' ne contiennent qu'un caractère
Et bien d'autres encore !
