#include <stdio.h>

        /* Ce programme C ne fait pas grand chose */

void main() {
   int n;
     char c;
        printf("{{{}test accolades dans le commentaire{}}");
       c = getchar(); /* on lit un {{{ aaa}} {aa }caractere */ /* sur stdin */

if (c==' ') { n++;putchar(c);}
     else /* sinon,
             on ne fait rien */
      { ;}
}
