/*
VIERLINCK Florian
BERNEAUX Denis
*/


#include <stdio.h>
#include <stdlib.h>
#define NB_BLANC 4 


int indentation = 0 ;
/*fct permettant d'ecrire le nombre de blanc selon l'indentation*/
void
indenter()
{
  int i ;
  for(i=0;i<(indentation*NB_BLANC);i++){
      putchar(' ');
  }
}

int 
main()
{
  /*Permet de savoir si un commentaire va débuter 0 = non | 1 = oui*/
  int DebComm = 0;
  /*Permet de savoir si caractere est dans un commentaire ou non*/
  int ActComm = 0;
  /*Permet de savoir si un commentaire va finir 0 = non | 1 = oui*/
  int FinComm = 0;
    int c;
    enum {ETAT_DBT_LIGNE, ETAT_NORMAL } etat = ETAT_DBT_LIGNE;
    /*parcourt entrée jusqu a la fin*/
    while ((c=getchar()) != EOF) {
        /* test l'état*/
        switch (etat) {
            case ETAT_DBT_LIGNE:
                switch (c) {
                    case ' ':
                    case '\t':
		    case '\n':
                        break;
                    case '/' :
                        DebComm = 1 ;
                        etat = ETAT_NORMAL ;
                        break;
      	       	    case '{':
	        	if(ActComm == 1)
			{
                          putchar(c);
			}else{
                          indenter();
                          putchar(c);
                          putchar('\n');
                          indentation++;
			}
		        break;
	       	     case '}':
			if(ActComm == 1)
			{
                          putchar(c);
			}else{
		          --indentation;
                          indenter();
                          putchar(c);
                          putchar('\n');			}
                        break;
                    default:  
		        /*caractere quelconque = changement état */
			DebComm = 0;
                        FinComm = 0;
		        indenter();
			if(ActComm == 1)
			{
                           putchar('/');
                           putchar('*');
			}
                        putchar(c);
                        etat = ETAT_NORMAL;
                        break;
                }
                break;
            case ETAT_NORMAL:
                switch (c) {
                    case '\n': 
			  if(ActComm == 1)
                          {
                             putchar('*');
                             putchar('/');
                          }
                          putchar('\n');
                          etat=ETAT_DBT_LIGNE;                      
                          break;
	   	    case '{' :
		          if(ActComm == 1)
			  {
                            putchar(c);
		          }else{
		            putchar('\n');
                            indenter();
		            putchar(c);
                            putchar('\n');
                            etat=ETAT_DBT_LIGNE;
		            indentation++;
			  }
                        break;
    		        case '}' :
		            /*a la ligne + indetation  + ecriture + changement etat*/
			    if(ActComm == 1)
			    {
                              putchar(c);
			    }else{
		              putchar('\n');
                              --indentation;
                              indenter();
		              putchar(c);
                              putchar('\n');
		              etat=ETAT_DBT_LIGNE;
			    }
                            break;
                        case '*' :
			   if(ActComm == 1){
                             FinComm = 1;
			   }
                           if(DebComm == 1){
                             ActComm = 1;
		             DebComm = 0;
                             putchar('\n');
                             indenter();
                             putchar('/');
                            }
                            putchar(c);
                            break;
                        case '/' :
                          if(ActComm == 0)
       			  {
                            DebComm = 1 ;
		          }
                          if(FinComm == 1)
			  {
                            putchar(c);
                            putchar('\n');
                            etat = ETAT_DBT_LIGNE ;
                            ActComm = 0;
		       	  }
                          break;
                        default :  
			    if(DebComm == 1)
			    {
                              putchar('/');
			    }
                            DebComm = 0;
                            FinComm = 0;
                            putchar(c);
                            break;
                }
        }
    }
    /*Sort avec 0 avertissements = test nb accolade ouvrante ou fermante*/
    if(indentation == 0){
       exit(EXIT_SUCCESS);
    }else{
      exit(EXIT_FAILURE);
    }
}
