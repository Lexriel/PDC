#include <stdio.h>
#include <stdlib.h>
#define NB_BLANC 4 


int indentation = 0 ;
/*fct permettant d'ecrire le nombre de blanc selon l'indentation*/
void
indenter()
{
  int i ;
  for(i=0;i<(indentation*NB_BLANC);i++){
      putchar(' ');
  }
}

int 
main()
{
    bool CommAct = false ;
    int c;
    enum {ETAT_DBT_LIGNE, ETAT_NORMAL } etat = ETAT_DBT_LIGNE;
    /*parcourt entrée jusqu a la fin*/
    while ((c=getchar()) != EOF) {
        /* test l'état*/
        switch (etat) {
            case ETAT_DBT_LIGNE:
                switch (c) {
                    case ' ':
                    case '\t':
		    case '\n':
                        break;
                    case '/' :
                        putchar(c);
                        break;
      	       	    case '{':
                        indenter();
                        putchar(c);
                        putchar('\n');
                        indentation++;
		        break;
	       	    case '}':
		        --indentation;
                        indenter();
                        putchar(c);
                        putchar('\n');
                        break;
                    default:  
		        /*caractere quelconque = changement état */
		        indenter();
                        putchar(c);
                        etat = ETAT_NORMAL;
                        break;
                }
                break;
            case ETAT_NORMAL:
                switch (c) {
                    case '\n': 
                        if(CommAct == true)
                        {
                          /*un commentaire sur une seule ligne*/
                          putchar('*');
                          putchar('/');
                          putchar('\n');
                          etat=ETAT_DBT_LIGNE;
                        }else{
                          putchar('\n');
                          etat=ETAT_DBT_LIGNE;
                        }
                        break;
	   	    case '{' :
		        putchar('\n');
                        indenter();
		        putchar(c);
                        putchar('\n');
                        etat=ETAT_DBT_LIGNE;
		        indentation++;
                        break;
    		    case '}' :
		      /*a la ligne + indetation  + ecriture + changement etat*/
		        putchar('\n');
                        --indentation;
                        indenter();
		        putchar(c);
                        putchar('\n');
		        etat=ETAT_DBT_LIGNE;
                        break;
                    default :  
                        putchar(c);
                        break;
                }
        }
    }
    /*Sort avec 0 avertissements = test nb accolade ouvrante ou fermante*/
    if(indentation == 0){
       exit(EXIT_SUCCESS);
    }else{
      exit(EXIT_FAILURE);
    }
}
