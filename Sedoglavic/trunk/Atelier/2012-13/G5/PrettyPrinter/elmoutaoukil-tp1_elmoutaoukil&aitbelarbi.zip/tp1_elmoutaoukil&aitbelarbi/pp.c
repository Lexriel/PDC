#include <stdio.h>
#include <stdlib.h>

int 
main()
{
    int c;

    int ident ,nbrac,i;
    i=0;		
    ident=0;
    nbrac=0;

    enum {ETAT_DBT_LIGNE, ETAT_NORMAL,ETATSUISJEUNCOM } etat = ETAT_DBT_LIGNE;
    	
    while ((c=getchar()) != EOF) {
        switch (etat) {
            case ETAT_DBT_LIGNE:
                switch (c) {
                    case ' ':
                    case '\t':
                        etat=ETAT_DBT_LIGNE;
			ident++;
			break ;
                    default:   
                        putchar(c);
                        etat = ETAT_NORMAL;
                        break;
                }
                break;
		
            case ETAT_NORMAL:
                switch (c) {
                    case '\n': 
                        putchar('\n');
                        etat=ETAT_DBT_LIGNE;
                        break;

		   case '{' : 
			nbrac++;
			putchar('\n');
			etat=ETAT_DBT_LIGNE;
			for(i=0 ; i<ident ; i++){
				putchar(' ');
				putchar('{');
			}
			break;
		   case '}' : 
			nbrac--;
			putchar('\n');
			etat=ETAT_DBT_LIGNE;
			for(i=0 ; i<ident ; i++){
				putchar(' ');
				putchar('}');
			}
			break;
		   case '/':
                        if(c=='*') {
			etat=ETATSUISJEUNCOM;
                        putchar('\n');
                        putchar('/');
                        putchar('*');
			}
			else etat = ETAT_NORMAL;			
			if(c=='\n'){
				putchar('*');
				putchar('/');
				etat=ETAT_DBT_LIGNE;
				putchar('\n');
				putchar('/');
                      	        putchar('*');		
			}
			if(c=='{' || c=='}') continue ;
			
			
			break;

			
			
                    default :  
                        putchar(c);
                        break;
                }
        }
    }

    exit(EXIT_SUCCESS);
}					
