#!/bin/sh
make 
./pp < test.c
./pp < test.c > sortie.c
