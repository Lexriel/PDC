#include <stdio.h>
#include <stdlib.h>

void tabulation(int nb)
{ if(nb<0) nb=0;
int i;
	for(i=0;i<nb;i++)
		putchar('\t');
}

int 
main()
{
  int c, cptNbAcc, i,erreur;
    enum {ETAT_DBT_LIGNE, ETAT_NORMAL } etat = ETAT_DBT_LIGNE;
    enum {ETAT_COM, ETAT_PAS_COM, ETAT_VERS_COM, ETAT_RET_COM } com = ETAT_PAS_COM;
    erreur=cptNbAcc=0;

    while ((c=getchar()) != EOF) {
		if(cptNbAcc<0)
		erreur=1;
        switch (etat) {
            case ETAT_DBT_LIGNE:
                switch (c) {
                    case ' ':
                    case '\n':
                    case '\t':
                        break;
                        case '"':
                        tabulation(cptNbAcc);
                        putchar(c);
                        c=getchar();
                        etat = ETAT_NORMAL;
						while (c!= '"' && c!='\n' && c!=EOF ){
						putchar(c);
						c=getchar();
						}
						
						putchar(c);
						break;
						case '\'':
                        tabulation(cptNbAcc);
                        putchar(c);
                        c=getchar();
                        etat = ETAT_NORMAL;
						while (c!= '\'' && c!='\n' && c!=EOF ){
						putchar(c);
						c=getchar();
						}
						
						putchar(c);
						break;
						
						
                        case '#':
                        putchar(c);
                        c=getchar();
						while (c!= '\n'&& c!=EOF) {
						putchar(c);
						c=getchar();
						}
						
						putchar('\n');
						break;

		    case '{' :
		      if(com==ETAT_COM)
			putchar(c);
		      else
		      {
				  
			  tabulation(cptNbAcc);

			  putchar(c);
			  putchar('\n');
			  cptNbAcc++;
		      }
		      break;
				
       		    case '}' :
		      if(com==ETAT_COM)
			putchar(c);
		      else
		      {
			
			cptNbAcc--;
			/* Erreur si negatif ? */
			tabulation(cptNbAcc);
			putchar(c);
			putchar('\n');
		      }
		      break;

		    case '/' :
		      if(com==ETAT_PAS_COM)
			com=ETAT_VERS_COM;
		      if(com==ETAT_RET_COM)
			com=ETAT_PAS_COM;
		      
		      tabulation(cptNbAcc);
                      
		      putchar(c);
		      etat = ETAT_NORMAL;
		      break;

		    case '*' :
		      if(com==ETAT_COM)
			com=ETAT_RET_COM;
		      if(com==ETAT_VERS_COM)
			com=ETAT_COM;

		      tabulation(cptNbAcc);

		      putchar(c);
		      etat = ETAT_NORMAL;
		      break;

                    default:  
		      tabulation(cptNbAcc);
                      putchar(c);
                      etat = ETAT_NORMAL;
                      break;
                }
                break;

            case ETAT_NORMAL:
                switch (c) {
                    case '\n': 
                        putchar('\n');
                        etat=ETAT_DBT_LIGNE;
                        
                        break;
					case '"':
                       
                        putchar(c);
                        c=getchar();
						while (c!= '"' && c!='\n'&& c!=EOF){
						putchar(c);
						c=getchar();
						}
						
						putchar(c);
						break;
						
						case '\'':
                       
                        putchar(c);
                        c=getchar();
						while (c!= '\'' && c!='\n'&& c!=EOF){
						putchar(c);
						c=getchar();
						}
						
						putchar(c);
						break;
						
		    case '/' :
		      if(com==ETAT_PAS_COM)
			com=ETAT_VERS_COM;
		      if(com==ETAT_RET_COM)
			com=ETAT_PAS_COM;
              putchar(c);
		      break;
			
		    case '*' :
		      if(com==ETAT_COM)
			com=ETAT_RET_COM;
		      if(com==ETAT_VERS_COM)
			com=ETAT_COM;

		      putchar(c);
		      break;

		    case '{' :
		      if(com==ETAT_COM)
			putchar(c);
		      else
		      {
			putchar('\n');
			tabulation(cptNbAcc);

			putchar(c);
			putchar('\n');
			cptNbAcc++;
			etat=ETAT_DBT_LIGNE;
		      }
		      break;
			case ';' :
			putchar(c);
			
			
			etat=ETAT_DBT_LIGNE;
			putchar('\n');
			
			break;

		    case '}' :
		      if(com==ETAT_COM)
			putchar(c);
		      else
		      {
			putchar('\n');
			cptNbAcc--;
			/* erreur si negatif ? */
			tabulation(cptNbAcc);
			putchar(c);
			putchar('\n');
			etat=ETAT_DBT_LIGNE;
		      }
		      break;

                    default :  
                        putchar(c);
                        break;
                }

        }
    }
    if(cptNbAcc!=0 || erreur==1)
    {fprintf(stderr,"\nLe nombre d'accolade est incorrect\n ");
		exit(EXIT_FAILURE);

}
    exit(EXIT_SUCCESS);
}
