#!/bin/sh

make
./pp <file.c
./pp <file.c>file_indente.c
