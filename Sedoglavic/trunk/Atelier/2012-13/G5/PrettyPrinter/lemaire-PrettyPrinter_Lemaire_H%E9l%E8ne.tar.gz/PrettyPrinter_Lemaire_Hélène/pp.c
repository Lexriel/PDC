#include <stdio.h>
#include <stdlib.h>

void
indent (int nombre)
{

  int i;
  for (i = 0; i < nombre; i++)
    {
      putchar ('\t');
    }
}

int
main ()
{
  int c;
  int erreur;
  erreur = 0;
  enum
  { ETAT_DBT_LIGNE, ETAT_NORMAL, ETAT_SLASH, ETAT_COMMENTAIRE,
    ETAT_CHAINE
  } etat = ETAT_DBT_LIGNE;
  int nb;
  nb = 0;

  while ((c = getchar ()) != EOF)
    {
      if (nb < 0)
	{
	  erreur = 1;
	}
      switch (etat)
	{
	case ETAT_DBT_LIGNE:
	  switch (c)
	    {
	    case ' ':
	    case '\n':
	    case '\t':
	      break;
	    case '{':
	      indent (nb);
	      putchar (c);
	      putchar ('\n');
	      nb++;
	      break;
	    case '/':
	      etat = ETAT_SLASH;
	      break;

	    case '}':
	      nb--;
	      putchar ('\n');
	      indent (nb);
	      putchar (c);
	      putchar ('\n');
	      break;
	    case '\'':
	      putchar (c);
	      etat = ETAT_CHAINE;
	      break;
	    default:
	      indent (nb);
	      putchar (c);
	      etat = ETAT_NORMAL;
	      break;
	    }
	  break;
	case ETAT_NORMAL:
	  switch (c)
	    {
	    case '\n':
	      putchar ('\n');
	      etat = ETAT_DBT_LIGNE;
	      break;
	    case '{':
	      putchar ('\n');
	      indent (nb);
	      putchar (c);
	      putchar ('\n');
	      nb++;
	      etat = ETAT_DBT_LIGNE;
	      break;
	    case '}':
	      nb--;
	      putchar ('\n');
	      indent (nb);
	      putchar (c);
	      putchar ('\n');
	      etat = ETAT_DBT_LIGNE;
	      break;
	    case '/':
	      etat = ETAT_SLASH;
	      break;
	    case '\'':
	      putchar (c);
	      etat = ETAT_CHAINE;
	      break;
	    default:
	      putchar (c);
	      break;
	    }
	  break;
	case ETAT_SLASH:
	  switch (c)
	    {
	    case '*':
	      indent (nb);
	      putchar ('/');
	      putchar (c);
	      etat = ETAT_COMMENTAIRE;
	      break;
	    case '/':
	      putchar (c);
	      putchar ('\n');
	      etat = ETAT_DBT_LIGNE;
	      break;
	    default:
	      putchar ('/');
	      putchar (c);
	      etat = ETAT_NORMAL;
	      break;
	    }
	  break;
	case ETAT_COMMENTAIRE:
	  switch (c)
	    {
	    case '*':
	      putchar (c);
	      etat = ETAT_SLASH;
	      break;
	    case '\t':
	    case '\n':
	      putchar ('*');
	      putchar ('/');
	      putchar ('\n');
	      putchar ('/');
	      putchar ('*');
	      break;
	    default:
	      putchar (c);
	      etat = ETAT_COMMENTAIRE;
	      break;
	    }
	  break;
	case ETAT_CHAINE:
	  switch (c)
	    {
	    case '\'':
	      putchar (c);
	      etat = ETAT_NORMAL;
	      break;
	    default:
	      putchar (c);
	      break;
	    }
	  break;

	}
    }
  if (erreur == 1 || nb != 0)
    {
      fprintf (stderr, "Erreur d'accolades \n");
      exit (EXIT_FAILURE);
    }
  exit (EXIT_SUCCESS);
}
