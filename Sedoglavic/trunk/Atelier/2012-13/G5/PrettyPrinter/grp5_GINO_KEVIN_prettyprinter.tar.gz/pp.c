


#include <stdio.h>
#include <stdlib.h>
#define nb_espace 4


int 
main()
{
    int c;
    int cpt_indent;
    int i;
    char temp;
    int commentaire;
    commentaire = 0;
    cpt_indent=0;


    enum {ETAT_DBT_LIGNE, ETAT_NORMAL } etat = ETAT_DBT_LIGNE;
  
    while ((c=getchar()) != EOF) {
        switch (etat) {
            case ETAT_DBT_LIGNE:
                switch (c) {

                    case ' ':/* on enleve les espaces et les tabulations en debut de ligne*/
		    case '\t':
		        break;

		    case '\n':	       
		        putchar(c);
		        break;

                    case  '{': /*detecte une accolade ouvrante, applique l'indentation, augmente l'indentation et passe a la ligne*/
		    	for(i=0 ; i < (cpt_indent * nb_espace) ; i++)
			{
			  putchar(' ');
			}
		      cpt_indent++;
		      putchar(c);
		      putchar('\n');
		      break;

		    case '}': /*detecte une accolade fermante, diminue l'indentation , applique l'indentation et passe a la ligne*/
		      cpt_indent--;
			for(i=0 ; i < (cpt_indent * nb_espace) ; i++)
			{
			  putchar(' ');
			}
		      putchar(c);
		      putchar('\n');
		      break;

                    default:   /*si on a autre chose, on met le char et on change d'etat */
		      for(i=0 ; i < (cpt_indent * nb_espace) ; i++)
			{
			  putchar(' ');
			}
		        putchar(c);
                        etat = ETAT_NORMAL;
                        break; 
                }
                break;


            case ETAT_NORMAL:
                switch (c) {
                    case '\n': 
			if (commentaire==0)
			{
                         putchar(c);
                         etat=ETAT_DBT_LIGNE; /*detecte un saut de ligne et change d'etat*/
			}
                        break;
		case '}': /* detecte une accolade fermante, diminue l'indentation et passe a la ligne apres }*/
		         --cpt_indent;
                        putchar('\n');
			for(i=0 ; i < (cpt_indent * nb_espace) ; i++)
			{
			  putchar(' ');
			}
			putchar(c);
			putchar('\n');
			etat=ETAT_DBT_LIGNE;
			break;
		case '{':/* detecte une accolade ouvrante, passe a la ligne, met l'accolade, passe a la ligne, augmente l'indentation et change d'etat*/
		        putchar ('\n');
			for(i=0 ; i < (cpt_indent * nb_espace) ; i++)
			{
			  putchar(' ');
			}
			cpt_indent++;
			putchar(c);
			putchar('\n');
			etat=ETAT_DBT_LIGNE;
			break;
		case '/' :  
			temp=c;
                	c=getchar();
			if (c=='*') /*reconnait le debut d'un commentaire */
			{
				commentaire=1;
				putchar('\n');
				putchar(temp);
				putchar(c);
			}
			break;
		case '*' : 
			temp=c;
			c=getchar();
			if(c=='/') /*reconnait la fin d'un commentaire */
			{
			 commentaire=0;
			 putchar(temp);
			 putchar(c);
			 putchar('\n');
			}else{
			putchar(temp);
			putchar(c);
			}
			break;
		
			
		default :  
                        putchar(c);
                        break; /* dans tout autre cas, on reste dans cet etat et on met le char dans la sortie */
                }
        }
    }

    exit(EXIT_SUCCESS);
}

