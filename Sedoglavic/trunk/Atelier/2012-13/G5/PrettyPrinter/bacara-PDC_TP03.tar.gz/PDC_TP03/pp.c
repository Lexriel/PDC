#include <stdio.h>
#include <stdlib.h>

#define HANDLED -42

typedef enum State State;
enum State { BEGIN_LINE, NORMAL, COMMENT, DIRECTIVE, LITTERAL, CHARACTER };

int flag_err = 0;

int line = 0;

void
newLine() {
	putchar('\n');
	line++;
}

void
printIndentation(int n) {
	int i;
	int space;
	for(i = 0; i < n; i++) {
		for(space = 0; space < 4; space++) {
			putchar(' ');
		}
	}
}

void
handleBrace(int *current, int *imbricationLevel, State *state) {
	if (*state == BEGIN_LINE) {
		printIndentation(*imbricationLevel);
	}
	putchar('{');
	if (*current == '\n') {
		*current = HANDLED;
	}
	newLine();
	*imbricationLevel += 1;
}

void
handleCloseBrace(int *current, int *imbricationLevel, State *state) {
	if (*state != BEGIN_LINE) {
		newLine();
	}
	*imbricationLevel -= 1;

	if (*imbricationLevel < 0) {
		*imbricationLevel = 0;
		flag_err = 1;
		fprintf(stderr, "Ligne %i: Cette portee n'a pas ete ouverte.\n", line);
	}

	printIndentation(*imbricationLevel);
	putchar('}');
	if (*current != '\n' && *current != ';') {
		newLine();
	}
}

void
handleComment(int *imbricationLevel) {
	newLine();
	printIndentation(*imbricationLevel);
	printf("/* ");
}

void ManageCharacterState(int *current, int *buffer, int *imbricationLevel, State *state) {
	switch (*buffer) {
		case '\n':
			fprintf(stderr, "Ligne %i: Un caractere n'a pas ete correctement ferme.\n", line);
			newLine();
			*state = BEGIN_LINE;
			break;
		case '\'':
			putchar('\'');
			if (*current == '\'') {
				putchar('\'');
				*current = HANDLED;
			}
			*state = NORMAL;
			break;
		default:
			putchar(*buffer);
			break;
	}
}

void ManageLitteralState(int *current, int *buffer, int *imbricationLevel, State *state) {
	switch (*buffer) {
		case '\n':
			fprintf(stderr, "Ligne %i: Une chaine de caracteres n'a pas ete correctement fermee.\n", line);
			newLine();
			*state = BEGIN_LINE;
			break;
		case '"':
			putchar('"');
			*state = NORMAL;
			break;
		/* Gestion des guillements echappes :: Pas au point, fonctionne tres bien mais renvoit une erreur (02/10/12 22:12 > Envie de dormir, flemme !)
		case '\\':
			if (*current == '"') {
				printf("\\\"");
				*current = HANDLED;
			}
			else {
				printf("\\");
			}
			break;
		*/
		default:
			putchar(*buffer);
			break;
	}
}

void
ManageDirectiveState(int *current, int *buffer, int *imbricationLevel, State *state) {
	switch (*buffer) {
		case '\n':
			newLine();
			*state = BEGIN_LINE;
			break;
		default:
			putchar(*buffer);
			break;
	}
}

void
ManageBeginLineState(int *current, int *buffer, int *imbricationLevel, State *state) {
	switch (*buffer) {
		/* Gestion des caracteres a effacer */
		case ' ':
		case '\t':
			break;
		/* Gestion de l'accolade ouvrante '{' */
		case '{': 
			handleBrace(current, imbricationLevel, state);
			break;
		/* Gestion de l'accolade fermante '}' */
		case '}': 
	        handleCloseBrace(current, imbricationLevel, state);
			break;
		/* Gestion de la barre oblique '/' (aka slash) */
		case '/':
			if (*current == '*') {
				*state = COMMENT;
			}
			printIndentation(*imbricationLevel);
			putchar('/');
			break;
		/* Gestion du line feed */
		case '\n':
			newLine();
			*state = BEGIN_LINE;
			break;
		/* Gestion des chaines de caracteres */
		case '"':
			printIndentation(*imbricationLevel);
			putchar('"');
			*state = LITTERAL;
			break;
		/* Gestion des caractères */
		case '\'':
			printIndentation(*imbricationLevel);
			putchar('\'');
			*state = CHARACTER;
			break;
		/* Gestion des directives cpp */
		case '#':
			printIndentation(*imbricationLevel);
			putchar('#');
			*state = DIRECTIVE;
			break;
		/* Gestion des caracteres a conserver */
		default:
			printIndentation(*imbricationLevel);
			putchar(*buffer);
			*state = NORMAL;
			break;
	}
}

void
ManageNormalState(int *current, int *buffer, int *imbricationLevel, State *state) {
	switch (*buffer) {
		/* Gestion du retour à la ligne */
		case '\n':
			newLine();
			*state = BEGIN_LINE;
			break;
		/* Gestion de l'accolade ouvrante */
		case '{':
			handleBrace(current, imbricationLevel, state);
			*state = BEGIN_LINE;
			break;
		/* Gestion de l'accolade fermante */
		case '}':
		    handleCloseBrace(current, imbricationLevel, state);
			*state = BEGIN_LINE;
			break;
		/* Gestion de l'oblique */
		case '/':
			if (*current == '*') {
				newLine();
				printIndentation(*imbricationLevel);
				putchar('/');
				*state = COMMENT;	
			}
			else {
				putchar('/');
			}
			break;
		/* Gestion des chaines de caracteres */
		case '"':
			putchar('"');
			*state = LITTERAL;
			break;
		/* Gestion des caractères */
		case '\'':
			putchar('\'');
			*state = CHARACTER;
			break;
		/* Gestion des caracteres a conserver */
		default:
			putchar(*buffer);
			break;
	}
}

void
ManageCommentState(int *current, int *buffer, int *imbricationLevel, int *flag, State *state) {
	switch (*buffer) {
		/* Gestion du retour a la ligne */
		case '\n':
			printf("*/");			
			newLine();
			printIndentation(*imbricationLevel);
			printf("/* ");
			break;
		/* Gestion de l'asterisque */
		case '*':
			if (*current == '/') {
				*flag = 1;
			}
			putchar(*buffer);
			break;
		/* Gestion de l'oblique (fin de commentaire) */
		case '/':
			if (*flag) {
				putchar('/');
				if (*current != '\n') {
					newLine();
				}
				*state = BEGIN_LINE;
			}
			break;
		/* Gestion des caracteres a commenter */
		default:
			putchar(*buffer);
			break;
	}

	if (*buffer != '*' && *flag == 1) {
		*flag = 0;
	}
}

void
DoYourJob(int *current, int *buffer, int *imbricationLevel, int *flag_endOfComment, State *state) {
	switch (*state) {
		case BEGIN_LINE:
			ManageBeginLineState(current, buffer, imbricationLevel, state);
			break;
		case NORMAL:
			ManageNormalState(current, buffer, imbricationLevel, state);
			break;
		case COMMENT:
			ManageCommentState(current, buffer, imbricationLevel, flag_endOfComment, state);
			break;
		case DIRECTIVE:
			ManageDirectiveState(current, buffer, imbricationLevel, state);
			break;
		case LITTERAL:
			ManageLitteralState(current, buffer, imbricationLevel, state);
			break;
		case CHARACTER:
			ManageCharacterState(current, buffer, imbricationLevel, state);
			break;
	}
}

int
main()
{
	State state = BEGIN_LINE;	/* Definition de l'etat de depart */

	int current; 				/* Stocke le caractere en cours de lecture. */
	int buffer;					/* Stocke le caractere précédemment lu. */
	int imbricationLevel;		/* Stocke le niveau d'imbrication. */

	int flag_endOfComment;		/* Flag de fin de commentaire */

	buffer = -1;
	imbricationLevel = 0;

	flag_endOfComment = 0;

	while ((current = getchar()) != EOF) {
		if (buffer != -1) {
			DoYourJob(&current, &buffer, &imbricationLevel, &flag_endOfComment, &state);
		}
 		if (current == HANDLED && (current = getchar()) == EOF) {
			break;
		}

		buffer = current;
	}

	DoYourJob(&current, &buffer, &imbricationLevel, &flag_endOfComment, &state);

	if (state == COMMENT) {
		fprintf(stderr, "Le dernier commentaire ouvert n'a pas ete ferme.\n");
		exit(EXIT_FAILURE);
	}
	else if (flag_err) {
		fprintf(stderr, "Les ouvertures/fermetures de portee ne correspondent pas.\n");
		exit(EXIT_FAILURE);
	}	
	else {
		exit(EXIT_SUCCESS);
	}
}
