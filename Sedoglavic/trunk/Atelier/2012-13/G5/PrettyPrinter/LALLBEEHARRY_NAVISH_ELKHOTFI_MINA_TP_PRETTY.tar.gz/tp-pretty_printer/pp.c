#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void faireTabulation(int nbTabulation)
{
	int i ;
	for ( i = 0 ; i < nbTabulation ; i++ )
	{
		putchar('\t');
	}

}


int main () {

	int nbTabulation = 0 ;
	
	char c ;
	
	enum {ETAT_DBT_LIGNE, ETAT_NORMAL, ETAT_PREPROCESS, ETAT_CHAINE, ETAT_DEBUT_COMM, ETAT_COMM, ETAT_FIN_COMM  } etat = ETAT_DBT_LIGNE;
	while ((c=getchar()) != EOF) {
		switch (etat) 
		{
		
			case ETAT_PREPROCESS: 
					switch (c)
					{
						case '\n' : putchar(c);
								    etat = ETAT_NORMAL; break ;
						case '/' : putchar(c);
								   etat = ETAT_DEBUT_COMM; break;
						default:
							putchar(c);
							break;
					}
					break ;
					
			case ETAT_CHAINE : 
					switch (c)
					{
						case '"' : putchar(c);
								   etat = ETAT_NORMAL; break ;
						default:
							putchar(c);
							break;
					}
					break ;
					
			case ETAT_DBT_LIGNE:
					if (c == '}')
					{
						nbTabulation--;
						faireTabulation(nbTabulation);
					}
					else
						faireTabulation(nbTabulation);
					switch (c) 
					{
						case '\n': putchar(c);
								   etat = ETAT_DBT_LIGNE ; break ;
						case '{': putchar('\n');
								  faireTabulation(nbTabulation);
								  putchar(c);
								  putchar('\n');
								  etat = ETAT_DBT_LIGNE;
								  nbTabulation++;
								  break;
						case '#': putchar(c);
								  etat = ETAT_PREPROCESS ; break ;
						case '"': putchar(c);
								  etat = ETAT_CHAINE ; break ;
						case '/': putchar(c);
								  etat = ETAT_DEBUT_COMM ; break ;
						default:
							putchar(c);
							etat = ETAT_NORMAL;
							break;
					}
					break;
					
			case ETAT_NORMAL:
					switch (c) 
					{
						case '/': putchar('\n');putchar(c);
								   etat = ETAT_DEBUT_COMM; break;
						case '"': putchar(c);
								  etat = ETAT_CHAINE; break;
						case '\n': putchar(c);
								   etat = ETAT_DBT_LIGNE; break;
						case '{': putchar('\n');
								  faireTabulation(nbTabulation);
								  putchar(c);
								  putchar('\n');
								  etat = ETAT_DBT_LIGNE;
								  nbTabulation++;
								  break;
						case '}': putchar('\n');
								  nbTabulation--;
								  faireTabulation(nbTabulation);
								  putchar(c);
								  etat = ETAT_DBT_LIGNE ;
								  break;
						default : 
								putchar(c);
								break;
					}
					break ;
					
			case ETAT_DEBUT_COMM:
					switch(c)
					{
						case '"': putchar(c);
								  etat = ETAT_CHAINE;
						case '/': putchar(c); break ;
						case '*': putchar(c);
								  etat = ETAT_COMM ; break ;
						default :
								putchar(c);
								etat = ETAT_NORMAL;
								break;
					}
					break ;
					
			case ETAT_COMM : 
					switch (c)
					{
						case '*': putchar(c);
								  etat = ETAT_FIN_COMM ; break ;
						default :
								putchar(c); 
								break ;
					}
					break ;
					
			case ETAT_FIN_COMM : 
					switch(c)
					{
						case '*' : putchar(c); break;
						case '/' : putchar(c);
								   etat = ETAT_DBT_LIGNE; break;
						default : 
								 putchar(c);
								 etat = ETAT_COMM;
								 break;
					}
					break ;
			
		}
	}
exit(EXIT_SUCCESS);


}
