make
./pp < file.c > file-i.c
cat file-i.c
indent pp.c
