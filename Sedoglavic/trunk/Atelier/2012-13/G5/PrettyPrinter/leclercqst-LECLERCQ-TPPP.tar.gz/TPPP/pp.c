#include <stdio.h>
#include <stdlib.h>

int
main ()
{
  int c;
  int nbtab = 0;
  int i;
  enum
  { ETAT_DBT_LIGNE, ETAT_NORMAL } etat = ETAT_DBT_LIGNE;

  while ((c = getchar ()) != EOF)
    {
      switch (etat)
	{
	case ETAT_DBT_LIGNE:
	  switch (c)
	    {
	    case ' ':
	    case '\n':
	    case '\t':
	      break;		//Si il y a une tabulation, un espace, ou un retour a la ligne, on reste en etat debut de ligne
	    case '{':

	      for (i = 0; i < nbtab; i++)
		putchar ('\t');
	      putchar (c);
	      putchar ('\n');
	      nbtab++;
	      break;		//Si il y a une accolade ouvrante, on ecrit l'accolade, retourne a la ligne, et effectue une tabulation. L etat passe en etat normal.
	    case '}':

	      nbtab--;
	      for (i = 0; i < nbtab; i++)
		putchar ('\t');
	      putchar (c);
	      putchar ('\n');

	      break;		//Si il y a une accolade fermante, on l'ecrit et on retourne a la ligne
	    default:

	      for (i = 0; i < nbtab; i++)
		putchar ('\t');
	      putchar (c);
	      etat = ETAT_NORMAL;
	      break;		//Si il y a un caractere, on passe en etat normal
	    }
	  break;

	case ETAT_NORMAL:
	  switch (c)
	    {
	    case '\n':
	      putchar ('\n');
	      etat = ETAT_DBT_LIGNE;

	      break;		//Si il y a un retour a la ligne, on passe en etat debut de ligne 
	    case '{':
	      putchar ('\n');
	      for (i = 0; i < nbtab; i++)
		putchar ('\t');
	      putchar (c);
	      putchar ('\n');
	      nbtab++;
	      etat = ETAT_DBT_LIGNE;
	      break;
	    case '}':
	      putchar ('\n');
	      nbtab--;
	      for (i = 0; i < nbtab; i++)
		putchar ('\t');
	      putchar (c);


	      break;
	    default:
	      putchar (c);
	      break;		//Si il y a un caractere, on reste en etat normal
	    }
	}
    }

  exit (EXIT_SUCCESS);
}
