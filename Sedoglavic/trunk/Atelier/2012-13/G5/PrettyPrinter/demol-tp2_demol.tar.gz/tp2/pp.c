#include <stdio.h>
#include <stdlib.h>

int 
main()
{
    int c , cpt, i;
    enum {ETAT_DBT_LIGNE, ETAT_NORMAL, ETAT_COM1, ETAT_COM2, ETAT_COM3, ETAT_COMTMP } etat = ETAT_DBT_LIGNE;
 
    cpt = 0;
    i=0;
    while ((c=getchar()) != EOF) {
      if(cpt < 0)
	  exit(EXIT_FAILURE);


      switch (etat) {
	case ETAT_COM3:
	  switch (c) {
	  case '/':
	    putchar(c);
	    putchar('\n');
	    etat = ETAT_DBT_LIGNE;
	    break;
	  default:
	    putchar(c);
	    etat = ETAT_COM2;
	    break;
	  }
	  break;
	case ETAT_COM2:
	  switch (c) {
	  case '*':
	       putchar(c);
	       etat = ETAT_COM3;
	       break;
	  case '\n':
	    etat = ETAT_COMTMP;
	    putchar(' ');
	    putchar('*');
	    putchar('/');
	    putchar('\n');
	     for(; i<cpt;i++)
		{
			putchar('\t');
		}
		i=0;
		putchar('/');
		putchar('*');
		putchar(' ');
	    break;
	  default :
	    putchar(c);
	    break;
	  }
	  break;
      case ETAT_COMTMP:
	switch (c) {
	case ' ':
	case '\t':
	  break;
	default :
	  putchar(c);
	  etat = ETAT_COM2;
	  break;
	}
	break;
	case ETAT_COM1:
	  switch (c) {
	  case '*':
	        for(; i<cpt;i++)
		{
			putchar('\t');
		}
		i=0;
		putchar('/');
                putchar(c);
                etat = ETAT_COM2;
                break;
	  case '\n':
	    putchar('/');
	    putchar('\n');
	    etat = ETAT_DBT_LIGNE;
	    break;
	  default :
	    	for(; i<cpt;i++)
		{
			putchar('\t');
		}
		i=0;
                putchar(c);
                etat = ETAT_NORMAL;
                break;
	  }
	  break;
            case ETAT_DBT_LIGNE:
                switch (c) {
                    case ' ':
                    case '\t':
		    case '\n':   	    
                        break;
		    case '/':
		      etat = ETAT_COM1;
		      break;
		    case '{':
			for(; i<cpt;i++)
			{
				putchar('\t');
			}
			i=0;
			cpt++;
			putchar(c);
			putchar('\n');
			break;	 
		    case '}':
			putchar('\n');
			cpt--;
			for(; i<cpt;i++)
			{
				putchar('\t');
			}
			i=0;
			putchar(c);
			putchar('\n');
			break;	
                    default:
		       	for(; i<cpt;i++)
			{
				putchar('\t');
			}
			i=0;
                        putchar(c);
                        etat = ETAT_NORMAL;
                        break;
                }
                break;
            case ETAT_NORMAL:
                switch (c) {
		    case '{':
			putchar('\n');
			for(; i<cpt;i++)
			{
				putchar('\t');
			}
			i=0;
			cpt++;
			putchar(c);
			putchar('\n');
			 etat=ETAT_DBT_LIGNE;
			break;	 
		case '/':
		  putchar('\n');
		  etat = ETAT_COM1;
		  break;
		    case '}':
			putchar('\n');
			cpt--;
			for(; i<cpt;i++)
			{
				putchar('\t');
			}
			i=0;
			putchar(c);
			putchar('\n');
			 etat=ETAT_DBT_LIGNE;
			break;	
                    case '\n':    
                        putchar('\n');
                        etat=ETAT_DBT_LIGNE;
                        break;
                    default :
                        putchar(c);
                        break;
                }
        }
    }

    if(cpt!=0)
        exit(EXIT_FAILURE);

    exit(EXIT_SUCCESS);
}
