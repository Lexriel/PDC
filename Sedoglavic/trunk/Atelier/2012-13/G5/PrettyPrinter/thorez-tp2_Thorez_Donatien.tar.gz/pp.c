#include <stdio.h>
#include <stdlib.h>

int
main()
{
    /* Char c en cours de lecture */
    int c;

    /* Enumeration des Etats possibles de l'automate :
	ETAT_DBT_LIGNE : Début d'une ligne normale
	ETAT_NORMAL    : Etat d'une ligne normale

	ETAT_ETOILE    : Etat où le caractère précédent était une étoile
	ETAT_SLASH     : Etat où le caractère précédent était un slash
	
	ETAT_COMMENTAIRE_DEBUT  : Début d'une ligne de commentaire
	ETAT_COMMENTAIRE_OUVERT : Etat d'une ligne de commentaire	
    */

    enum {ETAT_DBT_LIGNE, ETAT_NORMAL,ETAT_ETOILE,ETAT_SLASH,
	ETAT_COMMENTAIRE_OUVERT,ETAT_COMMENTAIRE_DEBUT } etat = ETAT_DBT_LIGNE;

    /* Int i servant pour les boucles for */
    int i = 0;

    /* Int indent indiquant de combien d'espaces il faut indenter le code */
    int indent = 1;


    while ((c=getchar()) != EOF) {
        switch (etat) {
            case ETAT_DBT_LIGNE:
                switch (c) {

		    case ' ':

                    case '\t':
                        break;

                    case '\n':
			putchar(c);
			break;

    /* Si on est en début de ligne et sur une accolade ouvrante, on passe à la ligne
	et on mets les indent espaces. On met ensuite l'accolade ouvrante, 
on passe une ligne, on indente et on ajoute 4 à indent*/

	            case '{':
			putchar('\n');
                        for(i=0;i<(indent);i++){
                        putchar(' ');}
                        putchar(c);
                        putchar('\n');
                        etat=ETAT_DBT_LIGNE;
                        indent+=4;
                        break;

    /* Même principe pour l'accolage fermante */ 

		    case '}':
                         putchar('\n');
			 indent-=4;
                         for(i=0;i<(indent);i++){
                         putchar(' ');}

                         putchar(c);
                         etat=ETAT_DBT_LIGNE;

                        break;
    /* Si on rencontre un slash, on entre dans l'état slash */

	            case '/':
                         etat=ETAT_SLASH;
                         break;

                    default:
			for(i=0;i<(indent);i++){
			putchar(' ');}

			putchar(c);
                        etat = ETAT_NORMAL;
                        break;

                }
                break;


            case ETAT_NORMAL:
                switch (c) {
                    case '\n':
                        putchar('\n');
                        etat=ETAT_DBT_LIGNE;
                        break;

    /* On fait la même chose qu'en début de ligne. La seule différence est dans la gestion des tabulations et des espaces qui sont recopiés ici.*/ 
    /*	En réalité, on aurait pu faire une fonction pour optimiser le code */

		    case '{':
			putchar('\n');
			for(i=0;i<(indent);i++){
			putchar(' ');}
			putchar(c);
			putchar('\n');
			etat=ETAT_DBT_LIGNE;
			indent+=4;
			break;

		    case '}':
			 putchar('\n');
			 indent-=4;
			 for(i=0;i<(indent);i++){
			 putchar(' ');}
			 putchar(c);
			 etat=ETAT_DBT_LIGNE;
			break;
    /* Si on rencontre un slash, on entre dans l'état slash */
		    case '/':
			 etat=ETAT_SLASH;
			 break;

                    default :
                        putchar(c);
                        break;
                }

	  break;


	  case ETAT_SLASH:
		switch (c){

    /* Si on rencontre une étoile après un slash cela signifie que c'est un commentaire.*/
    /* On rentre donc dans l'état commentaire en recopiant le slash et l'étoile. */

			case '*':
			etat=ETAT_COMMENTAIRE_DEBUT;
			putchar('\n');
			for(i=0;i<(indent);i++){
                        putchar(' ');}
			putchar('/');
			putchar('*');
			putchar(' ');
			break;

    /* Sinon il s'agit juste d'un slash donc on retourne dans l'état normal */

			default:
			etat=ETAT_NORMAL;
			putchar('/');
			putchar(c);
			break;}

	  break;

   /* Même principe pour l'étoile */

	  case ETAT_ETOILE:
		switch (c){
			case '/':
			etat=ETAT_NORMAL;
			putchar('*');
			putchar('/');
			break;

			default:
			etat=ETAT_COMMENTAIRE_OUVERT;
			putchar(c);
			break;
			}

	  break;

   /* Comme pour les lignes normales, on différencie le début et le milieu de la ligne en deux états */
		case ETAT_COMMENTAIRE_DEBUT:
                switch (c){

                        case '\n':
                        putchar('*');
                        putchar('/');
                        putchar('\n');
                        for(i=0;i<(indent);i++){
                        putchar(' ');}
                        putchar('/');
                        putchar('*');
			putchar(' ');
                        etat=ETAT_COMMENTAIRE_DEBUT;
                        break;

                        case '*':
                        etat=ETAT_ETOILE;
                        break; 

			case ' ':
			case '\t':
			break;

                        default:
                        putchar(c);
			etat=ETAT_COMMENTAIRE_OUVERT;
                        break;
                        }
         break;


	  case ETAT_COMMENTAIRE_OUVERT:
		switch (c){

		 	case '\n':
			putchar('*');
			putchar('/');
			putchar('\n');
			for(i=0;i<(indent);i++){
                        putchar(' ');}
			putchar('/');
			putchar('*');
			putchar(' ');
			etat=ETAT_COMMENTAIRE_DEBUT;
			break;

			case '*':
			etat=ETAT_ETOILE;
			break;

			default:
			putchar(c);
			break;
			}
	 break;
        }
    }

    exit(EXIT_SUCCESS);
}
