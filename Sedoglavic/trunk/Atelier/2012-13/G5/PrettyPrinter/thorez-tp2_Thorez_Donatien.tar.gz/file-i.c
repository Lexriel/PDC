 #include <stdio.h>


 /* Ce programme C ne fait pas grand chose */

 void main() 
 {

     int n;
     char c;

     c = getchar(); 
     /* on lit un caractere */ 
     /* sur stdin */

     if (c==' ') 
     {
         n++;putchar(c);
     }
     else 
     /* sinon,*/
     /* on ne fait rien */

     {
         ;
     }

 }
