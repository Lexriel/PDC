#include <stdio.h>
#include <stdlib.h>

   int main ()

     {
           char car ;
           char inc=' ';   
       
                
     
    enum {ETAT_DBT_LIGNE, ETAT_NORMAL } etat = ETAT_DBT_LIGNE;
  
    while ((car=getchar()) != 'EOF') {

      

          switch (etat) { 
              case ETAT_DBT_LIGNE:
                  
                   switch (car) {
             
                         case '{': 
		                 
                          putchar('\n');
                          inc=inc+3;         
                          putchar(car);
                          putchar('\n');                            
			   
                          break;     
	

  
                         case '}': 

                           inc=inc-3;
                           putchar('\n');  
                           putchar(car);
                           putchar('\n');              
		           
                         break;

 
                         case '\n':
 
                           putchar(car);
                           inc=inc+1;
                            
                          break;                  
                          


                         case '/':

                           putchar('/');
                           putchar('/');
                          
                          break;
	                  
                          case '\t':  
                           
                          break;

        	         case ' ': 

                           break; 
     

                        default:   
	               putchar(car);
	               etat = ETAT_NORMAL;
	               break;
                     }
    
                  // break;}

                     



	       case ETAT_NORMAL :

	             switch(car) {
                          
		     case '\n':

		        putchar('\n');
                        etat= ETAT_DBT_LIGNE;
                        break;


                      
                     case '{':

                          putchar('\n');
                          inc=inc+3; 
                          putchar(car);
                          putchar('\n');
			  
                        break;

              
 
                      case '}':  

                          inc=inc-3;
                          putchar('\n');
                          putchar(car);                          
                          putchar('\n');              
		          
                       break;
                            

                     case '\t':
                        break;




                    default: 
  
	                 putchar(car);
	                 break;
                   }
                 }

                }


   exit(EXIT_SUCCESS);
}









    

      
  

    
      

    

