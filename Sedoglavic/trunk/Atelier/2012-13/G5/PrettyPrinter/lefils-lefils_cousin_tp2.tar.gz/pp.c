#include <stdio.h>
#include <stdlib.h>

int 
main()
{
  int c;
  int indent = 0;
  int i;
  int comment_flag=0;
  enum {ETAT_DBT_LIGNE, ETAT_NORMAL, ETAT_COMMENT } etat = ETAT_DBT_LIGNE;
  
  while ((c=getchar()) != EOF) {
    switch (etat) {
    case ETAT_COMMENT:
      switch(c) {
      case '\n':
	putchar('*');
	putchar('/');
	putchar('\n');
	for(i=0;i<indent;i++) {
	  putchar('\t');
	}
	putchar('/');
	putchar('*');
	break;
      case '*':
	if(comment_flag==1) {
	  comment_flag=2;
	}
	else {
	  putchar('*');
	}
	break;
      case '/':
	if(comment_flag==2) {
	  putchar('*');
	  putchar('/');
	  putchar('\n');
	  comment_flag=0;
	  etat=ETAT_DBT_LIGNE;
	}
	else {
	  putchar(c);
	}
	break;
    	
      default:
	putchar(c);
      }
      break;
    case ETAT_DBT_LIGNE:
      switch (c) {
	/* on efface les blancs inutiles */
      case ' ':
      case '\t':
      case '\n':
	break;
      case '/':
	if(comment_flag==0) {
	  comment_flag++;
	}
	else {
	  comment_flag=0;
	  putchar('/');
	  putchar(c);
	}
	break;
      case '*':
	if(comment_flag==1) {
	  for(i=0;i<indent;i++) {
	    putchar('\t');
	  }
	  putchar('/');
	  putchar('*');
	  etat=ETAT_COMMENT;
	}
	else {
	  comment_flag=0;
	  for(i=0;i<indent;i++) {
	    putchar('\t');
	  }
	  putchar('/');
	  putchar(c);
	  etat = ETAT_NORMAL;
	}
	break;
      case '{':
	for(i=0;i<indent;i++) {
	  putchar('\t');
	}
	indent+=1;
	putchar(c);
	putchar('\n');

	break;
      case '}':
	indent-=1;
	for(i=0;i<indent;i++) {
	  putchar('\t');
	}
	putchar(c);
	putchar('\n');

	break;
      default:
	/* on ecrit la premiere lettre de la ligne avec l'indentation adequate */
	for(i=0;i<indent;i++) {
	  putchar('\t');
	}
	putchar(c);
	etat = ETAT_NORMAL;
	break;
      }
      break;
    case ETAT_NORMAL:
      switch (c) {
      case '/':
	if(comment_flag==0) {
	  comment_flag=1;
	}
	else {
	  putchar(c);
	}
	break;
      case '*':
	if(comment_flag==1) {
	  putchar('\n');
	  for(i=0;i<indent;i++) {
	    putchar('\t');
	  }
	  putchar('/');
	  putchar('*');
	  etat=ETAT_COMMENT;
	}
	else {
	  putchar(c);
	}
	break;
      case '{':
	putchar('\n');
	for(i=0;i<indent;i++) {
	  putchar('\t');
	}
	putchar(c);
	putchar('\n');
	indent+=1;
	etat=ETAT_DBT_LIGNE;
	break;
      case '}':
	indent-=1;
	putchar('\n');
	for(i=0;i<indent;i++) {
	  putchar('\t');
	}
	putchar(c);
	putchar('\n');
	etat=ETAT_DBT_LIGNE;
	break;
      case '\n': 
	putchar('\n');
	etat=ETAT_DBT_LIGNE;
	break;
      default :
	putchar(c);
	break;
      }
    }
  }
  if(indent==0) {
    exit(EXIT_SUCCESS);
  } else {
    exit(EXIT_FAILURE);
  }
}
