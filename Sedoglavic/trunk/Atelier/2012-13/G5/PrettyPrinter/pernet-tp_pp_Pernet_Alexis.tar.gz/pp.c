/*Auteur: PERNET Alexis*/
 
#include <stdio.h>
#include <stdlib.h>

void indent (unsigned int dec) {
  int i;
  for (i=0; i<dec; i++) {
    putchar('\t');
  }
}
  
int 
main()
{
  int c;
  unsigned int cpt_aco;
  cpt_aco = 0;
  /* definition du tampon et du compteur pour les accolades */
  enum {ETAT_DBT_LIGNE, ETAT_NORMAL, ETAT_FIN_LIGNE} etat = ETAT_DBT_LIGNE;
  /* les différents états utilisés*/
  
  while ((c=getchar()) != EOF) {
    switch (etat) {
    case ETAT_DBT_LIGNE:
      switch (c) {
      case '\n':
	putchar(c);
      case ' ':
      case '\t':
	break;
      /*tant qu'on a des espaces, on continue, et si fin de ligne, on l'imprime*/
      case '{':
       	indent (cpt_aco++);
	putchar(c);
	etat = ETAT_FIN_LIGNE;
	break;
      case '}':
	indent (--cpt_aco);
	putchar(c);
	etat = ETAT_FIN_LIGNE;
	break;
	/*dans le cas des accolades on incremente/decremente le compteur, et on passe en "fin de ligne" pour voir pour la ligne suivante*/ 

      default:
	indent (cpt_aco);
	putchar(c);
	etat = ETAT_NORMAL;
	break;
	/*cas d'un autre caractere, on indente puis passe en etat normal*/
      }
      break;
    case ETAT_NORMAL:
      switch (c) {
      case '\n': 
	putchar('\n');
	etat=ETAT_DBT_LIGNE;
	break;
	/* si saut de ligne on repasse en debut de ligne*/
      case '{':
	putchar('\n');
	indent (cpt_aco++);
	putchar(c);
	etat=ETAT_FIN_LIGNE;
	break;
      case '}':
	putchar('\n');
	indent(--cpt_aco);
	putchar(c);
	etat=ETAT_FIN_LIGNE;
	break;
	/* pour les accolades on passe la aussi en fin de ligne*/

      default :  
	putchar(c);
	break;
	/*cas normal, on imprime le caractère*/
      }
      break;
      /* etat apres une accolade, on regarde si le prochain caractere est un saut de ligne, pour voir si il faut rajouter un saut de ligne autrement */
    case ETAT_FIN_LIGNE:
      switch (c) {
      case '\n':
	putchar(c);
	etat = ETAT_DBT_LIGNE;
	break;
      case '{':
       	indent (cpt_aco++);
	putchar(c);
	break;
      case '}':
	indent (--cpt_aco);
	putchar(c);
	break;
      default:
	putchar('\n');
	indent(cpt_aco);
	putchar(c);
	etat = ETAT_NORMAL;
	break;
      }
      break;
	
    }
  }

  exit(EXIT_SUCCESS);
}
