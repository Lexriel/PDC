#include <stdio.h>
#include <stdlib.h>

void
indentfct
(int a)
{
  int i ;
  for(i=0;i<a;i++)
    putchar(' ') ;
  return ;
}

int
main()
{
  int indenta = 0 ;
  int c;
  enum 
  {
    ETAT_DBT_LIGNE, ETAT_NORMAL
  } 
  etat = ETAT_DBT_LIGNE;
  while ((c=getchar()) != EOF) 
     {
      switch (etat) {
      case ETAT_DBT_LIGNE:
	switch (c) {
	case ' ':
	case '\t':
	  break;
        case '{' :
	  indentfct(indenta) ;
	  putchar('{') ;
	  indenta++ ;
	  putchar('\n') ;
	  eta = ETAT_DBT_LIGNE ;
	default:
	  putchar(c);
	  etat = ETAT_NORMAL;
	  break;
	}
	break;
      case ETAT_NORMAL:
	switch (c) {
	case '\n':
	  putchar('\n');
	  etat=ETAT_DBT_LIGNE;
	  break;
        case '{' :
	  putchar('\n') ;
	  indentfct(indenta) ;
	  putchar('{') ;
	  indenta++ ;
	  putchar('\n') ;
	  eta = ETAT_DBT_LIGNE ;
	default :
	  putchar(c);
	  break;
	}
      }
    }
  exit(EXIT_SUCCESS);

  aa ;

}

