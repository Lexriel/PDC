#include<stdio.h>
#include<stdlib.h>
#include "pp.h"

int
main()
{
  pp();
  exit(EXIT_SUCCESS);
}
