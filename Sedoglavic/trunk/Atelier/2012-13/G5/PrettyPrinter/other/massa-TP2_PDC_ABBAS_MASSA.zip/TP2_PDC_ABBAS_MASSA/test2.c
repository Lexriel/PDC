#include <stdio.h>

/* Ce programme C ne fait pas grand chose */
void main() 
{
	int n;
	char c;
	#idef "biloute"
	c = getchar();

	/* on lit un car*ac*tere */

	/* sur stdin */
	if (c==' ') 
	{
		n++;
		putchar(c);

	}
	else 
	/* sinon,*/
	/* on ne fait rien */

	{
		;
	}
	String m = new String("va te faire}}}");

}
