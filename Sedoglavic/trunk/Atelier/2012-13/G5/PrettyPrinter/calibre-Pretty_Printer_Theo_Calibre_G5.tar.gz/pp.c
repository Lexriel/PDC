/* Calibre theo  
   Groupe 5 
   TP Pretty_Printer */ 


#include <stdio.h>
#include <stdlib.h>

/* Procedure incrementer */
/* Permet de decrementer ou incrementer l'indentation selon les accolades présentes dans le texte */ 
void ind(int a)
{
  int i,j;
  for(i=0;i<a;i++)
  {
      /* on realise 4 espaces pour une meilleur lisibilité */ 
      for(j=0;j<4;j++)
      {
      	putchar(' ');
      }
  }
} // fin fonction indentation

/* test si le programme ne commence pas par une accolade fermante */ 
void testIncolade (int b)
{
  if (b==-1)
  {
      perror("Erreur");
      (void)fprintf(stderr,"texte mal accoladé\n");
      exit(EXIT_FAILURE);
  }
} 

/* Utilisation d'un automate à 5 états pour gerer le pretty_printer
ETAT_DBT_LIGNE, ETAT_NORMAL, ETAT_OBLIQUE, ETAT_COMMENTAIRE, ETAT_ETOILE */ 
int main(void)
{
  int n;
  /* nombre d'accolade restant à la fin du programme */  
  int accolade=0;
  /* getchar() */ 
  int c;
  /* nombres d'espaces effectuées selon la position de l'accolade  */  
  int indentation=0;

    /* les différents états de l'automate */ /* q0 = ETAT_DBT_LIGNE */
    enum {ETAT_DBT_LIGNE, ETAT_NORMAL, ETAT_OBLIQUE, ETAT_COMMENTAIRE, ETAT_ETOILE} etat = ETAT_DBT_LIGNE;
  
    while ((c=getchar()) != EOF) {
        switch (etat) {
            case ETAT_DBT_LIGNE:
                switch (c) {
                    case ' ':
                    case '\t':
		    case '\n':
                        break;
		    /* accolade ouvrante en debut de ligne. On la place de debut de ligne, on incremente le nombre d'accolade et l'indentation */
		    case '{':
		        putchar('\n');
			ind(indentation);
		        putchar(c);
		        etat = ETAT_DBT_LIGNE;
			putchar('\n');
			indentation++;
			accolade++;
		        break;
		    /* accolade fermante en debut de ligne. On execute un retour chariot, on décremente le nombre d'accolade du texte et on décremente l'indentation */
		    case '}':
			indentation--;
		        putchar('\n');
			ind(indentation);
		        putchar(c);
			accolade--;
			testIncolade(accolade);
			etat = ETAT_DBT_LIGNE;
		        break;
		    /* debut commentaire ? */ 
		    case '/':
			putchar('\n');
			ind(indentation);
			putchar(c);
                        etat = ETAT_OBLIQUE;
			break;
                    default:   
			ind(indentation);
                        putchar(c);
                        etat = ETAT_NORMAL;
                        break;
                }
                break;
            case ETAT_NORMAL:
                switch (c) {
		    case '{':
		        putchar('\n');
			ind(indentation);
		        putchar(c);
			putchar('\n');
			indentation++;
			etat = ETAT_DBT_LIGNE;
			accolade++;
			break;
                    case '\n': 
                        putchar('\n');
                        etat = ETAT_DBT_LIGNE;
                        break;
		    case '}':
			indentation--;
		        putchar('\n');
			ind(indentation);
		        putchar(c);
			putchar('\n');
			etat = ETAT_DBT_LIGNE;
			accolade--;
			testIncolade(accolade);
			break;
		    /* debut commentaire ? */ 
	            case '/':
			putchar('\n');
			ind(indentation);
			putchar(c);
                        etat = ETAT_OBLIQUE;
		        break;
                    default :  
                        putchar(c);
                        break;
                }
		break;
	    
	    case ETAT_OBLIQUE:
		switch(c) {
		    /* c'est un commentaire */ 
 		    case '*':
			putchar('*');
			etat=ETAT_COMMENTAIRE;
			break;
		    /* ce n'est pas un commentaire, retour à l'état normal */ 
		    default :
			etat = ETAT_NORMAL;
			break;
		}
		break;

	    case ETAT_COMMENTAIRE:
		switch(c) {
		    /* fin commentaire ? */
		    case '*':
			putchar(c);
			etat=ETAT_ETOILE;
			break;
		    case '\n':
		    case '\t':
			break;
		    /* on continue l'écriture du commentaire */ 
		    default :
			putchar(c);
		    	break;
		}
		break;


	    case ETAT_ETOILE:
		switch(c) {
		    /* fin commentaire retour debut de ligne */
		    case '/':
			putchar(c);
			etat = ETAT_NORMAL;
		    	break;
		    /* il n'y a pas d'oblique apres l'etoile retour dans l'état commentaire */ 
		    default:
			etat = ETAT_COMMENTAIRE;
		    	break;
		}
		break;			
	}

    }

    /* Gere l'erreur des accolades  */ 	
    /* Si accolade !=0 erreur car cela veut dire qu'il en reste dans le programme  */ 

    if(accolade !=0)
    {
	/* exit error */
	perror("Erreur");
        (void)fprintf(stderr,"texte mal accoladé\n");
        exit(EXIT_FAILURE);
    }
    else 
    {
	exit(EXIT_SUCCESS);
    }
 
} // fin main 





  
