#!/bin/sh
make 
./pp < file.c 
./pp <file.c> file2.c
