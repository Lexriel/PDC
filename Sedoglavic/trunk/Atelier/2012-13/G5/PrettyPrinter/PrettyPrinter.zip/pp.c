/**
* FOURNIER Quentin
**/


#include <stdio.h>
#include <stdlib.h>

int
main
(void)
{
	unsigned int i;
	int indent, tmp_char, car, incom;
	indent = 0;
	incom = 0;

	int c;
	enum {ETAT_DBT_LIGNE, ETAT_NORMAL } etat = ETAT_DBT_LIGNE;
	while ((c=getchar()) != EOF) // Tant que le caract�re courant n'est pas le caract�re 'fin de fichier'.
	{
		switch (etat) // Selon l'�tat actuel.
		{
			case ETAT_DBT_LIGNE: // Lors d'un d�but de ligne.
			switch (c)
			{
				case ' ': // Si espace,
				case '\t': // tabulation ou
				case '\n': // retour � la ligne, on ne fait rien.
				break;
				case '{': // Reconnaissance d'une accolade ouvrante.
					for(i = 0 ; i < indent ; i++) // On indente avec le niveau voulu.
					{
						putchar('\t'); // Ajout d'une tabulation.
					}
					putchar('{'); // Ajout de l'accolade ouvrante.
					putchar('\n'); // Ajout d'un retour � la ligne.
					indent++; // Incr�mentation de l'indentation.
				break;
				case '}': // Reconnaissance d'une accolade fermante.
					indent--; // D�cr�mentation de l'indentation.
					putchar('\n'); // Ajout d'un retour � la ligne.
					for(i = 0 ; i < indent ; i++) // On indente avec le niveau voulu.
					{
						putchar('\t'); // Ajout d'une tabulation.
					}
					putchar('}'); // Ajout de l'accolade fermante.
				break;
				case '/': // Dans le cas du caract�re '/'.
					if((tmp_char = getchar()) == '*') // Si le caract�re suivant est '*'.
					{
						for(i = 0 ; i < indent ; i++) // On indente avec le niveau voulu.
						{
							putchar('\t'); // Ajout d'une tabulation.
						}
						incom = 1; // Passage en commentaire.
					}
					putchar(c); // Ajout du caract�re stock� dans la variable c.
					putchar(tmp_char); // Ajout du caract�rement stock� dans la variable tmp_char.
				break;
				default: // Dans tout autre cas.
					if(incom == 0) // Si nous ne sommes pas dans un commentaire.
						for(i = 0 ; i < indent ; i++) // On indente avec le niveau voulu.
						{
							putchar('\t'); // Ajout d'une tabulation.
						}
					putchar(c); // Ajout du caract�re stock� dans la variable c.
					etat = ETAT_NORMAL; // Passage en �tat normal.
				break;
			}
			break;
			case ETAT_NORMAL: // Lors d'un �tat normal.
			switch (c)
			{
				case '\n': // Dans le cas d'un retour � la ligne.
					if(incom == 1)
					{
						putchar(' '); // Ajout du caract�re ' '.
						putchar('*'); // Ajout du caract�re '*'.
						putchar('/'); // Ajout du caract�re '/'.
					}
					putchar('\n'); // Ajout d'un retour � la ligne.
					if(incom == 1)
					{
						for(i = 0 ; i < indent ; i++) // On indente avec le niveau voulu.
						{
							putchar('\t'); // Ajout d'une tabulation.
						}
						putchar('/'); // Ajout du caract�re '/'.
						putchar('*'); // Ajout du caract�re '*'.
						putchar(' '); // Ajout du caract�re ' '.
					}
					etat=ETAT_DBT_LIGNE; // Passage en d�but de ligne.
				break;
				case '{': // En cas d'accolade ouvrante.
					putchar('\n');
					for(i = 0 ; i < indent ; i++) // On indente avec le niveau voulu.
					{
						putchar('\t'); // Ajout d'une tabulation.
					}
					indent++; // Incr�mentation du niveau d'indentation.
					putchar('{'); // Ajout d'une accolade ouvrante.
					putchar('\n'); // Ajout d'un retour � la ligne.
					etat=ETAT_DBT_LIGNE; // Passage en d�but de ligne.
				break;
				case '}': // En cas d'accolade fermante.
					indent--; // D�cr�mentation du niveau d'indentation.
					putchar('\n'); // Ajout d'un retour � la ligne.
					for(i = 0 ; i < indent ; i++) // On indente avec le niveau voulu.
					{
						putchar('\t'); // Ajout d'une tabulation.
					}
					putchar('}'); // Ajout de l'accolade fermante.
				break;
				case '/': // En cas de caract�re '/'.
					if((tmp_char = getchar()) == '*') // Si le caract�re stock� dans la variable tmp_char est '*'.
					{
						for(i = 0 ; i < indent ; i++) // On indente avec le niveau voulu.
						{
							putchar('\n'); // Ajout d'un retour � la ligne.
							putchar('\t'); // Ajout d'une tabulation.
						}
						incom = 1; // Passage en commentaire.
					}
					putchar(c); // Ajout du caract�re stock� dans la variable c.
					putchar(tmp_char); // Ajout du caract�re stock� dans la variable tmp_char.
				break;
				case '*': // En cas de caract�re '*'.
					tmp_char = getchar(); // Affectation de la variable tmp_char par la valeur du prochain caract�re.
					putchar(c); // Ajout du caract�re stock� dans la variable c.
					putchar(tmp_char); // Ajout du caract�re stock� dans la variable tmp_char.
					if(tmp_char == '/') // Si le caract�re dans tmp_char est '/'.
					{
						incom = 0; // Sortie de commentaire.
					}
				break;
				default : // Dans tout autre cas.
					putchar(c); // Ajout du caract�re stock� dans la variable c.
				break;
			}
		}
	}
	if(indent > 0) // Si le niveau d'indentation est toujours sup�rieur � 0.
	{
		fprintf(stderr, "Il manque %i accolade(s) fermantes.", indent); // Avertissement avec le nombre d'accolades fermantes manquantes.
		exit(EXIT_FAILURE); // Sortie du programme avec �chec.
	}
	if(indent < 0) // Si l'indentation devait �tre n�gative � la fin de l'application du programme.
	{
		fprintf(stderr, "Il manque %i accolade(s) ouvrantes.", -indent); // Avertissement avec le nombre d'accolades ouvrantes manquantes.
		exit(EXIT_FAILURE); // Sortie du programme avec �chec.
	}
	if(incom != 0) // Si nous sommes toujours en commentaire.
	{
		fprintf(stderr, "Une ligne de commentaire � mal �t� ferm�e."); // Avertissement sur une ligne de commentaire mal ferm�e.
		exit(EXIT_FAILURE); // Sortie du programme avec �chec.
	}
	exit(EXIT_SUCCESS); // Sortie du programme sans erreurs.
}
