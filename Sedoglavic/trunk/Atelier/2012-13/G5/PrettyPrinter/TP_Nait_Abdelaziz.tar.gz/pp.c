#include<stdio.h>
#include<stdlib.h>

void indenter(int indent)
{
	int i;
	for(i=0; i<indent; i++) for(i=0; i<indent; i++) putchar('\t');
}
int main()
{
	char c;
	enum {ETAT_DBT_LIGNE, ETAT_NORMAL, ETAT_DBT_COMMENTAIRE, ETAT_FIN_COMMENTAIRE, ETAT_ESPACES} etat = ETAT_DBT_LIGNE;	
	int indent = 0;
	char dernier;


	while((c = getchar()) != EOF)
	{
		/* Je supprime les espaces consécutifs */
		while(dernier==' ' && c==' ' && c!=EOF)
			c=getchar();
		if(c==EOF)break;

		switch(etat)
		{
			case ETAT_DBT_LIGNE:
				switch(c)
				{
					/* Je supprimes les blancs, les tabulations et les retours chariots en début de ligne */
					case ' ':						
					case '\n':						
					case '\t':
						break; 


					case '/':
						etat = ETAT_DBT_COMMENTAIRE;
						break;

					case '*':
						putchar(c);
						etat=ETAT_FIN_COMMENTAIRE;
						break;
					case '{':
						indenter(indent);
						putchar(c);
						indent++;
						putchar('\n');
						etat=ETAT_DBT_LIGNE;
						break;
					case '}':
						indent--;
						putchar('\n');
						indenter(indent);
						putchar(c);
						putchar('\n');
						break;
					default:
						indenter(indent);
						putchar(c); 
						etat=ETAT_NORMAL;
						break;
				}
				break;
			case ETAT_NORMAL:
				switch(c)
				{
					case ';':
						putchar(c);						
						if(dernier!='\'' && dernier!='\"') 
						{
							putchar('\n');
							etat=ETAT_DBT_LIGNE; 
						}
						break;
					case ':':
						if(dernier!='\'' && dernier!='\"')
						{
							putchar(c);
							putchar('\n');
							etat=ETAT_DBT_LIGNE;
						}
						break;
					case '{':
						putchar('\n');
						indenter(indent);
						putchar(c);
						indent++;
						putchar('\n');
						etat=ETAT_DBT_LIGNE;
						break;
					case '}':
						indent--;
						putchar('\n');
						etat=ETAT_DBT_LIGNE;
						indenter(indent);
						putchar(c);
						putchar('\n');
						break;
					case '/':
						etat = ETAT_DBT_COMMENTAIRE;
						break;
					case '*':
						putchar(c);
						etat=ETAT_FIN_COMMENTAIRE;
						break;
					case '\n':						
					case '\t':
						break;
					default :  
						putchar(c);
						break;
				}
				break;
			case ETAT_DBT_COMMENTAIRE:
				switch(c)
				{

					case '*':
						putchar('\n');
						indenter(indent);
						putchar('/');
						putchar(c);
						etat=ETAT_NORMAL;
						break;
					default:
						putchar(c);
						etat=ETAT_NORMAL;
				}
				break;
			case ETAT_FIN_COMMENTAIRE:
				switch(c)
				{
					case '/':
						putchar(c);
						putchar('\n');
						etat = ETAT_DBT_LIGNE;
						break;
					case '*':
						putchar(c);
						break;
					default:
						putchar(c);
						etat=ETAT_NORMAL;
						break;
				}
				break;
			case ETAT_ESPACES:
				switch(c)
				{
					case ' ':
						break;
					default:
						putchar(c);
						etat=ETAT_NORMAL;
						break;
				}
		}
		dernier = c;
	}
	
	return 0;
}
