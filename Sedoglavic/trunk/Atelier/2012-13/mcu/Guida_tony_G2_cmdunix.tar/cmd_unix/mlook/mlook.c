#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"
int main (int argc, char *argv[])
{
	char ligne[MAXLINE];
	char *chaineachercher;
	char *find;
	fi=stdin;
    	if (argc>2){
     		printf("nombre d'argument incorrect\n");
      		return 0;
    	}
	chaineachercher=argv[1];
	/*  stop sur fin de fichier ou erreur  */
	while (fgets(ligne,MAX,fi) != NULL)   
   	{
		find= strstr(ligne,chaineachercher);
		
   		if (find!=NULL){
			printf("%s\n",chaineachercher);
			exit(EXIT_SUCCESS);
		}
   	}
	exit(EXIT_FAILURE);;
}
