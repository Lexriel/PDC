#!/bin/bash

./mlook toto < fichier.txt > file-i.txt
cat file-i.txt 
