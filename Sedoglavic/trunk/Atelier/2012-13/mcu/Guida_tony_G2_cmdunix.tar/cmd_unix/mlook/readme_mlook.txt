mlook mot_a_chercher

Ne marche pas fonctionne comme mgrep
