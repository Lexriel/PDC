#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"
int main (int argc, char *argv[])
{
	char ligne[MAXLINE];
	/* nbcol est le champs qu'il faut recuperer*/
	int nbcol;
	/* delimiter est une varible temporaire pour trouver le bon champs*/
	int delimiter;
	int verif;
	/* delimiteur est le caractére qui delimite les champs*/
	char delimiteur;
	nbcol= atoi(argv[2]);
    	if (argc<3 ){
     		printf("nombre d'argument incorrect\n");
      		return 0;
    	}
	delimiter=1;
	delimiteur=*argv[1];
	/* si le nombre d'argument = 2*/
	if ( argc==3) {
		while ((verif=readl(ligne))!=-1)   /*  stop sur fin de fichier ou erreur  */
   			{
   			if (verif==-2){
   				continue;
   			}
				int i;
				
				
   				for (i=0;i<MAXLINE;i++){
					char act;
					act=ligne[i];
					
					if (act==delimiteur){
						delimiter++;
					}

					else if ( delimiter==nbcol){
						printf("%c",ligne[i]);
					}
				}
   				printf("\n");
				delimiter=1;
   			}
	}
return 0;
}
