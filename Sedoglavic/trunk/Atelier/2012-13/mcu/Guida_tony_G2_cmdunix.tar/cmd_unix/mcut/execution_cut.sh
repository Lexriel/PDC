#!/bin/bash

./mcut ';' 2 < fichier.txt > file-i.txt
gedit file-i.txt &
