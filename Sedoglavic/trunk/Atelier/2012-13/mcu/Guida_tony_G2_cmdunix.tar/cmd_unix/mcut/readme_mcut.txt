mcut delimiteur num_champ ...

Pas encore totalement au point, il marche qu'avec un seul numero de champ

Pour executer le programme lancer ./execution_cut