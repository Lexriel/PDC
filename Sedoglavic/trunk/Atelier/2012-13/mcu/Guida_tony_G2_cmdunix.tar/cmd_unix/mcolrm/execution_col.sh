#!/bin/bash

./mcolrm 2 6 <fichier.txt>file-i.txt
gedit file-i.txt &
