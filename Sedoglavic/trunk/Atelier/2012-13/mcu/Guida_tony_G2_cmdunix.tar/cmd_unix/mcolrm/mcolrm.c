#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"

int main (int argc, char *argv[])
{
	char ligne[MAXLINE];
	char resultat[MAXLINE];
	int tmp;
	int i = 0;
	int j= 0;
	int test=0;
	int verif;
	tmp= atoi(argv[1]);
    	if (argc>3 || argc ==1){
     		printf("nombre d'argument incorrect\n");
      		return 0;
    	}

	/* if qu'un seul parametre */
 	if ( argc==2){
	  /*  stop sur fin de fichier ou erreur  */
		while ((verif=readl(ligne)) != -1)   
   			{
   			if (verif==-2){
   				continue;
   			}
   			for (j=0;j<MAXLINE;j++){
   				if (j!=tmp){
   					resultat[j-test]=ligne[j];
   				} else {
   					test=1;
   				}
   			}
		     
			 printf("%s",resultat);
			 test=0;
   			}
   			
	}
	else {
		int tmpp = atoi(argv[2]);
		if (tmp>tmpp){
			printf("La colonne de fin est inferieur à celle du debut\n");
			return 0;
		}
		while ((verif=readl(ligne)) != -1)   /*  stop sur fin de fichier ou erreur  */
  		 {
  		    if (verif==-2){
   				continue;
   			}
			
			for (i=0;i<MAXLINE;i++){
   				if ((i<tmp) || (i>=tmpp)){
   					resultat[i-test]=ligne[i];
   				} else {
   					test+=1;
   				}
   			}
		     
			 printf("%s",resultat);
			 test=0;
   			}
   			
   		}
	
   

	
    exit(EXIT_SUCCESS);
}
