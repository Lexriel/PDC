mcolrm colonne_debut [colonne_fin]

Si les arguments sont des lettres alors ils seront = 0

Si colonne_debut > colonne fin alors il y aura une erreur!!

Pour executer le programme lancer ./execution_colrm