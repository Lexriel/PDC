mgrep mot_a_chercher

Si il y a trop d'argument erreur, pareil pour trop peu.

Pour executer le programme lancer ./execution_grep
