#!/bin/bash

./mgrep toto < fichier.txt > file-i.txt
cat file-i.txt 
