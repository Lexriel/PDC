#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "readl.h"

void syntax();

int
main(int argc, char *argv[])
{
  char line[MAXLINE];
  int  i, j ;
  char *res;
  if (argc < 2)
    {
      syntax();
      exit(EXIT_FAILURE);
    }
  else
    {      
      while ((j=readl(line)) != EOF)
	{
	  res = strstr(line,argv[1]);
	  if (res!=NULL){
	    fprintf(stdout, "%s", line);
	    putchar('\n');
	  }
	}
    }
  exit(EXIT_SUCCESS);
}


void
syntax()
{
  printf("Vous devez utilisez la syntaxe suivante\n");
  printf("\t./mlook -word\n");
  printf("\t\t-word le mot que vous recherchez\n");
}
