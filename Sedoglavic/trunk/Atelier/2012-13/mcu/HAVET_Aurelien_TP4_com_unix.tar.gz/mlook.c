#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "readl.h"

void syntax();

int
main(int argc, char *argv[])
{
  char line[MAXLINE];
  int  j ;
  char *res;
  if (argc < 2)
    {
      syntax();
      exit(EXIT_FAILURE);
    }
  else
    {      
      while ((j=readl(line)) != EOF)
	{
	  res = strstr(line,argv[1]);
	  if ((res!=NULL)&&(strcmp(line,res)==0)){
	    fprintf(stdout, "%s", line);
	    putchar('\n');
	  }
	}
    }
   exit(EXIT_SUCCESS);
}


void
syntax()
{
  fprintf(stdout, "Vous devez utilisez la syntaxe suivante\n");
  fprintf(stdout, "\t./mlook -word\n");
  fprintf(stdout, "\t\t-word le mot que vous recherchez\n");
}
