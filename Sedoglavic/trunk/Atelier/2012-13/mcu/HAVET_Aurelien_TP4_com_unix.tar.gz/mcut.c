#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "readl.h"

void syntax();

int
main(int argc, char *argv[])
{
  char delim;
  int debut, fin, i, j, col ;
  if (argc < 3)
    {
      syntax();
      exit(EXIT_FAILURE);
    }
  delim = argv[1][0];
  if (argc == 3)
    debut = fin = atoi(argv[2]);
  else
    {
      debut = atoi(argv[2]);
      fin = atoi(argv[3]);
    }

  char line[MAXLINE];
  while ((j=readl(line)) != EOF)
    {
      col = 1;
      for (i=0;i<=j;i++)
	{
	  if (line[i] == delim)
	    {
	      col++;
	      if ((col>debut)&&(col<=fin))
		putchar(delim);
	    }
	  else if (col>=debut && col<=fin)
	    putchar(line[i]);
	}
      putchar('\n');
    }
  exit(EXIT_SUCCESS);  
}



void
syntax()
{
  printf("Vous devez utilisez la syntaxe suivante\n");
  printf("\t./mcut -col1 -col2\n");
  printf("\t\t-col1 numero de la colonne a partir de laquelle vous souhaitez afficher\n");
  printf("\t\t-col2 numero de la colonne jusqu'a laquelle vous souhaitez afficher\n");
  printf("\t\tSi -col2 n'est pas precise, le programme n'affiche que la colonne -col1\n");
}
