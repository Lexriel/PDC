#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "readl.h"

void syntax();

int
main(int argc, char *argv[])
{
  int debut, fin, i, j ;
  if (argc == 1)
    exit(EXIT_FAILURE);
  if (argc == 2)
    debut = fin = atoi(argv[1])-1;
  else
    {
      debut = atoi(argv[1])-1;
      fin = atoi(argv[2])-1;
    }

  char line[MAXLINE];
  while ((j=readl(line)) != EOF)
    {
      for (i=0;i<=j;i++)
	{
	  if (i<debut || i>fin)
	    putchar(line[i]);
	}
      putchar('\n');
    }
  exit(EXIT_SUCCESS);  
}


void
syntax()
{
  fprintf(stdout, "Vous devez utilisez la syntaxe suivante\n");
  fprintf(stdout, "\t./mcolrm -col1 -col2\n");
  fprintf(stdout, "\t\t-col1 la colonne a partir de laquelle il faut imprimer\n");
  fprintf(stdout, "\t\t-col2 la colonne jusqu'a laquelle il faut imprimer (on imprime juste -col1 si -col2 n'est pas specifie)\n");
}
