#include <stdio.h>
#include <stdlib.h>
#include "readl.h"

extern int 
readl(char line[])
{
  int i;
  i = 0;
  char c;
  while (((c=getchar()) != EOF) && (c != '\n') && (i<MAXLINE))
    {
       line[i++] = c;
    }
 
 line[i] = '\0';

  if ((c == EOF) && (i == 0))
    return EOF;

  if (i == MAXLINE){
    fprintf(stdout,"\n!!! Le fichier contient une ligne de plus de 80 caracteres !!!\n");
    exit(EXIT_FAILURE);
  }
  return i;
}
