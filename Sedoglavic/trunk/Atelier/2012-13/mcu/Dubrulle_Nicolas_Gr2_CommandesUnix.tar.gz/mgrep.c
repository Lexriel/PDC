#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"


/* Lit une ligne, et retourne sa taille, EOF si vide */
int readl(char line[])
{
    int len;
    if (fgets(line, MAXLINE, stdin) == NULL)
    {
        if(feof(stdin))
            return EOF;
        else
            return 0;
    }
    else
    {
        /* Remplace dans line la 1ere occurence de \n par \0 */
        line[strcspn(line, "\n")] = '\0';
        len = strlen(line);
        /* printf("len = %d\n", len); */
        if(len >= MAXLINE-1)
        {
            fprintf(stderr, "Erreur longueur chaine");
            exit(EXIT_FAILURE);
        }
        else 
            return len;
    }
}


void usage_mgrep()
{
    printf("usage: \n");
    printf("   mgrep word\n\n");
}


int main(int argc, char *argv[])
{
    int str_length;
    char str[MAXLINE];
    
    if(argc < 2)
        usage_mgrep();
    else
    {
    
        str_length = readl(str);
        while (str_length != EOF)
        {
            if(strstr(str, argv[1]) != NULL)
                printf("%s\n", str);            
            
            str_length = readl(str);
        }

    }


    exit(EXIT_SUCCESS);

}






















