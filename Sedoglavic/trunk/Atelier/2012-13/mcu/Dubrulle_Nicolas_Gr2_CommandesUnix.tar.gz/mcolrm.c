#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"


/* Lit une ligne, et retourne sa taille, EOF si vide */
int readl(char line[])
{
    int len;
    if (fgets(line, MAXLINE, stdin) == NULL)
    {
        if(feof(stdin))
            return EOF;
        else
            return 0;
    }
    else
    {
        len = strlen(line);
        if(len == 0 || len >= MAXLINE)
        {
            fprintf(stderr, "Erreur longueur chaine");
            exit(EXIT_FAILURE);
        }
        else 
            return len;
    }
}


void usage_mcolrm()
{
    printf("usage: \n");
    printf("   mcolrm col [end]\n\n");
}




int main(int argc, char *argv[])
{
    int deb;
    int fin;
    int i, p;
    int str_length;
    char str[MAXLINE];
    /*, instr[MAXLINE];*/
        
    if(argc <= 1 || argc >= 4)
        usage_mcolrm();
    else if(argc == 2) /* coupe le reste de la ligne à partir de deb */
    {
        deb = atoi(argv[1]);
        
        str_length = readl(str);
        while (str_length != EOF)
        {
            str[deb-1] = '\0';

            printf("%s\n", str);
            str_length = readl(str);
            
        }
        
    }
    else /* coupe la ligne entre deb et fin */
    {    
        deb = atoi(argv[1]);
        fin = atoi(argv[2]);

        str_length = readl(str);
        while (str_length != EOF)
        {
            for(i = 0; i <= fin - deb; i++)
            {
                for(p = deb - 1; str[p] != '\0'; p++)
                    str[p] = str[p+1];

                str[p + 1] = '\0';
            }
           
                    
            printf("%s", str);
            
            str_length = readl(str);
        }
    }



    exit(EXIT_SUCCESS);
}






































