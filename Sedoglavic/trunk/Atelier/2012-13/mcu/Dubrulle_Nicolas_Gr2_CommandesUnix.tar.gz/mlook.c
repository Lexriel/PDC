#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"


/* Lit une ligne, et retourne sa taille, EOF si vide */
int readl(char line[])
{
    int len;
    if (fgets(line, MAXLINE, stdin) == NULL)
    {
        if(feof(stdin))
            return EOF;
        else
            return 0;
    }
    else
    {
        len = strlen(line);
        if(len == 0 || len >= MAXLINE)
        {
            fprintf(stderr, "Erreur longueur chaine");
            exit(EXIT_FAILURE);
        }
        else 
            return len;
    }
}


void usage_mlook()
{
    printf("usage: \n");
    printf("   mlook word\n\n");
}



int main(int argc, char *argv[])
{    
    usage_mlook();
    printf("\nNot implemented yet...\n");

    exit(EXIT_SUCCESS);
}






















