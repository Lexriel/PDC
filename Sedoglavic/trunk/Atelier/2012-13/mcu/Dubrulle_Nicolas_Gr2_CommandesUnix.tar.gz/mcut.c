#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"


/* Lit une ligne, et retourne sa taille, EOF si vide */
int readl(char line[])
{
    int len;
    if (fgets(line, MAXLINE, stdin) == NULL)
    {
        if(feof(stdin))
            return EOF;
        else
            return 0;
    }
    else
    {
        len = strlen(line);
        if(len == 0 || len >= MAXLINE)
        {
            fprintf(stderr, "Erreur longueur chaine");
            exit(EXIT_FAILURE);
        }
        else 
            return len;
    }
}


void usage_mcut()
{
    printf("usage: \n");
    printf("   mcut delim fieldno [fieldno]\n\n");
}

/* Retourne le champ spécifié par l'index et le délimiteur */
char* split(char *inputString, const char *delim, int index)
{
    int tempc = 0;
    char *result = strtok(inputString, delim);

    while(tempc != index)
    {
        result = strtok(NULL, delim);
        tempc++;
    }

    return result;
}


int main(int argc, char *argv[])
{
    int field;
    int i;
    char* delim;
    char* champ;
    int str_length;
    char str[MAXLINE], instr[MAXLINE];
    
    if(argc <= 2)
        usage_mcut();
    else
    {
        str_length = readl(str);
        while (str_length != EOF)
        {
            delim = argv[1];
            for(i = 2; i < argc; i++)
            {
                field = atoi(argv[i]);
                strcpy(instr, str);
                /* les colonnes commencent à 1 */
                if(field > 0)
                {
                    champ = split(instr, delim, field-1);
                    if(champ != NULL)
                    {
                        if(i == argc-1)
                            printf("%s", champ);
                        else
                            printf("%s%s", champ, delim);
                                            
                    }
                }
            }

            printf("\n");
            
            str_length = readl(str);
        }

    }


    exit(EXIT_SUCCESS);

}






















