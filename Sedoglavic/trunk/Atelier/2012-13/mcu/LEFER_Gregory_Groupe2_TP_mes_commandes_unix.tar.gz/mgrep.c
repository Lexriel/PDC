#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "mreadl.h"

void usage();

/**
 * Class to search lines containing a specific text
 * @author LEFER Gregory
 */
int main (int argc, char *argv[]){
  
  char line[MAXLINE+1];  // current line read
  char *mem;
  int lineLength, cpt,cptmem,i,numColonne;
  char trouve;

  trouve = 0;
  //reading the first line
  lineLength = readl(line);

  while (lineLength != EOF){
    if (argc == 2){
      //on récupére la sous-chaine associé à la chaine envoyé en paramétre
      mem = strstr(line,argv[1]);
      //if the line contains the text then displays it
      if ( (mem!=NULL)){
	trouve = 1;
	printf("%s\n",line);
      }
    }
    lineLength = readl(line);
  }
  
  if (trouve) exit(EXIT_SUCCESS);
  else exit(EXIT_FAILURE);
}

/**
 * Method displayed if the programm is not launch with correct syntax
 */
void usage(){
  printf("Syntax error:\n");
  printf("\t ./mgrep text\n");
  printf("\t -text : text searched in each line\n");
}
