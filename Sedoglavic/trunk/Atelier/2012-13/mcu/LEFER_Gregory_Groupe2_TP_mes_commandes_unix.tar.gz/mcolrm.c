#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "mreadl.h"

void usage();

/**
 * Class to remove one or some columns of a text reads from the standard input
 * @author LEFER Gregory
 */
int main (int argc, char *argv[]){

  char line[MAXLINE+1]; //line contening each line of the file
  // lineLength : number of character read
  int lineLength, cpt;

  //reading of the first line
  lineLength = readl(line);

  //if there is a unique argument then delete the column indicate
  if (argc == 2){
    while(lineLength != EOF){
      for (cpt = 0; cpt <= lineLength; cpt++){
	//if the number of current column is the same than the argument
	if (cpt != (atoi(argv[1])-1))
	  printf("%c",line[cpt]);
      }
      printf("\n");
      lineLength = readl(line);
    }
  }
  //if there are 2 argument then delete columns between first and second argument
  else if (argc == 3){
    while(lineLength != EOF){
      for (cpt = 0; cpt <= lineLength; cpt++){
	//if the number of current column isn't between first and second parameter
	if (cpt < (atoi(argv[1])-1) || cpt > (atoi(argv[2])-1))
	  printf("%c",line[cpt]);
      }
      printf("\n");
      //reading of the next line
      lineLength = readl(line);
    }
  }
  else
    usage(); //affichage de l'aide
  return 0;
}


/**
 * Method displayed if the programm is not launch with correct syntax
 */
void usage(){
  printf("Syntax error:\n");
  printf("\t ./mcolrm nbCol [nbCol2]\n");
  printf("\t -nbCol : numero de la colonne où l'on souhaite commencer la suppression\n");
  printf("\t -nbCol2 : numero de la derniére colonne que l'on souhaite supprimer\n");
  printf("\nRemarque : Si le paramétre nbCol2 n'est pas précisé alors on supprime uniquement la colonne nbCol.\n\n");
}
