#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "mreadl.h"

void usage();

/**
 * Class to conserve one or some columns separated by a separator of a text reads from the standard input
 * @author LEFER Gregory
 */
int main (int argc, char *argv[]){
  
  char line[MAXLINE+1]; //line contening each line of the file
  char mem[MAXLINE+1];  //line contening the text of current column read
  int lineLength, cpt,cptmem,i,numColonne;

  //reading of the first line
  lineLength = readl(line);

 
  if (argc >= 3 ){
    //while end of file is not reached
    while(lineLength != EOF){
      numColonne = 1;
      cptmem = 0;
      
      for (cpt = 0; cpt <= lineLength; cpt++){

	//if a separator or end of line is reached the column text is closed
	if ((line[cpt] == argv[1][0]) || (cpt == lineLength)){
	  mem[cptmem++] = argv[1][0];
	  mem[cptmem] = '\0';

	  //if the current column is indicated in argument it's displayed
	  for (i=2; i< argc ;i++){
	    if (numColonne == atoi(argv[i]))
	      printf("%s",mem);
	  }
	  cptmem = 0;
	  numColonne++;
	}
	else{
	  mem[cptmem++] = line[cpt];
	}

      }
      printf("\n");
      //reading of the next line
      lineLength = readl(line);
    }
    return 0;
  }
  else{
    usage();
    return 1;
  }

}

/**
 * Method displayed if the programm is not launch with correct syntax
 */
void usage(){
  printf("Syntax error:\n");
  printf("\t ./mcut sep nbCol [nbCol..]\n");
  printf("\t -sep : separator between the differents columns\n");
  printf("\t -nbCol : indice(s) of columns to display\n");
}
