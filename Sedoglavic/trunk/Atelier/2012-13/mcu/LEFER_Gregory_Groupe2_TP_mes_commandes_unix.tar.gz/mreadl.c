#include <stdio.h>
#include <string.h>
#include "mreadl.h"
#include <stdlib.h>

/**
 * Method to read a line from the standard input and put it in the line in argument. The maximum line size is defined
 *  in the mreadl.h file.
 * If the line has a more character than MAXLINE then the programm finish with an exception
 * @return int presenting the number of character read, if the line is the character EOF then this value is returned.
 * @author LEFER Gregory
 */
extern int readl(char line[]){
  int c,cpt; 
  cpt = 0;

  // while the end of file isn't reach or that the end of line isn't reach then record the character
  while ((c=getchar()) != EOF && (c != '\n' ) && (c != '\0' ) && cpt <= MAXLINE) {
    line[cpt++] = c;
  }
  
  //If the end of file is reach and it's the first character read for the line then return EOF
  if ((c == EOF) && (cpt == 0))
    return EOF;

  //if the line has more character than MAXLINE then an error is put in the stderr else the endline character
  // is add and the number of character read is returned.
  if (cpt > MAXLINE){
    fprintf(stderr,"\nFailure :\nLa chaine lue fait plus de %d caracteres\n\n",MAXLINE);
    exit(EXIT_FAILURE);
  }
  else{
    line[cpt] = '\0';
    return cpt;
  }
}
