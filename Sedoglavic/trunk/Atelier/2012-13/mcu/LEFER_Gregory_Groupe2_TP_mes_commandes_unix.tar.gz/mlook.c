#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "mreadl.h"

void usage();

/**
 * Class to conserve lines of a text reads from the standard input containing a text
 */
int main (int argc, char *argv[]){

  if (argc == 2){  
    char previousLine[MAXLINE+1]; // previous line used to control if the lines are ordered
    char line[MAXLINE+1];         // current line of the text
    char *mem;                    // used by the method strstr
    int lineLength, cpt,cptmem,i,numColonne;
    char trouve; // to know if a line corresponding of the text is find
    char estTrie;

    estTrie = 1;
    trouve = 0;
    lineLength = readl(line);
    strcpy(previousLine,line); //copy the current line to previousLine to initialize the order test

    while (lineLength != EOF){
      
      //if the current line is less than previous line then the lines aren't ordered
      if ( strcmp(line,previousLine) < 0 ) estTrie=0;

      //on recupere la sous-chaine associe a la chaine envoye en parametre
      mem = strstr(line,argv[1]);
      if ( (mem!=NULL)  && (strcmp(line,mem) == 0)){
	trouve = 1;
	printf("%s\n",line);
      }
      
      //saving of the previous line and reading the next line
      strcpy(previousLine,line);
      lineLength = readl(line);
    }
  
    if (!estTrie)
      fprintf(stderr,"Warning :\n\tLes lignes ne sont pas triees.\n");

    if (trouve) exit(EXIT_SUCCESS);
    else exit(EXIT_FAILURE);
  }
  else{
    usage();
    exit(EXIT_FAILURE);
  }
}


/**
 * Method displayed if the programm is not launch with correct syntax
 */
void usage(){
  printf("Syntax error:\n");
  printf("\t ./mlook text\n");
  printf("\t -text : text searched at the start of each line\n");
}
