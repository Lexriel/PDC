#include <stdio.h>
#include <string.h>
#include "readl.h"


int readl (char line[]) {
	
	//Declaration des variables
	
	line = fgets(line, MAXLINE+5, stdin);
	int i;
	
	
	if (feof(stdin)) {
		fprintf(stderr, "Erreur : Cette ligne est vide\n");
		return EOF;
	}
	
	else {
		
		
		i=0;
		
		while (line[i] != '\0') {
			i++;
		}
		
		
		if (i > MAXLINE) {
			return -2;
			fprintf(stderr, "Erreur : Cette ligne comporte plus de MACLINE caracteres\n");
		}
		else {
			if (line[i-1] == '\n') {
				return i-1;
			}
			else {
				return i;
			}

		}

	}	
	

}
	
