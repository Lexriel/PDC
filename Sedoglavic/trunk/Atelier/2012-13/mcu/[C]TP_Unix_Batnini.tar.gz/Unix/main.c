#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"


extern int readl(char line[]);

int main (void)
{
    char chaine[MAXLINE + 1];
	
	printf("La ligne contient %d caracteres.\n",readl(chaine));

	 
}
	

		
		
		

