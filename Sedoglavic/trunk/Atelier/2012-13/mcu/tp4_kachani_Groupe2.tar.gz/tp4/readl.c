#include <stdio.h>
#include <stdlib.h>
#include <readl.h>




#define MAXLINE 81




extern int readl(char line[]){

  fgets(line,MAXLINE,stdin);
  
 int length=strlen(line);

    
  if (length<= MAXLINE+1 )

    return length-1;

  else if (line(length)=EOF)

    return EOF;


}



