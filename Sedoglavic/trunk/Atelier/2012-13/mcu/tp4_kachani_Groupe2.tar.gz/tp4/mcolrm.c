
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.c"
#include "readl.h"

int 
main (int argc, char *argv[])
{

    char tab_line[MAXLINE+1];
    int colonne1=atoi(argv[1]); /* premier argument correspondant à la première colonne*/
    int colonne2=colonne1;     /* cas ou si la deuxieme colonne n'est pas precisé */
    int colonne_courante=1;
    char c; /*caractere courant*/
   
	
          if (argc==3){          /* dans le cas ou le second argument est precisé */
		colonne2=atoi(argv[2]); 
	}


	while ((c=getchar())!=EOF){
 if (c!='\n') {

            colonne_courante=readl(tab_line);
                 while (colonne_courante != -1) {
                    if (colonne1<colonne_courante)         /* si on est pas dans les bornes colonne1 -colonne2 */
                      {
                         if (colonne2>colonne_courante)
                             {   colonne2=colonne_courante;           

                              }
                        for (i=0; i<colonne1; i++ 

                         { putchar(tab_line[i]);  }
                                                   
                       }
                 for(i=colonne2 ;i<colonne_courante; i++)

                   { putchar(tab_line[i]); }

                 }
         }
    else 
           putchar('\n');          
          colonne_courante=readl(read_line);
  }  
           
  
     /* (!(colonne_courante>=colonne1 && colonne_courante<=colonne_deux)){ */
