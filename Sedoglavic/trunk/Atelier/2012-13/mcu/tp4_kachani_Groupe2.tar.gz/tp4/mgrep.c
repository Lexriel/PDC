#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.c"
#include "readl.h"

int main(int argc, char *argv[])
{
  int res;
  char line[MAXLINE + 1 ];
  
  char *word;

  if (argc<2)
    {
      printf("proposer un mot à rechercher : ");
      exit(0);
    }
  
   word=strstr(argv[1],argv[2]); 
   if (word != NULL ) 
    { 
       printf("%s",word); 
     } 
   printf("\n"); 
  res=strcmp(argv[1],argv[2]); 
   if (res!= NULL ) 
     { 
     printf("%d",res); 
     } 
   printf("\n"); 
   printf("%s",argv[1]); 
   

 
}
