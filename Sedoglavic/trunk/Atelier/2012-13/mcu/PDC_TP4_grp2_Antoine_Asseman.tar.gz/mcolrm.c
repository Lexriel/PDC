#include<stdio.h>
#include<stdlib.h>



int main(int argc, char** argv)
{
	char c;
	int colonne;

	if(argc!=2)
	{
		printf("usage: mcolrm [column number] < file\n");
		return 1;
	}
 	colonne = atoi(argv[1]);
	while((c=getchar())!=EOF)
	{
		if(colonne>0)
		{
			colonne--;
			if(c!='\n')putchar(c); /* sinon sera affiché deux fois si placé avant le numéro de fin de colonne */
		}

		/* afficher le saut de ligne même si il est positionné avant le numéro de fin de colonne */
		if(c=='\n')
		{
			colonne=atoi(argv[1]);
			putchar(c);
		}
	}
	/* putchar('\n'); */

	return 0;
}
