#include<stdio.h>
#include<stdlib.h>
#include<string.h>


int usage()
{
		printf("usage: mcut -d ['delimiter'] -f [field1 field2 ...] < file\n");
		return 1;
}


int main(int argc, char** argv)
{
	int maxLineSize = 80;
	char *buffer = malloc(maxLineSize);
	char delim;
	int fieldNumber; /* position du field dans la ligne de commande */
	int fieldValue; /* valeur du field lu dans la ligne de commande */
	int i;
	int counter;

	/* vérification de la ligne de commande */
	if(argv[1]==NULL || argv[2]==NULL || argv[3]==NULL || argv[4]==NULL )
	{
		printf("nombre de paramètres incorrect.\n");
		return usage();
	}
	/* premier paramètre: l'option -d */
	if(strlen(argv[1])!=2 || strcmp(argv[1],"-d")!=0)
	{
		printf("valeur du premier paramètre: -d\n");
		return usage();
	}
	/* second paramètre: un caractère placé entre quotes simples ('#') */
	if(strlen(argv[2])!=1) /* les guillemets et quotes simples sont automatiquement supprimés, pas besoin de les gérer */
	{
		printf("second paramètre sour la forme '#' (# est le délimiteur)\n");
		return usage();
	}
	/* troisième paramètre: l'option -f */
	if(strlen(argv[3])!=2 || strcmp(argv[3],"-f")!=0)
	{
		printf("troisième paramètre: -t\n");
		return usage();
	}

	delim=argv[2][1];

	/* parcours des lignes de l'entrée standard */
	while(fgets(buffer, maxLineSize, stdin)!=NULL)
	{
		fieldNumber = 4; /* la première valeur de field est placée en 4ème position dans la ligne de commande */
		/* parcours de la liste des fields dans la ligne de commande au fur et à mesure de la lecture de l'entrée standard */
		while(argv[fieldNumber]!=NULL)
		{
			fieldValue = atoi(argv[fieldNumber]);
			counter=1;
			i=0;
			/* i: caractère courant de l'entrée standard
			 * counter: nombre d'occurences du délimiteur trouvées
			 */
			while(i<strlen(buffer) && counter<=fieldValue)
			{
				if(buffer[i]==argv[2][0])counter++; /* le caractère courant est un délimiteur */
				else if(counter==fieldValue)putchar(buffer[i]); /* nous somme dans le field recherché */
				i++;
			}
			fieldNumber++;
		}

		putchar('\n');
	}
	return 0;
}
