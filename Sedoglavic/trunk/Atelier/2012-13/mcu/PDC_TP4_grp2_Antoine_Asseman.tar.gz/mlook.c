#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/* "Les lignes fournies sur l'entrée de la commande doivent être triées; une erreur est reportée sinon"......????? */
int main(int argc, char **argv)
{
	int maxLineSize = 80;
	char *buffer = malloc(maxLineSize);
	int success = 0;
	while(fgets(buffer, maxLineSize, stdin)!=NULL)
		if(strcmp(argv[1],buffer)<0){
			printf("%s",buffer);
			success = 1;
		}
	if(!success)return -1; /* ceci n'est pas un succès */
	return 0;
}
