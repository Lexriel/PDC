#include "readl.h" 
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
/*
Maximum possible à lire est  81 caractère sur une ligne.
*/
int
readl
(char line[])
{
int i ;
   if (fgets(line, MAXLINE+5, stdin) == NULL ){
	if (feof(stdin)) {
		return EOF;
   	}
   } else {
	
	i = 0;
	while (line[i] != '\0') {
		
		i++;}
	
	if (i > MAXLINE) {
		fprintf(stderr,"Erreur, nombre de ligne supérieures à MAXLINE.\n");
		exit(EXIT_FAILURE);
	} else if (line[i-1] == '\n') {
		return i-1;
	} else {													
   	return i; }
  }
}

