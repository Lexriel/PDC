#include <stdlib.h>
#include <stdio.h>
#include <string.h>  
#include "readl.h"

int
main
(void)
{
  char ligne[MAXLINE+1] = "";
  printf("\nNombre de caract�re sur la ligne  : %d\n",readl(ligne));
}
