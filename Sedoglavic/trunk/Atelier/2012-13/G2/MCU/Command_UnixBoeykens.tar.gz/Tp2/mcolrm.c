#include <stdlib.h>
#include <stdio.h>
#include <string.h>  
#include "readl.h"


void
mcolrm
(int debut,int fin) {
	
	 char ligne[MAXLINE+1] = "";
	printf("\nNombre de caractre sur la ligne  : %d\n",readl(ligne));
	printf("Argv1 = %d et argv2 = %d\n",debut,fin);
}

int 
main
(int argc, char *argv[])
{
	
	int debut;
	int fin;
	debut = atoi(argv[1]);
	fin = atoi(argv[2]);
	
    	mcolrm(debut,fin);
	return 0;
	
}
