Boeykens Matthieu

fonction readl(char *) --> ok

Pour le reste pas mal de difficulté sur le main est les 'args' que vous m'avez expliqué pendant le tp, les autres fonctions ne sont pas faites car j'ai mis un moment avant de bien comprendre comment faire le readl et gérer les exceptions en sortie 'stderr' et l'acquisition en 'stdin'.
