#include <stdio.h>
#include <stdlib.h>

void
incre(int x)
{
  int nbre;
  for (nbre = 0; nbre < x; nbre++)
    {
      putchar(' ');
    }

}

int 
main()
{
  int c;
  int incremant;
  incremant=0;
  enum {ETAT_DBT_LIGNE, ETAT_NORMAL,ACCOLADE,COMMENTAIRE} etat = ETAT_DBT_LIGNE;
  while ((c=getchar()) != EOF) {
    switch (etat) {
    case ETAT_DBT_LIGNE:
      switch (c) {

      case '{':
	putchar('\n');
	incre(incremant);
	putchar('{');
	putchar('\n');
	incremant=incremant+4;
	incre(incremant);
	etat=ACCOLADE;
	break;

      case '}':
	incremant=incremant-4;
	putchar('\n');
	incre(incremant);
	putchar(c);
	putchar('\n');
	incre(incremant);
	etat=ACCOLADE;
	break;

      case '\n':
	putchar(c);
	incre(incremant);
	break;

      case '\t':
	break;

      case ' ':
	break;

      case '/':
	if ((c=getchar())=='*') 
	  {	   
	    incre(incremant);
	    putchar('/');
	    putchar('*');
	    etat = COMMENTAIRE;
	    break;
	  } 
	else {
	  putchar('/');
	}
      default:   
	putchar(c);
	etat = ETAT_NORMAL;
	break;
      }
      break;

    case ETAT_NORMAL:
      switch (c) {

      case '{':
	putchar('\n');
	incre(incremant);
	putchar('{');
	putchar('\n');
	incremant=incremant+4;
	incre(incremant);
	etat=ACCOLADE;
	break;

      case '}':
	incremant=incremant-4;
	putchar('\n');
	incre(incremant);
	putchar(c);
	putchar('\n');
	etat=ACCOLADE;
	incre(incremant);
	break;

      case '\n': 
	putchar('\n');
	etat=ETAT_DBT_LIGNE;
	break;

      case '/':
	if ((c=getchar())=='*') 
	  {
	    putchar('\n');
	    incre(incremant);
	    putchar('/');
	    putchar('*');
	    etat = COMMENTAIRE;
	    break;
	  } 
	else {
	  putchar('/');
	}
      default:   
	putchar(c);
	break;
      }
      break;

    case ACCOLADE:
      switch (c) {

      case '\n':
	etat = ETAT_DBT_LIGNE;
	break;

      default:   
	putchar(c);
	etat = ETAT_DBT_LIGNE;
	break;
      }
      break;
    case COMMENTAIRE:
      switch (c) {
      case '*':
	if ((c=getchar())=='/') 
	  {
	    putchar('*');
	    putchar('/');
	    putchar('\n');
	    etat = ETAT_DBT_LIGNE;
	  } 
	else
	  {
	   putchar('*');
	   putchar(c);
	  }
	break;
      case '\n':
	putchar('*');
	putchar('/');
	putchar(c);
	incre(incremant);
	putchar('/');
	putchar('*');
	break;
      default:   
	putchar(c);
	break;
      }
      break;
	
    }
  }
  exit(EXIT_SUCCESS);
}

