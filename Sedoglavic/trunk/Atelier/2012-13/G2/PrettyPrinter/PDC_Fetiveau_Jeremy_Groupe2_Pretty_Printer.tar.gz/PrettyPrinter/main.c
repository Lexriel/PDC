#include <stdio.h>
#include <ctype.h>

#define SHIFT_WIDTH 4
#define INC indentLevel += SHIFT_WIDTH
#define DEC indentLevel -= SHIFT_WIDTH

/**
  *Inserts the right amount of spaces at the be beginning of the line
  */
static void insert_white_spaces(int indentLevel)
{
    int i = 0;
    for (i = 0; i < indentLevel; ++i)
        (void)(void)putchar(' ');
}

/**
  *This "pretty printer"  allows to correctly re-indent a given source code.
  */

int main(void)
{
    int b_curly_brace = 0;
    int c = 0;
    int indentLevel = 0;
    unsigned int openBrace = 0, closeBrace = 0;
    unsigned int openCom = 0, closeCom = 0;
    enum {DEBUT_LIGNE, NORMAL, COM} etat = DEBUT_LIGNE;
    while ((c = getchar()) != EOF)
    {
        switch(etat){
            /**
              *Manages the first chars of a line.
              */
            case DEBUT_LIGNE:
                switch(c){
                    case ' ' :
                    case '\n':
                    case '\t':
                        break;
                    case '}' :
                        ++closeBrace;
                        DEC;
                        insert_white_spaces(indentLevel);
                        (void)putchar(c);
                        b_curly_brace = 1;
                        (void)putchar('\n');
                        etat = NORMAL;
                        break;
                    case '/':
                        insert_white_spaces(indentLevel);
                        (void)putchar(c);
                        ++openCom;
                        etat = COM;
                        break;
                    default:
                        insert_white_spaces(indentLevel);
                        (void)putchar(c);
                        etat = NORMAL;
                        break;
                }
                break;
            case NORMAL:
                switch(c){
                    case '/':
                        insert_white_spaces(indentLevel);
                        (void)putchar(c);
                        ++openCom;
                        etat = COM;
                        break;
                    case '{':
                        ++openBrace;
                        (void)putchar('\n');
                        insert_white_spaces(indentLevel);
                        INC;
                        (void)putchar(c);
                        (void)putchar('\n');
                        etat = DEBUT_LIGNE;
                        break;
                    case '}':
                        ++closeBrace;
                        (void)putchar('\n');
                        DEC;
                        insert_white_spaces(indentLevel);
                        (void)putchar(c);
                        break;
                    case '\n':
                        etat = DEBUT_LIGNE;
                        if (b_curly_brace == 0)
                            (void)putchar(c);
                        b_curly_brace = 0;
                        break;
                    case ';':
                        (void)putchar(c);
                        (void)putchar('\n');
                        etat = DEBUT_LIGNE;
                        break;
                    default:
                        (void)putchar(c);
                        break;
                }
                break;
            /**
              *Manages comments
              */
            case COM:
                switch(c){
                    case '/':
                        (void)putchar(c);
                        (void)putchar('\n');
                        ++closeCom;
                        etat = DEBUT_LIGNE;
                        break;
                    default:
                        (void)putchar(c);
                }
           break;
        }
    }
    if (openBrace != closeBrace)
        fprintf(stderr, "Braces mismatch!\n");
    if (openCom != closeCom)
        fprintf(stderr, "Slashes mismatch!\n");
    return 0;
}
