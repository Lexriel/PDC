#include <stdio.h>
#include <stdlib.h>

int
main(void)
{
  int car, indent, cpt, etoile, slash, accolade, dieze, guillemet, apostrophe, antislash;
  enum {ETAT_DBT_LIGNE, ETAT_NORMAL, ETAT_COMMENTAIRE, ETAT_GUILLEMET, ETAT_APOSTROPHE } etat = ETAT_DBT_LIGNE;
  indent = 0;
/*permet de memoriser si l'on a lue une etoile precedement (pour les commentaires)*/
  etoile = 0;
/*permet de memoriser si l'on a lue une oblique precedement (pour les commentaires)*/
  slash = 0;
/*permet de verifier si il n'y a pas d'erreur d'accolade*/
  accolade = 0;  
/*permet de verifier si il n'y a pas d'erreur d'accolade*/
  dieze = 0; 
/*permet de gerer les apostrophes et les guillemets*/
  guillemet = apostrophe = antislash = 0; 

  while((car=getchar())!=EOF)
    {

	/* gestion des lignes commencant par #*/
	if(dieze == 1)
	{
	  putchar(car);
	  if(car=='\n')
		dieze = 0; 
	  continue;
	}

	/* gestion des commentaires*/
	 if(car=='/' && etat != ETAT_COMMENTAIRE)
	 {
	    slash = 1;
	    continue;
	 }
	 else if(car=='*' && etat != ETAT_COMMENTAIRE)
	 {
	    etoile = 1;
	    if(slash == 1)
		etat = ETAT_COMMENTAIRE;
	 }
	 if(slash==1 && etat != ETAT_COMMENTAIRE)
	 {
	    putchar('/');
	    slash=0;
	 }

      switch(etat)
      {
	case ETAT_DBT_LIGNE:
          switch(car)
	    {
	    case ' ' :
	    case '\t':
	    case '\n':
	    	break;
	    case '{' : 
		for(cpt=0; cpt<indent;cpt++)
			putchar(' ');
		putchar(car);
		putchar('\n');
		indent+=4;
		accolade++;
	   	break;
	    case '}': 
		indent-=4;
		putchar('\n'); 
		for(cpt=0; cpt<indent;cpt++)
			putchar(' ');
		putchar(car); 
		putchar('\n');
		accolade--;
	    	break;
	    case '#':
		putchar(car);
	 	dieze = 1;
	    break;
	    case '\"':
		putchar(car);
		if(antislash == 1)
			antislash = 0;
		else
	 		etat=ETAT_GUILLEMET; 
	    break;
	    case '\'':
		putchar(car);
		if(antislash == 1)
			antislash = 0;
		else
	 		etat=ETAT_APOSTROPHE; 
	    break;
	    case '\\':
		putchar(car);
		if(antislash == 1)
			antislash = 0;
		else
	 		antislash = 1;
	    break;
	    default : 
		etat=ETAT_NORMAL; 
		for(cpt=0; cpt<indent;cpt++)
			putchar(' '); 
		putchar(car);
		break;
	    }
	break;
        case ETAT_NORMAL:
	  switch(car)
	    {
	    case '\n': 
		etat=ETAT_DBT_LIGNE; 
		putchar(car);
	    	break;
	    case '{' : 
		putchar('\n');
		for(cpt=0; cpt<indent;cpt++)
		  putchar(' '); 
		putchar(car);
		putchar('\n'); 
		etat=ETAT_DBT_LIGNE; 
		indent+=4;
		accolade++;
	    	break;
	    case '}':  
		indent-=4;
		putchar('\n');
		for(cpt=0; cpt<indent;cpt++)
			putchar(' '); 
		putchar(car); 
		putchar('\n');
		etat=ETAT_DBT_LIGNE; 
		accolade--;
	    	break;
	    case '\"':
		putchar(car);
		if(antislash == 1)
			antislash = 0;
		else
	 		etat=ETAT_GUILLEMET; 
	    break;
	    case '\'':
		putchar(car);
		if(antislash == 1)
			antislash = 0;
		else
	 		etat=ETAT_APOSTROPHE;
	    break;
	    case '\\':
		putchar(car);
	 	if(antislash == 1)
			antislash = 0;
		else
	 		antislash = 1;
	    break;
	    default : 
		putchar(car);
	    }
	break;
	case ETAT_COMMENTAIRE:
	   switch(car)
	    {
	    case '*':
		etoile=1;
		if(slash == 1)
		{
		  /*ceci est donc un debut de commentaire */
		  putchar('\n');
		  for(cpt=0; cpt<indent;cpt++)
		    putchar(' '); 
		  putchar('/');
		  slash = 0;
		  etoile=0;
		}
		putchar(car);
	    break;
	    case '/':
		putchar(car);
		if(etoile == 1)
		{
		  putchar('\n');
		  etat=ETAT_DBT_LIGNE; 
		  etoile=0;		
		}
	    break;
	    case '\n':
		putchar('*');
		putchar('/');
		putchar(car);
		for(cpt=0; cpt<indent;cpt++)
		    putchar(' ');
		putchar('/');
		putchar('*');
	    break;	
	    default: 
		putchar(car);
	    }
	break;
	case ETAT_GUILLEMET:
	   switch(car)
	    {	 
		case '\\':
			putchar(car);
	 		if(antislash == 1)
				antislash = 0;
			else
	 			antislash = 1;
	    	break; 
		case '\"':
			putchar(car);
			if(antislash == 1)
				antislash = 0;
			else
	 			etat=ETAT_NORMAL; 
		break;
		default: 
			putchar(car);
		break;
	    }
	    break; 
	case ETAT_APOSTROPHE:
	   switch(car)
	    {	 
		case '\\':
			putchar(car);
		 	if(antislash == 1)
				antislash = 0;
			else
	 			antislash = 1;
	    	break; 
		case '\'':
			putchar(car);
			if(antislash == 1)
				antislash = 0;
			else
		 		etat=ETAT_NORMAL;
		break; 
		default: 
			putchar(car);
		break;
	    }
	    break; 
      }	
	if(car!='\\')
		antislash = 0;
    }

	/*On verifie si il n'y a pas d'erreur */
	if(etat == ETAT_COMMENTAIRE)
	{
	  printf("Commentaire non ferme");
	  return EXIT_FAILURE;
	}
	else if(accolade !=0)
	{
	  printf("texte mal accoladé : %d", accolade);
	  return EXIT_FAILURE;
	}  
		
	return EXIT_SUCCESS;
}
















