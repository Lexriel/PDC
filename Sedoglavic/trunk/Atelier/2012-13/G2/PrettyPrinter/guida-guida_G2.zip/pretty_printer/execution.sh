#!/bin/bash
make pp
./pp<file.C>file-i.c
gedit file-i.c &
