#include <stdio.h>
#include <string.h>

void main(){
  char c;
  char ind = '\t';
  int acc =0;
  int esp=0;
  while ((c=getchar())!=EOF){
    switch (c)
      {
	/* cas où le caractére est { on passe une ligne et on ajoute 1*/
      case '{':
	acc++;
      putchar('\n');
      if (acc>1){
	putchar(ind);
      }
      putchar(c);
      c=getchar();
      if (c!='\n'){
	putchar('\n');
      }
      putchar(c);
      putchar(ind);
      
      if (acc>1){
	putchar(ind);
      }
      break;

      /* cas de } passant une ligne et décrémentant le nombre d'accolade */
      case '}':
	
      putchar('\n');
     
      putchar(c);
      acc--;
      break;

      /* cas du ; vérifie si ce qui suis est un retour à la ligne sinon on le fait*/
      case ';':
	
      putchar(c);
      c=getchar();
      if (c!='\n'){
	putchar('\n');
	if (acc>1){
	  putchar(ind);
      }
      putchar(ind);
      putchar(c);
      }else {
	putchar(c);
	if (acc>1){
	  putchar(ind);
      }
      putchar(ind);
      }
      break;

      /*cas de espace permettant de supprimer tout les espaces nuisibles*/
      case ' ':

	esp++;
	if (esp>1){
	  /* putchar('_');*/
	}
	else
	  {
	putchar(c);
	}
	break;

	/* cas du retour à la ligne pour l'indentation*/
      case '\n':

	putchar(c);
	if (acc>0){
	  putchar(ind);
	} else if( acc>1){
	putchar(ind);
	}
	break;

	/*cas pour les commentaires*/
      case '/':
	c=getchar();
	if (c=='*'){
	  putchar('\n');
	  if (acc>0){
	  putchar(ind);
	} else if( acc>1){
	putchar(ind);
	}
	  putchar('/');
	  putchar(c);
	}else {
	  putchar('/');
	}
	break;

	/*cas par defaut permettant d'ajouter le caractére */
      default:
      putchar(c);
      esp=0;
      break;
      }
  }
}
