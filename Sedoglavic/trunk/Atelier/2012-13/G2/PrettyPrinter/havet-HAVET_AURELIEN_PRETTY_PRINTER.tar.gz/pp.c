#include <stdio.h>
#include <stdlib.h>

int 
main()
{
  int acc;
  int c;
  int i;
  enum{ ETAT_DBT_LIGNE, ETAT_NORMAL, ETAT_ACC, ETAT_COMMENTAIRE, ETAT_COMMENTAIRE_DBT, ETAT_COMMENTAIRE_SLASH, ETAT_COMMENTAIRE_ETOILE_DBT, ETAT_COMMENTAIRE_ETOILE, ETAT_COMMENTAIRE_ETOILE_FIN, ETAT_COMMENTAIRE_ETOILE_ESP, ETAT_DIRECTIVE, ETAT_LITTERAL_Q, ETAT_LITTERAL_DQ } etat = ETAT_DBT_LIGNE;
  acc = 0;
  while ((c=getchar()) != EOF) 
    {
      switch (etat) 
        {
	  //en début de ligne de code
	case ETAT_DBT_LIGNE:
	  switch (c) 
            {
	    case ' ':
	    case '\t':
	      break;
	    case '\n':
	      putchar(c);
	      break;
	    case '{':
	      for (i=0; i < acc*4; i++)
                putchar(' ');
	      putchar(c);
	      acc++;
	      etat = ETAT_ACC;
	      break;
	    case '}':
	      acc--;
	      for (i=0; i < acc*4; i++)
                putchar(' ');
	      putchar(c);
	      etat = ETAT_ACC;
	      break;
	    case '/':
	      etat = ETAT_COMMENTAIRE_DBT;
	      break;
	    case '#':
	      putchar(c);
	      etat = ETAT_DIRECTIVE;
	      break;
	    default:
	      for (i=0; i < acc*4; i++)
                putchar(' ');
	      putchar(c);
	      etat = ETAT_NORMAL;
	      break;
            }
	  break;

	  //dans une ligne de code
	case ETAT_NORMAL:
	  switch (c)
            {
	    case '\n': 
	      putchar(c);
	      etat = ETAT_DBT_LIGNE;
	      break;
	    case '{':
	      putchar('\n');
	      for (i=0; i < acc*4; i++)
                putchar(' ');
	      putchar(c);
	      acc++;
	      etat = ETAT_ACC;
	      break;
	    case '}':
	      acc--;
	      putchar('\n');
	      for (i=0; i < acc*4; i++)
                putchar(' ');
	      putchar(c);
	      etat = ETAT_ACC;
	      break;
	    case '/':
	      etat = ETAT_COMMENTAIRE;
	      break;
	    case '\'':
	      putchar(c);
	      etat = ETAT_LITTERAL_Q;
	      break;
	    case '"':
	      putchar(c);
	      etat = ETAT_LITTERAL_DQ;
	      break;
	    default :  
	      putchar(c);
	      break;
            }
	  break;

	  //à la suite d'une accolade (ouvrante ou fermante)
	case ETAT_ACC:
	  switch (c)
            {
	    case ' ':
	    case '\t':
	      break;
	    case '\n': 
	      putchar(c);
	      etat = ETAT_DBT_LIGNE;
	      break;
	    case '{':
	      putchar('\n');
	      for (i=0; i < acc*4; i++)
                putchar(' ');
	      putchar(c);
	      acc++;
	      etat = ETAT_ACC;
	      break;
	    case '}':
	      acc--;
	      putchar('\n');
	      for (i=0; i < acc*4; i++)
                putchar(' ');
	      putchar(c);
	      etat = ETAT_ACC;
	      break;
	    case '/':
	      etat = ETAT_COMMENTAIRE_DBT;
	      break;
	    case '\'':
	      putchar('\n');
	      putchar(c);
	      etat = ETAT_LITTERAL_Q;
	      break;
	    case '"':
	      putchar('\n');	      
	      putchar(c);
	      etat = ETAT_LITTERAL_DQ;
	      break;
	    default :  
	      putchar('\n');
	      for (i=0; i < acc*4; i++)
                putchar(' ');
	      putchar(c);
	      etat = ETAT_NORMAL;
	      break;
            }
	  break;

	  //après l'apparition d'un slash en début de ligne
	case ETAT_COMMENTAIRE_DBT:
	  switch (c)
            {
	    case '*':
	      for (i=0; i < acc*4; i++)
                putchar(' ');
	      putchar('/');
	      putchar(c);
	      etat = ETAT_COMMENTAIRE_ETOILE_DBT;
	      break;
	    case '/':
	      for (i=0; i < acc*4; i++)
                putchar(' ');
	      putchar('/');
	      putchar(c);
	      etat = ETAT_COMMENTAIRE_SLASH;
	      break;
	    case '\n':
	      putchar('/');
	      putchar(c);
	      etat = ETAT_DBT_LIGNE;
	      break;
	    default:
	      putchar('/');
	      putchar(c);
	      etat = ETAT_NORMAL;
	      break;
            }
	  break;

	  //après l'apparition d'un slash dans une ligne
	case ETAT_COMMENTAIRE:
	  switch (c)
            {
	    case '*':
	      putchar('\n');
	      for (i=0; i < acc*4; i++)
                putchar(' ');
	      putchar('/');
	      putchar(c);
	      etat = ETAT_COMMENTAIRE_ETOILE_DBT;
	      break;
	    case '/':
	      putchar('\n');
	      for (i=0; i < acc*4; i++)
                putchar(' ');
	      putchar('/');
	      putchar(c);
	      etat = ETAT_COMMENTAIRE_SLASH;
	      break;
	    case '\n':
	      putchar('\n');
	      putchar('/');
	      putchar(c);
	      etat = ETAT_DBT_LIGNE;
	      break;
	    default:
	      putchar('/');
	      putchar(c);
	      etat = ETAT_NORMAL;
	      break;
            }
	  break;

	  //dans un commentaire '//'
	case ETAT_COMMENTAIRE_SLASH:
	  switch (c)
            {
	    case '\n':
	      putchar(c);
	      etat = ETAT_DBT_LIGNE;
	      break;
	    default:
	      putchar(c);
	      break;
            }
	  break;

	  //au début d'un commentaire '/* */'
	case ETAT_COMMENTAIRE_ETOILE_DBT:
	  switch (c)
            {
	    case '\n':
	    case '\t':
	    case ' ':
	      break;
	    case '*':
	      putchar(' ');
	      etat = ETAT_COMMENTAIRE_ETOILE_FIN;
	      break;
	    default:
	      putchar(' ');
	      putchar(c);
	      etat = ETAT_COMMENTAIRE_ETOILE;
	      break;
            }
	  break;

	  //dans un commentaire '/* */'
	case ETAT_COMMENTAIRE_ETOILE:
	  switch (c)
            {
	    case '\n':
	      putchar(' ');
	      putchar('*');
	      putchar('/');
	      putchar(c);
	      for (i=0; i < acc*4; i++)
                putchar(' ');
	      putchar('/');
	      putchar('*');
	      etat = ETAT_COMMENTAIRE_ETOILE_DBT;
	      break;
	    case '*':
	      etat = ETAT_COMMENTAIRE_ETOILE_FIN;
	      break;
	    case (' '):
	      etat = ETAT_COMMENTAIRE_ETOILE_ESP;
	      break;
	    default:
	      putchar(c);
	      break;
            }
	  break;

	  //fin d'un commentaire '/* */'
	case ETAT_COMMENTAIRE_ETOILE_FIN:
	  switch (c)
            {
	    case '\n':
	      putchar(' ');
	      putchar('*');
	      putchar('/');
	      putchar(c);
	      for (i=0; i < acc*4; i++)
                putchar(' ');
	      putchar('/');
	      putchar('*');
	      etat = ETAT_COMMENTAIRE_ETOILE_DBT;
	      break;
	    case '*':
	      putchar(c);
	      break;
	    case '/':
	      putchar('*');
	      putchar(c);
	      etat = ETAT_NORMAL;
	      break;
	    default:
	      putchar('*');
	      putchar(c);
	      etat = ETAT_COMMENTAIRE_ETOILE;
	      break;
            }
	  break;

	  //espace dans un commantaire '/* */' (pour supprimer les espaces inutiles)
	case ETAT_COMMENTAIRE_ETOILE_ESP:
	  switch(c)
            {
	    case '\n':
	      putchar(' ');
	      putchar('*');
	      putchar('/');
	      putchar(c);
	      for (i=0; i < acc*4; i++)
                putchar(' ');
	      putchar('/');
	      putchar('*');
	      etat = ETAT_COMMENTAIRE_ETOILE_DBT;
	      break;
	    case '*':
	      putchar(' ');
	      etat = ETAT_COMMENTAIRE_ETOILE_FIN;
	      break;
	    default:
	      putchar(' ');
	      putchar(c);
	      etat = ETAT_COMMENTAIRE_ETOILE;
	      break;
            }
	  break;

	  //cas d'une directive (commencant par #)
	case ETAT_DIRECTIVE:
	  switch (c)
            {
	    case '\n':
	      putchar(c);
	      etat = ETAT_DBT_LIGNE;
	      break;
	    default:
	      putchar(c);
	      break;
            }
	  break;

	  //cas d'un litteral simple quote
	case ETAT_LITTERAL_Q:
	  switch (c)
            {
	    case '\'':
	      putchar(c);
	      etat = ETAT_NORMAL;
	      break;
	    case '\\':
	      putchar(c);
	      putchar(getchar());
	      break;
	    default:
	      putchar(c);
	      break;
            }
	  break;

	  //cas d'un litteral double quote
	case ETAT_LITTERAL_DQ:
	  switch (c)
            {
	    case '"':
	      putchar(c);
	      etat = ETAT_NORMAL;
	      break;
	    case '\\':
	      putchar(c);
	      putchar(getchar());
	      break;
	    default:
	      putchar(c);
	      break;
            }
	  break;
        }
    }
  if (acc != 0) {
    printf("\n\033[33m!!Ca bug sur la parité des accolades!!\033[0m\n");
    exit(EXIT_FAILURE);
  }
  exit(EXIT_SUCCESS);
}
