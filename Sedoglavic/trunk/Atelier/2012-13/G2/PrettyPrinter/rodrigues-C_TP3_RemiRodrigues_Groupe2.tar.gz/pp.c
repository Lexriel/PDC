#include <stdio.h>
#include <stdlib.h>

void indent(int cpt)
{
    int i = 0;
    for(; i < cpt ; i++)
    {
            putchar('\t');   
    }
}

int main()
{
    enum {ETAT_DBT_LIGNE, ETAT_NORMAL, ETAT_DEBUT_COMMENTAIRE, ETAT_COMMENTAIRE_NORMAL} etat = ETAT_DBT_LIGNE;
    
    int c;
    int i = 0;
    int c_old = getchar();
 
    while ((c=getchar()) != EOF)
    {
        switch (etat)
        {
            case ETAT_DBT_LIGNE:
                switch (c_old)
                {
                    case '\n':
                    case ' ':
                    case '\t':
                        break;
                    case '/':
                        if(c=='*'){
                            etat = ETAT_DEBUT_COMMENTAIRE;
                            indent(i);
                            putchar('/');
                            putchar('*');
                        }
                        break;
                    case '{':
                        indent(i);
                        putchar('{');
                        putchar('\n');
                        i++;
                        break;
                    case '}':
                        i--;
                        indent(i);
                        putchar('}');
                        putchar('\n');
                        break;
                    case ';':
                        indent(i);
                        putchar(';');
                        putchar('\n');
                        break;
                    default:
                        indent(i);
                        putchar(c_old);
                        etat = ETAT_NORMAL;
                        break;
                }
                c_old = c;
                break;
            case ETAT_NORMAL:
                switch (c_old)
                {
                    case '\n': 
                        putchar('\n');
                        etat = ETAT_DBT_LIGNE;
                        break;
                    case '/':
                        if(c=='*')
                        {
                            etat = ETAT_DEBUT_COMMENTAIRE;
                            putchar('\n');
                            indent(i);
                            putchar('/');
                            putchar('*');
                        }
                        break;
                    case '{':
                        putchar('\n');;
                        indent(i);
                        putchar('{');
                        putchar('\n');
                        ++i;
                        etat = ETAT_DBT_LIGNE;
                        break;
                    case '}':
                        putchar('\n');
                        indent(--i);
                        putchar('}');
                        putchar('\n');
                        etat = ETAT_DBT_LIGNE;
                        break;
                    case ';':
                        putchar(';');
                        putchar('\n');
                        etat = ETAT_DBT_LIGNE;
                        break;
                    default :  
                        putchar(c_old);
                        break;
                }
                c_old = c;
                break;
            case ETAT_DEBUT_COMMENTAIRE:
                switch (c_old)
                {
                    case '\n':
                    case ' ':
                    case '\t':
                        break;
                    case '*' :
                        putchar(' ');
                        break;
                    default :
                        putchar(c_old);
                        etat = ETAT_COMMENTAIRE_NORMAL;
                        break;
                }
                c_old = c;
                break;
            case ETAT_COMMENTAIRE_NORMAL:
                switch (c_old)
                {
                    case '*':
                        if(c=='/')
                        {
                            etat = ETAT_DBT_LIGNE;
                            putchar('*');
                            putchar('/');
                            putchar('\n');
                        }
                        break;
                    case '\n':
                        putchar(' ');
                        putchar('*');
                        putchar('/');
                        putchar('\n');
                        indent(i);
                        putchar('/');
                        putchar('*');
                        putchar(' ');
                        etat = ETAT_DEBUT_COMMENTAIRE;
                        break;
                    default :
                        putchar(c_old);
                        break;
                }
                c_old = c;
                break;
        }
    }
    exit(EXIT_SUCCESS);
}
