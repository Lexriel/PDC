#include <stdio.h>
#include <stdlib.h>

/**
 * Class allowing automatic indentation of a text
 * @author LEFER Gregory 
 */

void indentation(int cpt){
  int i;
  
  for (i = 0; i<cpt*4;i++)
    putchar(' ');
}

int 
main()
{
  
  int c,niveauIndentation,nbAccolades;
  
  //initialisation des variables
  niveauIndentation = 0;
  nbAccolades = 0;

  enum {ETAT_DBT_LIGNE, ETAT_NORMAL, ETAT_FIN_LIGNE, ETAT_DBT_COMM,ETAT_COMM_UL, ETAT_COMM_ML, FIN_COMM_ML, ETAT_CAR,ETAT_STRING, ETAT_CAR_ESCAPE, DBT_COMM_ML, ETAT_SIMPLE, ETAT_PARENTHESE } etat = ETAT_DBT_LIGNE;
  
  while ((c=getchar()) != EOF) {
    switch (etat) {
      /*Etat correspondant au debut de ligne */
    case ETAT_DBT_LIGNE:
      switch (c) {
      case ' ':
      case '\t':
	break;
      case '\n':
	putchar(c);
	break;
      case '{':
	nbAccolades++;
	indentation(niveauIndentation);
	putchar(c);
	niveauIndentation++;
	etat = ETAT_FIN_LIGNE;
	break;
      case '}':
	nbAccolades--;
	niveauIndentation--;
	indentation(niveauIndentation);
	putchar(c);
	etat = ETAT_FIN_LIGNE;
	break;
      case '/':
	indentation(niveauIndentation);
	putchar(c);
	etat = ETAT_DBT_COMM;
	break;
      case '\'':
	indentation(niveauIndentation);
	putchar(c);
	etat = ETAT_CAR;
	break;
      case '\"':
	indentation(niveauIndentation);
	putchar(c);
	etat = ETAT_STRING;
	break;
      case '#':
	putchar(c);
	etat = ETAT_SIMPLE;
	break;
      case '(':
	putchar(c);
	etat = ETAT_PARENTHESE;
	break;
      default:   
	indentation(niveauIndentation);
	putchar(c);
	etat = ETAT_NORMAL;
	break;
      }
      break;
      /* Etat correspondant a la lecture d'un texte qui n'est pas un commentaire */
    case ETAT_NORMAL:
      switch (c) {
      case '\n': 
	putchar('\n');
	etat=ETAT_DBT_LIGNE;
	break;
      case '{':
	nbAccolades++;
	putchar('\n');
	indentation(niveauIndentation);
	putchar(c);
	niveauIndentation++;
	etat = ETAT_FIN_LIGNE;
	break;
      case '\"':
	putchar(c);
	etat = ETAT_STRING;
	break;
      case '\'':
	putchar(c);
	etat = ETAT_CAR;
	break;   
      case '}':
	nbAccolades--;
	putchar('\n');
	niveauIndentation--;
	indentation(niveauIndentation);
	putchar(c);
	etat= ETAT_FIN_LIGNE;
	break;
      case '/':
	putchar('\n');
	indentation(niveauIndentation);
	putchar(c);
	etat = ETAT_DBT_COMM;
	break;
      case ';':
	putchar(c);
	etat = ETAT_FIN_LIGNE;
	break;
      case '(':
	putchar(c);
	etat = ETAT_PARENTHESE;
	break;
      default :  
	putchar(c);
	break;
      }
      break;
      /* Etat suivant la lecture d'un caractere devant être à la fin d'une ligne */
    case ETAT_FIN_LIGNE:
      switch(c){
      case '\n':
	putchar(c);
	etat = ETAT_DBT_LIGNE;
	break;
      case ' ':
	putchar('\n');
	etat= ETAT_DBT_LIGNE;
	break;
      case '}':
	nbAccolades--;
	putchar('\n');
	niveauIndentation--;
	indentation(niveauIndentation);
	putchar(c);
	break;
      case '{':
	nbAccolades++;
	putchar('\n');
	indentation(niveauIndentation);
	niveauIndentation++;
	putchar(c);
	break;
      default :
	putchar('\n');
	indentation(niveauIndentation);
	putchar(c);
	etat = ETAT_NORMAL;
      }
      break;
    case ETAT_PARENTHESE:
      switch(c){
      case ')':
	putchar(c);
	etat = ETAT_NORMAL;
	break;
      default:
	putchar(c);
      }
      break;
      /* Etat aprés avoir lu un '/' et donc on recherche quel type de commentaire va être ouvert */
    case ETAT_DBT_COMM:
      switch(c){
      case '*':
	putchar(c);
	etat = ETAT_COMM_ML;
	break;
      case '/':
	putchar(c);
	etat = ETAT_COMM_UL;
	break;
      default:
	putchar(c);
	etat = ETAT_NORMAL;
      }
      break;
      /* Etat représentant un commentaire sur plusieurs lignes */
    case ETAT_COMM_ML:
      switch(c){
      case '*':
	putchar(c);
	etat= FIN_COMM_ML;
	break;
      case '\n':
	putchar('*');
	putchar('/');
	putchar('\n');
	etat = DBT_COMM_ML;
	break;
      default:
	putchar(c);
      }
      break;
      /* Etat representant une nouvelle ligne de commentaire multiligne
	 dont on souhaite supprimer les espaces et tabulations inutiles */
    case DBT_COMM_ML:
      switch(c){
      case ' ':
      case '\t':
	break;
      case '*' :
	indentation(niveauIndentation);
	putchar('/');
	putchar('*');
	putchar(c);
	etat = FIN_COMM_ML;
	break;
      default:
	indentation(niveauIndentation);
	putchar('/');
	putchar('*');
	putchar(c);
	etat = ETAT_COMM_ML;
      }
      break;
      /* Etat aprés avoir lu une étoile pendant un commentaire multiligne pour savoir si on a finis de traiter 
         ce type de commentaire */
    case FIN_COMM_ML:
      switch(c){
      case '/':
	putchar(c);
	etat= ETAT_FIN_LIGNE;
	break;
      case '\n':
	putchar('*');
	putchar('/');
	putchar('\n');
	etat = DBT_COMM_ML;
	break;
      case '*':
	putchar(c);
	break;
      default:
	putchar(c);
	etat = ETAT_COMM_ML;
      }
      break;
      /* Etat lors de la lecture d'un commentaire sur une ligne  */
    case ETAT_COMM_UL:
      switch (c){
      case '\n':
	putchar(c);
	etat= ETAT_DBT_LIGNE;
	break;
      default:
	putchar(c);
	break;
      }
      break;
      /* Etat déclenché lors de la lecture d'un apostrophe signifiant que l'on va lire un caractére */
    case ETAT_CAR:
      switch(c){
      case '\'':
	putchar(c);
	etat= ETAT_NORMAL;
	break;
      case '\\':
	putchar(c);
	etat = ETAT_CAR_ESCAPE;
	break;
      default:
	putchar(c);
      }
      break;
    case ETAT_SIMPLE:
      switch(c){
      case '\n':
	putchar(c);
	etat = ETAT_DBT_LIGNE;
	break;
      default:
	putchar(c);
      }
      break;
      /* Etat déclenché lors de la lecture d'une double quote signifiant que l'on va lire une chaine de caractére */
    case ETAT_STRING:
      switch(c){
      case '\"':
	putchar(c);
	etat = ETAT_NORMAL;
	break;
      default:
	putchar(c);
      }
      break;
      /* Etat déclenché lors de la lecture de caractére si on a lue un caractére d'échapement '\' */
    case ETAT_CAR_ESCAPE:
      putchar(c);
      etat=ETAT_CAR;
    }

    //si il existe un probléme d'accolade on l'affiche dans la sortie d'erreur
     if (nbAccolades <0)
       fprintf(stderr, "Il existe une erreur de parenthesage");

  }
  //si jamais on repére qu'il y a une erreur dans le fichier on l'affiche
  if (nbAccolades <0 || etat == ETAT_DBT_COMM || etat == ETAT_COMM_ML || etat == FIN_COMM_ML){
    //permet de colorer le texte (je ne sais pas si ça fonctionne sur un autre terminal que linux)
    printf("\033[31m");
    if (nbAccolades <0)
      printf("\n\n Attention : il existe une erreur d'accolades\n");
    else
      printf("\n\n Attention : il existe une erreur de commentaires\n");
    printf("\033[0m");
    exit(EXIT_FAILURE);
  }
  else
    exit(EXIT_SUCCESS);
}

