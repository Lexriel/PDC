#================================>
	LEFER Gregory
	   Groupe 2
      PDC- TP indentation
<================================#

Utilisation : 
 Commande pour compiler le programme : 
 	  % make
 Commande d'utilisation du programme
 	  % ./pp < NomFichierSource > NomFichierSortie
   - NomFichierSource : fichier que l'on souhaite indenter
   - NomFichierSortie : fichier dans lequel on va écrire le fichier indenté, si aucun fichier n'est précisé alors la sortie standard sera utilisée.

Le programme fonctionne correctement et la série de commande suivante renvoie aucune différence entre les fichiers : 

% make pp
% pp < pp.c > pp2.c
% gcc -o pp2 pp2.c
% pp2 < pp2.c > pp3.c
% diff pp2.c pp3.c 

Remarque : cette suite de commande peut être effectuée en faisant :
% make test

Sinon lors de la lecture d'un point-vigule, on insére un retour à la ligne permettant de mettre une instruction par ligne.
