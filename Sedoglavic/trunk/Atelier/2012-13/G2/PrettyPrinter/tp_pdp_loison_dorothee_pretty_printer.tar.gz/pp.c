#include <stdio.h>
#include <stdlib.h>

int 
main()
{
    int i = 0;
    int c, d/*, e*/;
    int n = 0;
    enum {ETAT_DBT_LIGNE, ETAT_NORMAL } etat = ETAT_DBT_LIGNE;
  
    while ((c=getchar()) != EOF) 
	{
        switch (etat) 
	{
		
            case ETAT_DBT_LIGNE:

                switch (c) 
		{
                    case ' ':
		    case '\t':
                        break;
 		    case '{' :



    			for (; i != n; i++)
    			{
				putchar(' ');
				putchar(' ');
				putchar(' ');
				putchar(' ');
			}
			i = 0;
			n++;
			putchar('{');
			putchar('\n');

			break;
		    case '}' :


			n--;
			if (n < 0) fprintf(stderr, "Problème d'accolades");

			for (; i != n; i++)
    			{
				putchar(' ');
				putchar(' ');
				putchar(' ');
				putchar(' ');
			}
			i = 0;	


			putchar('}');
			putchar('\n');

			break;
		    case '\n':
			putchar('\n');


			break;
                    default:   

    			for (; i != n; i++)
    			{
				putchar(' ');
				putchar(' ');
				putchar(' ');
				putchar(' ');
			}
			i = 0;

                        putchar(c);

                        etat = ETAT_NORMAL;
                        break;
                }
                break;

            case ETAT_NORMAL:
                switch (c) 
		{
                    case '\n': 
                        putchar('\n');
                        etat=ETAT_DBT_LIGNE;
                        break;
		    case '{' :
			putchar('\n');
    			for (; i != n; i++)
    			{
				putchar(' ');
				putchar(' ');
				putchar(' ');
				putchar(' ');
			}
			i = 0;
			putchar('{');
			putchar('\n');
			n++;
                        etat=ETAT_DBT_LIGNE;
			break;
		    case '}' :
			n--;
			if (n < 0) fprintf(stderr, "Problème d'accolades");
			putchar('\n');
    			for (; i != n; i++)
    			{
				putchar(' ');
				putchar(' ');
				putchar(' ');
				putchar(' ');
			}
			i = 0;
			putchar('}');
			etat=ETAT_DBT_LIGNE;
			break;

		    


		    case ';' : 
			putchar(';');

			switch(d=getchar())
			{
				case ' ':

		    		case '\t':

				case '\n' :
					putchar('\n');


				break;

				default : 
				putchar('\n');



				c= ungetc(d, stdin);

				break;
			}
		    	etat = ETAT_DBT_LIGNE;		
			break;


			/*case '/':
				
				switch(e = getchar())
				{*/
					/*case '*' : putchar('\n');
					c = ungetc(e, stdin);

					putchar(c);

					break;*/
					/*default : putchar('\n');
					c = ungetc(e, stdin);
					putchar(c);
					break;
				}
				break;*/
			
			/*case '*' :
			    f = getchar();
			    switch(f)
				{

					case '/' :
					c = ungetc(f, stdin);
					putchar(c);
					c = getchar();
					putchar(c);
					putchar('\n');
					etat = ETAT_DBT_LIGNE;
					break;
					default : 
					c = ungetc(f, stdin);
					putchar(c);
					break;
				}				
				break;*/
			
                    default :  
                        putchar(c);
                        break;
                }
		break;
        }
    }

	if (n != 0) exit(EXIT_FAILURE);

	exit(EXIT_SUCCESS);
}

