#ifndef _READL__H_
#define _READL__H_
#define MAXLINE  10000

extern int readl(char line[]);

#endif /* _READL__H_ */
