#include<stdio.h>

#include"arbre.h"
#include"parse.h"
#include"automate.h"

extern NODE * root;

int main(int argc, char **argv){
	
	return 0;
}
