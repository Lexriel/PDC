#!/bin/bash
./mgrep $1 < mgrep-xampl.txt
