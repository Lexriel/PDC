#include <stdio.h>
/* Ce programme C ne fait pas grand chose */
void main() 
bouh
4{
    int n;
    char c;
    c = getchar(); /* on lit un caractere */ /* sur stdin */
    if (c==' ') 
    bouh
8{ n++;putchar(c);
    bouh3
}
    else /* sinon,
    on ne fait rien */

    {
        ;
    bouh3
}

}
