#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "qsint.h"

void tabAleatoire (int tab[], int size, int seed) {
	int i;
	i = 0;
	srand(seed);
	while (i < size) {
		tab[i++] = rand();
	}
}

int partitionnement(int tab[], int pivot,  unsigned int size) {
        int montant;
        int descendant;
        int tmp;
	int p;
	montant = 0;
	descendant = size - 1;
	p = tab[pivot];
	while (1) {
		while (tab[montant] < p) {
			montant++;
		}
		while (tab[descendant] > p) {
			descendant--;
		}
		if (montant == descendant) {
			break;
		} else {
			tmp = tab[montant];
			tab[montant] = tab[descendant];
			tab[descendant] = tmp;
		}
	}
	return montant;
}

void quicksort_int(int tab[], unsigned int size) {
	int pivot;
	int s;
	if (size != 1) {
		pivot = size / 2;
	} else {
		pivot = 1;
	}
	if (pivot < size) {
		s = partitionnement(tab,pivot,size);
        	quicksort_int(&tab[0],s);
		quicksort_int(&tab[s+1],(size - s - 1));
	}
}

int main () {
	int tab[TABSIZE];
	int i;
	tabAleatoire(tab,TABSIZE,time(NULL));
        for (i = 0; i < TABSIZE; i++) {
                printf("Valeur de la case %d du tableau trie (AVANT) : %d\n",i,tab[i]);
        }
	quicksort_int(tab,TABSIZE);
	printf("\n");
	for (i = 0; i < TABSIZE; i++) {
                printf("Valeur de la case %d du tableau trie (APRES) : %d\n",i,tab[i]);
        }
	return 1;
}
