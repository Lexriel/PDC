#define TABSIZE 1000

void quicksort(void *base, int nmemb, int size, int(*compar)(const void *, const void *));
