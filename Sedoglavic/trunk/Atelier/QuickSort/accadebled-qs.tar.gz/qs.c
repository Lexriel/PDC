#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "qs.h"

void tabAleatoire (int tab[], int size, int seed) {
	int i;
	i = 0;
	srand(seed);
	while (i < size) {
		tab[i++] = rand();
	}
}

void echanger(void *a, void *b,int size) {
	int i;
        char tmp ;
        for(i = 0; i < size; i++)
        {
                tmp = *((char *) a+i) ;
                *((char *) a+i) = *((char *) b+i) ;
                *((char *) b+i) = tmp ;
        }
        return ;
}

void sauvegarde(void *a, void *b, int size) {
	int i;
        for(i = 0; i < size; i++)
        {
                *((char *) b+i) = *((char *) a+i);
        }
        return ;	
}


int partitionnement(void *base, int pivot, int nmemb, int size,int (*compar)(const void *, const void *)) {
	int montant;
	int descendant;
	void *m = NULL;
	void *d = NULL;
	void *p = malloc(size);
	montant = 0;
	descendant = nmemb - 1;
	m = (void *)((char *) base+(montant*size));
	d = (void *)((char *) base+(descendant*size));
	sauvegarde((void *)((char *) base+(pivot*size)),p,size);
	while (1) {
		while (compar(m, p) < 0) {
			montant++;
			m = (void *)((char *) base+(montant*size));
		}
		while (compar(d, p) > 0) {
			descendant--;
			d = (void *)((char *) base+(descendant*size));
		}
		if (montant == descendant) {
			break;
		} else {
			echanger(m,d,size);
		}
	}
	free(p);
	return montant;
}

void quicksort(void *base, int nmemb, int size, int(*compar)(const void *, const void *)) {
	int pivot;
	int s;
	if (nmemb != 1) {
		pivot = nmemb / 2;
	} else {
		pivot = 1;
	}
	if (pivot < nmemb) {
		s = partitionnement(base,pivot,nmemb,size,compar);
		quicksort(base,s,size,compar);
		quicksort((void *)((char *) base+(((s+1)*size))),(nmemb - s - 1),size,compar);
	}
}

int comparaison(const void *a, const void *b) {
	return   *((int *)a)- *((int *)b);
}

int compChar(const void *a, const void *b) {
	return	(int)*((char *)a) - (int)*((char *)b);
}

int main() {
	int i;
	int tab[TABSIZE];
	char tab2[5] = {'B','x','Z','d','Q'};
	tabAleatoire(tab,TABSIZE,time(NULL));

	for (i = 0; i < 5; i++) {
		printf("Tableau de caracteres avant le tri : %c\n",tab2[i]);
	}
	quicksort(tab2,5,sizeof(char),compChar);
	printf("\n");
	for (i = 0; i < 5; i++) {
		printf("Tableau de caracteres apres le tri: %c\n",tab2[i]);
	}

	printf("\n");

	for (i = 0; i < TABSIZE; i++) {
		printf("Tableau d entiers avant le tri: %d\n",tab[i]);
	}
	quicksort(tab,TABSIZE,sizeof(int),comparaison);
	printf("\n");
	for (i = 0; i < TABSIZE; i++) {
		printf("Tableau d entiers apres le tri : %d\n",tab[i]);
	}

	return 1;
}
