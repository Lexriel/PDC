#include "qs.c"

/*fonctions de comparaisons :
  retourne 0 si les deux éléments sont équivalents ;
  retourne une valeur positive si le premier élément est considéré plus grand que le second ;
  retourne une valeur négative sinon.

compare les entiers*/
int
compare_i( const void *x, const void *y)
{
  return *((int *) x)- *((int *)y);
}

/*compare les char*/
int
compare_c( const void *x, const void *y)
{
  return *((char*)x) - *((char*)y );
}

/*affiche les valeurs des cellules du tableau passé en parametre*/
void
afficheTab(int tab[])
{
  int i;
  for (i = 0; i < TABSIZE; i++ )
    {
      printf("%i,", tab[i]);
    }
}

/*affiche les valeurs des cellules du tableau passé en parametre*/
void
afficheTab_2dim(char tab[2][4])
{
  int i;
  int j;
  for (i=0; i < 2; i++ )
    {
		for (j = 0 ; j < 4; j++)
		{
			 printf("%i,", tab[i][j]);
		}
    }
}

/*rempli le tableau de valeurs aleatoires*/
void 
initTab(int tab[])
{
  int i;
  for (i=0; i < TABSIZE; i++ )
    {
      /*      tab[i] = rand()/10000;*/
      tab[i] =(int) ((double) rand() / RAND_MAX * 100);
    }
}

int
main()
{
  int tabTest[TABSIZE]; /*la taille des tableau qu'on va tester*/
  char tabTest2[2][4];

  initTab(tabTest);	/*rempli le tableau avec des int*/
  afficheTab(tabTest); /*tableau le tableau de depart : non trie*/
  
  printf("\n \nIci commence qsort d'entier:\n\n");
  quicksort(tabTest, TABSIZE, sizeof *tabTest, compare_i); /*qsort generique execute sur entier*/
  afficheTab(tabTest);
  printf("\n\n");

/*Ne fonctionne pas*/
  /*tabTest2[0][0] = 't';
  tabTest2[0][1] = 'e';
  tabTest2[0][2] = 's';
  tabTest2[0][3] = 't';

  tabTest2[1][0] = 't';
  tabTest2[1][1] = 'r';
  tabTest2[1][2] = 'u';
  tabTest2[1][3] = 'c';*/

	/*qsort generique execute sur char*/
/*
  quicksort(tabTest2, TABSIZE, sizeof *tabTest2, compare_c); 
  afficheTab_2dim(tabTest2);*/

  return 0;
}
