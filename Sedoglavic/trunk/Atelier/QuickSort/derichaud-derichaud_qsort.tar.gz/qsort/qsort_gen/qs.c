#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "qs.h"

typedef unsigned char byte;

/*Permute les valeurs des tableaux de bytes parametre*/
void swap_bytes(byte *a, byte *b, int size)
{
  byte tmp;
  int i;

  for(i = 0; i < size; i++)
    {
      tmp = *(a + i) ;
      *(a + i) = *(b + i) ;
      *(b + i) = tmp ;
    }
}

/*quicksort generique*/
void quicksort(void *base, int nmemb, int size, int(*compar)(const void *, const void *))
{
  byte *ptr2a, *ptr2b, *ptr2base;
  int i,j;

  /*utilisation d'un pointeur de byte pour pouvoir utiliser les operateurs arithmetiques*/
  ptr2base = (byte *)base ;

  /* on trie*/
  for(i = nmemb - 1; i >= 0; i--)
    {
      for(j = 1; j <= i; j++)
		{
		  ptr2a = (byte*) (ptr2base + size * (j - 1)) ;
		  ptr2b = (byte*) (ptr2base + size * j) ;

		  if(compar(ptr2a, ptr2b) > 0)
			swap_bytes(ptr2a, ptr2b, size) ;
		}
    }
}
