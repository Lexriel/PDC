#include "qsint.c"

/*rempli le tableau de valeurs aleatoires*/
void 
initTab(int tab[])
{
  int i;
  for (i=0; i < TABSIZE; i++ )
    {
      /*      tab[i] = rand()/10000;*/
      tab[i] =(int) ((double) rand() / RAND_MAX * 100);
    }
}

/*affiche les valeurs des cellules du tableau passé en prarmetre*/
void
afficheTab(int tab[])
{
  int i;
  for (i=0; i < TABSIZE; i++ )
    {
      printf("%i,", tab[i]);
    }
}

int
main()
{
  int tabTest[TABSIZE];

  initTab(tabTest);
  afficheTab(tabTest);
  
  printf("\n \nIci commence qsort entier\n\n");
  quicksort_int(tabTest,TABSIZE);
  afficheTab(tabTest);
  printf("\n");

  return 0;
}
