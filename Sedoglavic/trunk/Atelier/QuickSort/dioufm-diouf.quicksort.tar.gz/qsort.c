#include<stdio.h>
#include <stdlib.h>

#define TABSIZE 5


float 
f
(int x,int y)
{
  return x-y ;
}
        

void 
quicksort_int
(int tab[], unsigned int size)
{
  int temp ;
  int montant,descendant;

  if(size<=1)
    return ;

  if(size==2)
    {
      if (tab[0]>tab[1])
	{
	  temp= tab[1] ;
	  tab[1] = tab[0];
	  tab[0] = temp ;
	}
      return ;
    }
    
  montant=0; 
  descendant=size-2;

  while(1)
    {
      while(f(tab[montant],tab[size-1])<=0 && montant < size-1)
	montant++;
      while(f(tab[descendant],tab[size-1])>0 && descendant > 0)
	descendant--;
      
      if (montant >= descendant)
	break ;

      temp=tab[descendant];
      tab[descendant]=tab[montant];
      tab[montant]=temp;
      
      montant ++ ;
      descendant -- ;
    }

  temp=tab[montant];
  tab[montant]=tab[size-1];
  tab[size-1]=temp;
  
  
    
  quicksort_int(tab,montant);
  quicksort_int(tab+montant+1,size-montant-1) ;
   
  
   
}

int
main()
{

  int i, tab[TABSIZE];

  for(i=0;i<TABSIZE;i++)
    tab[i]=rand();

  printf("\n tableau genere\n");

  tab[0]= 83;
  tab[1]= 86;
  tab[2]= 77;
  tab[3]= 15;
  tab[4]= 93;

  for(i=0;i<TABSIZE;i++)
    printf("%d ",tab[i]);

  quicksort_int(tab,TABSIZE);
  
  printf("\n le tableau trie est \n");

  
  for(i=0;i<TABSIZE;i++)
    printf(" %d ",tab[i]);
  


    
  return 0 ;
}
