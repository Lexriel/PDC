
/*********************************************/
/**                                         **
 *                                           *
 * Author: Baptiste LEGRAND                  *
 *                                           *
 **                                         **/
/*********************************************/

#include <stdio.h>
#include <stdlib.h>

#define TABSIZE 10
#define MAX 10

#define TRUE 1
#define FALSE 0

int tableau[TABSIZE] ={ 1,2 };

void quicksort_int(int * tab,unsigned int size);

int compare(int a, int b);

/*------------------------------------------------------------
  ------------------------------------------------------------*/

int main (int argc,char * argv[]){

  int iterateur = TABSIZE;

  /* Generation du tableau avec des nombres aleatoires.*/
  for(iterateur =0; iterateur < TABSIZE ;iterateur ++)
    *(tableau + iterateur) = rand()%MAX+1;

  for(iterateur =0; iterateur < TABSIZE ;iterateur ++)
    printf("[%d]: %d\n", iterateur, *(tableau + iterateur));
  /* --- */
  /* Le TRI */
  //while(iterateur>=0){
    quicksort_int(tableau, TABSIZE);
    //    iterateur --;
    //}
  /* On affiche le contenue du tableau*/
  for(iterateur =0; iterateur < TABSIZE ;iterateur ++)
    printf("[%d]: %d\n", iterateur, *(tableau + iterateur));
  
  return 0;
}

/*------------------------------------------------------------
  ------------------------------------------------------------*/

void quicksort_int(int * tab,unsigned int size){
  // printf("\n\n\n#!--Nouvel Appel de QuickSort--\n");

  unsigned int indice_pivot = 0;
  unsigned int montant = 1;
  unsigned int descendant = size - 1;
  unsigned int pivot = tab[indice_pivot];

  int tmp= 0;
  /*  printf("#!----- Tableau a trier --------\n");

  for(iterateur =0; iterateur < size ;iterateur ++)
  printf("#! [%d]: %d\n", iterateur, *(tableau + iterateur));*/

  //  printf("#!-- Size:%d Descendant:%d --\n", size, descendant);
  //
 
  if (size<=1)
	  	return ;

  if (size==2)
  {
	  if (tab[0] > tab[1])
	  {
		  tmp = tab[1] ;
	  	tab[1]=tab[0] ;
	       tab[0] = tmp ;

	  return ;
	  }

  }	
    //    printf("#!-- ACTIONS --\n");

    /* Tant que la valeur du tableau[montant] est different de
       tableau[descendant] alors on fait ... */
    while(1){
      /* Dans le cas ou la valeur qui se trouve a droite du pivot est
	 inferieur au pivot on incremente montant */
      while(compare( (*(tab+montant)), pivot) <= 0 && montant < size )
	montant ++;
      
      /* Dans le cas ou la valeur qui se trouve a gauche du pivot est
	 superieur au pivot on decremente descendant */
      while(compare(pivot, (*(tab+descendant))) < 0 && descendant > 1)
	descendant --;
      
      printf("On met [%d]: %d dans [%d]: %d\n",  montant, tab[montant], descendant, tab[descendant]);
     
     if (montant >= descendant )
	    break ; 

      tmp= tab[montant];
      tab[montant] = tab[descendant];
      tab[descendant] = tmp;
      
    }
      tmp= tab[0];
      tab[0] = tab[descendant];
      tab[descendant] = tmp;
	
      quicksort_int(tab, descendant);
      quicksort_int(tab+descendant+1,size-descendant-1);
	
    // printf("#!--------- Fin Rec---------\n");
}

/*------------------------------------------------------------
  ------------------------------------------------------------*/

int compare(int a, int b){
  //printf("On compare %d et %d\n", a,b);
  if(a == b)
    {
      // printf("#! - %d EGAL %d\n", a, b);
      return 0;
    }
  else if(a>b)
    {
      // printf("#! - %d SUP %d\n", a, b);  
      return 1;
    }
  else
    {
      // printf("#! - %d INF %d\n", a, b);
      return -1;
    }
}
