#include<stdio.h>
#include<stdlib.h>

#include "qsint.h"

/*Fonction de comparaison d'int*/
int f(int x, int y)
{
  return x-y;
}

void q_sort(int tab[], int montant, int descendant)
{
  int pivot, tmp_montant, tmp_descendant;
 
  tmp_montant = montant;
  tmp_descendant = descendant;
  pivot = tab[montant];

  while (montant < descendant)
    {
      while (f(tab[descendant],pivot) >=0 && (montant < descendant))
	descendant--;
      if (montant != descendant)
	{
	  tab[montant] = tab[descendant];
	  montant++;
	}
      while (f(tab[montant],pivot) <= 0 && (montant < descendant))
	montant++;
      if (montant != descendant)
	{
	  tab[descendant] = tab[montant];
	  descendant--;
	}
    }
  tab[montant] = pivot;
  pivot = montant;
  montant = tmp_montant;
  descendant = tmp_descendant;

  if (montant < pivot)
    q_sort(tab, montant, pivot-1);
  if (descendant > pivot)
    q_sort(tab, pivot+1, descendant);
}

void quicksort_int(int tab[],unsigned int size)
{
  q_sort(tab, (int)0, size - 1);
}
