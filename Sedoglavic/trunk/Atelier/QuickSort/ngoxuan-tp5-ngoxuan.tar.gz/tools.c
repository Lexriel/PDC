#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tools.h"

int readl(char line[])
{
/*  int taille;*/
  char *c;
  c = fgets(line, NMAXLINE, stdin);
  if (line == NULL)
      return -1;
  else
      return strlen(c);
}
