#include <string.h>

#include "qsint.c"
#include "qs.c"
#include "tools.c"

int cmpstringp(const void *p1, const void *p2)
{
  return strcmp(* (char * const *) p1, * (char * const *) p2);
}

int main()
{
  int i, j;
  /*int ligne, col, nb_car;*/
  int tab[TABSIZE];
  /*char fichier[NMAXLINE][NMAXCHAR];
  char line[NMAXCHAR];
  char c;*/

  for(j=0;j<TABSIZE;j++)
    {
      tab[j]=(int) ((double) rand() / RAND_MAX * 1000);
    }

  /* quicksort d'un tableau d'entiers*/
  quicksort_int(tab,TABSIZE);
  /*quicksort generique avec un tableau generique*/
  
    quicksort(tab,TABSIZE,sizeof *tab,compar_int);

    printf("Voici votre tableau trié:\ntab[");
    for(i=0;i<TABSIZE-1;i++)
    {
    printf("%d,",tab[i]);
    }
    printf("%d]\n",tab[TABSIZE-1]);/*Affichage du dernier element*/

  /*msort*/
  /*Remplissage du tableau*/
  /*ligne = 0;
  col = 0;
  nb_car = 0;
  while ((c = readl(line)) != EOF)
    {
      nb_car = 0;
 for(col=0;col<NMAXCHAR;col++)
    {
      fichier[ligne][col] = line[col];
    }
  ligne++;
    }*/

  /*quicksort(fichier,NMAXLINE,sizeof *fichier,cmpstringp);
  printf("Voici votre tableau trié:\nfichier[");
  for(i=0;i<NMAXLINE-1;i++)
    {
      printf(fichier[i]);
      printf(",");
    }
    printf("]\n");*//*Affichage du dernier element*/
  return 0;
}
