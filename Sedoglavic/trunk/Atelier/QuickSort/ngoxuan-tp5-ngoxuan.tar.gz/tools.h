#define NMAXLINE  81
#define NMAXCHAR  70
extern int readl(char line[]);
