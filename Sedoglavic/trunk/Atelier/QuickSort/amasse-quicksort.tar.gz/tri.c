#include <stdlib.h>
#include <stdio.h>
#define TABSIZE 99

void affichageTab(int *tab,int taille){
  int i;
  for(i=0;i<taille;i++){
    printf("%d ",tab[i]);
  }
  printf("\n");
}


int f(int n1,int n2){
  return n1-n2;
}

void initTab(int *tab){
  int i;
  int nbr;
  for(i=0;i<TABSIZE;i++){
    tab[i]=rand()%100;
  }
}

void remplacer(int *tab,int a,int b){
  int tmp;
  tmp=tab[a];
  tab[a]=tab[b];
  tab[b]=tmp;
}


int partition(int *tab,int debut, int fin) {
  int pivot = tab[debut];
  int montant = debut-1;
  int descendant = fin+1; 
  
  while (1) {
    do {
      montant++;
    } while (f(tab[montant],pivot)<0);
    do {
      descendant--;
    } while (f(pivot,tab[descendant])<0);
    if (montant<descendant) {
      remplacer(tab, montant, descendant);
    } else {
      return descendant;
    }
  }
}
void quicksort(int *tab,int debut,int fin){
  int pivot;
  if(debut<fin){
    pivot=partition(tab,debut,fin);
    quicksort(tab,debut,pivot);
    quicksort(tab,pivot+1,fin);
  }
}

int main(int argc,char * argv[]){
  int *tab;
  tab=malloc(TABSIZE*sizeof(int));
  initTab(tab);
  affichageTab(tab,TABSIZE);

  quicksort(tab,0,TABSIZE);

  printf("\napres le tri\n");
  affichageTab(tab,TABSIZE);
}
