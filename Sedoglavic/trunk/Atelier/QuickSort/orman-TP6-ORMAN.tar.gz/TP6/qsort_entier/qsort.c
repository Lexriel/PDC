
/*********************************************/
/**                                         **
 *                                           *
 * Author: Baptiste LEGRAND                  *
 *                                           *
 **                                         **/
/*********************************************/

#include <stdio.h>
#include <stdlib.h>

#define TABSIZE 10
#define MAX 10

#define TRUE 1
#define FALSE 0

int tableau[TABSIZE] ={ 1,2 };

void quicksort_int(int * tab,unsigned int size);

int compare(int a, int b);

/*------------------------------------------------------------
  ------------------------------------------------------------*/

int main (int argc,char * argv[]){

  int iterateur = TABSIZE;

  /* Generation du tableau avec des nombres aleatoires.*/
  for(iterateur =0; iterateur < TABSIZE ;iterateur ++)
    *(tableau + iterateur) = rand()%MAX+1;

  for(iterateur =0; iterateur < TABSIZE ;iterateur ++)
    printf("[%d]: %d\n", iterateur, *(tableau + iterateur));

    quicksort_int(tableau, TABSIZE);
  /* Tableau trie*/
  for(iterateur =0; iterateur < TABSIZE ;iterateur ++)
    printf("[%d]: %d\n", iterateur, *(tableau + iterateur));
  
  return 0;
}

/*------------------------------------------------------------
  ------------------------------------------------------------*/

void quicksort_int(int * tab,unsigned int size){
  // printf("\n\n\n#!--Nouvel Appel de QuickSort--\n");

  unsigned int indice_pivot = 0;
  unsigned int montant = 1;
  unsigned int descendant = size - 1;
  unsigned int pivot = tab[indice_pivot];

  int tmp= 0;
  if (size<=1)
	  	return ;

  if (size==2)
  {
	  if (tab[0] > tab[1])
	  {
		  tmp = tab[1] ;
	  	tab[1]=tab[0] ;
	       tab[0] = tmp ;

	  return ;
	  }

  }	

    while(1){

      while(compare( (*(tab+montant)), pivot) <= 0 && montant < size )
	montant ++;
    
      while(compare(pivot, (*(tab+descendant))) < 0 && descendant > 1)
	descendant --;
      
      printf("On met [%d]: %d dans [%d]: %d\n",  montant, tab[montant], descendant, tab[descendant]);
     
     if (montant >= descendant )
	    break ; 

      tmp= tab[montant];
      tab[montant] = tab[descendant];
      tab[descendant] = tmp;
      
    }
      tmp= tab[0];
      tab[0] = tab[descendant];
      tab[descendant] = tmp;
	
      quicksort_int(tab, descendant);
      quicksort_int(tab+descendant+1,size-descendant-1);
	
}

/*fonction de comparaison entre deux entiers*/

int compare(int a, int b){

  if(a == b)
    {
      return 0;
    }
  else if(a>b)
    {
 
      return 1;
    }
  else
    {
      return -1;
    }
}
