
#include<string.h>
#include<stdio.h>
#define TABSIZE 5
int
f
(char *x1,char *x2)
{
  return (int)(*x1-*x2);
  
}

void
quicksort
(char *base, int nmemb, int size ,int(*compar)(const void *,const void *))
{
  int montant,descendant,temp;
  switch(size)
 {
 case '1':(char)temp;break;
 case '4':(int)temp;break;
 }
  if(nmemb==1)
    return;
  if(nmemb==2)
    {
      if(compar(base,(base+1))>0)
	{ 
	  temp=*base ;
	  *base =*(base+1);
	  *(base+1)= temp ;
	}
    }
    
  montant=0; 
  descendant=nmemb-2;

  while(1)
    {
      while(compar((base+montant),(base+nmemb-1))<=0&&montant<nmemb-1)
	montant++;
      while(compar((base+descendant),(base+nmemb-1))<=0&&descendant<nmemb-1)
	descendant--;
      if(montant>=descendant)
	break;
      
      
      temp=*(base+descendant);
      *(base+descendant)=*(base+montant);
      *(base+montant)=temp;
      
     
      montant++;
      descendant--;
      
      
    }
  temp=*(base+montant);
  *(base+montant)=*(base+nmemb-1);
  *(base+nmemb-1)=temp;
  
  
  quicksort(base,descendant+1,size,&f);
  quicksort(base+descendant+1,nmemb-descendant-1,size,&f);
}
    
int
main()
{
  
  int i, tab[TABSIZE];
  char base[]={'2','3','a','s','f'} ;
  /*for(i=0;i<TABSIZE;i++)
    tab[i]=rand()%100; */	     
  printf("\n tableau genere\n");	    
  for(i=0;i<TABSIZE;i++)
    printf("%d ",tab[i]);

  quicksort(base,i+1,sizeof(*base),&f);
  printf("\n le tableau trie est \n");
  for(i=0;i<TABSIZE;i++)
  printf(" %d ",tab[i]);
  return 0  ;
}
    
