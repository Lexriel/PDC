#include<stdio.h>
#include <stdlib.h>
#define TABSIZE 10


float 
f
(int x,int y)
{
  return x-y ;
}


void 
quicksort_int
(int tab[], unsigned int size)
{
  int temp ;
  int montant,descendant;
  
  if(size<=1)
    return ;
  
  if(size==2)
    {
      if (tab[0]>tab[1])
	{
	  temp= tab[1] ;
	  tab[1] = tab[0];
	  tab[0] = temp ;
	}
      return ;
    }
  
  montant=0; 
  descendant=size-2;
  
  while(1)
    {
      while(f(tab[montant],tab[size-1])<=0&&montant<size-1)
	montant++;
      while(f(tab[descendant],tab[size-1])>0&&0<descendant)
	descendant--;
      if(montant>=descendant)
	break;
      
      
      temp=tab[descendant];
      tab[descendant]=tab[montant];
      tab[montant]=temp;
      
      
      montant++;
      descendant--;
      
      
    }
  temp=tab[montant];
  tab[montant]=tab[size-1];
  tab[size-1]=temp;
  
  
  quicksort_int(tab,descendant+1);
  quicksort_int(tab+descendant+1,size-descendant-1) ;
  
}

int
main()
{
  int i, tab[TABSIZE];
  for(i=0;i<TABSIZE;i++)
    tab[i]=rand();
  printf("\n tableau genere\n");
  for(i=0;i<TABSIZE;i++)
    printf("%d ",tab[i]);
  quicksort_int(tab,TABSIZE);
  printf("\n le tableau trie est \n");
  for(i=0;i<TABSIZE;i++)
    printf(" %d ",tab[i]);
  return 0 ;
}






