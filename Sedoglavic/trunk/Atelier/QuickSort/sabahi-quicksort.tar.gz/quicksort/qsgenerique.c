#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/* partionnement du tableau*/

void *partitionner(void *base, int nmemb, int size,int (*compar)(const void *, const void *)) {
  void *p;
  char *pivot, *montant, *descendant, *aux;
  char *t = base;
  aux = malloc(sizeof (char )*size);
  montant = base;
  descendant = montant + (size)*(nmemb-1);
  pivot = montant;
  while(montant<descendant){
     	 while( (compar ((void*)(montant+=size),(void *)pivot)<0) && (montant<t+(size)*(nmemb-1)));
              if(compar((void*) montant,(void *)pivot)>0) {
		   while(montant<descendant) {
				if(compar((void *)montant,(void *)descendant)>0) {
					memcpy(aux,montant,size);
					memcpy(montant,descendant,size);
					memcpy(descendant,aux,size);
				}
				descendant-=size;
				montant+=size;
	 	 }
 	 }
}
montant-=size;
p=montant;
if(compar((void *)montant,(void *) pivot)<0){
   memcpy(aux,montant,size);
   memcpy(montant,base,size);
   memcpy(base,aux,size);
}
free(aux);
return p; 
}

void qsgenerique(void *base, int nmemb, int size,int (*compar)(const void *, const void *))
{
  void *p;
   int i;
   char *t = base;
  if (nmemb == 1) return;
    p = partitionner(base,nmemb,size,compar);
    for (i = 0; i < nmemb; i++)
      if (compar((void *)(t+(i*size)),p)==0){
	break;
    } 
if (i==0) return;
if (nmemb-i==0) return;
qsgenerique(base,i,size,compar);
qsgenerique((void *)(t+i*size),nmemb-i,size,compar);
}



