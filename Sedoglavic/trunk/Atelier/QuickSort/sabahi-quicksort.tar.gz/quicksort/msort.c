#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "qsgenerique.h"
#include "readl.h"

/* structure pour memoriser l'ensemble des lignes du fichier */

struct fichier{
 char tabfichier[MAXLINE][MAXCHAR];
 unsigned int nblines;
};

struct fichier fichier;
char line[MAXCHAR];

int compar(const void *x, const void *y)
{
 char *xx=(char *)x;
 char *yy=(char *)y;
 return strcmp(xx,yy);
}

/* initialisation du tableau tabfichier */

void init(struct fichier *fic){
  int i,j;
  for(i=0;i<10;i++)
      for(j=0;j<MAXCHAR;j++)
         fic->tabfichier[i][j] = '\0';
 }

/* affichage des lignes du fichier*/

void affiche(struct fichier *fic){
  int i,j;
  for(i=0;i<fic->nblines;i++)
      for(j=0;j<MAXCHAR;j++)
         printf("%c",fic->tabfichier[i][j]);
   } 

int
main(){
int i,l;
init(&fichier);
fichier.nblines = 0;
i = 0;
while((l=readl(line))!=EOF){
     strcpy(fichier.tabfichier[i],line);
    fichier.nblines++;
   i++;
}
printf("\t Avant le qs\n");
affiche(&fichier);
qsgenerique(fichier.tabfichier,fichier.nblines,MAXCHAR*sizeof(char),&compar);
printf("\t Apres le qs\n");
affiche(&fichier);
return 0;
}
