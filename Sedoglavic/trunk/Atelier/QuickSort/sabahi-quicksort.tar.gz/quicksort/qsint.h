#define TABSIZE 7
/* initialisation aleatoire du tableau*/

void init (int t[], unsigned int size);
/* partionnement du tableau*/

int *partitionner(int t[], unsigned int size);

void qsint (int t[], unsigned int size);
