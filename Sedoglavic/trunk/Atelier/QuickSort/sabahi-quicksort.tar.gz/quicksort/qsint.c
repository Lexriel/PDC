#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "qsint.h"

/* initialisation aleatoire du tableau*/

void init (int t[], unsigned int size)
{
 int i;  
  for (i = 0; i < size; i++)
    t[i] = rand()%size;
 }

/* comparaison de deux elements*/

int f(int x, int y)
{
  if (x == y)
    return 0;
  else if (x > y)
    return 1;
    else return -1;
} 

/* partionnement du tableau*/

int *partitionner(int t[], unsigned int size) {
  int *p;
  int pivot, *montant, *descendant, aux;
  montant = t;
  descendant = t+size-1;
  pivot = *montant;
  while(montant<descendant){
     	 while( (f(*(++montant),pivot)<0) && (montant<t+size-1));
          if(f(*montant,pivot)>0) {
       		  while(montant<descendant) {
				if(f(*montant,*descendant)>0) {
					aux = *montant;
					*montant = *descendant;
					*descendant = aux;
				}
				descendant--;
				montant++;
	 	 }
 	 }
}
/*montant--;*/
p=montant;
aux = 0;
if(f(*montant,pivot)<0){
   aux = *montant;
   *montant = *(t);
   *(t) = aux;
}
return p;
}

void qsint (int t[], unsigned int size)
{
  int *p,i;
  if (size == 1) return;
    p = partitionner(t,size);
    for (i = 0; i < size; i++)
      if (*(t+i) == *p){
	break;
    } 
if (i==0) return;
if (size-i==0) return;
     qsint(t,i);
     qsint(t+i,size-i);
 }

