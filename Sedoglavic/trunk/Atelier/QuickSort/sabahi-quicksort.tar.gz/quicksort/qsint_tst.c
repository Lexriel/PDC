#include <stdlib.h>
#include <stdio.h>
#include "qsint.h"

int tab[TABSIZE];
int
main ()
{
  int i;
  printf("Tableau non trié\n");
  init(tab,TABSIZE);
  for(i=0;i<TABSIZE;i++) printf("%d ",tab[i]);
  printf("\n");
  qsint(tab,TABSIZE);
  printf("Tableau trié\n");
  for(i=0;i<TABSIZE;i++) printf("%d ",tab[i]);
  putchar('\n');
   exit(EXIT_SUCCESS);
}
