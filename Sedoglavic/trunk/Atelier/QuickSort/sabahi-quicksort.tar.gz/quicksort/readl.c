#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "readl.h"

int readl(char line[])
{
  int i, nbcar;
  char *status;
  nbcar = 0;
  for (i = 0; i < MAXCHAR+1; i++)
    line[i] = '\0';
  status = fgets(line,MAXCHAR+1,stdin);
  if (status == NULL) return EOF;
  for (nbcar = 0; nbcar < MAXCHAR; nbcar++)
    if (line[nbcar]=='\n')
      break;
  if (++nbcar == MAXCHAR)
    fprintf(stderr,"-- ERROR: line(s) with more than MAXLINE (80) characters --\n");
  return nbcar;
}


