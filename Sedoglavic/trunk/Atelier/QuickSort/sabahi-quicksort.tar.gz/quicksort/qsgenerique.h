#define TABSIZE 10

void qsgenerique(void *base, int nmemb, int size,int (*compar)(const void *, const void *));





