#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "quickSortGeneric.h"
#define MAXSIZE 10

int comparaison(const int *a,const int *b) {

  if (*a>*b) {
    return 1;}
  else { 
    if (*a<*b){
      return -1;}
    else{ return 0;}
  }
}

void swap(int a, int b,int size,void *tab) {

  int id=0;
  char *i = malloc(size*sizeof(char)); 
  
  memcpy(i,tab+a,size);
  memcpy(tab+a,tab+b,size);
  memcpy(tab+b,i,size);
  
  free(i);

}

void quickSort(void *tab,int length, int size,
	       int(*compar)(const void *,const void *)) {
  
  int montant = 0;
  int descendant = length-2;
  int x = length-1;

  
  
  while (montant!=descendant) {
    
    while ((compar(tab+x,tab+descendant)<0) && (montant != descendant)) {
      
	descendant--;
    }
      
    while ((compar(tab+montant,tab+x)<0) && (montant != descendant)) {
	
      montant++;
    }


    swap(montant,descendant,size,tab);
    
  }

  if (compar(tab+descendant,tab+x)>0){
  
    swap(descendant,x,size,tab);
    x=descendant;
    
  } else { 

    swap(x,descendant+1,size,tab);
    x=descendant+1;
  }    
    


  if (descendant>2){
      
    quickSort(tab,descendant,size,compar);
    
  }
    
  if (descendant<size-3){
    
    char *tabRec=malloc(size*MAXSIZE*sizeof(char));
    int k =0;
    int j;
    int id=0;

    for (j=descendant+1; j<size; j++) {
      mempcy(tabRec+k,tab+j,size);
      k++;
    }
    
    quickSort(tabRec,k,size,compar);

    k=0;
    
    for (j=descendant+1; j<size; j++) {
      mempcy(tab+j,tabRec+k,size);
      k++;
    }
  }
 
}
  
	    
int main() {

  /*generation du tableau a trier*/
  
  int tab[MAXSIZE];
  int n;

  printf("tableau avant le tri \n");

  for (n=0; n<MAXSIZE; n++) {
    
    tab[n]= rand()% 100;
    printf("%ud \n", tab[n]);
  }

  quickSort(tab,MAXSIZE,7,comparaison);

  printf("tableau apres le tri \n");


  for (n=0; n<MAXSIZE;n++) {

    printf("%ud \n",tab[n]);
  }

  exit(EXIT_SUCCESS);

}
