qsGen: probleme dans le main => non testé
mQS: non faisable sans le qsGen
