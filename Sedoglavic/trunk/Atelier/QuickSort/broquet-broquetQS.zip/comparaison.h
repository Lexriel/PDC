extern int comparaison(int n , int m);
