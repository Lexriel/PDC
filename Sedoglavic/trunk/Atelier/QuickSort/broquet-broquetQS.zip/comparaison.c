#include <stdlib.h>
#include "comparaison.h"

int comparaison(int n,int m) {

  if (n > m) {return 1;
  } else {
    if (n<m) {return -1;}
  }
  return 0; 
}
