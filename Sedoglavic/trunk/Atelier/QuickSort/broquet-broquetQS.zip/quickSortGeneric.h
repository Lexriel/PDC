void quickSortGeneric(void *tab,int length, int size,
		      int(*compar)(const void *,const void *));
