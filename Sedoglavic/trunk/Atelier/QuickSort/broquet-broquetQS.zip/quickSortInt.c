#include <stdio.h>
#include <stdlib.h>
#include "comparaison.h"
#include "quickSortInt.h"
#define MAXSIZE 10

/*void swap(int a, int b) {

  int i=0;

  i=a;
  a=b;
  b=i;

}
*/

void quickSort(int tab[], unsigned int size) {
  
  int montant = 0;
  int descendant = size-2;
  int x = tab[size-1];
  int i =0;

  while (montant!=descendant) {
    
    while ((comparaison(x,tab[descendant])<0) && (montant != descendant)) {
      
	descendant--;
    }
      
    while ((comparaison(tab[montant],x)<0) && (montant != descendant)) {
	
      montant++;
    }
    
    /*  swap(tab[montant],tab[descendant]);*/
    i=tab[montant];
    tab[montant]=tab[descendant];
    tab[descendant]=i;

  }

  if (comparaison(tab[descendant],x)>0){

    /*    swap(tab[descendant],tab[size-1]);*/
    i=tab[descendant];
    tab[descendant]=x;
    tab[size-1]=i;

    
  } else { 

    /*    swap(tab[descendant+1],tab[size-1]);*/
    i=tab[descendant+1];
    tab[descendant+1]=x;
    tab[size-1]=i;

  }    
    


  if (descendant>2){
      
    quickSort(tab,descendant);
    
  }
    
  if (descendant<size-3){
    
    int tabRec[MAXSIZE];
    int k =0;
    int j;
    
    for (j=descendant+1; j<size; j++) {
      tabRec[k]=tab[j];
      k++;
    }
    
    quickSort(tabRec,k);

    printf("test");
    
    k=0;
    
    for (j=descendant+1; j<size; j++) {
      tab[j]=tabRec[k];
      k++;
    }
  }
 
}
  
	    
int main() {

  /*generation du tableau a trier*/
  
  int tab[MAXSIZE];
  int n;

  printf("tableau avant le tri \n");

  for (n=0; n<MAXSIZE; n++) {
    
    tab[n]= rand()% 100;
    printf("%ud \n", tab[n]);
  }

  quickSort(tab,MAXSIZE);

  printf("tableau apres le tri \n");


  for (n=0; n<MAXSIZE;n++) {

    printf("%ud \n",tab[n]);
  }

  exit(EXIT_SUCCESS);

}
