


#define TABSIZE 100


void quickSort( int[], int, int);
int partition( int[], int, int);
void quicksort_int(int tab[], unsigned int size);


