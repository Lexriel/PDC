#define TABSIZE 10 



int comp_char(char x, char y);
void quick(char base[], int nmemb, int(*compar)(const void *, const void *));
void quickSort( char a[], int ascendent, int descendent, int(*compar)(const void *, const void *));
int partition( char a[], int ascendent, int descendent, int(*compar)(const void *, const void *));


