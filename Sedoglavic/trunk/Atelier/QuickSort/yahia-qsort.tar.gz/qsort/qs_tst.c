
#include <stdio.h>
#include "qs.h"


int main() 
{
	char a[TABSIZE]={'f','y','e','x','g','u','i','h','z','s'} ;	

	int i;


	printf("\n\nLE TABLEAU NON TRIE EST                           : \n\n");
	
             for(i = 0; i < TABSIZE; ++i)
		printf(" [%c] ", a[i]);

	
quick(a,TABSIZE,comp_char);


printf("\n\nLE TABLEAU TRIE EST                              : \n");
	for(i = 0; i < TABSIZE; ++i)
		if (a[i]!='\n') printf("[%c] ", a[i]);
       printf ("\n\n FIN DE L'ALGORITHME...|||||||||||||||||||||||||||||||||||\n\n\n\n");

return 0;
} 
