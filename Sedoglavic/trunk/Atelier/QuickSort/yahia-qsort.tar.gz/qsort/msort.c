#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "msort.h"




int comp_str(char x[MAXLINE], char y[MAXLINE]){


if ( strcmp(x,y)<0 || strcmp(x,y)==0)  return 1;
   else {
               return 0;
           }
}

void quick(char base[MAXLINE][MAXLINE], int nmemb, int(*compar)(const void *, const void *))
{


 int ascendent =0, descendent =nmemb;
  quickSort( base,ascendent ,descendent,compar);
}


void quickSort( char a[MAXLINE][MAXLINE], int ascendent, int descendent, int(*compar)(const void *, const void *))
{
   int j;

   if( ascendent < descendent ) 
   {

        j = partition( a, ascendent, descendent,compar);
       quickSort( a, ascendent, j-1,compar);
       quickSort( a, j+1, descendent,compar);
   }
}


int partition( char a[MAXLINE][MAXLINE], int ascendent, int descendent, int(*compar)(const void *, const void *)) {
   char pivot[MAXLINE], t[MAXLINE],tt[MAXLINE];
   int i,j,zz=0;


   for( zz=0;zz<MAXLINE;zz++) pivot[zz] = a[ascendent][zz];
   i = ascendent; j = descendent+1;

   while( 1)
   {

   	do{ ++i;  for( zz=0;zz<MAXLINE;zz++) tt[zz] = a[i][zz];   } while( (comp_str(tt ,pivot)==1) && i <= descendent );
       do {--j; for( zz=0;zz<MAXLINE;zz++) tt[zz] = a[j][zz];} while( comp_str(tt , pivot)==0 );
       // do ++i; while( a[i] <= pivot && i <= descendent );
   	//do --j; while( a[j] > pivot );
        if( i >= j ) break;
   //	t = a[i]; a[i] = a[j]; a[j] = t;
for(zz=0;zz<MAXLINE;zz++) t[zz] = a[i][zz];
for( zz=0;zz<MAXLINE;zz++) a[i][zz] = a[j][zz];
for(zz=0;zz<MAXLINE;zz++) a[j][zz] = t[zz];
   }

 for(zz=0;zz<MAXLINE;zz++) t[zz] = a[ascendent][zz];
for( zz=0;zz<MAXLINE;zz++) a[ascendent][zz] = a[j][zz];
for(zz=0;zz<MAXLINE;zz++) a[j][zz] = t[zz];
//   t = a[ascendent]; a[ascendent] = a[j]; a[j] = t;
   return j;
}




