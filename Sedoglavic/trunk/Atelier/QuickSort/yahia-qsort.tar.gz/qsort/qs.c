#include <stdio.h>
#include "qs.h"



int comp_char(char x, char y){

if (x<y||x==y) return 1;
    else {
               return -1;
            }
}


void quick(char base[], int nmemb, int(*compar)(const void *, const void *))
{

 int ascendent =0, descendent =nmemb;
  quickSort( base,ascendent ,descendent,compar);
}


void quickSort( char a[], int ascendent, int descendent, int(*compar)(const void *, const void *))
{
   int j;

   if( ascendent < descendent ) 
   {
        j = partition( a, ascendent, descendent,compar);
       quickSort( a, ascendent, j-1,compar);
       quickSort( a, j+1, descendent,compar);
   }
}


int partition( char a[], int ascendent, int descendent, int(*compar)(const void *, const void *)) {
   char pivot,t;
int  i, j;
   pivot = a[ascendent];
   i = ascendent; j = descendent+1;
		
   while( 1)
   {
   	do ++i; while( (comp_char(a[i] ,pivot)==1) && i <= descendent );
   	do --j; while( comp_char(a[j] , pivot)==-1 );
      
        if( i >= j ) break;
   	t = a[i]; a[i] = a[j]; a[j] = t;
   }
   t = a[ascendent]; a[ascendent] = a[j]; a[j] = t;
   return j;
}


