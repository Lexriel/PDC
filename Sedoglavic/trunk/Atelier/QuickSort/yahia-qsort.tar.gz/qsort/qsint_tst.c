#include <stdio.h>
#include<stdlib.h>
#include "qsint.h"



void main() 
{
	int a[TABSIZE] ;	

	int i;

  for(i = 0; i < TABSIZE; ++i) a[i]=rand()%99;

	printf("\n\nLE TABLEAU NON TRIE EST                           : \n\n");
	
             for(i = 0; i < TABSIZE; ++i)
		printf(" [%d] ", a[i]);


        quicksort_int(a, TABSIZE);
	
printf("\n\nLE TABLEAU TRIE EST                              : \n");
	for(i = 0; i < TABSIZE; ++i)
		printf("[%d ] ", a[i]);
       printf ("\n\n FIN DE L'ALGORITHME...|||||||||||||||||||||||||||||||||||\n\n\n\n");

}
