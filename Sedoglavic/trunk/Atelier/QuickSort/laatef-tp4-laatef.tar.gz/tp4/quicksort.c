#include <stdlib.h>
#include <stdio.h>

#define TABSIZE 1000

void initTab(int *tab){
 
  int i;
  
  for(i = 0; i < TABSIZE; i++){
    tab[i]= rand()%350;
  }
}

int compare(int x, int y){
 
  return x - y;
}


  
void affichageTab(int tab[],int size){
  int i;
  for(i = 0 ; i < size; i++){
    printf("%d ",tab[i]);
    if(i % 30 == 0 && i != 0 ){
      printf("\n");
    }
  }
  printf("\n");
}


void quicksort_int(int tab[], unsigned int size){

  int pivot ; 
  int montant = -1;
  int descendant = size;
  int tmp  ;

  if(size<=0)
    {
      return ;
    }
  if(size == 1)
    {
      return ;
    }
  
  if(size == 2)
    {
      if(compare(tab[0],tab[1]) > 0)
	{ 
	  tmp = tab[0] ;
	  tab[0] = tab[1];
	  tab[1] = tmp;
	}
      
      return ;
    }

  pivot = 0 ;
 
  while(1){
    montant++ ;
    descendant-- ;

    while(compare(tab[montant],tab[pivot]) <= 0 && montant< size-1 )
      montant ++;
    
    while(compare(tab[pivot],tab[descendant]) < 0 && descendant > 0)
      descendant-- ;

    if(montant >= descendant)
      break ;

    tmp = tab[descendant];
    tab[descendant] = tab[montant];
    tab[montant] = tmp;
  }

  tmp = tab[pivot];
  tab[pivot] = tab[descendant]; 
  tab[descendant] = tmp;
  pivot = descendant ;

  quicksort_int(tab,pivot);
  quicksort_int(tab+pivot+1,size-pivot-1);
  
  return ;
}

int main(int argc, char **argv){
  
  int tab[TABSIZE];
  
  initTab(tab);
  affichageTab(tab,TABSIZE);
  quicksort_int(tab,TABSIZE);

  affichageTab(tab,TABSIZE);

  return 0;

}
  
