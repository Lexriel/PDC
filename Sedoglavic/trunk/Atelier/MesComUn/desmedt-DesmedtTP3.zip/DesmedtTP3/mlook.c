#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"


int main(int argc,char *argv[])
{
  char line[MAXLINE];
  int nbCharLine=0,succes=0;
  int i = 0,j=0;
  

  if (argc<1)
    {
      fprintf(stderr,"Mot clé manquant");
      exit(EXIT_FAILURE);
    }

  if (argc>2)
    {
      fprintf(stderr,"usage : mlook word");
      exit(EXIT_FAILURE);
    }    
  
  

  while ((nbCharLine=readl(line))!=EOF)
    {
      while ((line[i]==' ') || (line[i]=='\t'))
	i++;

      j=i;

      while (i<i+strlen(argv[1]))
	{
	  if (line[i]==(*(argv[1]+i-j)))
	    i++;
	  else
	    break;
	}

      if (i==j+strlen(argv[1]))
	{
	  fprintf(stdout,"%s\n",line);
	  succes = 1;
	}
	  
      i = j = 0;
	
    }
	  
      if (succes)
	exit(EXIT_SUCCESS);
      else
	exit(EXIT_FAILURE);
}
