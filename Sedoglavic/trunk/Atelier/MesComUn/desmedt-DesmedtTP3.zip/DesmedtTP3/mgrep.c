#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"


int main(int argc,char *argv[])
{
  char line[MAXLINE];
  int nbCharLine=0,succes=0;
 
  

  if (argc<1)
    {
      fprintf(stderr,"Mot clé manquant");
      exit(EXIT_FAILURE);
    }

  if (argc>2)
    {
      fprintf(stderr,"usage : mgrep word");
      exit(EXIT_FAILURE);
    }    
  
  

  while ((nbCharLine=readl(line))!=EOF)
    {
      if (strstr(line,argv[1])!=NULL)
	{
	  fprintf(stdout,"%s \n",line);
	  succes = 1;
	}
	
    }
	  
      if (succes)
	exit(EXIT_SUCCESS);
      else
	exit(EXIT_FAILURE);
}
