#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"



int main(int argc,char *argv[])
{
  int charDsLigne=0,debutSuppr=0,finSuppr=0,i;
  char line[MAXLINE]={0};
  
  
  if (argc<2)
    {
      
      fprintf(stderr,"Pas de numero de colonne\n");
      exit(EXIT_FAILURE);
    }


  if (argc>3)
    {
      fprintf(stderr,"usage : mcolrm start stop\n");
      exit(EXIT_FAILURE);
    }

  debutSuppr = atoi(argv[1]);

  if (argc == 3)
    finSuppr = atoi(argv[2]);
  else
    finSuppr = MAXLINE -1;
  
  if (debutSuppr>finSuppr)
    {
      fprintf(stderr,"numero de colonnes incorrects\n");
      exit(EXIT_FAILURE);
    }

  while ((charDsLigne = readl(line))!=EOF)
    {
      
      
      for (i=0;i<=charDsLigne;i++)
	{
	  if (!((i>=debutSuppr-1) && (i<finSuppr)))
	    putchar(line[i]);
	}
      putchar('\n');
    }

  for (i=0;i<strlen(line);i++)
    {
      if (!((i>=debutSuppr-1) && (i<finSuppr)))
	{
	  putchar(line[i]);
	}
    }
	
  
  exit(EXIT_SUCCESS);
}


