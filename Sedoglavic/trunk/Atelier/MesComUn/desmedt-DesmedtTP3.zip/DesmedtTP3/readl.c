#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"



extern int readl(char line[])
{
  char c;
  int comptChar =0;

  memset(line,0,sizeof(line));
  while ((c=getchar())!= EOF)
    {
      
      if (c=='\n')
	{
	  line[comptChar]='\0';
	  return (comptChar);
	  
	}
      else
	{
	  
	  if (comptChar>=MAXLINE-1)
	    {
	      fprintf(stderr,"Ligne de plus de 80 caracteres");
	      exit(EXIT_FAILURE);
	    }

	  line[comptChar++]= c;
	  
	}

    }

  return EOF;

}
