#include <stdio.h>
#include <stdlib.h>
#include "readl.h"

int main (int argc, char *argv[]) {
	int i,j,k;
	char line[MAXLINE];
	j = 0;
	k = 0;
	if (argc != 2) {
		fprintf(stderr,"usage: mgrep word\n");
		exit(EXIT_FAILURE);
	} else {
		while (readl(line) != EOF) {
			i = 0;
			while (line[i] != '\0') {
				if (line[i] == argv[1][j]) {
					i++;
					j++;
					if (argv[1][j] == '\0') {
						printf("%s\n",line);
						j = 0;
						k++;
					}	
				} else {
					j = 0;
					if (line[i] == argv[1][j]) {
						j++;
					}
					i++;
				}
			}
		}
		if (k == 0) {
			fprintf(stderr,"no word found\n");
			exit(EXIT_FAILURE);
		}
	}
	return 1;
}
