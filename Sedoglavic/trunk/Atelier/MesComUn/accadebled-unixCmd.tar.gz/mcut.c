#include <stdio.h>
#include <stdlib.h>
#include "readl.h"

int main (int argc, char *argv[]) {
	int i;
	char line[MAXLINE];
	char delim;
	int champs;
	int param;
	param = 2;
	if (argc <= 2) {
		fprintf(stderr,"usage: mcut delim fieldno [fieldno]...\n");
		exit(EXIT_FAILURE);
	} else {
		if (argv[1][1] != '\0') {
			fprintf(stderr,"mcut: Le delimiteur doit etre un caractere simple.\n");
			exit(EXIT_FAILURE);
		} else {
			delim = *argv[1];
			while (readl(line) != EOF) {
				i = 0;
				champs = 1;
				param = 2;
				while ((line[i] != '\0') && (argc-1 >= param)) {
                                        if (champs == atoi(argv[param])) {
						if ((argc-1 != param) || (line[i] != delim)) {
                                                	printf("%c",line[i]);
						}
					}
					if (line[i] == delim) {
						champs++;
					}
					if (champs > atoi(argv[param])) {
						param++;
						/**/
						if ((argc-1 >= param) && (champs > atoi(argv[param]))) {
							champs = 1;
							i = -1;							
						}
						/**/
					}
					i++;
				}
				printf("\n");
			}
		}
	}	
	return 1;
}
