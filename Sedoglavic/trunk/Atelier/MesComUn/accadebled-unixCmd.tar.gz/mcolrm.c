#include <stdio.h>
#include <stdlib.h>
#include "readl.h"

int main (int argc, char *argv[]) {
	int i;
	int start;
	int stop;
	char line[MAXLINE];
	switch(argc) {
		case 2 :	stop = atoi(argv[1]);
				while (readl(line) != EOF) {
					i = 0;
					while (i < stop-1 && line[i] != '\0') {
						printf("%c",line[i]);
						i++;
					}
					printf("\n");
				}
				break;

		case 3 :	start = atoi(argv[1]);
				stop = atoi(argv[2]);
				if (stop < start) {
					fprintf(stderr, "mcolrm: illegal start and stop columns\n");
					exit(EXIT_FAILURE);
				}
				while (readl(line) != EOF) {
					i = 0;
					while (line[i] != '\0') {
						if (i < start-1 || i > stop-1) {
							printf("%c",line[i]);
						}
						i++;
					}
					printf("\n");
				}
				break;

		default :	fprintf(stderr, "usage: mcolrm [start [stop]]\n");
				exit(EXIT_FAILURE);
	}
	return 1;
}
