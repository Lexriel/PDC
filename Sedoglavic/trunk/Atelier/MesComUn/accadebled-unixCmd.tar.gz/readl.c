#include <stdio.h>
#include "readl.h"
#include <stdlib.h>

extern int readl(char line[]) {
	int nbCar;
	char *c = NULL;
	nbCar = 0;
	c = fgets(&line[0],MAXLINE+1,stdin);
	if (c == NULL) {
		return EOF;
	} else {
		while (line[nbCar] != '\0') {
			if ((nbCar == MAXLINE-1) && (line[nbCar] != '\n')) {
				fprintf(stderr,"Ligne de plus de %d caracteres.\n",MAXLINE-1);
				exit(EXIT_FAILURE);
			} else {
				nbCar++;
			}
		}
		line[--nbCar] = '\0';
		return nbCar;
	}
}
