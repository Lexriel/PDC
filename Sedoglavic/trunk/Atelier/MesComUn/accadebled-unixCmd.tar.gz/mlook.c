#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"

int main (int argc, char *argv[]) {
	int i;
	char line[MAXLINE];
	i = 0;
	if (argc != 2) {
		fprintf(stderr,"usage: mlook word\n");
		exit(EXIT_FAILURE);
	} else {
		while (readl(line) != EOF) {
			if (line == strstr(line,argv[1])) {
				printf("%s\n",line);
				i++;
			}
		}
		if (i == 0) {
			fprintf(stderr,"no word found\n");
			exit(EXIT_FAILURE);
		}
	}
	return 1;
}
