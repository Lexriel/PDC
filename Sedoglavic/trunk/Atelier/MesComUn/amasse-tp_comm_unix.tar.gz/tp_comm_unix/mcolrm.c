#include <stdio.h>
#include <stdlib.h>
#include "readl.h"

void mcolrm1(int c1){
  char c;
  int i=0;
  while((c=getchar())!=EOF){
    i++;
    if(c=='\n'){
      i=0;
      putchar('\n');
    }
    else
      if(i<c1){
	putchar(c);
      }
  }
}
void mcolrm2(int c1,int c2){
  char c;
  int i=0;
  while((c=getchar())!=EOF){
    i++;
    if(c=='\n'){
      i=0;
      putchar('\n');
    }
    else
      if(i<c1 || i >c2){
	putchar(c);
      }
  }
}
int main(int argc,char *argv[]){
  char *t = argv[1]; 
  int nbr = argc;
  char c;
  if(nbr==2){
    mcolrm1(atoi(argv[1]));
  }
  else
    if(nbr==3){
      mcolrm2(atoi(argv[1]),atoi(argv[2]));
    }
    else{
      printf("probleme de parametre\n");
    } 
}
