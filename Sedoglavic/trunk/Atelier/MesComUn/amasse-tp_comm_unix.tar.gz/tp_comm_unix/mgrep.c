#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"

void mgrep(char *mot){
  char ligne[MAXLINE+1];
  int longLign;
  while(longLign != EOF){
    longLign = readl(ligne);
    
    if(strstr(ligne,mot)!=NULL)
      printf("%s\n",ligne);
  }  
}
int main(int argc, char **argv){
  
  char* mot = argv[1];
  mgrep(mot);

  return 0;
}
