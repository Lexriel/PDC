#include "readl.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int readl(char line[]){
  char c;
  int i = 0;

  while(1){
    c = getchar();

    if(i > MAXLINE){ 
      printf("ligne de plus de 80 caracteres\n");
    }
    if(c == '\n'){
      line[i] = '\0';
      return i;
    }else
      if(c == EOF){
	line[i] = '\0';
	return EOF;
      }else
	line[i] = c;
    i++;
  }

  return i;
}
