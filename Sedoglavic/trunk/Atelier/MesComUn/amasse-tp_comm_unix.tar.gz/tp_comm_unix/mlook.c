#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"

void mlook(char *mot){
  int i;
  int longLign;
  int taille=strlen(mot);
  char ligne[MAXLINE+1];
  char premMot[taille];

while(longLign != EOF){
    longLign=readl(ligne);
    for(i = 0;i < taille; i++){
      premMot[i]=ligne[i];
    }
    premMot[i]='\0';

    if(strcmp(premMot,mot) == 0){
      printf("%s\n",ligne);      
    }
  }
}


int main(int argc, char **argv){
  
  char* mot = argv[1];
  mlook(mot);

  return 0;
}
