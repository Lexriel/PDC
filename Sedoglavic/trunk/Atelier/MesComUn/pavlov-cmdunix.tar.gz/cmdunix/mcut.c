#include <stdio.h>
#include <stdlib.h>
#include "lire.c"
#include "tools.c"

#define MAXLINE  80

int
main(int argc, char *argv[])
{
    char line[MAXLINE+1];
    int status;
    int ind;
    int i;
    char delim;
    int fieldno[80];


    for (i=2;i<argc;i++){
	    fieldno[i-2]=atoi(argv[i]);
    }
    delim=argv[1][0];

    for (;;){

	status = lire(line);
	ind=1;
	for (i=0;i<MAXLINE ;i++){
		if (line[i]==EOF){
				return 0;
			}else{
				if (line[i]=='\n'){
				    i=MAXLINE;
				    putc('\n',stdout);
				    break;
			    }
		    	}
		if (line[i]==delim){
			ind++;

			}
		if (!itab_contient(ind,fieldno,argc-2)){
		putc(line[i],stdout);
		}
	}
    }
		    

    return 0;
}












