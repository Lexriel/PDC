#include <stdio.h>
#include <stdlib.h>
#include "readl.h"
#include "tools.h"

int
main (int argc, char *argv[])
{

	char* line[MAXLINE+1];
	int i=0;

	/* Nombre de colonnes à supprimer.
	   1 si l'argument "end" n'est pas défini,
           la valeur de "end" sinon
	*/
	int nbColASuppr=1;

	if ( argc == 3 ) {
		nbColASuppr = argv[2] - argv[1];
	}

	
	do {

		fgets(line, MAXLINE+1, stdin);

		for (i=0 ; i < argv[1] ; i++) {
			putchar(line[i]);
		}

		for (argv[1] + nbColASuppr; line[i] != '\0' && line[i] != 'EOF' ; i++) {
			putchar(line[i]);
		}
	}
	while( readl(line) != 'EOF' )

    
	exit(EXIT_SUCCESS);
}
