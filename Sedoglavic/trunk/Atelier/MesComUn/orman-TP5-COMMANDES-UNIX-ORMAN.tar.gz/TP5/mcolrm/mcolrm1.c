#include <stdio.h>
#include <stdlib.h>
/*#include "readl.h"*/


#define MAXLINE 81

int main(int argc, char *argv[])
{
  printf("nombre total d'argument: %d\n",argc);
  char c,tab[MAXLINE];
  int i,j,k,cpt_col,colmin,colmax;
  k=j=i=cpt_col=0;
  colmax=*(argv+2);
  colmin=*(argv+1);

  for(i;i<argc;i++)
    {
      printf("argument %i : %s \n",i,argv[i]);
    }
  while ((c=getchar()) != EOF) 
    {
      tab[k]=c;
      cpt_col++;
      k++;
    }
  printf("je vais afficher les %d premiers caracteres.\n",colmax);
  
  
  switch(argc)
    {
    case '2':
      break;
    case '3':
      
      for(j=0;j<=colmin;j++)
	{
	  printf("%c",tab[j]);
	}
    for(j=colmax;j<=cpt_col;j++)
      {
        printf("%c",tab[j]);
      }
    
    break;
    
    }
  
  printf("\nvotre fichier possede %d colonnes \n ",cpt_col);
  
  
}
