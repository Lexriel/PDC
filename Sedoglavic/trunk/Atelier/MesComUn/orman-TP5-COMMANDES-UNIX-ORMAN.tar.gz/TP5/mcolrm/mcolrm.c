#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *argv[])
{
  int cptCol,debut,end;
  char c;
  
  switch(argc)
    {
    case 1:
      fprintf(stderr,"Vous devez specifier au moins un numero de colonne a effacer !\n");   
      break;
      
      
      /* Si argc vaut , on doit supprimer la colonne dont le numero correspond a l'argument*/      
    case 2: 
      end = atoi(*(argv+1));
      cptCol = 0;
      while((c = getchar())!= EOF)
	{
	  if(c=='\n')
	    
	    {
	      cptCol=0;
	    }
	  else
	    {
	      cptCol++;
	      if(cptCol != end)
		{
		  putchar(c);
		}
	    }
	}     
      break;
      /*
	Si argc vaut trois, on doit effacer les colonnes comprises entre debut et fin qui sont respectivement l'argument 1 et l'argument 2, l'argument 0 etant le nom de la commande
	
	On affecte a debut et a end leur valeur, si la valeur de fin est superieur a la valeur de debut, on retourne un message d'erreur informant l'utilisateur qu'il a sans nul doute inverse les numeros de colonnes a effacer.
	
	sinon on initialise le compteur de colonne a 0, tant que l'on a pas atteint la fin du fichier, si on lit le caractere de retour a la ligne, on  remet le compteur de colonne a 0 sinon on increment le compteur de colonne et si sa valeur est inferieur a la colonne de debut d'effacement ou superieur a la valeur de fin d'effacement, on place le caractere dans le fichier de sortie
      */      
    case 3:   
      debut = atoi(*(argv+1));
      end = atoi(*(argv+2));
      if(debut<end)
	{
	  cptCol = 0;
	  while((c = getchar())!= EOF)
	    {
	      if(c=='\n')
		{
		  cptCol=0;
		}
	      else
		{ 
		  cptCol++;
		  if(cptCol < debut || cptCol > end)
		    { 
		      putchar(c);
		      
		    }
		  
		}
	    }
	}
      else
	{
	  fprintf(stderr,"Vous avez surement inverse la colonne de debut avec la colonne de fin\n");
	}
      
      break;
      
      /*Dans tous les autres cas, on affiche un message d'erreur*/
    default:
      
      printf("Erreur pendant le traitement du fichier, verifiez votre syntaxe\n");
      break;
    }
  
  exit(EXIT_SUCCESS);
}

