#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXLINE 81

int main(int argv, char *argc[])
{

  char s[MAXLINE];/*contient la chaine que l'on va lire sur l'entree standard*/
  char * word;/* contient le mot qui doit etre contenu dans la phrase poru etre afficher*/
  word=*(argc+1);

  /*tant que l'on recupere des lignes, si la ligne contient le mot word, on l'affiche, sinon on ne fait rien*/
  while(fgets(s, MAXLINE, stdin))
    {
      if(strstr(s, word) != NULL)
	{
	  printf("%s",s);
	  
	}
    }
exit(EXIT_SUCCESS);
}
