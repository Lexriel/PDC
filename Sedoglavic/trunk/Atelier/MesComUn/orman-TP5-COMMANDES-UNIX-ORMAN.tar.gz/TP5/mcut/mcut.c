#include <stdio.h>
#include <stdlib.h>



#define MAXLINE 81

int main(int argc, char *argv[])
{
  printf("nombre total d'argument: %d\n",argc);
  char c;/*le caractere qu'on va lire via getchar*/

  char delimiteur;/* le caractere qui va delimiter les chaines*/
  int cpt_col,compteur,i,j;/*le compteur de colonne ainsi que des variables utilisees pour le parcours des boucles*/
  int colonne[argc-2];/*tableau qui contiendra les numeros de colonne a afficher*/
  int colonne_act;
int parcours_colonne;
 compteur=2;/* permet de demarrer a partir du premier fieldno*/
 j=i=cpt_col=parcours_colonne=0; /* j et i servent juste pour des boucles, parcours_colonne ne sert qu'a la fin pour les test*/
 delimiteur=*argv[1];/* on recupere le caractere qui delimite*/
 colonne_act=1; /*de base, on se trouve dans la colonne 1 */
  


/* recupere  la liste des numeros de colonne*/
  for(j=0;j<argc-2;j++)
    {
      colonne[j]=atoi(*(argv+compteur));
      compteur++;
    }
  


/*
On lit l'integralite du fichier sur l'entree standard. On démarre à la colonne 1, si le premier fieldno demande est la colonne 1, alors on place le caractere que l'on a lu dans le fichier de sortie.
Si c atteint la valeur du délimiteur, on incrémente la colonne courante et l'indice du tableau contenant la liste des colonnes a afficher.
*/


   while ((c=getchar()) != EOF) 
    {
      
        if(colonne_act==colonne[parcours_colonne])
	  {
	  putchar(c);
	}
  
      if(c==delimiteur)
	{
	  colonne_act++;
	  parcours_colonne++;
	  
	}
    }
exit(EXIT_SUCCESS);
}
