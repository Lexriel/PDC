#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXLINE 81

int main(int argv, char *argc[])
{

  char s[MAXLINE];/*contient la ligne courante*/
  char * word;/*contient le mot par lequelle doit commencer*/
  int compteur;/*variable utlise pour la boucle for*/
  int affiche;/*variable utilise pour savoir si on doit ou non afficher la ligne*/
  word=*(argc+1);

  /*
    tant qu'on lit le fichier, on effectue une boucle dont les actions seront effectuees pour une taille egale a la taille de word -1. Si la phrase commence par word, on l'affiche,sinon on ne l'affiche pas.
*/
  while(fgets(s, MAXLINE, stdin))
    {
      for(compteur=0;compteur<(sizeof(word)-1);compteur++)
	{
	  if(word[compteur]!=s[compteur])
	    {
	      affiche=0;
	    }
	  else
	    {
	      affiche=1;
	    }
	    
	}
      if(affiche==1)
	{
	  fprintf(stdout,s);
	}
      
    }
exit(EXIT_SUCCESS);
}
