#include "readl.h"

int readl(char line[])
{
	/** On lit sur l'entree standard une chaine de MAXLINE caract�res que l'on met dans " chaine" **/
	if (fgets (line ,MAXLINE , stdin)!=NULL)
		return 1;
	else
		return 0;
}
