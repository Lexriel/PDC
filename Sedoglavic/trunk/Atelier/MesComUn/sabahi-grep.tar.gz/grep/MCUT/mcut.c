#include <stdio.h>
#include <stdlib.h>
#include "readl.h"


int main(int argc, char **argv) {

  char ligne[MAXLINE];
  char delim;
  int i = 0, deb = 0, fin = 0, field = 0;
  
  if(argc < 3) {
    printf("Error argument\n");
    exit(EXIT_FAILURE);
  }

  readl(ligne);

  delim = (*argv[1]);
  deb = (int) (*argv[2] - '0');

  if(argc == 4) {
    fin = (int) (*argv[3] - '0');
  } else {
    fin = deb;
  }

  /* On parcours la chaine */
  while(ligne[i] != '\0') {

    if(ligne[i] == delim) {
      field++;
    }

    if(field >= deb && field <= fin)
      printf("%c", ligne[i]);
    i++;
  }

  printf("\n");
  exit(EXIT_SUCCESS);
}

