#include "readl.h"

int main(int argc, char *argv[])
{
  int cpt,rep;
  char line[MAXLINE] ;
  if (argc!= 2)
    {
      fprintf(stderr,"Usage: %s word\n",argv[0]);
      exit(EXIT_FAILURE);
    }
  else
    {
      cpt=0;/** Initialisation du compteur de ligne **/
      rep= readl(line);
      while (rep)
	{
	  if (strstr(line, argv[1]) != NULL )
	    {
	      printf("%s", line);/** On imprime la chaine line sur la sortie standard  **/
	      cpt++;/** on incremente le compteur lorsqu'une ligne est trouvee  **/
	    }
	  rep= readl(line);/** lecture d'une ligne **/
	}
      if (cpt>0)/** On a trouve au moins une ligne **/
	exit(EXIT_SUCCESS);
      else /** Aucune ligne trouvee ou autre probleme **/
	{
	  fprintf(stderr,"Pas de ligne trouvee\n");
	  exit(EXIT_FAILURE);
	}
    }
}
