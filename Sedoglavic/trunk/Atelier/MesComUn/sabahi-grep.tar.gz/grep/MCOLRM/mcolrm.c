#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TOUT_EST_OK 1
#define ERREUR_NB_PARAM -1
#define ERREUR_SUR_PARAM -2
#define MAXLINE 80

int main(int argc, char **argv )
{
  int c,col,begin,end;
 
      switch(argc) 
	{
	case 1: /** Pas de parametres **/
	  fprintf(stderr,"******* Attention, vous n'avez donne aucun parametre! *******\n");
	  fprintf(stderr,"******* Le texte reste inchange! ****************************\n\n");
	  end= MAXLINE;
	  while(((c=getchar())!=EOF) && (end>=0))
	    {
	      if ((end == 0) && (c!='\n'))
		while((c=getchar())!='\n');
	      /*tant qu'on est pas à la fin de la ligne, on lit le caractere et on ne fait rien*/
	      if ((c=='\n'))
		 end= MAXLINE+1;
	      putchar(c);
	      end--;
	    }
	  break;
	case 2: /** Un seul parametre **/
		end=atoi(argv[1]);
		if ((end <= MAXLINE) && (end>0))
		{
		  col=0;      
		  while((c=getchar())!=EOF )
		    {
		      col++;
		      if ((col>=end) && (c!='\n'))
			{
			  col=0;
			  while((c=getchar()) != '\n');
			}
			if ((col!=end) && (c=='\n'))
			  col=0;
			if (c=='\t')
			  col +=7;
			putchar(c);
		    }
		}
		else
		  {
		    fprintf(stderr,"Le premier parametre doit etre dans l'intervalle [0-%d]!\n",MAXLINE);
		    return ERREUR_SUR_PARAM;
		  }
		break;
	case 3:/** Deux parametre **/
	  begin=atoi(argv[1]); 
	  end=atoi(argv[2]);  
	  if ((begin > end) || (begin > MAXLINE)|| (begin <= 0) || (end > MAXLINE) ||(end <= 0))
	    {
	      fprintf(stderr,"Erreur sur parametre!\n");
	      return ERREUR_SUR_PARAM; 
	    }
	  else                      
	    {
	      col=0;
	      while((c=getchar())!=EOF )
		{
		  col++;
		  if (c=='\n')
		    col=0;
		  if (col<begin) 
		    putchar(c);
		  if (col>end)
		    putchar(c);
		}
	    }
	  break;
  	default:/**Mauvais nombre d'arguments**/
    	{
	  fprintf(stderr,"Usage: %s col [end]\n",argv[0]);
	  return ERREUR_NB_PARAM;
    	}
 
	}
      return TOUT_EST_OK;
}
