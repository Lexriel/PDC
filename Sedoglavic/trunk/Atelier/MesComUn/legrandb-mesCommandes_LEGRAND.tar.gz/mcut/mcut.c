/*********************************************/
/*                                          **
 * Author: Baptiste LEGRAND & Benjamin ORMAN *
 * @contact: legrand.baptiste@gmail.com      *
 **                                         **/
/*********************************************/
#include <stdio.h>
#include <stdlib.h>


#define MAXLINE 81

int main(int argc, char *argv[])
{
  /* c : Le caractere qui sera lu par la methode getchar() */
  char c;
  /* delimiteur :Le delimiteur qui sera recuperer lors de l'appel de
     la fonction principale */
  char delimiteur;
  /* cpt_col : Le compteur de colonne. Initialiser a 0*/
  /* compteur,i ,j :Des compteurs comme les autres. Initialiser a 0*/
  int cpt_col,compteur,i,j;
  /* colonne[] : tableau d'entier qui contiendra les numeros de
     colonne a afficher*/
  int colonne[argc-2];
  /* colonne_act : Entier designant le numeros de la colonne
     actuelle. Initialiser a 1*/
  int colonne_act;
  /* parcours_colonne : L'indice du tableau qui contient les differents numeros de
     colonnes a ne pas afficher*/ 
  int parcours_colonne;
  compteur=2;/* permet de demarrer a partir du premier fieldno*/
  j=i=cpt_col=parcours_colonne=0; /* j et i servent juste pour des
				     boucles*/
  delimiteur=*argv[1];/* on recupere le caractere qui delimite*/
  colonne_act=1; /*de base, on se trouve dans la colonne 1 */

  /*On chercher a recuperer la liste des numeros de colonne a
    afficher. Ces numeros sont envoyer lors de l'appel de la fonction
    principale*/
  for(j=0;j<argc-2;j++)
    {
      colonne[j]=atoi(*(argv+compteur));
      compteur++;
    }

  /* On effectue le traitement sur le flux entrant temps qu'on est pas
     � la fin du fichier*/
   while ((c=getchar()) != EOF) 
    {
      if(colonne_act==colonne[parcours_colonne])
	  {
	  putchar(c);
	}
  
      if(c==delimiteur)
	{
	  colonne_act++;
	  parcours_colonne++;
	  
	}
    }
exit(EXIT_SUCCESS);
}
