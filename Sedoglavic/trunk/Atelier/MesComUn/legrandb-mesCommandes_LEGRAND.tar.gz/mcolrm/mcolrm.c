/*********************************************/
/*                                          **
 * Author: Baptiste LEGRAND		     *
 * @contact: legrand.baptiste@gmail.com      *
 **                                         **/
/*********************************************/

#include <stdio.h>
#include <stdlib.h>
/*#include "readl.h"*/

int main(int argv, char *argc[])
{
  int compteurColonne;
  char caractereLu;

  int colonneDebut;
  int colonneFin;

  typedef  enum TypeColrm TypeColrm;
  enum TypeColrm {
    JUSQUA,
    ENTRE,
    ERROR
  };
  
  TypeColrm monColrm = JUSQUA;
  /*On definit le type de colrm en fonction du nombre d'argument lors
    de l'appel de la methode main */
  switch(argv)
    {
      
    case 1:
      /*le premier argument est toujours le nom de la fonction appele
	dans notre cas mcolrm*/
      monColrm = ERROR;
      break;
    case 2: colonneFin = atoi(*(argc+1));
      /*Si il n'y a que deux (2) arguments alors cela signifie que le
	second argument est la numeros de la colonne ou lon souhaite
	garder le texte. Tous le reste sera supprimee. monColrm passe
	alors dans l'etat qui lui permetrat deffectuer ce traitement*/
      monColrm = JUSQUA;
      break;
    case 3:
       /*Si il y a trois (3) arguments alors cela signifie que
	 l'utilitaire devra supprimer les colonnes se trouvrant entre
	 la valeur du second parametre et la valeur du troisieme
	 parametre. On effectuera plus tard les test concernant l'arite
	 et la valeur de ces deux valeurs. monColrm passe alors dans
	 l'etat qui lui permetrat deffectuer ce traitement*/
      colonneDebut = atoi(*(argc+1));
      colonneFin = atoi(*(argc+2));
      (colonneDebut < colonneFin)?(monColrm = ENTRE):(monColrm = ERROR);
	break;
    default:
        /*Si il y a plus de trois (3) arguments alors on envoi chier
	  l'utilisateur*/
      printf("Erreur pendant le traitement du fichier");
      break;
    }
  /* On parcourt l'ensemble du fichier temps qu'on ne rencontre pas de
     symbole de fin fichier*/
  compteurColonne = 0;
  while((caractereLu = getchar())!= EOF)
    {
      /*On incremente le nombre de colonne lue au fur et a mesure
	qu'on lit le fichier. Si on tombe sur un retour a la ligne
	alors on remet se nombre a 0*/
      if(caractereLu=='\n')
	compteurColonne=0;
      else
	compteurColonne++;
      /* On effectue un traitement different suivant l'etat de
	 l'automate definissant monColrm*/
      switch(monColrm)
	{
	case ENTRE:
	  if(compteurColonne < colonneDebut || compteurColonne > colonneFin)
	    putchar(caractereLu);
	  break;

	case JUSQUA:
	  if(compteurColonne < colonneFin)
	    putchar(caractereLu);
	  break;
	case ERROR:
	  break;
	}
    }
  return 1;
}
