/*********************************************/
/*                                          **
 * Author: Baptiste LEGRAND                  *
 * @contact: legrand.baptiste@gmail.com      *
 **                                         **/
/*********************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXLIGNE 81

char ligne[MAXLIGNE];

void initialisationLigne()
{
  int i;
  for (i=0; i<MAXLIGNE; i++)
    *(ligne+i) = ' ';
}

int main(int argc, char ** argv)
{
  /* Fichier : pointe vers un fichier passer en parametre lors de
     l'appel du main. Initialiser a null */
  FILE* fichier = NULL;
  
  /* firstWord: va servir de pointeur de tableau contenant le mot a
     chercher en premiere position. Initialiser a null*/
  char* firstWord = NULL;

   /* Avant toute chose on initialise le tableau qui va contenir la
     phrase lu */
  initialisationLigne();

  /* Si on le nombre d'information lors de lappel de la commande est
     inferieur ou egal a 2 alors ça signifie qu'on a pas indiquer le
     fichier a ouvrir */
  if(argc == 3){
    /* On stocke le mot a cherche passe en parametre lors de l'appel
       de la fonction principale*/
    firstWord = argv[1];
    fichier = fopen(argv[2], "r+");
    /* Si l'ouverture de fichier a reussi alors on peut lire le
       contenu du fichier*/
    if (fichier != NULL)
      {
	/*On lit le fichier tant qu'on ne recoit pas d'erreur*/
	while (fgets(ligne, MAXLIGNE, fichier) != NULL) 
        {
	  if((strstr(ligne,firstWord ) != NULL) )
	    printf("%s", ligne);       
	}

	/* Enfin on ferme le fichier */
	fclose(fichier);
       }
    else
      {
	/* On affiche un message d'erreur si l'ouverture a echoue */
        fprintf(stderr,"Impossible d'ouvrir le fichier demande \n");
      }
    
    /* IMPORTANT : On libere la memoire contenant le mot a chercher
       dans en premiere position */
  }
  else
    {
      fprintf(stderr, "Erreur, Arguments insuffisants");
      return -1;
    }
  return 0;
}
