/* termine l'execution du programme sur une erreur fatale */
extern void fatal(int assert, const char *message, int status);

/* recupere le parametre passée initialement au programme a la position n */
extern char* getParam(int argc, char **argv, int pos);

/* initilisation d'une chaine de caractere */
extern void initChaine(char* chaine, int size);
