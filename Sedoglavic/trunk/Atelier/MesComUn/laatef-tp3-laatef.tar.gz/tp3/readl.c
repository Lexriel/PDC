#include "readl.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tool.h"

int readl(char line[]){
  char c;
  int i = 0;

  while(1){
    c = getchar();

    if(i > MAXLINE){
      fatal(0,"ligne superieur a 80 caracteres\n",EXIT_FAILURE);
    }
    if(c == '\n'){
      line[i] = '\0';
      return i;
    }else
      if(c == EOF){
	line[i] = '\0';
	return EOF;
      }else
	line[i] = c;
    i++;
  }

  return i;
}
