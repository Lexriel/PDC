#include <stdio.h>

char* getParam(int argc, char **argv,int pos){

  if(argc >= pos)
    return argv[pos];
  return NULL;
}
