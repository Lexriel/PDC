#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"
#include "tool.h"

int main(int argc, char **argv){
  
  char* motFiltre = getParam(argc,argv,1);
  char ligne[MAXLINE+1];
  int longueurChaine;

  initChaine(ligne,MAXLINE+1);
 
  while(1){
    longueurChaine = readl(ligne);
    
    if(strstr(ligne,motFiltre) != NULL)
      fprintf(stdout,"%s\n",ligne);
    if(longueurChaine == EOF){
      break;
    }
  }
  return 0;
}
