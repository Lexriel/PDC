#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"
#include "tool.h"

int main(int argc, char **argv){
  
  int col = atoi(getParam(argc,argv,1));
  int end;
  char ligne[MAXLINE+1];
  int longueurChaine,i;
	  
  if(argc > 2)
    end = atoi(getParam(argc,argv,2));
  else
    end = -1;
  
  initChaine(ligne,MAXLINE+1);

  if((col < 1 || col > end) && end != -1){
    fprintf(stderr,"probleme avec les arguments\n");
    exit(EXIT_FAILURE);
  }
  col--; 
 
  while(1){

    longueurChaine = readl(ligne);  
    if(end == -1){
      for(i=0;i<col;i++){
	putchar(ligne[i]);
      }
      putchar('\n');
    }else{
       for(i=0;i<col;i++){
	 putchar(ligne[i]);
       }
       for(i=end;i<strlen(ligne);i++){
	 putchar(ligne[i]);
       }
       putchar('\n');
    }

    if(longueurChaine == EOF){
      break;
    }
  }
  return 0;
}
