#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"
#include "tool.h"

int main(int argc, char **argv){
  
  char* delim = getParam(argc,argv,1);
  int fieldno, cpt;
  char ligne[MAXLINE+1];
  int longueurChaine,size,i;
  char lim;

  if(delim[0] == '\''){
    lim = delim[1];
  }
  else
    lim = delim[0];

  if(argc > 2)
    fieldno = atoi(getParam(argc,argv,2));
  else
    fieldno = -1;
  

  initChaine(ligne,MAXLINE+1);

  if(fieldno < 1){
    fprintf(stderr,"numero du champ superieur a 0\n");
    exit(EXIT_FAILURE);
  } 
 
  while(1){
    cpt = 1;
    longueurChaine = readl(ligne);  
    size = strlen(ligne);
    for(i = 0; i < size ; i++){
      if(ligne[i] == lim)
	cpt++;
      if(cpt == fieldno && ligne[i] != lim)
	putchar(ligne[i]);
    }
    putchar('\n');
    if(longueurChaine == EOF){
      break;
    }
  }
  return 0;
}
