void initChaine(char* chaine, int size){

  int i;
  for(i = 0; i < size; i++){
    chaine[i]='\0';
  }
}
