#include <stdio.h>
#include <stdlib.h>

void fatal(int assert, const char *msg, int status){
  
  fprintf(stderr,msg);
  exit(status);
}
