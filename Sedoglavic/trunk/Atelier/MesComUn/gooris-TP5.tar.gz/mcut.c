#include "readl.h" 

int main(int argc, char *argv[])
{
	char phrase[MAXLINE+1];
	char tmp[MAXLINE+1];
	int nb_car;
	int i,j,k;
	char delim;
	int nb_zone = 0;
	int cpt;

	if (argc <= 2) {
		fprintf(stderr,"Manque d'arguments\n");
		exit(EXIT_FAILURE);
	} 

	else {	k = 0;
		delim = argv[1][0];
		
		while (nb_car = readl(phrase)) {
			for (j = 2; j < argc;j++) {
				nb_zone = atoi(argv[j]);
				cpt = 0; 
			
				for (i = 0; i<strlen(phrase);i++) {
					if (phrase[i] != delim) {
						if  (nb_zone == (cpt+1)){
							tmp[k] = phrase[i];
							k++;
						} else {; }
					} else { 
						cpt ++;
						}
				tmp[k] = '\0';
				}
		 }

		 printf("Phrase obtenue : %s \n",tmp); k = 0;
		 if (nb_car == EOF) break;
		 }
          return 0; 
	}
}


