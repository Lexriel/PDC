#include "readl.h" 

int main(int argc, char *argv[])
{
	char phrase[MAXLINE+1];
	char tmp[MAXLINE+1];
	int nb_car;
	int i,j;

	if (argc == 1 || argc > 3) {
		fprintf(stderr,"Manque d'arguments (ou trop)\n");
		exit(EXIT_FAILURE);
	} 

	else if (argc == 2) {
		while (nb_car = readl(phrase)) {
			for (i = 0; i<(atoi(argv[1])-1);i++) {
				tmp[i] = phrase[i];
			}
			tmp[(atoi(argv[1])-1)] = '\0';

			printf("Phrase obtenue : %s \n",tmp);
			i = 0;
			
			if (nb_car == EOF) break;
		}
	return 0;
	} else {
		while (nb_car = readl(phrase)) {
		
			for (i = 0; i<(atoi(argv[1])-1);i++) {
				tmp[i] = phrase[i];
			}

			for (j = atoi(argv[2]); j<=nb_car;j++,i++) {
				tmp[i] = phrase[j];
			}

		printf("Phrase obtenue : %s \n",tmp);
		i,j = 0;
		
			if (nb_car == EOF) break;
		}

	return 0;
}
}
