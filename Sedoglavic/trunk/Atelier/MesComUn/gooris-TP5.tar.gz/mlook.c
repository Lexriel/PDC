#include "readl.h" 

int main(int argc, char *argv[])
{
	char phrase[MAXLINE+1];
	char tmp[MAXLINE+1];
	char mot[20];
	int nb_car;
	int i,j;

	if (argc != 2) {
		fprintf(stderr,"Manque d'arguments (ou trop)\n");
		exit(EXIT_FAILURE);
	} 

	else { 
		j = 0; i = 0;
		while (argv[1][j] != '\0') {
			mot[j] = argv[1][j];
			j++;
		}
		mot[j] = '\0';

		while (nb_car = readl(phrase)) {

			if (nb_car < strlen(mot)) {
				;
			} else {
				while (i< strlen(mot) && (mot[i] == phrase[i])) {
					i++;
				} 
	
			if (i == strlen(mot)) {
				printf("Phrase obtenue : %s \n",phrase);
				i = 0;
			} else {
					;
				}
			}
		
		if (nb_car == EOF) { break;} 
		}
	}
return 0;
}
