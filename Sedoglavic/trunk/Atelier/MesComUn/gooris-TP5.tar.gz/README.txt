Bonjour!

Ci joint, les 4 commandes unix et le Makefile.
Chaque commande fonctionne correctement en principe.

Cordialement, Adrien.