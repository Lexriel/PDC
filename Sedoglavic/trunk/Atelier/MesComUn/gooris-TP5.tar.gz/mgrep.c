#include "readl.h" 

int main(int argc, char *argv[])
{
	char phrase[MAXLINE+1];
	char tmp[MAXLINE+1];
	char mot[20];
	int nb_car;
	int i,j,k,cpt;

	if (argc != 2) {
		fprintf(stderr,"Manque d'arguments (ou trop)\n");
		exit(EXIT_FAILURE);
	} 

	else {	
		j = 0; i = 0; cpt = 0; k = 0;

		while (argv[1][j] != '\0') {
			mot[j] = argv[1][j];
			j++;
		}
		mot[j] = '\0';
		
		while (nb_car = readl(phrase)) {
			if (strstr(phrase,mot)) { 
				for (i = 0; i < strlen(phrase) ; i++) { 
					if (phrase[i] == mot[k]) {
						cpt++;
						k++;
					if (cpt == strlen(mot)) { 
						break;
					}
					} else {
						cpt = 0;
						k = 0;
					}
				}
			}
		if (cpt == strlen(mot)) {
			printf("Ligne retenue : %s \n", phrase);
			cpt = 0; j = 0; k = 0;
		}
		if (nb_car == EOF) break;
		}
	}
return 0;
}
