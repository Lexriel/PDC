#define MAXLINE  80

/* Lit dans line une ligne sur l'entree standard.

   Cette ligne doit contenir au plus MAXLINE caracteres.
   Un '\0' est écrit en fin de la chaine. 
   Le tableau line doit contenir au moins MAXLINE+1 caracteres.
   Retourne le nombre de caracteres lus, non compris le \0 final, EOF
   si la fin de fichier est atteinte sur l'entree standard.
   Termine le programme sur une erreur si rencontre une ligne de plus
   de MAXLINE caracteres. 
*/
extern int readl(char line[]);
