#include <stdio.h>
#include <stdlib.h>
#include "readl.h"


int main(int argc, char *argv[]) {

 char line[MAXLINE+1];
 int i=0, col=0, end=0, dif=0, foe=0;

 readl(line);


 while(line[i] != '\0' && i<=MAXLINE+1){
     foe=line[i++];
   }

 if(argc == 1){ 
   col=(int) argv[1];

   for(i=col;i<foe;i++){
     line[i]=line[i+1];
   }

 }else
     if(argc == 2){
       col=(int) argv[1];
       end=(int) argv[2];
       dif=end-col;

	  for(i=col;i+dif<=foe;i++){
     	    line[i]=line[i+dif];
   	  }

	}else{ /*fatal*/ }
   

  exit(EXIT_SUCCESS);
}

