#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readl.h"


int readl(char line[]){

	/* char * fgets(char * line[], int MAXLINE, FILE * stdin); */

	return strlen( fgets(line, MAXLINE, stdin) ) -1 ;
}

/*
int 
main()
{

char line[MAXLINE];

printf( "%d\n", readl(line) );

exit(EXIT_SUCCESS);
}
*/


