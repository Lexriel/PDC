#include <stdio.h>
#include <stdlib.h>
#include "readl.h"

int main (int argc, char *argv[])
{
  int i;
  int arg1;
  int arg2;
  int nb_char_line;
  char line[2*MAXLINE];
  
  /*obligation de tester le nombre d'argument*/
  if(argc>3){
    fprintf(stderr,"usage: mcolrm [start [stop]]\n");
    exit(EXIT_FAILURE);
  }
 
  /*tranformation des arguments en int*/
  if(argc==1){
    arg1=MAXLINE-1;
  }else{
    arg1=atoi(argv[1]);
  }
  /*test du arg 1 si egale 0*/
  if(arg1==0){
    fprintf(stderr,"mcolrm: illegal column -- 0\n");
    exit(EXIT_FAILURE);
  }
  /*test l'agument 2*/
  if(argc<3){
    arg2=MAXLINE;
  }else{
    arg2=atoi(argv[2]);
  }
 
  /*test des arguments coherents*/
  if(arg1>arg2){
    fprintf(stderr,"mcolrm: illegal start and stop columns\n");
    exit(EXIT_FAILURE);
  }
 
  /*test des arguments transformer en int*/
  
  fprintf(stderr,"arg1 %d\n",arg1);
  fprintf(stderr,"arg2 %d\n",arg2);
  
  
  fprintf(stderr, "   argc = %d\n", argc);
  
  for (i=0; i<argc ; i++) {
    fprintf(stderr, "argv[%d] = %s\n", i, argv[i]);
  }
  /*ecrire la ligne dans un tableau tant que le fichier n'est pas vide*/
  
  fprintf(stderr,"debut du traitement de mcolrm\n");
  
  /*manque une boucle pour tout le fichier*/
  while((fgets(line,2*MAXLINE,stdin))!=NULL){
    nb_char_line=readl(line);
    fprintf(stderr,"nb_char_line %d\n",nb_char_line);
    
    for(i=0;i<nb_char_line;i++){
      if(i<(arg1-1)){
	printf("%c",line[i]);
      }
      else if (i>(arg2-1)){
	printf("%c",line[i]);
      }
    }
    printf("\n");
  }
  fprintf(stderr,"fin du traitement de mcolrm \n");
  exit(EXIT_SUCCESS);
}

