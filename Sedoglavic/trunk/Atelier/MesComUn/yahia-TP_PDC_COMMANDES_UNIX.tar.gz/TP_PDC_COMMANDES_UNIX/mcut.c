#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "readl.h"

void table_trier(int table[], int n)
{
  int i, tmp, permutation = 1;
  while (permutation == 1){
    permutation = 0;
    for (i=0; i<n-1; i++)
      if (table[i] > table[i+1]){
	tmp = table[i];
	table[i] = table[i+1];
	table[i+1] = tmp;
	/* Il y a eu permutation */
	permutation = 1;
      } /* if */
  } /* while */
}



int main (int argc, char *argv[])
{
#define MAXARGC 20
  int i,j,f;
  char *arg1;
  int cpt_ligne;
  int nb_char_line=0;
  char line[2*MAXLINE];
  int tab_argc[MAXARGC];
  int nb_argc=0;
  
  if(argc==1){
    fprintf(stderr,"mcut : UN DELIMITEUR ILLIGAL\n");
    exit(EXIT_FAILURE);
  }
  /*affichage du nombre d'argument*/
  fprintf(stderr, "   argc = %d\n", argc);
  /*voir s'il y a trop d'argument*/
  if(argc>(MAXARGC+2)){
    fprintf(stderr,"VOUS AVEZ ENTRE trop d'arguments");
    exit(EXIT_FAILURE);
  }
 
  for (i=0; i<argc ; i++) {
    fprintf(stderr, "argv[%d] = %s\n", i, argv[i]);
    if(i==1){
      arg1=argv[i];
    }
    if(i>1){
      tab_argc[i-2]=atoi(argv[i]);
      fprintf(stderr,"tab_arg[%d] %d\n",i-2,tab_argc[i-2]);
      if(tab_argc[i-2]==0){
	fprintf(stderr,"attention mauvais argument pour les colonnes\n");
	exit(EXIT_FAILURE);
      }
    }
  }
  fprintf(stderr,"delim : %s\n",arg1);
  nb_argc=argc-2;
  fprintf(stderr,"nombre de colonne a affiche : %d\n",nb_argc);
  if(argc==2){
    fprintf(stderr,"attention pas de colonne selectionne\n");
    exit(EXIT_SUCCESS);
  }
  table_trier(tab_argc,nb_argc);
  for(i=0;i<nb_argc;i++){
    fprintf(stderr,"tab_argc[%d]=%d\n",i,tab_argc[i]);
  }
  cpt_ligne=1;
  
  fprintf(stderr,"debut du traitement de mcut\n");

  /*traitement des arguments trie dans un tableau*/
  f=0;
  j=0;
  while((fgets(line,2*MAXLINE,stdin))!=NULL){
    nb_char_line=readl(line);
    fprintf(stderr,"nb_char_line %d\n",nb_char_line);
    if((strstr(line,arg1))!=NULL){
      f++;
      printf("on trouve une ligne");
      if(tab_argc[j]!=f){
	j++;
	for(i=0;i<nb_char_line;i++){
	printf("%c",line[i]);
	}
      }
      printf("\n");
    }
  }

  fprintf(stderr,"fin du traitement de mcut \n");
  exit(EXIT_SUCCESS);
}
