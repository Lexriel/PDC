#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "readl.h"

int main (int argc, char *argv[])
{
  char line[2*MAXLINE];
  int i;
  int nb_char_line;
  int nb_char_arg;
  char *tmp_comp;

  /*test du nombre d'argument*/
  if(argc>2){
    fprintf(stderr,"trop d'argument\n");
    exit(EXIT_FAILURE);
  }
  if(argc==1){
    fprintf(stderr,"usage: mgrep [-bdf] [-t char] string [file ...]\n");
    exit(EXIT_FAILURE);
  }
 
  fprintf(stderr,"debut du traitement de mgrep\n");
 
  nb_char_arg=readl(argv[1])+1;
  fprintf(stderr,"nb_char_arg %d\n",nb_char_arg);
 
  while((fgets(line,2*MAXLINE,stdin))!=NULL){
    nb_char_line=readl(line);
    tmp_comp=strstr(line,argv[1]);
    
    if(tmp_comp!=NULL){
      /* autre methode
	if(strncmp(argv[1],line,nb_char_arg)==0){
      */
      for(i=0;i<nb_char_line;i++){
	printf("%c",line[i]);
      }
    }
    printf("\n");
  }
  fprintf(stderr,"fin du traitement de mgrep \n");
  
  
  exit(EXIT_SUCCESS);
}
